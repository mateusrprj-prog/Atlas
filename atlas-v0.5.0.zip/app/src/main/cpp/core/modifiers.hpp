// Non-destructive modifier stack: pure functions that turn a base mesh into an evaluated mesh.
#pragma once
#include <algorithm>
#include <cmath>
#include <vector>
#include "mesh.hpp"

namespace atlas {

enum ModType { kMirror = 0, kArray = 1 };

struct Modifier {
    int type = kMirror;
    bool enabled = true;
    int axis = 0;              // mirror: 0 X, 1 Y, 2 Z (object-local plane through the origin)
    float merge = 0.001f;      // mirror: vertices this close to the plane are welded to their mirror image
    int count = 2;             // array: number of copies (1..64)
    float offset[3] = {1, 0, 0};  // array: constant offset between copies (local units)
};

inline const char* modifierName(int t) { return t == kArray ? "Array" : "Mirror"; }
inline bool validModifier(const Modifier& m) {
    if (m.type < 0 || m.type > 1 || m.axis < 0 || m.axis > 2 || m.count < 1 || m.count > 64) return false;
    if (!std::isfinite(m.merge) || m.merge < 0.f) return false;
    for (float o : m.offset) if (!std::isfinite(o)) return false;
    return true;
}

inline float& comp(Vec3& v, int a) { return a == 0 ? v.x : a == 1 ? v.y : v.z; }
inline float compOf(const Vec3& v, int a) { return a == 0 ? v.x : a == 1 ? v.y : v.z; }

// Mirror across the local plane. Vertices on the plane are shared; faces lying entirely on the plane are not duplicated.
inline Mesh applyMirror(const Mesh& in, const Modifier& md) {
    Mesh out = in; const int n = (int)in.v.size();
    std::vector<int> mi(n, -1);
    for (int i = 0; i < n; ++i) {
        if (std::fabs(compOf(in.v[i], md.axis)) <= md.merge) { mi[i] = i; continue; }
        Vec3 p = in.v[i]; comp(p, md.axis) = -comp(p, md.axis);
        mi[i] = (int)out.v.size(); out.v.push_back(p);
    }
    for (const auto& fc : in.f) {
        std::vector<int> r; bool same = true;
        for (size_t k = fc.size(); k-- > 0;) { r.push_back(mi[fc[k]]); if (mi[fc[k]] != fc[k]) same = false; }
        if (!same) out.f.push_back(r);
    }
    return out;
}
inline Mesh applyArray(const Mesh& in, const Modifier& md) {
    Mesh out = in; const int n = (int)in.v.size();
    for (int c = 1; c < md.count; ++c) {
        Vec3 d{md.offset[0] * c, md.offset[1] * c, md.offset[2] * c}; const int base = (int)out.v.size();
        for (int i = 0; i < n; ++i) out.v.push_back(in.v[i] + d);
        for (const auto& fc : in.f) { std::vector<int> g = fc; for (int& x : g) x += base; out.f.push_back(g); }
    }
    return out;
}
inline Mesh applyModifier(const Mesh& in, const Modifier& md) { return md.type == kArray ? applyArray(in, md) : applyMirror(in, md); }

inline bool anyEnabled(const std::vector<Modifier>& mods) { for (auto& m : mods) if (m.enabled) return true; return false; }

// Evaluates the stack top to bottom (disabled modifiers are skipped). Guards against absurd sizes.
inline Mesh evaluateStack(const Mesh& base, const std::vector<Modifier>& mods) {
    Mesh cur = base;
    for (const auto& m : mods) {
        if (!m.enabled) continue;
        if (cur.f.size() * (size_t)(m.type == kArray ? m.count : 2) > 4000000) break;
        cur = applyModifier(cur, m);
    }
    return cur;
}

}  // namespace atlas
