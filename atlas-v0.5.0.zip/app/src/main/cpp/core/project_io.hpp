// Versioned text project format with atomic save. v1 (cubes only, Y-up) is migrated on load; v2 has meshes; v3 adds modifier stacks.
#pragma once
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <set>
#include <string>
#include "scene.hpp"

namespace atlas {

constexpr int kProjectVersion = 3;

inline bool saveProject(const Scene& s, const std::string& path) {
    const std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp, std::ios::trunc);
        if (!f) return false;
        f << std::setprecision(9);
        f << "ATLAS " << kProjectVersion << "\nnext " << s.nextId << "\n";
        for (const auto& o : s.objects) {
            std::string nm = o.name.empty() ? "Object" : o.name;
            for (auto& c : nm) if (c == ' ' || c == '\t' || c == '\n') c = '_';
            f << "object " << o.id << " " << nm;
            for (int i = 0; i < 3; ++i) f << " " << o.pos[i];
            for (int i = 0; i < 3; ++i) f << " " << o.rot[i];
            for (int i = 0; i < 3; ++i) f << " " << o.scale[i];
            f << " " << o.mesh.v.size() << " " << o.mesh.f.size() << "\n";
            for (const auto& v : o.mesh.v) f << "v " << v.x << " " << v.y << " " << v.z << "\n";
            for (const auto& fc : o.mesh.f) { f << "f " << fc.size(); for (int i : fc) f << " " << i; f << "\n"; }
            f << "mods " << o.mods.size() << "\n";
            for (const auto& m : o.mods)
                f << "mod " << m.type << " " << (m.enabled ? 1 : 0) << " " << m.axis << " " << m.merge << " " << m.count << " "
                  << m.offset[0] << " " << m.offset[1] << " " << m.offset[2] << "\n";
        }
        f << "end\n"; f.flush();
        if (!f) { std::remove(tmp.c_str()); return false; }
    }
    return std::rename(tmp.c_str(), path.c_str()) == 0;
}

// Loads into `out` only if the whole file is valid; otherwise `out` is untouched.
inline bool loadProject(Scene& out, const std::string& path, std::string* err = nullptr) {
    auto fail = [&](const char* m) { if (err) *err = m; return false; };
    std::ifstream f(path);
    if (!f) return fail("cannot open file");
    std::string tag; int ver = 0;
    if (!(f >> tag >> ver) || tag != "ATLAS") return fail("not an Atlas project");
    if (ver < 1 || ver > kProjectVersion) return fail("unsupported project version");
    std::vector<Object> objs; uint32_t next = 1; bool ended = false; std::string w;
    std::set<uint32_t> ids;
    while (f >> w) {
        if (w == "next") { if (!(f >> next)) return fail("bad header"); }
        else if (w == "cube" && ver == 1) {  // v1: Y-up unit cube with half-extent 0.5*scale
            Object o; float p[3], sc[3];
            if (!(f >> o.id >> p[0] >> p[1] >> p[2] >> sc[0] >> sc[1] >> sc[2])) return fail("corrupt cube record");
            o.name = "Cube." + std::to_string(o.id); o.mesh = makeCube();
            o.pos[0] = p[0]; o.pos[1] = -p[2]; o.pos[2] = p[1];
            o.scale[0] = sc[0] * 0.5f; o.scale[1] = sc[2] * 0.5f; o.scale[2] = sc[1] * 0.5f;
            if (o.id == 0 || !ids.insert(o.id).second) return fail("bad object id");
            objs.push_back(std::move(o));
        } else if (w == "object" && ver >= 2) {
            Object o; size_t nv = 0, nf = 0;
            if (!(f >> o.id >> o.name)) return fail("corrupt object record");
            for (int i = 0; i < 3; ++i) f >> o.pos[i];
            for (int i = 0; i < 3; ++i) f >> o.rot[i];
            for (int i = 0; i < 3; ++i) f >> o.scale[i];
            if (!(f >> nv >> nf)) return fail("corrupt object record");
            if (o.id == 0 || !ids.insert(o.id).second) return fail("bad object id");
            if (nv > 10000000 || nf > 10000000) return fail("mesh too large");
            for (size_t i = 0; i < nv; ++i) {
                std::string t; Vec3 v;
                if (!(f >> t >> v.x >> v.y >> v.z) || t != "v") return fail("corrupt vertex");
                if (!std::isfinite(v.x) || !std::isfinite(v.y) || !std::isfinite(v.z)) return fail("bad vertex");
                o.mesh.v.push_back(v);
            }
            for (size_t i = 0; i < nf; ++i) {
                std::string t; size_t k = 0;
                if (!(f >> t >> k) || t != "f" || k < 3 || k > 4096) return fail("corrupt face");
                std::vector<int> fc(k);
                for (size_t j = 0; j < k; ++j) if (!(f >> fc[j])) return fail("corrupt face");
                o.mesh.f.push_back(std::move(fc));
            }
            if (!f || !validMesh(o.mesh)) return fail("invalid mesh");
            if (ver >= 3) {
                std::string t; size_t nm = 0;
                if (!(f >> t >> nm) || t != "mods" || nm > 16) return fail("corrupt modifier list");
                for (size_t i = 0; i < nm; ++i) {
                    Modifier m; int en = 1;
                    if (!(f >> t >> m.type >> en >> m.axis >> m.merge >> m.count >> m.offset[0] >> m.offset[1] >> m.offset[2]) || t != "mod")
                        return fail("corrupt modifier");
                    m.enabled = en != 0;
                    if (!validModifier(m)) return fail("invalid modifier");
                    o.mods.push_back(m);
                }
                o.modsRev = nextRev();
            }
            objs.push_back(std::move(o));
        } else if (w == "end") { ended = true; break; }
        else return fail("unknown record");
    }
    if (!ended) return fail("truncated file");
    uint32_t maxId = 0; for (auto& o : objs) { maxId = std::max(maxId, o.id); o.meshRev = nextRev(); }
    out.reset(); out.objects = std::move(objs); out.nextId = std::max(next, maxId + 1);
    return true;
}

}  // namespace atlas
