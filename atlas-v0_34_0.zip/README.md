# Atlas
Independent 3D creation app for Android (no Blender code). See FEATURES.md for per-feature status and
**ATLAS_HANDOFF.md for the full project context (read it first if you are an AI continuing this work).**

## Build
CI builds the APK (`.github/workflows/build.yml`) and runs the core tests first. Locally: `gradle :app:assembleDebug`.
Core tests (host, no Android needed): `sh tests/run_all.sh` runs everything (`test_scene`, `test_rig`, `test_rig_scene`, `test_import`, `test_autorig`); or one by one: `g++ -std=c++17 -Wall -Wextra -O1 tests/test_scene.cpp -o t && ./t` (do not commit the `t` binaries).

## Controls (landscape)
- Select tool: 1 finger orbit, 2 fingers pan, pinch zoom, tap selects (object, or vertex/edge/face in Edit Mode; tap again to deselect).
- Move/Rotate/Scale: 1 finger drag transforms the selection (X/Y/Z buttons constrain), 2 fingers orbit. Works on objects and on mesh selections.
- Modeling tab / Object Mode menu enters Edit Mode. Header buttons ● ╱ ▣ switch vertex / edge / face selection.
- Edit Mode: Triangulate/Poke Faces, Recalculate Normals, Select Boundary/Non-Manifold/Random, Box Select tool (▭), Proportional Editing (Properties). Mesh menu: Bevel Edges (Bevel Width field), Edge Slide (factor field, -1..1), Extrude (distance field in Properties), Inset Faces (amount field), Loop Cut (position field), Select Edge Loop, Subdivide, Merge at Center, Merge by Distance, Dissolve Edges, Dissolve Vertices, Dissolve Faces, Limited Dissolve (angle field), Fill, Bridge Edge Loops, Bevel Vertices (width field), Separate Selection, Flip Normals, Delete.

## Modifiers
Properties > Modifiers: `+ Mirror` / `+ Array` / `+ Subsurf` / `+ Solidify` / `+ Triangulate` / `+ Weld` / `+ Smooth` / `+ Simple Deform` / `+ Planar Decimate` / `+ Bevel`. Each card has On/Off, reorder, Apply (bakes into the mesh, Object Mode) and remove. Mirror: pick the axis. Array: count + offset X/Y/Z. Subsurf: levels 1-4. Solidify: thickness + offset In/Center/Out. Weld: distance. Smooth: factor + repeat. Simple Deform: Twist/Bend/Taper/Stretch, axis, angle or factor. Planar Decimate: angle limit.

## Object menu
Rename (or tap the name in Properties), Duplicate, Apply All Transforms, Apply Scale, Join, Separate Loose Parts, Origin to Geometry, Delete. Select > More / Less / Linked and Mesh > Merge by Distance work in Edit Mode.

## Rig (0.31.0 / 0.32.0)
Add > Armature creates an armature with one bone. Select it: Properties > Rig lists the bones (tap to select). + Bone, Extrude (new connected bone at the tip, length field), Delete, Mirror Bone / Mirror All (names `.L`<->`.R`), Reset Pose, Rename, Deform on/off, Parent / Connect, numeric Rest (head, tail, roll) and Pose (loc, rot, scale in the bone's own axes; Y = along the bone). To skin: select the mesh object > Properties > Rig > Bind to Armature… (automatic weights). In Edit Mode select vertices and use "Atribuir a osso…" to set weights. Unbind returns the mesh to its normal state.

## Import and Auto-Rig (0.33.0 / 0.34.0)
File > Import opens the system file picker for `.glb`, `.gltf` (embedded buffers only) and binary `.fbx`. Everything in the file becomes one mesh object (geometry only for now). Then Object > Auto-Rig Humanoid (or Properties > Rig) builds a 21-bone skeleton that fits the body and binds the mesh. The character must stand on Z, centred on X, with the arms away from the body.
