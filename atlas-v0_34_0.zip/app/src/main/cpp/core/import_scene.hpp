// Scene-level import and auto-rig (0.33.0 / 0.34.0). Object Mode only; each operation is undoable.
#pragma once
#include "autorig.hpp"
#include "import.hpp"
#include "rig_scene.hpp"

namespace atlas {

// Imports a GLB / glTF / FBX file as ONE mesh object (all parts merged, transforms baked). One undo step. Returns the new object id, 0 on failure
// (`msg` gets the reason or a summary).
inline uint32_t importModelToScene(Scene& s, const uint8_t* data, size_t n, const std::string& ext, const std::string& baseName, std::string* msg = nullptr) {
    if (s.editMode) { if (msg) *msg = "Import só no Object Mode"; return 0; }
    ImportResult r = importModel(data, n, ext);
    if (!r.ok) { if (msg) *msg = r.error; return 0; }
    Object o; o.id = s.nextId++; o.name = uniqueName(s, baseName.empty() ? "Imported" : baseName);
    o.mesh = std::move(r.mesh); o.meshRev = nextRev();
    if (msg) *msg = std::to_string(o.mesh.v.size()) + " vértices, " + std::to_string(o.mesh.f.size()) + " faces" + (r.skipped ? " (" + std::to_string(r.skipped) + " primitivas ignoradas)" : "");
    const uint32_t id = o.id; s.execute(std::make_unique<AddObjectCmd>(std::move(o))); return id;
}

// Auto-rig for the selected mesh: measures it in world space, adds an armature object (identity transform) and binds the mesh with automatic weights.
// Two undo steps (armature, then binding). The armature ends up selected. Returns its id, 0 on failure.
inline uint32_t autoRigSelected(Scene& s, std::string* msg = nullptr) {
    Object* m = s.find(s.selected);
    if (s.editMode || !m || m->isArmature || m->mesh.v.empty()) { if (msg) *msg = "Selecione uma malha no Object Mode"; return 0; }
    const uint32_t meshId = m->id; const std::string base = m->name;
    const Mat4 w = objectMatrix(*m); std::vector<Vec3> P; P.reserve(m->mesh.v.size());
    for (const Vec3& v : m->mesh.v) P.push_back(xfPoint(w, v));
    AutoRigReport rep = autoRigHumanoid(P);
    if (!rep.ok) { if (msg) *msg = rep.error; return 0; }
    Object a; a.id = s.nextId++; a.name = uniqueName(s, base + "_Rig"); a.isArmature = true; a.arm = rep.arm; a.activeBone = 0; a.meshRev = nextRev();
    const uint32_t armId = a.id; s.execute(std::make_unique<AddObjectCmd>(std::move(a)));
    s.selected = meshId;
    if (!bindMeshToArmature(s, armId)) {
        s.undo();   // roll the armature back: nothing half-done
        s.selected = meshId; if (msg) *msg = "não consegui ligar a malha ao esqueleto"; return 0;
    }
    s.selected = armId;
    if (msg) *msg = std::to_string(rep.arm.bones.size()) + " ossos criados e malha ligada" + (rep.notes.empty() ? "" : " — " + rep.notes);
    return armId;
}

}  // namespace atlas
