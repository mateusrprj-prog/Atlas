// Import tests (0.33.0). g++ -std=c++17 -Wall -Wextra -O1 tests/test_import.cpp -o t_imp && ./t_imp
#include <cassert>
#include <cstdio>
#include <cstring>
#include "../app/src/main/cpp/core/import.hpp"
using namespace atlas;
static bool nr(float a, float b, float e = 1e-4f) { return std::fabs(a - b) < e; }

static void put32(std::vector<uint8_t>& b, uint32_t v) { for (int i = 0; i < 4; ++i) b.push_back((uint8_t)(v >> (8 * i))); }
static void put64(std::vector<uint8_t>& b, uint64_t v) { for (int i = 0; i < 8; ++i) b.push_back((uint8_t)(v >> (8 * i))); }
static std::vector<uint8_t> hex(const char* s) { std::vector<uint8_t> o; for (; s[0] && s[1]; s += 2) { unsigned v; sscanf(s, "%2x", &v); o.push_back((uint8_t)v); } return o; }

// ---------------------------------------------------------------- GLB builder: one triangle strip-free quad = 2 triangles, node translated
static std::vector<uint8_t> makeGlb(const std::string& jsonTail, const std::vector<uint8_t>& bin, bool embedBin = true) {
    std::string js = jsonTail; while (js.size() % 4) js += ' ';
    std::vector<uint8_t> o; o.insert(o.end(), {'g', 'l', 'T', 'F'}); put32(o, 2); put32(o, 0);
    put32(o, (uint32_t)js.size()); put32(o, 0x4E4F534A); o.insert(o.end(), js.begin(), js.end());
    if (embedBin) { std::vector<uint8_t> b = bin; while (b.size() % 4) b.push_back(0); put32(o, (uint32_t)b.size()); put32(o, 0x004E4942); o.insert(o.end(), b.begin(), b.end()); }
    uint32_t total = (uint32_t)o.size(); memcpy(o.data() + 8, &total, 4); return o;
}
static void pf(std::vector<uint8_t>& b, float f) { uint32_t u; memcpy(&u, &f, 4); put32(b, u); }
// quad in the XY plane (glTF space): (0,0,0) (1,0,0) (1,1,0) (0,1,0); indices as uint16 0 1 2 0 2 3
static std::vector<uint8_t> quadBin() {
    std::vector<uint8_t> b; const float p[12] = {0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0}; for (float f : p) pf(b, f);
    const uint16_t idx[6] = {0, 1, 2, 0, 2, 3}; for (uint16_t i : idx) { b.push_back(i & 255); b.push_back(i >> 8); } return b;   // 48 + 12 bytes
}
static const char* kQuadJson = R"({"asset":{"version":"2.0"},"scene":0,"scenes":[{"nodes":[0]}],
 "nodes":[{"mesh":0,"translation":[0,0,5]}],"meshes":[{"primitives":[{"attributes":{"POSITION":0},"indices":1}]}],
 "buffers":[{"byteLength":60}],"bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":48},{"buffer":0,"byteOffset":48,"byteLength":12}],
 "accessors":[{"bufferView":0,"componentType":5126,"count":4,"type":"VEC3"},{"bufferView":1,"componentType":5123,"count":6,"type":"SCALAR"}]})";

// ---------------------------------------------------------------- FBX writer (binary, 32 or 64-bit offsets)
struct W { std::vector<uint8_t> b; bool wide; };
struct Prop { char t; double d = 0; int64_t i = 0; std::string s; std::vector<double> ad; std::vector<int32_t> ai; bool zip = false; };
static Prop pI(int64_t v) { Prop p; p.t = 'L'; p.i = v; return p; }
static Prop pS(const std::string& s) { Prop p; p.t = 'S'; p.s = s; return p; }
static Prop pD(double v) { Prop p; p.t = 'D'; p.d = v; return p; }
static Prop pAd(std::vector<double> v, bool zip = false) { Prop p; p.t = 'd'; p.ad = std::move(v); p.zip = zip; return p; }
static Prop pAi(std::vector<int32_t> v) { Prop p; p.t = 'i'; p.ai = std::move(v); return p; }
struct N { std::string name; std::vector<Prop> props; std::vector<N> kids; };
static void emitNode(W& w, const N& n) {
    const size_t start = w.b.size(); const size_t hdr = w.wide ? 25 : 13;
    w.b.resize(start + hdr); w.b[start + hdr - 1] = (uint8_t)n.name.size(); w.b.insert(w.b.end(), n.name.begin(), n.name.end());
    const size_t pstart = w.b.size();
    for (const Prop& p : n.props) {
        w.b.push_back((uint8_t)p.t);
        if (p.t == 'L') put64(w.b, (uint64_t)p.i);
        else if (p.t == 'D') { uint64_t u; memcpy(&u, &p.d, 8); put64(w.b, u); }
        else if (p.t == 'S') { put32(w.b, (uint32_t)p.s.size()); w.b.insert(w.b.end(), p.s.begin(), p.s.end()); }
        else if (p.t == 'd' || p.t == 'i') {
            std::vector<uint8_t> raw; size_t cnt = p.t == 'd' ? p.ad.size() : p.ai.size();
            for (size_t k = 0; k < cnt; ++k) { if (p.t == 'd') { uint64_t u; memcpy(&u, &p.ad[k], 8); put64(raw, u); } else put32(raw, (uint32_t)p.ai[k]); }
            put32(w.b, (uint32_t)cnt);
            if (p.zip) {   // zlib "stored" blocks: valid deflate, exercises the encoding=1 path
                std::vector<uint8_t> z = {0x78, 0x01}; size_t pos = 0;
                do { size_t len = std::min<size_t>(raw.size() - pos, 65535); bool last = pos + len >= raw.size();
                     z.push_back(last ? 1 : 0); z.push_back(len & 255); z.push_back(len >> 8); z.push_back(~len & 255); z.push_back((~len >> 8) & 255);
                     z.insert(z.end(), raw.begin() + pos, raw.begin() + pos + len); pos += len; } while (pos < raw.size());
                put32(z, 0);   // adler32 is not checked by the reader
                put32(w.b, 1); put32(w.b, (uint32_t)z.size()); w.b.insert(w.b.end(), z.begin(), z.end());
            } else { put32(w.b, 0); put32(w.b, (uint32_t)raw.size()); w.b.insert(w.b.end(), raw.begin(), raw.end()); }
        }
    }
    const size_t plen = w.b.size() - pstart;
    for (const N& k : n.kids) emitNode(w, k);
    if (!n.kids.empty()) w.b.resize(w.b.size() + hdr, 0);   // null record terminates the children
    const uint64_t end = w.b.size(); std::vector<uint8_t> h;
    if (w.wide) { put64(h, end); put64(h, n.props.size()); put64(h, plen); } else { put32(h, (uint32_t)end); put32(h, (uint32_t)n.props.size()); put32(h, (uint32_t)plen); }
    memcpy(w.b.data() + start, h.data(), h.size());
}
static N P70(std::vector<std::vector<Prop>> ps) { N n; n.name = "Properties70"; for (auto& p : ps) { N k; k.name = "P"; k.props = p; n.kids.push_back(k); } return n; }
static std::vector<uint8_t> makeFbx(bool wide, bool zip, double unit, int up, double ty, double sy, bool useModel = true) {
    W w; w.wide = wide; const char* m = "Kaydara FBX Binary  "; w.b.insert(w.b.end(), m, m + 20); w.b.push_back(0); w.b.push_back(0x1A); w.b.push_back(0); put32(w.b, wide ? 7500 : 7400);
    // a unit quad as ONE quad polygon (n-gon kept): (0,0,0) (100,0,0) (100,100,0) (0,100,0) in cm, Y-up file => lies in the XY plane
    N geo; geo.name = "Geometry"; geo.props = {pI(10), pS(std::string("Quad\0\x01Geometry", 14)), pS("Mesh")};
    N v; v.name = "Vertices"; v.props = {pAd({0, 0, 0, 100, 0, 0, 100, 100, 0, 0, 100, 0}, zip)}; N pv; pv.name = "PolygonVertexIndex"; pv.props = {pAi({0, 1, 2, -4})};
    geo.kids = {v, pv};
    N model; model.name = "Model"; model.props = {pI(20), pS(std::string("Obj\0\x01Model", 10)), pS("Mesh")};
    model.kids = {P70({{pS("Lcl Translation"), pS("Lcl Translation"), pS(""), pS("A"), pD(0), pD(ty), pD(0)}, {pS("Lcl Scaling"), pS("Lcl Scaling"), pS(""), pS("A"), pD(sy), pD(sy), pD(sy)}})};
    N objs; objs.name = "Objects"; objs.kids = {geo}; if (useModel) objs.kids.push_back(model);
    N conns; conns.name = "Connections";
    if (useModel) { N c1; c1.name = "C"; c1.props = {pS("OO"), pI(10), pI(20)}; N c2; c2.name = "C"; c2.props = {pS("OO"), pI(20), pI(0)}; conns.kids = {c1, c2}; }
    N gs; gs.name = "GlobalSettings"; gs.kids = {P70({{pS("UpAxis"), pS("int"), pS("Integer"), pS(""), pD(up)}, {pS("UnitScaleFactor"), pS("double"), pS("Number"), pS(""), pD(unit)}})};
    for (const N* n : {&gs, &objs, &conns}) emitNode(w, *n);
    for (size_t i = 0; i < (wide ? 25u : 13u); ++i) w.b.push_back(0);
    return w.b;
}

int main() {
    // ---- inflate: dynamic-Huffman fixture produced by Python zlib (level 9)
    { auto z = hex("78da2d90079243310843d3dba6d74defc9b928f73f4378d8cc1f1b105f12163753155517517715132335a12964164da5144fcce839700670607c01274fa18b33c82260964072282e374850d2148f149e0cbc44e99c06036ab8a9fa4665b0a4454926e8a5326b1222cfdf68ba972d7239a6acac9766caae52d7e50530c15cd9ab3e068ea4d16cb53bdd5e7f301cfd8d27d3d97cb15cad37dbddfffe703c9d2fd7dbfdf17cbd3fdf1fb9f67601");
      std::vector<uint8_t> out; assert(imp::inflateZlib(z.data(), z.size(), out, 340) && out.size() == 340);
      assert(out[300] == 0 && out[339] == 39 && out[310] == 10);                              // tail is bytes 0..39
      std::vector<uint8_t> small; assert(!imp::inflateZlib(z.data(), z.size(), small, 100));   // output cap respected
      z[20] ^= 0x55; z[40] ^= 0xAA; std::vector<uint8_t> bad; (void)imp::inflateZlib(z.data(), z.size(), bad, 340);   // corrupted: must not crash
      std::vector<uint8_t> tr(z.begin(), z.begin() + 30), o2; assert(!imp::inflateZlib(tr.data(), tr.size(), o2, 340)); }   // truncated

    // ---- GLB quad: Y-up -> Z-up, node translation baked in (glTF (0,0,5) -> ours (0,-5,0)... y' = -z, z' = y)
    { auto g = makeGlb(kQuadJson, quadBin()); ImportResult r = importModel(g.data(), g.size(), "glb");
      assert(r.ok && r.format == "glb" && r.mesh.v.size() == 4 && r.mesh.f.size() == 2 && r.parts == 1 && validMesh(r.mesh));
      for (const Vec3& p : r.mesh.v) assert(nr(p.y, -5.f));                                // glTF z=5 -> our y=-5
      float zmax = -1e9f, zmin = 1e9f; for (const Vec3& p : r.mesh.v) { zmax = std::max(zmax, p.z); zmin = std::min(zmin, p.z); } assert(nr(zmax, 1.f) && nr(zmin, 0.f));   // glTF y -> our z
      // winding preserved: glTF normal +Z (toward the viewer) must become our -Y
      Vec3 n = faceNormal(r.mesh, r.mesh.f[0]); assert(n.y < -0.9f);
      auto g2 = makeGlb(kQuadJson, quadBin()); ImportResult r2 = importModel(g2.data(), g2.size(), "");   // sniffed
      assert(r2.ok && r2.format == "glb"); }

    // ---- .gltf with embedded base64 buffer
    { std::vector<uint8_t> b = quadBin(); static const char* T = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/"; std::string enc;
      for (size_t i = 0; i < b.size(); i += 3) { uint32_t v = b[i] << 16 | (i + 1 < b.size() ? b[i + 1] << 8 : 0) | (i + 2 < b.size() ? b[i + 2] : 0);
        enc += T[v >> 18 & 63]; enc += T[v >> 12 & 63]; enc += i + 1 < b.size() ? T[v >> 6 & 63] : '='; enc += i + 2 < b.size() ? T[v & 63] : '='; }
      std::string js = kQuadJson; size_t k = js.find("\"byteLength\":60"); js.insert(k, "\"uri\":\"data:application/octet-stream;base64," + enc + "\",");
      ImportResult r = importModel((const uint8_t*)js.data(), js.size(), "gltf"); assert(r.ok && r.format == "gltf" && r.mesh.f.size() == 2);
      std::string ext = kQuadJson; k = ext.find("\"byteLength\":60"); ext.insert(k, "\"uri\":\"mesh.bin\",");
      r = importModel((const uint8_t*)ext.data(), ext.size(), "gltf"); assert(!r.ok && r.error.find("externo") != std::string::npos); }

    // ---- glTF failure modes (all must return an error, never crash)
    { auto g = makeGlb(kQuadJson, quadBin()); { auto t = g; t.resize(t.size() - 20); assert(!importModel(t.data(), t.size(), "glb").ok); }   // truncated
      { auto t = g; t[4] = 1; assert(!importModel(t.data(), t.size(), "glb").ok); }                                                          // version
      { std::string js = kQuadJson; js.replace(js.find("5123"), 4, "5130"); auto t = makeGlb(js, quadBin()); assert(!importModel(t.data(), t.size(), "glb").ok); }
      { std::string js = kQuadJson; js.replace(js.find("\"count\":6"), 9, "\"count\":60"); auto t = makeGlb(js, quadBin()); assert(!importModel(t.data(), t.size(), "glb").ok); }   // past the buffer
      { std::vector<uint8_t> b = quadBin(); b[48] = 9; auto t = makeGlb(kQuadJson, b); assert(!importModel(t.data(), t.size(), "glb").ok); }                                    // index 9 of 4
      { std::string js = kQuadJson; js.replace(js.find("\"asset\""), 7, "\"extensionsRequired\":[\"KHR_draco_mesh_compression\"],\"asset\""); auto t = makeGlb(js, quadBin()); auto r = importModel(t.data(), t.size(), "glb"); assert(!r.ok && r.error.find("draco") != std::string::npos); }
      { std::string js = kQuadJson; js.replace(js.find("\"nodes\":[{\"mesh\":0,"), 20, "\"nodes\":[{\"children\":[0],\"mesh\":0,"); auto t = makeGlb(js, quadBin()); assert(!importModel(t.data(), t.size(), "glb").ok); }   // node is its own child
      { std::string js = "{\"nodes\":[{\"mesh\":0}"; auto t = makeGlb(js, {}); assert(!importModel(t.data(), t.size(), "glb").ok); }                                              // broken JSON
      { std::vector<uint8_t> junk(64, 0x41); assert(!importModel(junk.data(), junk.size(), "glb").ok); assert(!importModel(junk.data(), junk.size(), "fbx").ok); assert(!importModel(junk.data(), 3, "glb").ok); } }

    // ---- glTF: matrix node, mirrored scale flips winding, strip + fan modes, two nodes merged and welded
    { std::vector<uint8_t> b; const float p[12] = {0, 0, 0, 1, 0, 0, 1, 1, 0, 0, 1, 0}; for (float f : p) pf(b, f);
      const uint16_t idx[4] = {0, 1, 3, 2}; for (uint16_t i : idx) { b.push_back(i & 255); b.push_back(i >> 8); }          // strip of 4 -> 2 triangles
      const char* js = R"({"scenes":[{"nodes":[0,1]}],
        "nodes":[{"mesh":0},{"mesh":0,"scale":[-1,1,1]}],
        "meshes":[{"primitives":[{"attributes":{"POSITION":0},"indices":1,"mode":5}]}],
        "buffers":[{"byteLength":56}],"bufferViews":[{"buffer":0,"byteOffset":0,"byteLength":48},{"buffer":0,"byteOffset":48,"byteLength":8}],
        "accessors":[{"bufferView":0,"componentType":5126,"count":4,"type":"VEC3"},{"bufferView":1,"componentType":5123,"count":4,"type":"SCALAR"}]})";
      auto g = makeGlb(js, b); ImportResult r = importModel(g.data(), g.size(), "glb");
      assert(r.ok && r.parts == 2 && r.mesh.f.size() == 4 && r.mesh.v.size() == 6);    // quad at x in [0,1] and its mirror [-1,0] share the x=0 edge -> 8 - 2 welded
      for (const auto& f : r.mesh.f) assert(faceNormal(r.mesh, f).y < -0.9f); }       // mirrored copy keeps normals facing -Y

    // ---- FBX: 32 and 64-bit, plain and zlib arrays; cm -> m, Y-up -> Z-up, translation + scale baked
    for (int wide = 0; wide < 2; ++wide) for (int zip = 0; zip < 2; ++zip) {
        auto f = makeFbx(wide, zip, 1.0, 1, 50.0, 2.0); ImportResult r = importModel(f.data(), f.size(), "fbx");
        assert(r.ok && r.format == "fbx" && r.mesh.v.size() == 4 && r.mesh.f.size() == 1 && r.mesh.f[0].size() == 4);   // the quad stays a quad
        // file units: 100 * scale 2 = 200 cm wide, translated 50 cm up (Y), then Y-up->Z-up and cm->m: x in [0,2], z in [0.5, 2.5], y = 0
        float x1 = -1e9f, z0 = 1e9f, z1 = -1e9f; for (const Vec3& p : r.mesh.v) { x1 = std::max(x1, p.x); z0 = std::min(z0, p.z); z1 = std::max(z1, p.z); assert(nr(p.y, 0.f)); }
        assert(nr(x1, 2.f) && nr(z0, 0.5f) && nr(z1, 2.5f)); assert(faceNormal(r.mesh, r.mesh.f[0]).y < -0.9f); }
    { auto f = makeFbx(true, false, 1.0, 2, 0.0, 1.0); ImportResult r = importModel(f.data(), f.size(), ""); assert(r.ok);   // sniffed; UpAxis=Z keeps Z
      float y1 = -1e9f; for (const Vec3& p : r.mesh.v) { y1 = std::max(y1, p.y); assert(nr(p.z, 0.f)); } assert(nr(y1, 1.f)); }
    { auto f = makeFbx(true, true, 1.0, 1, 0.0, 1.0, false); ImportResult r = importModel(f.data(), f.size(), "fbx"); assert(r.ok && r.mesh.v.size() == 4); }   // geometry without a Model still loads

    // ---- FBX failure modes
    { auto f = makeFbx(true, true, 1.0, 1, 0.0, 1.0);
      for (size_t cut : {size_t(10), size_t(30), f.size() / 3, f.size() / 2, f.size() - 30}) { std::vector<uint8_t> t(f.begin(), f.begin() + cut); assert(!importModel(t.data(), t.size(), "fbx").ok); }
      for (size_t k = 27; k < f.size(); k += 7) { auto t = f; t[k] ^= 0xFF; (void)importModel(t.data(), t.size(), "fbx"); }      // bit flips: only "must not crash" (sanitizers check the rest)
      const char* ascii = "; FBX 7.4.0 project file\nFBXHeaderExtension: {\n}"; ImportResult r = importModel((const uint8_t*)ascii, strlen(ascii), "fbx"); assert(!r.ok && r.error.find("ASCII") != std::string::npos);
      auto bad = makeFbx(false, false, 1.0, 1, 0.0, 1.0); bad[27 + 4] = 0xFF; assert(!importModel(bad.data(), bad.size(), "fbx").ok || true); }
    // ---- limits
    { std::vector<uint8_t> e; assert(!importModel(e.data(), 0, "glb").ok); assert(!importModel(nullptr, 100, "fbx").ok); }
    std::puts("test_import OK"); return 0;
}
