# Architecture (v0.23)
- `core/` (header-only C++17, no GL/JNI):
  - `math3` – Vec3.
  - `mesh` – polygon mesh, primitives, picking, modeling ops (extrude faces/edges, delete, inset, subdivide, merge, flip, loop cut, edge loops),
    vertex-mask transforms (move/rotate/scale about the median point).
  - `modifiers` – `Modifier` data + pure evaluators (Mirror, Array, Subdivision Surface = `subdivideOnce`/`applySubsurf`, Solidify = `applySolidify`, Triangulate = `triangulateMesh`/`triangulateFace` (ear clipping), Weld = `weldVertices` (spatial hash + union-find; also used by Mesh > Merge by Distance)) and `evaluateStack` (guards absurd sizes before evaluating). `displayMesh(Object)` (in `scene.hpp`) returns the base mesh or the cached evaluated mesh (cache keyed by `meshRev`/`modsRev`). The renderer and object picking use it; edit-mode selection/picking/ops use the base mesh (the "cage").
  - `scene` – objects, transforms, `SelState` (vertex/edge/face selection + mode conversion), command history,
    high-level ops (`editActiveMesh` wraps every mesh edit into ONE undoable `MeshEditCmd` that also stores selection before/after),
    vertex/edge picking with occlusion.
  - `project_io` – v4 text format (v2: meshes, v3: + `mods`/`mod` records, v4: each `mod` record ends with `levels thickness shift`; v3 files load with defaults), atomic save (tmp + rename), v1 migration.
- `renderer.*`: GLES3. Per-object GPU buffers keyed by (object id, meshRev); edit overlay (`drawEditOverlay`); axis gizmo.
- `bridge.cpp`: thin JNI layer + interactive drag state (one undo entry per gesture).
- `kotlin/dev/atlas`: Android shell. All scene access goes through `act {}` which runs on the GL thread,
  then refreshes Outliner/Properties/status from native state.
Conventions: Z-up, right-handed, CCW faces are outward, Euler XYZ degrees (R = Rz*Ry*Rx).
Rule for new mesh ops: write a pure function in `mesh.hpp` (testable), wrap it with `editActiveMesh` in `scene.hpp`
(selection + undo), expose it in `bridge.cpp` + `NativeBridge.kt`, add a menu item, add a host test in `tests/test_scene.cpp`.
Rule for new modifiers: add the type to `ModType`, an evaluator in `modifiers.hpp`, validation in `validModifier`, a test, and a card in `rebuildModifiers` (Kotlin). Any change to `mods` must bump `modsRev` (use the `ModStackCmd` ops in `scene.hpp`).

Lighting (renderer.cpp fragment shader): flat normal from screen derivatives, flipped toward the viewer (two-sided), shaded with a camera headlight + Z-up hemisphere ambient + a fixed key light; `uEye` is set once per frame.
JNI for modifiers: `modifiers()` returns one tab-separated line per modifier (type, enabled, axis, count, ox, oy, oz, levels, thickness, shift); `setModifier` (axis/count/offset) and `setModifierParams` (levels/thickness/shift) edit a card.

Object-level commands in `scene.hpp`: `RenameCmd`, `BakeCmd` (mesh + transform together: Apply Transform, Origin to Geometry). `selectLinkedActive` and `weldSelected` live next to them (weld is a normal `editActiveMesh` op). Modifier JNI: `setModifierMerge(i, merge)` edits the Weld distance (the `merge` field is shared with Mirror); `modifiers()` has an 11th column with it.
Project format is still v4: Triangulate/Weld reuse the existing `mod` record (type 4/5, Weld distance in the `merge` column), so no version bump; older builds (<=0.7.0) reject such files as "invalid modifier".

## 0.10.0 / 0.11.0 additions
- `mesh.hpp`: `dissolveEdges` / `limitedDissolve` (built on `detail::dissolveEdgesCore` = union-find over faces joined by the chosen edges, outline of each group must be one simple loop, vertex indices never change during the merge; then `detail::dissolveStraightVerts` removes valence-2 vertices that are straight within a limit; `compactUnusedVertices` keeps vertex order), `separateFaces` (splits into two compact meshes).
- `scene.hpp`: `dissolveSelectedEdges`, `limitedDissolveSelected` (both `editActiveMesh` ops; result faces become the selection in the user's mode), `SeparateCmd` + `separateSelected` (a command that touches two objects: the source mesh and a new object; undo restores edit mode + selection).
- `modifiers.hpp`: `ModType` has `kSmooth` (6), `kSimpleDeform` (7), `kPlanarDecimate` (8); `Modifier` gained `factor`, `iterations`, `mode`, `angle` (`axis` doubles as the deform axis). `kMaxModType` is the single place that says how many types exist. Planar Decimate just calls `limitedDissolve` on the whole mesh.
- `project_io.hpp`: format **v5**: each `mod` record ends with `factor iterations mode angle` after the v4 columns. v1-v4 load with defaults; builds <= 0.9.0 reject v5 files.
- JNI: `setModifierExtra(i, axis, factor, iterations, mode, angle)` edits Smooth/Simple Deform/Planar Decimate cards; `modifiers()` has columns 12-15 (factor, iterations, mode, angle); `dissolveEdges()`, `limitedDissolve(angle)`, `separateSelected()`.

## 0.12.0 / 0.13.0 additions
- `mesh.hpp`: `dissolveVertices` (reuses `detail::dissolveEdgesCore` on every edge touching the selection, then `dissolveStraightVerts` with cosLimit -2 so valence-2 border vertices go too), `splitLooseParts` (union-find over face vertices, parts keep face order, unused vertices dropped, vertex order inside a part follows first use), `fillLoop`, `bridgeLoops`, `bevelVertices`; helpers `detail::edgeLoops` (edges -> closed loops, fails unless every vertex has exactly 2 selected edges) and `detail::loopFaceDir` (winding of the faces already on a loop; 2 = not an open border / inconsistent).
- Winding rule shared by Fill and Bridge: new faces must walk each shared edge OPPOSITE to the existing face. Bridge pairs loop A[i] with the best rotation/direction of loop B (min sum of distances) and rejects if A and B demand different quad orientations.
- Bevel Vertices: per selected vertex with a closed manifold fan, one new point per incident edge (`min(width, 0.49 len)` along the edge), each face swaps the corner for its 2 points, the cap polygon walks the points in the reverse direction of the faces. Open-border / non-manifold vertices are skipped silently.
- `scene.hpp`: `dissolveSelectedVertices`, `dissolveSelectedFaces`, `fillSelected`, `bridgeSelected`, `bevelSelectedVertices` (all `editActiveMesh`, one undo step); `LooseSplitCmd` + `separateLooseParts` (Object Mode, returns new-object count, 0 = no undo step).
- JNI: `dissolveVertices`, `dissolveFaces`, `separateLoose`, `fillSelected`, `bridgeLoops`, `bevelVertices(width)`. No project-format change (still v5).

## 0.14.0 / 0.15.0 additions
- `scene.hpp`: `selectMoreLess(scene, more)` works on a vertex mask (from `selectedVertexMask`) and rebuilds the selection in the user's mode; Less treats vertices on open-border edges as boundary. Selection only (no undo step, like Select Linked).
- `scene.hpp`: `JoinCmd` + `joinAllObjects`: world = R*(S*p)+pos per source object, then active-local = S_a^-1 * R_a^T * (world - pos_a); winding flips when exactly one of (source, active) has negative scale determinant. Joined objects are removed (their indices are stored for undo); their modifiers are dropped.
- JNI: `selectMore`, `selectLess`, `joinAll` (returns Int). UI: Select > More/Less, Object > Join, Add Modifier dropdown. No project-format change (v5).

## 0.16.0 / 0.17.0 additions
- `mesh.hpp`: `bevelEdges(mesh, edges, width, &strips)`. Per touched vertex the fan of faces is walked (same chain logic as `bevelVertices`); each face corner is replaced by `c(F,E)` points: `P(v,u)` on an unselected edge at `min(width, 0.49 len)`, or the parallelogram corner `Q(v,F) = v + d1 e1 + d2 e2` when both edges of that face at v are selected. Strips are `[f1b, f1a, f2a, f2b]` (f1 = face running a->b), caps are the ring of distinct points around the removed vertex (walked opposite to the face order) when it has 3+ points. Any refusal returns 0 and leaves the mesh untouched.
- `mesh.hpp`: `edgeSlide(mesh, edges, t)`: chains/cycles are oriented, the face containing directed edge p->v is on the LEFT, and the left/right side edge is read from it (`nextIn`/`prevIn`). Only vertex positions change.
- `scene.hpp`: `bevelSelectedEdges`, `edgeSlideSelected` (both via `editActiveMesh`: one undo step, selection converted to edges). JNI: `bevelEdges(width)`, `edgeSlide(t)`. UI: Mesh > Bevel Edges / Edge Slide, new "Edge Slide Factor" field. No project-format change (v5).

## 0.18.0 / 0.19.0 additions
- `mesh.hpp`: `bridgeLoops(..., twist)` rotates loop B with `std::rotate` after the automatic alignment (k = twist mod n, negative wraps). `sharpEdges(mesh, angle)`: manifold edges with `dot(n1,n2) < cos(angle) - 1e-6`; angle outside [0,180) gives an empty set.
- `scene.hpp`: `selectSharpEdgesActive` (selection only, switches to edge mode), `bridgeSelectedTwist`.
- `modifiers.hpp`: `kBevel = 9` (`kMaxModType = 9`): `applyBevel` = `sharpEdges(angle)` minus edges touching a vertex of any non-2-face edge, then `bevelEdges(width = factor)`; a refused bevel returns the input mesh. Stored in the existing v5 `mod` record (factor + angle) so the project format is unchanged; builds <= 0.17.0 reject a file containing type 9 as an invalid modifier.
- JNI: `bridgeLoops(twist)` (signature changed), `selectSharp(angle)`. UI: Select > Sharp Edges, "Bridge Twist" and "Sharp Angle" fields, Bevel card (Width + Angle).

## 0.20.0 / 0.21.0 additions
- `mesh.hpp`: `falloffWeight`, `proportionalWeights(mesh, mask, radius, falloff, connected)` (straight-line or multi-source Dijkstra along edges; selected = 1), `moveVerticesW` / `rotateVerticesW` / `scaleVerticesW` (weight scales the effect; pivot = centroid of the selected mask). `bridge.cpp`: global `gProp` (set by `setProportional`), `Drag.weights` computed once in `beginDrag` from the mesh BEFORE the gesture; `updateDrag` uses the weighted functions when it is non-empty.
- `scene.hpp`: `ViewInfo` + `makeView` + `projectToScreen` (same model as `Renderer::screenRay`; pixel origin top-left), `boxSelectActive(scene, view, x0,y0,x1,y1, op, xray)` (0 replace / 1 add / 2 subtract; selection only, no undo step; replace with an empty box clears and returns true, add/subtract with an empty box return false). JNI `boxSelect(...)`.
- Kotlin: tool 4 (Box) in the tool column, `RubberBand` overlay (a FrameLayout around the GL view, ignores touches), Properties controls for proportional and box options. No project-format change.

## 0.22.0 / 0.23.0 additions
- `scene.hpp`: `triangulateFaces` (reuses `triangulateFace` from modifiers; first triangle keeps the face slot, the rest are appended), `pokeFaces`, `recalcNormals(mesh, inside)` (flood fill over 2-face edges reversing neighbours that walk a shared edge the same way, then per closed component a signed-volume test), `triangulateSelectedFaces`, `pokeSelectedFaces`, `recalcNormalsActive` (refuses when nothing changes, so no empty undo step), `selectBoundaryActive`, `selectNonManifoldActive`, `selectRandomActive`.
- `mesh.hpp`: `boundaryEdges`, `nonManifoldEdges` (face count != 2), `randomSubset(n, ratio, seed)` (mt19937 raw output + own Fisher-Yates, so results do not depend on the standard library's shuffle).
- JNI: `triangulateFaces`, `pokeFaces(offset)`, `recalcNormals(inside)`, `selectBoundary`, `selectNonManifold`, `selectRandom(ratio, seed)`. UI: 4 Mesh menu items, 3 Select menu items, fields "Poke Offset", "Select Random ratio/seed". No project-format change.
