#include "renderer.hpp"
#include <GLES3/gl3.h>
#include <cmath>
#include <vector>

namespace atlas {
namespace {
const char* kVS = R"(#version 300 es
layout(location=0) in vec3 aPos;
uniform mat4 uVP; uniform mat4 uModel; uniform float uPt;
out vec3 vWorld;
void main(){ vec4 w = uModel*vec4(aPos,1.0); vWorld = w.xyz; gl_Position = uVP*w; gl_PointSize = uPt; })";
const char* kFS = R"(#version 300 es
precision mediump float;
in vec3 vWorld; uniform vec4 uColor; uniform float uLit; uniform vec3 uEye; out vec4 o;
void main(){
  if(uLit < 0.5){ o = uColor; return; }
  vec3 n = normalize(cross(dFdx(vWorld), dFdy(vWorld)));
  vec3 V = normalize(uEye - vWorld);
  if(dot(n, V) < 0.0) n = -n;                       // two-sided: back faces are lit like front faces
  float hemi = 0.5 + 0.5*n.z;                       // Z-up sky/ground ambient
  float d = 0.30 + 0.20*hemi + 0.36*max(dot(n, V), 0.0) + 0.20*max(dot(n, normalize(vec3(0.35,-0.5,0.8))), 0.0);
  o = vec4(uColor.rgb*min(d, 1.0), 1.0); })";

unsigned compile(GLenum t, const char* src) {
    unsigned s = glCreateShader(t); glShaderSource(s, 1, &src, nullptr); glCompileShader(s); return s;
}
void mul(const float* a, const float* b, float* r) {  // column-major r = a*b
    for (int c = 0; c < 4; ++c) for (int rI = 0; rI < 4; ++rI) {
        float v = 0; for (int k = 0; k < 4; ++k) v += a[k * 4 + rI] * b[c * 4 + k]; r[c * 4 + rI] = v;
    }
}
const float kIdentity[16] = {1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1};
}  // namespace

Vec3 Camera::eye() const {
    return target + Vec3{dist * std::cos(pitch) * std::cos(yaw), dist * std::cos(pitch) * std::sin(yaw), dist * std::sin(pitch)};
}
void Camera::basis(Vec3& f, Vec3& r, Vec3& u) const {
    f = normalized(target - eye());
    r = normalized(cross(f, Vec3{0, 0, 1}));
    u = cross(r, f);
}
void Renderer::screenRay(float px, float py, Vec3& org, Vec3& dir) const {
    Vec3 f, r, u; cam.basis(f, r, u); org = cam.eye();
    float nx = 2.f * px / width - 1.f, ny = 1.f - 2.f * py / height, t = std::tan(cam.fovY * 0.5f);
    dir = normalized(f + r * (nx * t * cam.aspect) + u * (ny * t));
}

void Renderer::init() {
    gpu.clear();  // old GL objects died with the previous context
    unsigned vs = compile(GL_VERTEX_SHADER, kVS), fs = compile(GL_FRAGMENT_SHADER, kFS);
    prog = glCreateProgram(); glAttachShader(prog, vs); glAttachShader(prog, fs); glLinkProgram(prog);
    uVP = glGetUniformLocation(prog, "uVP"); uModel = glGetUniformLocation(prog, "uModel");
    uColor = glGetUniformLocation(prog, "uColor"); uLit = glGetUniformLocation(prog, "uLit"); uPt = glGetUniformLocation(prog, "uPt"); uEye = glGetUniformLocation(prog, "uEye");
    // unit cube (gizmo tips)
    const float p[8][3] = {{-.5f,-.5f,-.5f},{.5f,-.5f,-.5f},{.5f,.5f,-.5f},{-.5f,.5f,-.5f},
                           {-.5f,-.5f,.5f},{.5f,-.5f,.5f},{.5f,.5f,.5f},{-.5f,.5f,.5f}};
    const int idx[36] = {0,2,1,0,3,2, 4,5,6,4,6,7, 0,1,5,0,5,4, 3,6,2,3,7,6, 0,4,7,0,7,3, 1,2,6,1,6,5};
    std::vector<float> cube; for (int i : idx) cube.insert(cube.end(), p[i], p[i] + 3);
    glGenBuffers(1, &cubeVbo); glBindBuffer(GL_ARRAY_BUFFER, cubeVbo);
    glBufferData(GL_ARRAY_BUFFER, cube.size() * 4, cube.data(), GL_STATIC_DRAW);
    // grid on the XY plane (skipping the axes), then X and Y axis lines
    std::vector<float> g;
    for (int i = -10; i <= 10; ++i) {
        if (i == 0) continue;
        g.insert(g.end(), {(float)i, -10, 0, (float)i, 10, 0, -10, (float)i, 0, 10, (float)i, 0});
    }
    gridN = (int)g.size() / 3;
    g.insert(g.end(), {-10, 0, 0, 10, 0, 0, 0, -10, 0, 0, 10, 0});
    glGenBuffers(1, &gridVbo); glBindBuffer(GL_ARRAY_BUFFER, gridVbo);
    glBufferData(GL_ARRAY_BUFFER, g.size() * 4, g.data(), GL_STATIC_DRAW);
    const float gz[18] = {0,0,0, 1,0,0, 0,0,0, 0,1,0, 0,0,0, 0,0,1};
    glGenBuffers(1, &gizmoVbo); glBindBuffer(GL_ARRAY_BUFFER, gizmoVbo);
    glBufferData(GL_ARRAY_BUFFER, sizeof gz, gz, GL_STATIC_DRAW);
    glGenBuffers(1, &overlayVbo);
    glEnable(GL_DEPTH_TEST); glClearColor(0.235f, 0.235f, 0.245f, 1);
}

void Renderer::resize(int w, int h) {
    width = w > 0 ? w : 1; height = h > 0 ? h : 1; cam.aspect = (float)width / height; glViewport(0, 0, width, height);
}

Renderer::Gpu& Renderer::ensure(const Object& o) {
    Gpu& g = gpu[o.id];
    if (!g.tri) { glGenBuffers(1, &g.tri); glGenBuffers(1, &g.line); glGenBuffers(1, &g.lineBase); g.rev = 0; g.mrev = ~0ull; }
    if (g.rev != o.meshRev || g.mrev != o.modsRev) {
        const Mesh& dm = displayMesh(o);   // base mesh, or the modifier-stack result
        auto lines = [](const Mesh& m) {
            std::vector<float> l;
            for (auto& e : uniqueEdges(m)) {
                const Vec3& a = m.v[e.first]; const Vec3& b = m.v[e.second];
                l.insert(l.end(), {a.x, a.y, a.z, b.x, b.y, b.z});
            }
            return l;
        };
        std::vector<float> t;
        for (const auto& fc : dm.f)
            for (size_t i = 1; i + 1 < fc.size(); ++i)
                for (int k : {fc[0], fc[i], fc[i + 1]}) { const Vec3& v = dm.v[k]; t.push_back(v.x); t.push_back(v.y); t.push_back(v.z); }
        std::vector<float> l = lines(dm), lb = (&dm == &o.mesh) ? l : lines(o.mesh);   // lineBase = edit cage
        g.triN = (int)t.size() / 3; g.lineN = (int)l.size() / 3; g.lineBaseN = (int)lb.size() / 3;
        glBindBuffer(GL_ARRAY_BUFFER, g.tri); glBufferData(GL_ARRAY_BUFFER, t.size() * 4, t.data(), GL_STATIC_DRAW);
        glBindBuffer(GL_ARRAY_BUFFER, g.line); glBufferData(GL_ARRAY_BUFFER, l.size() * 4, l.data(), GL_STATIC_DRAW);
        glBindBuffer(GL_ARRAY_BUFFER, g.lineBase); glBufferData(GL_ARRAY_BUFFER, lb.size() * 4, lb.data(), GL_STATIC_DRAW);
        g.rev = o.meshRev; g.mrev = o.modsRev;
    }
    return g;
}

// Edit-mode element overlay: selected faces / edges, or vertex dots, depending on the select mode.
void Renderer::drawEditOverlay(const Scene& s, const Object& o, const Gpu&) {
    const SelState& sl = s.sel; const Mesh& m = o.mesh; const int nv = (int)m.v.size();
    auto upload = [&](const std::vector<float>& d) {
        glBindBuffer(GL_ARRAY_BUFFER, overlayVbo); glBufferData(GL_ARRAY_BUFFER, d.size() * 4, d.data(), GL_STREAM_DRAW);
        glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
    };
    auto put = [](std::vector<float>& d, const Vec3& v) { d.push_back(v.x); d.push_back(v.y); d.push_back(v.z); };
    glDepthFunc(GL_LEQUAL);
    if (sl.mode == 2 && !sl.f.empty()) {
        std::vector<float> ov;
        for (int fi : sl.f) {
            if (fi < 0 || fi >= (int)m.f.size()) continue;
            const auto& fc = m.f[fi];
            for (size_t i = 1; i + 1 < fc.size(); ++i) for (int k : {fc[0], fc[i], fc[i + 1]}) put(ov, m.v[k]);
        }
        if (!ov.empty()) {
            glPolygonOffset(1.f, 1.f); glUniform1f(uLit, 1.f); glUniform4f(uColor, 1.f, 0.62f, 0.17f, 1);
            upload(ov); glDrawArrays(GL_TRIANGLES, 0, (int)ov.size() / 3);
        }
    } else if (sl.mode == 1 && !sl.e.empty()) {
        std::vector<float> ov;
        for (const auto& e : sl.e) if (e.first >= 0 && e.second < nv) { put(ov, m.v[e.first]); put(ov, m.v[e.second]); }
        if (!ov.empty()) { glUniform1f(uLit, 0.f); glUniform4f(uColor, 1.f, 0.62f, 0.17f, 1); upload(ov); glDrawArrays(GL_LINES, 0, (int)ov.size() / 3); }
    } else if (sl.mode == 0) {
        std::vector<float> plain, chosen;
        for (int i = 0; i < nv; ++i) put(sl.v.count(i) ? chosen : plain, m.v[i]);
        glUniform1f(uLit, 0.f);
        if (!plain.empty()) { glUniform1f(uPt, 7.f); glUniform4f(uColor, 0.02f, 0.02f, 0.03f, 1); upload(plain); glDrawArrays(GL_POINTS, 0, (int)plain.size() / 3); }
        if (!chosen.empty()) { glUniform1f(uPt, 11.f); glUniform4f(uColor, 1.f, 0.62f, 0.17f, 1); upload(chosen); glDrawArrays(GL_POINTS, 0, (int)chosen.size() / 3); }
        glUniform1f(uPt, 1.f);
    }
    glDepthFunc(GL_LESS);
}

void Renderer::draw(const Scene& s) {
    glViewport(0, 0, width, height);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgram(prog); glUniform1f(uPt, 1.f);
    Vec3 e = cam.eye(), f, r, u; cam.basis(f, r, u); glUniform3f(uEye, e.x, e.y, e.z);
    float V[16] = {r.x, u.x, -f.x, 0, r.y, u.y, -f.y, 0, r.z, u.z, -f.z, 0, -dot(r, e), -dot(u, e), dot(f, e), 1};
    float n = 0.1f, fa = 300.f, t = 1.f / std::tan(cam.fovY * 0.5f);
    float P[16] = {t / cam.aspect, 0, 0, 0, 0, t, 0, 0, 0, 0, -(fa + n) / (fa - n), -1, 0, 0, -2 * fa * n / (fa - n), 0};
    float VP[16]; mul(P, V, VP);
    glUniformMatrix4fv(uVP, 1, GL_FALSE, VP);
    glUniformMatrix4fv(uModel, 1, GL_FALSE, kIdentity);
    glEnableVertexAttribArray(0);

    // grid + axes
    glUniform1f(uLit, 0.f);
    glBindBuffer(GL_ARRAY_BUFFER, gridVbo); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
    glUniform4f(uColor, 0.33f, 0.33f, 0.35f, 1); glDrawArrays(GL_LINES, 0, gridN);
    glUniform4f(uColor, 0.75f, 0.28f, 0.30f, 1); glDrawArrays(GL_LINES, gridN, 2);
    glUniform4f(uColor, 0.45f, 0.70f, 0.25f, 1); glDrawArrays(GL_LINES, gridN + 2, 2);

    // objects
    glEnable(GL_POLYGON_OFFSET_FILL);
    for (const auto& o : s.objects) {
        Gpu& g = ensure(o);
        float M[16]; modelMatrix(o, M); glUniformMatrix4fv(uModel, 1, GL_FALSE, M);
        const bool sel = o.id == s.selected, edit = sel && s.editMode;
        if (shading == 1) {
            if (g.lineN) {
                glUniform1f(uLit, 0.f);
                if (sel) glUniform4f(uColor, 1.f, 0.62f, 0.17f, 1); else glUniform4f(uColor, 0.8f, 0.8f, 0.82f, 1);
                glBindBuffer(GL_ARRAY_BUFFER, g.line); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
                glDrawArrays(GL_LINES, 0, g.lineN);
            }
            if (edit) drawEditOverlay(s, o, g);
            continue;
        }
        if (g.triN) {
            glPolygonOffset(2.f, 2.f); glUniform1f(uLit, 1.f); glUniform4f(uColor, 0.72f, 0.72f, 0.75f, 1);
            glBindBuffer(GL_ARRAY_BUFFER, g.tri); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
            glDrawArrays(GL_TRIANGLES, 0, g.triN);
        }
        if (sel && g.lineN) {  // selected object: orange edges; edit mode: dark edges
            glUniform1f(uLit, 0.f);
            if (edit) glUniform4f(uColor, 0.05f, 0.05f, 0.06f, 1); else glUniform4f(uColor, 1.f, 0.62f, 0.17f, 1);
            glBindBuffer(GL_ARRAY_BUFFER, edit ? g.lineBase : g.line); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
            glDrawArrays(GL_LINES, 0, edit ? g.lineBaseN : g.lineN);
        }
        if (edit) drawEditOverlay(s, o, g);
    }
    glDisable(GL_POLYGON_OFFSET_FILL);
    for (auto it = gpu.begin(); it != gpu.end();) {  // free GPU data of deleted objects
        if (!s.find(it->first)) { glDeleteBuffers(1, &it->second.tri); glDeleteBuffers(1, &it->second.line); glDeleteBuffers(1, &it->second.lineBase); it = gpu.erase(it); }
        else ++it;
    }

    // orientation gizmo (top-right corner): rotation-only view, X red / Y green / Z blue
    int gs = (int)(0.22f * (width < height ? width : height)); if (gs < 90) gs = 90;
    glViewport(width - gs - 10, height - gs - 10, gs, gs);
    glClear(GL_DEPTH_BUFFER_BIT);
    float Vg[16] = {r.x, u.x, -f.x, 0, r.y, u.y, -f.y, 0, r.z, u.z, -f.z, 0, 0, 0, 0, 1};
    const float sc = 1.f / 1.5f;
    float Pg[16] = {sc, 0, 0, 0, 0, sc, 0, 0, 0, 0, -0.2f, 0, 0, 0, 0, 1};
    float VPg[16]; mul(Pg, Vg, VPg);
    glUniformMatrix4fv(uVP, 1, GL_FALSE, VPg);
    glUniform1f(uLit, 0.f);
    const float cols[3][3] = {{0.9f, 0.25f, 0.28f}, {0.5f, 0.8f, 0.25f}, {0.25f, 0.5f, 0.95f}};
    glBindBuffer(GL_ARRAY_BUFFER, gizmoVbo); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
    glUniformMatrix4fv(uModel, 1, GL_FALSE, kIdentity);
    for (int a = 0; a < 3; ++a) { glUniform4f(uColor, cols[a][0], cols[a][1], cols[a][2], 1); glDrawArrays(GL_LINES, a * 2, 2); }
    glBindBuffer(GL_ARRAY_BUFFER, cubeVbo); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
    for (int a = 0; a < 3; ++a) {
        float M[16] = {0.2f,0,0,0, 0,0.2f,0,0, 0,0,0.2f,0, 0,0,0,1};
        M[12 + a] = 1.f;
        glUniformMatrix4fv(uModel, 1, GL_FALSE, M);
        glUniform4f(uColor, cols[a][0], cols[a][1], cols[a][2], 1); glDrawArrays(GL_TRIANGLES, 0, 36);
    }
    glViewport(0, 0, width, height);
}
}  // namespace atlas
