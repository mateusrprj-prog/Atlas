#include <cassert>
#include <map>
#include <set>
#include <cstdio>
#include "../app/src/main/cpp/core/project_io.hpp"
using namespace atlas;

static void checkOutward(const Mesh& m) {
    assert(validMesh(m));
    for (const auto& fc : m.f) {
        Vec3 c; for (int i : fc) c = c + m.v[i]; c = c * (1.f / fc.size());
        assert(dot(faceNormal(m, fc), c) > 0);  // normals point away from the origin
    }
}

int main() {
    // primitives
    checkOutward(makeCube()); checkOutward(makeCylinder()); checkOutward(makeUVSphere());
    assert(makeCube().v.size() == 8 && makeCube().f.size() == 6);

    // object add / transform / undo / redo
    Scene s; uint32_t a = addPrimitive(s, 0);
    assert(s.objects.size() == 1 && s.selected == a && s.objects[0].name == "Cube");
    uint32_t b = addPrimitive(s, 0); assert(s.find(b)->name == "Cube.001");
    Xf x = getXf(*s.find(a)); x.pos[0] = 3; x.rot[2] = 90; assert(s.selected == b);
    s.selected = a; assert(setObjectTransform(s, x));
    assert(s.find(a)->pos[0] == 3); assert(s.undo()); assert(s.find(a)->pos[0] == 0); assert(s.redo()); assert(s.find(a)->rot[2] == 90);

    // picking respects rotation/scale/translation
    Scene p; uint32_t c1 = addPrimitive(p, 0); uint32_t c2 = addPrimitive(p, 0);
    p.find(c2)->pos[1] = -6;   // behind c1 along the ray from +y? ray goes -y from y=+10
    Vec3 org{0, 10, 0}, dir{0, -1, 0};
    assert(pickObject(p, org, dir) == c1);
    Vec3 miss{5, 10, 0}; assert(pickObject(p, miss, dir) == 0);
    p.find(c1)->scale[0] = 6; assert(pickObject(p, miss, dir) == c1);  // scaled object now hit

    // edit mode: extrude a face, undo restores exact mesh
    Scene e; uint32_t id = addPrimitive(e, 0); assert(setEditMode(e, true)); assert(setSelectMode(e, 2));
    Mesh original = e.find(id)->mesh;
    int topFace = pickActiveFace(e, Vec3{0, 0, 10}, Vec3{0, 0, -1}); assert(topFace == 1);
    e.toggleFace(topFace);
    assert(extrudeSelected(e, 0.5f));
    const Mesh& m = e.find(id)->mesh;
    assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m));
    for (const auto& fc : m.f) { Vec3 n = faceNormal(m, fc); assert(length(n) > 0.99f); }
    float maxz = -9; for (auto& v : m.v) maxz = std::max(maxz, v.z); assert(std::fabs(maxz - 1.5f) < 1e-5f);
    assert(e.undo()); assert(sameMesh(e.find(id)->mesh, original));
    assert(e.redo()); assert(e.find(id)->mesh.f.size() == 10);
    assert(deleteSelection(e)); assert(e.find(id)->mesh.f.size() == 9 && validMesh(e.find(id)->mesh));
    assert(e.undo()); assert(e.find(id)->mesh.f.size() == 10);

    // undoing the creation while in edit mode leaves a consistent state
    Scene g; addPrimitive(g, 3); setEditMode(g, true); g.undo();
    assert(g.objects.empty() && !g.editMode && g.selected == 0);

    // delete / duplicate
    Scene d; addPrimitive(d, 2); assert(duplicateSelected(d) != 0 && d.objects.size() == 2);
    assert(deleteSelectedObject(d) && d.objects.size() == 1); assert(d.undo() && d.objects.size() == 2);

    // project round trip (v2)
    assert(saveProject(e, "/tmp/atlas_t2.atlas"));
    Scene q; assert(loadProject(q, "/tmp/atlas_t2.atlas"));
    assert(q.objects.size() == 1 && sameMesh(q.objects[0].mesh, e.objects[0].mesh) && q.nextId == e.nextId);

    // v1 migration + invalid files leave the scene untouched
    FILE* f1 = fopen("/tmp/atlas_v1.atlas", "w"); fputs("ATLAS 1\nnext 2\ncube 1 1 2 3 1 1 1\nend\n", f1); fclose(f1);
    Scene m1; assert(loadProject(m1, "/tmp/atlas_v1.atlas") && m1.objects.size() == 1);
    assert(m1.objects[0].pos[0] == 1 && m1.objects[0].pos[1] == -3 && m1.objects[0].pos[2] == 2);
    FILE* f2 = fopen("/tmp/atlas_bad.atlas", "w"); fputs("ATLAS 2\nnext 3\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 9\nend\n", f2); fclose(f2);
    Scene r; addPrimitive(r, 0); std::string err;
    assert(!loadProject(r, "/tmp/atlas_bad.atlas", &err)); assert(r.objects.size() == 1);
    // ================= v0.3: element selection and new modeling ops =================
    puts("v0.3 tests...");
    // closed-manifold check: every directed edge appears exactly once and so does its reverse
    auto closed = [](const Mesh& m) {
        std::map<std::pair<int, int>, int> c;
        for (const auto& fc : m.f) for (size_t i = 0; i < fc.size(); ++i) c[{fc[i], fc[(i + 1) % fc.size()]}]++;
        for (auto& kv : c) if (kv.second != 1 || c.count({kv.first.second, kv.first.first}) != 1) return false;
        return true;
    };
    auto totalArea = [](const Mesh& m) { float a = 0; for (auto& fc : m.f) a += faceArea(m, fc); return a; };
    assert(closed(makeCube()) && closed(makeCylinder()) && closed(makeUVSphere()));
    assert(std::fabs(totalArea(makeCube()) - 24.f) < 1e-4f);

    // selection mode conversion: face -> vertex -> edge -> face round trip on the cube's top face
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(setSelectMode(c, 0) && c.sel.mode == 0 && c.sel.v == std::set<int>({4, 5, 6, 7}) && c.sel.f.empty());
        assert(setSelectMode(c, 1) && c.sel.e.size() == 4 && c.sel.v.empty());
        assert(setSelectMode(c, 2) && c.sel.f == std::set<int>({1}));
        // two lone vertices are not enough for a face
        setSelectMode(c, 0); c.sel.v = {4, 5}; assert(setSelectMode(c, 2) && c.sel.f.empty());
        // invert / select all
        setSelectMode(c, 2); c.sel.clearSets(); selectAllActive(c); assert(c.sel.f.size() == 6);
        invertActive(c); assert(c.sel.f.empty()); (void)cid;
    }

    // picking vertices / edges with occlusion
    {
        Scene c; addPrimitive(c, 0); setEditMode(c, true);
        float tol = 0.02f; Vec3 eye{3, 3, 3};
        assert(pickActiveVertex(c, eye, normalized(Vec3{-1, -1, -1}), tol) == 6);       // front corner, not the hidden one behind it
        assert(pickActiveVertex(c, eye, normalized(Vec3{-1, 0.2f, -1}), tol) == -1);      // empty space
        Edge ed; Vec3 e2{0, -5, 5};
        assert(pickActiveEdge(c, e2, normalized(Vec3{0, 4, -4}), tol, &ed) && ed == mkEdge(4, 5));
        assert(!pickActiveEdge(c, Vec3{0, -5, 5}, normalized(Vec3{0, 1, 0.2f}), 0.001f, &ed));
    }

    // extrude edges of a plane (boundary edge) -> strip of quads, new edge selected, exact undo
    {
        Scene c; uint32_t pid = addPrimitive(c, 1); setEditMode(c, true); setSelectMode(c, 1);
        Mesh orig = c.find(pid)->mesh; c.toggleEdge(mkEdge(0, 1));
        assert(extrudeSelected(c, 0.5f));
        const Mesh& m = c.find(pid)->mesh;
        assert(m.v.size() == 6 && m.f.size() == 2 && validMesh(m));
        assert(m.v[4].z == 0.5f && m.v[5].z == 0.5f && c.sel.e.size() == 1 && *c.sel.e.begin() == mkEdge(4, 5));
        assert(c.undo() && sameMesh(c.find(pid)->mesh, orig) && c.sel.e.count(mkEdge(0, 1)) == 1);  // selection restored too
        assert(c.redo() && c.find(pid)->mesh.f.size() == 2);
        assert(!extrudeSelected(c, 0.f));
    }
    // extrude from vertex mode: 4 verts of a face extrude as a face; 2 verts extrude as an edge
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0);
        c.sel.v = {4, 5, 6, 7}; assert(extrudeSelected(c, 1.f));
        const Mesh& m = c.find(cid)->mesh; assert(m.v.size() == 12 && m.f.size() == 10 && closed(m) && c.sel.v.size() == 4);
        float maxz = -9; for (auto& v : m.v) maxz = std::max(maxz, v.z); assert(std::fabs(maxz - 2.f) < 1e-5f);
        setSelectMode(c, 0); c.sel.v = {0, 1}; assert(extrudeSelected(c, 0.3f)); assert(c.find(cid)->mesh.f.size() == 11);
    }
    // delete vertices / edges
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0);
        c.sel.v = {0}; assert(deleteSelection(c)); const Mesh& m = c.find(cid)->mesh;   // 3 faces touch a corner
        assert(m.f.size() == 3 && validMesh(m) && c.sel.v.empty()); assert(c.undo() && c.find(cid)->mesh.f.size() == 6 && c.sel.v.count(0));
        setSelectMode(c, 1); c.sel.clearSets(); c.toggleEdge(mkEdge(0, 1)); assert(deleteSelection(c) && c.find(cid)->mesh.f.size() == 4);
    }
    // inset: ring of quads, inner face keeps its index and orientation, area drops as expected
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(!insetSelected(c, 0.f) && !insetSelected(c, 1.f));
        assert(insetSelected(c, 0.5f)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m) && closed(m) && c.sel.f == std::set<int>({1}));
        assert(std::fabs(faceArea(m, m.f[1]) - 1.f) < 1e-5f);           // 2x2 face scaled by 0.5 -> 1x1
        assert(std::fabs(totalArea(m) - (20.f + 1.f + 3.f)) < 1e-4f);   // 5 untouched faces (20) + inner (1) + ring (4-1=3)
        assert(dot(faceNormal(m, m.f[1]), Vec3{0, 0, 1}) > 0.99f);
    }
    // subdivide: watertight, area preserved, neighbours get the new midpoints
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(subdivideSelected(c)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 13 && m.f.size() == 9 && validMesh(m) && closed(m) && c.sel.f.size() == 4);
        assert(std::fabs(totalArea(m) - 24.f) < 1e-4f);
        for (const auto& fc : m.f) assert(dot(faceNormal(m, fc), Vec3{0, 0, 0}) == 0 && length(faceNormal(m, fc)) > 0.99f);
        assert(subdivideSelected(c) && closed(c.find(cid)->mesh) && std::fabs(totalArea(c.find(cid)->mesh) - 24.f) < 1e-3f);  // repeatable
        assert(c.undo() && c.undo() && sameMesh(c.find(cid)->mesh, makeCube()));
    }
    // merge at center collapses a face into a vertex (cube -> pyramid-like, 5 verts / 5 faces)
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0); c.sel.v = {4, 5, 6, 7};
        assert(mergeSelectedAtCenter(c)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 5 && m.f.size() == 5 && validMesh(m) && closed(m) && c.sel.v.size() == 1);
        int tip = *c.sel.v.begin(); assert(std::fabs(m.v[tip].z - 1.f) < 1e-6f && std::fabs(m.v[tip].x) < 1e-6f);
        assert(!mergeSelectedAtCenter(c));   // one vertex is nothing to merge
    }
    // flip normals
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(flipSelectedFaces(c)); assert(dot(faceNormal(c.find(cid)->mesh, c.find(cid)->mesh.f[1]), Vec3{0, 0, 1}) < -0.99f);
        assert(c.undo() && sameMesh(c.find(cid)->mesh, makeCube()));
    }
    // edit-mode transforms about the pivot
    {
        Mesh m = makeCube(); std::vector<char> top(8, 0); for (int i = 4; i < 8; ++i) top[i] = 1;
        assert(moveVertices(m, top, Vec3{0, 0, 2}) && m.v[4].z == 3.f && m.v[0].z == -1.f);
        assert(scaleVertices(m, top, Vec3{0.5f, 0.5f, 1.f}) && std::fabs(m.v[6].x - 0.5f) < 1e-6f && m.v[6].z == 3.f);
        assert(rotateVertices(m, top, 2, 90.f) && std::fabs(m.v[6].x + 0.5f) < 1e-5f && std::fabs(m.v[6].y - 0.5f) < 1e-5f);
        std::vector<char> none(8, 0); assert(!moveVertices(m, none, Vec3{1, 0, 0}) && !rotateVertices(m, none, 0, 10.f));
    }
    // history keeps selection valid after the object is removed
    {
        Scene c; addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0); c.sel.v = {0, 1};
        c.undo(); assert(c.sel.v.empty() && !c.editMode);
    }

    puts("all tests passed"); return 0;
}
