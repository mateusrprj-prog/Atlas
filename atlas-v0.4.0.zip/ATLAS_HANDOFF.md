# ATLAS_HANDOFF.md — contexto completo do projeto (LEIA PRIMEIRO)

> **Versão do projeto: 0.4.0** · Atualizado em 2026-11-15
> Este arquivo existe porque o usuário já perdeu contexto uma vez (a IA anterior bateu no limite de uso sem exportar nada).

## 0. REGRAS PARA A IA QUE CONTINUAR (obrigatório)

1. **Toda vez que você fizer uma atualização, entregue DUAS coisas ao usuário:**
   - o projeto inteiro em `.zip` (mesma estrutura deste zip, sem `build/`, `.gradle/`, `.cxx/`);
   - **este arquivo `ATLAS_HANDOFF.md` atualizado**: novo número de versão, changelog, estado real, problemas conhecidos, próximos passos.
2. **Nunca diga que algo funciona no aparelho se você só testou no host.** Use os status do `FEATURES.md`
   (Not started / In development / Implemented but untested / Implemented and tested / Blocked).
3. Mantenha `docs/MASTER_PROMPT.md` (o prompt original do projeto) no repositório. Ele é a visão de longo prazo.
4. Responda ao usuário em **português (BR)**, tom direto e informal (ele escreve "cara", "tlgd"). Código, nomes de arquivos e commits em inglês.
5. Antes de mexer: leia `FEATURES.md`, `docs/ARCHITECTURE.md` e este arquivo. Depois de mexer: rode os testes, atualize docs, atualize este arquivo.
6. Não use código do Blender. O Atlas é independente (veja `docs/MASTER_PROMPT.md`, seções 1–2).

## 1. Quem é o usuário e como ele trabalha

- Desenvolve **pelo celular (Android), com IA + GitHub**. Não compila localmente.
- Fluxo: a IA entrega um `.zip` → o usuário sobe no GitHub → **GitHub Actions** (`.github/workflows/build.yml`) roda os testes do núcleo e compila o APK debug → ele baixa o APK (artifact `atlas-debug-apk`) e testa no celular.
- O workflow aceita um `.zip` na raiz do repo (extrai e compila) ou o projeto direto na raiz.
- Ele manda prints/vídeos do app rodando para guiar a UI. A UI deve se inspirar no **Blender desktop** (menos "mobile genérico"), mas continuar usável em toque.
- Última tela vista (v0.2.0, landscape, celular): barra Atlas/File/Edit/Render/Window/Help + abas de workspace; coluna de ferramentas à esquerda; header do viewport (Object Mode, View, Select, Add, Object, X Y Z, shading); Outliner + Properties à direita; status bar embaixo. Observações dessa tela: as abas/painel direito cortam na lateral (scroll horizontal), e o painel Properties fica pequeno em altura.

## 2. O que é o projeto (resumo do prompt mestre)

Atlas = app 3D profissional independente para Android, com ambição "nível Blender", mas **motor, formato de projeto, UI e arquitetura próprios**.
Prompt completo: `docs/MASTER_PROMPT.md`. Pontos que mais importam:
- Nada de botão sem operação real, nada de mockup, nada de feature "fake". Só marque completo se implementado **e testado**.
- Roadmap em fases (0–10): fundação+viewport → modelagem → import (OBJ/GLB/glTF) → materiais/UV → escultura → rig/animação → render → avançado → vídeo/VFX/scripts → release.
- Dependências: só licenças permissivas (MIT/BSD/Apache/zlib/MPL2). Documentar em `DEPENDENCIES.md` / `LICENSES.md` quando entrarem (ainda **não há dependência externa**).
- Arquitetura alvo: Kotlin (shell/UI/SAF) + C++ NDK (core) + JNI fino. Render alvo: Filament (ou GLES próprio) — reavaliar antes de escultura.

## 3. Estado atual (v0.4.0)

### Stack real hoje
- `app/src/main/kotlin/dev/atlas/` — `MainActivity.kt` (UI em Views programáticas, estilo Blender escuro), `NativeBridge.kt` (declarações JNI).
- `app/src/main/cpp/core/` — **núcleo header-only C++17, sem GL/JNI, testável no host**: `math3.hpp`, `mesh.hpp`, `scene.hpp`, `project_io.hpp`.
- `app/src/main/cpp/renderer.*` — GLES 3 próprio (grid, eixos, objetos, overlay de edição, gizmo de eixos). **Ainda não usa Filament.**
- `app/src/main/cpp/bridge.cpp` — ponte JNI + estado de arrasto interativo (um passo de undo por gesto).
- `tests/test_scene.cpp` — testes do núcleo (assert). `g++ -std=c++17 -Wall -Wextra -O1 tests/test_scene.cpp -o t && ./t`
- CI: `.github/workflows/build.yml` (testes do núcleo → APK debug). Gradle 8.9, JDK 17, NDK 26.1.10909125, minSdk 26, ABIs arm64-v8a + x86_64.

### Convenções
Z-up, destro; faces CCW = para fora; Euler XYZ em graus (R = Rz·Ry·Rx); formato de projeto v2 (texto, salvamento atômico tmp+rename, migra v1).
Todo acesso à cena pelo Kotlin passa por `act { }` (roda na thread GL, depois atualiza Outliner/Properties/status).

### Changelog
- **0.4.0 (esta versão)** — **Loop Cut** e **Select Edge Loop**:
  - Loop Cut: percorre o anel de quads da aresta selecionada (ou 2 vértices) e corta todos com um novo loop; a posição (0–1) vem do campo "Loop Cut Position" e fica consistente em todo o anel; triângulos/n-gons no fim de um anel aberto recebem o ponto (malha continua fechada). Seleciona o novo loop. Um passo de undo (restaura malha + seleção).
  - Select Edge Loop: estende a seleção atravessando vértices de valência 4 nos dois sentidos.
  - Testes novos: cubo (posição 0.25 em todas as arestas), plano (anel aberto), esfera (anel fechado e anel terminando nos polos), grade 4x4 (loop de 4 arestas), canto de cubo (loop = 1 aresta).
  - Menu Mesh ganhou os dois itens; versão 0.4.0 / versionCode 4.
- 0.3.0 — Modelagem com seleção por elemento:
  - Edit Mode com seleção **vértice / aresta / face** (botões ● ╱ ▣ no header), conversão entre modos como no Blender (vértice→aresta mantém arestas com as duas pontas selecionadas, etc.), Select All / None / Invert.
  - Picking de vértice e aresta com tolerância em pixels (~22 px) e teste de oclusão (não seleciona o que está atrás da malha).
  - Operações: **Extrude** (faces, arestas, e a partir de vértices — detecta faces completas, senão arestas), **Inset Faces**, **Subdivide** (sem T-junction: vizinhas recebem os pontos médios), **Merge at Center**, **Flip Normals**, **Delete** (vértices/arestas/faces).
  - **Mover / Rotacionar / Escalar** qualquer seleção em Edit Mode (pivô = ponto médio; rotação/escala em eixos locais).
  - Undo/redo agora restaura **malha + seleção** (`MeshEditCmd` guarda os dois).
  - Overlay no renderer: pontos de vértice, arestas selecionadas, faces selecionadas.
  - CI roda os testes do núcleo antes do APK. `docs/MASTER_PROMPT.md` agora faz parte do repo.
- 0.2.0 — Núcleo de malha poligonal (n-gons), primitivas (cubo/plano/cilindro/esfera UV), seleção de faces, extrude/delete de faces, undo/redo, formato v2, shell estilo Blender, viewport com orbit/pan/zoom/presets/gizmo.
- 0.1.0 — Esqueleto Android + viewport + cubos + save/load v1.

### O que foi verificado e o que NÃO foi
- ✅ Núcleo (`core/`) compila com `-Wall -Wextra` e **todos os testes passam** no host (inclui um teste mutante para garantir que os asserts realmente falham quando deveriam).
- ✅ `renderer.cpp` e `bridge.cpp` passam em checagem de sintaxe com headers GLES/JNI *stub*.
- ⚠️ **Kotlin NÃO foi compilado (0.3.0 e 0.4.0)** (não havia kotlinc/SDK no ambiente da IA). Reescrito com cuidado, mas o primeiro build do CI pode apontar erro de compilação — se acontecer, o log do Actions diz a linha; corrigir é rápido.
- ⚠️ **Nada foi testado no aparelho**: sensação do toque ao selecionar vértices/arestas, desenho dos pontos (`gl_PointSize`), gesto de arrastar em Edit Mode. Peça ao usuário um print/vídeo após instalar.

### Problemas conhecidos / dívida técnica
- Snapshot de malha inteira por passo de undo (ok para malhas pequenas; trocar por deltas antes da escultura).
- Triangulação em leque assume faces convexas.
- Loop Cut usa só a primeira aresta selecionada, um corte por operação.
- Inset é por face (não por região) e relativo ao centróide.
- Distância do Extrude vem de um campo numérico (Properties); depois o usuário arrasta com Move. Falta o extrude "interativo" estilo Blender (extrude + arrastar num gesto).
- Teste de oclusão do picking é O(faces) por candidato — precisa de BVH para malhas grandes.
- UI: abas de workspace e painel direito cortam em telas estreitas; Properties pequeno em altura; só Layout/Modeling funcionam (demais abas desabilitadas, e dizem isso).
- Objetos: lista plana, sem parent/collections/multi-seleção.
- Seleção não é salva no projeto (é estado de edição).

## 4. Próximos passos sugeridos (em ordem)

1. **Confirmar o build do CI e testar v0.4.0 (e o que ficou pendente da 0.3.0) no aparelho** (corrigir erros de Kotlin/GL se aparecerem). Pedir vídeo ao usuário.
2. Edit Mode: **Bevel**, **Edge Slide**, loop cut interativo (arrastar para posicionar), extrude interativo (gesto único), seleção linked, box select, loop cut em várias arestas.
3. Modificadores (Mirror, Subdivision Surface, Array) com avaliação não destrutiva — fecha a Fase 2 do roadmap.
4. Hierarquia de objetos (parent/child) + Collections no Outliner + multi-seleção.
5. UI: refinar para ficar mais "Blender desktop" — painéis redimensionáveis, Properties com abas (Object/Modifiers/Material), menus Add/Select/Mesh completos, atalhos de gesto, tema. Usar os prints do usuário como referência.
6. Fase 3: importadores OBJ/GLB/glTF (tinyobjloader / tinygltf — documentar licença em DEPENDENCIES.md).
7. Reavaliar Filament vs renderer próprio antes da Fase 4/5.

## 5. Como entregar uma atualização (checklist para a próxima IA)

1. Ler este arquivo + `FEATURES.md` + `docs/ARCHITECTURE.md`.
2. Implementar a lógica **no `core/` primeiro** (função pura em `mesh.hpp`, comando/seleção em `scene.hpp`), com teste em `tests/test_scene.cpp`.
3. Expor em `bridge.cpp` + `NativeBridge.kt`, ligar na UI (`MainActivity.kt`). Nomes JNI sem underscore.
4. Rodar: `g++ -std=c++17 -Wall -Wextra -O1 tests/test_scene.cpp -o t && ./t`.
5. Atualizar `FEATURES.md`, `docs/ARCHITECTURE.md`, `README.md`, `versionName/versionCode` (`app/build.gradle.kts`), string "Atlas x.y.z" no Kotlin, e **este arquivo** (changelog + estado + próximos passos).
6. Gerar o `.zip` do projeto e enviar junto com o `ATLAS_HANDOFF.md`. Dizer claramente o que foi testado e o que não foi.
