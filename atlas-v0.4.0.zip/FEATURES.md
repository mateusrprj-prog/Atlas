# Features (status per feature)
| Feature | Status |
|---|---|
| Scene graph (flat, single collection), persistent ids, unique names | Implemented and tested (host) |
| Polygon mesh core (n-gon faces), primitives: cube, plane, cylinder, UV sphere | Implemented and tested (host) |
| Edit Mode element selection: vertex / edge / face, mode conversion, select all/none/invert | Implemented and tested (host) |
| Picking of vertices and edges with occlusion test (screen-radius tolerance) | Implemented and tested (host); touch feel untested on device |
| Extrude: faces, edges (strip of quads), from vertex mode (auto-detects faces/edges) | Implemented and tested (host) |
| Inset faces (individual, towards centroid), Subdivide faces (watertight with neighbours), Merge at Center, Flip Normals | Implemented and tested (host) |
| Loop Cut (quad ring, position 0–1, consistent direction, watertight at ring ends) and Select Edge Loop (through valence-4 vertices) | Implemented and tested (host) |
| Delete vertices / edges / faces | Implemented and tested (host) |
| Edit-mode Move / Rotate / Scale of any selection about its median point | Implemented and tested (host math); drag gesture untested on device |
| Undo/redo restores mesh AND element selection | Implemented and tested (host) |
| Move / Rotate / Scale objects by drag, X/Y/Z constraint, one undo step per gesture | Implemented but untested on device |
| Numeric Location/Rotation/Scale fields (Properties) | Implemented but untested on device |
| Command undo/redo (add, delete, transform, mesh edit) | Implemented and tested (host) |
| Project format v2 (meshes), atomic save, v1 migration | Implemented and tested (host) |
| Viewport: orbit/pan/zoom, view presets, frame selected, wireframe/solid, axis gizmo | Implemented but untested on device |
| Edit overlay rendering (vertex dots, selected edges, selected faces) | Implemented but untested on device (compiles against stub GL only) |
| Blender-style shell: menus, workspace tabs, Outliner, Properties, header, status bar | Implemented but untested on device |
| Bevel, knife, bridge, edge slide, region inset, proportional editing | Not started |
| Parenting, collections, multi-select objects, local orientation, ortho view | Not started |
| Timeline / animation | Not started (Phase 6) |
| Workspaces other than Layout/Modeling | Not started (tabs are disabled) |
| Materials, UV, sculpt, rig, render, import/export | Not started |

Known limits: Loop Cut uses the first selected edge, one cut per operation, position from a numeric field (no interactive slide yet); edit snapshots copy the whole mesh per undo step (fine for small meshes); n-gon fan
triangulation assumes convex faces; Z-up like Blender (import converters will handle Y-up formats);
Inset is per-face (not region) and uses a centroid-relative amount; edge/face extrude distance comes from a
numeric field (the Move tool then drags the result); edit-mode rotate/scale use local axes; vertex/edge
occlusion test is O(faces) per candidate (fine for small meshes, needs a BVH later); loose vertices/edges
cannot exist (meshes are face-based, deleting faces removes orphan vertices).
