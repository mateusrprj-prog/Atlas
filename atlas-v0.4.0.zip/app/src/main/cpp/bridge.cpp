#include <jni.h>
#include <cmath>
#include <string>
#include "core/project_io.hpp"
#include "renderer.hpp"

using namespace atlas;

static Scene gScene;
static Renderer gRenderer;
static bool gStarted = false;

namespace {

// ---- interactive transform (move / rotate / scale) with one undo entry per gesture ----
struct Drag {
    bool active = false, editMesh = false, moved = false;
    int tool = 0, axis = 0; uint32_t id = 0;
    Xf before; Mesh meshBefore; SelState selBefore;
} gDrag;

Vec3 axisVec(int a) { return a == 1 ? Vec3{1, 0, 0} : a == 2 ? Vec3{0, 1, 0} : Vec3{0, 0, 1}; }

bool beginDrag(int tool, int axis) {
    gDrag.active = false;
    if (tool <= 0) return false;
    Object* o = gScene.find(gScene.selected);
    if (!o) return false;
    if (gScene.editMode) {
        std::vector<char> mask = selectedVertexMask(gScene.sel, o->mesh);
        if (std::find(mask.begin(), mask.end(), (char)1) == mask.end()) return false;
        gDrag.editMesh = true; gDrag.meshBefore = o->mesh; gDrag.selBefore = gScene.sel;
    } else gDrag.editMesh = false;
    gDrag.before = getXf(*o); gDrag.id = o->id; gDrag.tool = tool; gDrag.axis = axis;
    gDrag.moved = false; gDrag.active = true; return true;
}

void restoreDrag(Object& o) {
    setXf(o, gDrag.before);
    if (gDrag.editMesh) { o.mesh = gDrag.meshBefore; o.meshRev = nextRev(); }
}

void updateDrag(float dx, float dy) {
    Object* o = gScene.find(gDrag.id);
    if (!gDrag.active || !o) return;
    restoreDrag(*o);
    if (dx == 0 && dy == 0) return;
    gDrag.moved = true;
    Camera& c = gRenderer.cam; Vec3 f, r, u; c.basis(f, r, u);
    Vec3 p{o->pos[0], o->pos[1], o->pos[2]};
    float depth = dot(p - c.eye(), f); if (depth < 0.1f) depth = 0.1f;
    float wpp = 2.f * depth * std::tan(c.fovY * 0.5f) / (float)gRenderer.height;  // world units per pixel
    if (gDrag.tool == 1) {
        Vec3 delta;
        if (gDrag.axis == 0) delta = r * (dx * wpp) - u * (dy * wpp);
        else {
            Vec3 a = axisVec(gDrag.axis); float sx = dot(a, r), sy = dot(a, u), s2 = sx * sx + sy * sy;
            delta = s2 < 1e-4f ? Vec3{} : a * (((dx * sx - dy * sy) * wpp) / s2);
        }
        if (gDrag.editMesh) moveVertices(o->mesh, selectedVertexMask(gScene.sel, o->mesh), worldToLocalDir(*o, delta));
        else { o->pos[0] += delta.x; o->pos[1] += delta.y; o->pos[2] += delta.z; }
    } else if (gDrag.tool == 2) {
        int a = gDrag.axis ? gDrag.axis - 1 : 2;
        if (gDrag.editMesh) rotateVertices(o->mesh, selectedVertexMask(gScene.sel, o->mesh), a, dx * 0.4f);   // local axis
        else o->rot[a] += dx * 0.4f;
    } else if (gDrag.tool == 3) {
        float k = std::exp(dx * 0.005f);
        if (gDrag.editMesh) {
            Vec3 kk{gDrag.axis == 0 || gDrag.axis == 1 ? k : 1.f, gDrag.axis == 0 || gDrag.axis == 2 ? k : 1.f, gDrag.axis == 0 || gDrag.axis == 3 ? k : 1.f};
            scaleVertices(o->mesh, selectedVertexMask(gScene.sel, o->mesh), kk);
        } else for (int i = 0; i < 3; ++i) if (gDrag.axis == 0 || gDrag.axis - 1 == i) o->scale[i] *= k;
    }
    if (gDrag.editMesh) o->meshRev = nextRev();
}

void endDrag() {
    if (!gDrag.active) return;
    gDrag.active = false;
    Object* o = gScene.find(gDrag.id);
    if (!o || !gDrag.moved) return;
    if (gDrag.editMesh) gScene.record(std::make_unique<MeshEditCmd>(o->id, gDrag.meshBefore, o->mesh, gDrag.selBefore, gScene.sel));
    else { Xf after = getXf(*o); if (!sameXf(after, gDrag.before)) gScene.record(std::make_unique<TransformCmd>(o->id, gDrag.before, after)); }
}

void cancelDrag() {
    if (!gDrag.active) return;
    gDrag.active = false;
    if (Object* o = gScene.find(gDrag.id)) restoreDrag(*o);
}

void startupScene() {
    if (gStarted) return;
    gStarted = true;
    gScene.reset();
    Object o; o.id = gScene.nextId++; o.name = "Cube"; o.mesh = makeCube(); o.meshRev = nextRev();
    gScene.selected = o.id; gScene.objects.push_back(o);
}

}  // namespace

extern "C" {
#define FN(name) JNIEXPORT auto JNICALL Java_dev_atlas_NativeBridge_##name

FN(init)(JNIEnv*, jobject) -> void { gRenderer.init(); }
FN(resize)(JNIEnv*, jobject, jint w, jint h) -> void { gRenderer.resize(w, h); }
FN(draw)(JNIEnv*, jobject) -> void { gRenderer.draw(gScene); }
FN(ensureScene)(JNIEnv*, jobject) -> void { startupScene(); }
FN(newScene)(JNIEnv*, jobject) -> void {
    cancelDrag(); gScene.reset();
    Object o; o.id = gScene.nextId++; o.name = "Cube"; o.mesh = makeCube(); o.meshRev = nextRev();
    gScene.selected = o.id; gScene.objects.push_back(o);
}

// ---- camera ----
FN(orbit)(JNIEnv*, jobject, jfloat dx, jfloat dy) -> void {
    Camera& c = gRenderer.cam; c.yaw -= dx * 0.01f; c.pitch += dy * 0.01f;
    if (c.pitch > 1.55f) c.pitch = 1.55f;
    if (c.pitch < -1.55f) c.pitch = -1.55f;
}
FN(pan)(JNIEnv*, jobject, jfloat dx, jfloat dy) -> void {
    Camera& c = gRenderer.cam; Vec3 f, r, u; c.basis(f, r, u);
    float wpp = 2.f * c.dist * std::tan(c.fovY * 0.5f) / (float)gRenderer.height;
    c.target = c.target - r * (dx * wpp) + u * (dy * wpp);
}
FN(zoom)(JNIEnv*, jobject, jfloat k) -> void {
    Camera& c = gRenderer.cam; c.dist /= k;
    if (c.dist < 0.5f) c.dist = 0.5f;
    if (c.dist > 100.f) c.dist = 100.f;
}
FN(viewPreset)(JNIEnv*, jobject, jint p) -> void {
    Camera& c = gRenderer.cam; const float h = 1.5707963f;
    switch (p) {
        case 0: c.yaw = -h; c.pitch = 0; break;       // front
        case 1: c.yaw = h; c.pitch = 0; break;        // back
        case 2: c.yaw = 0; c.pitch = 0; break;        // right
        case 3: c.yaw = 2 * h; c.pitch = 0; break;    // left
        case 4: c.yaw = -h; c.pitch = 1.55f; break;   // top
        default: c.yaw = -h; c.pitch = -1.55f; break; // bottom
    }
}
FN(resetView)(JNIEnv*, jobject) -> void { float asp = gRenderer.cam.aspect; gRenderer.cam = Camera(); gRenderer.cam.aspect = asp; }
FN(frameSelected)(JNIEnv*, jobject) -> jboolean {
    const Object* o = gScene.find(gScene.selected);
    if (!o) return false;
    float rad = 0; for (const auto& v : o->mesh.v) rad = std::max(rad, length(v));
    float sc = std::max(o->scale[0], std::max(o->scale[1], o->scale[2]));
    gRenderer.cam.target = Vec3{o->pos[0], o->pos[1], o->pos[2]};
    gRenderer.cam.dist = std::max(3.f, rad * sc * 3.f); return true;
}
FN(setShading)(JNIEnv*, jobject, jint m) -> void { gRenderer.shading = m; }

// ---- scene operations ----
FN(addPrimitive)(JNIEnv*, jobject, jint kind) -> jboolean { if (gScene.editMode) return false; cancelDrag(); addPrimitive(gScene, kind); return true; }
FN(duplicateSelected)(JNIEnv*, jobject) -> jboolean { return duplicateSelected(gScene) != 0; }
FN(deleteSelected)(JNIEnv*, jobject) -> jboolean { return deleteSelectedObject(gScene); }
FN(selectObject)(JNIEnv*, jobject, jint id) -> jboolean {
    if (gScene.editMode || !gScene.find((uint32_t)id)) return false;
    gScene.selected = (uint32_t)id; return true;
}
FN(selectAll)(JNIEnv*, jobject) -> void { selectAllActive(gScene); }
FN(selectInvert)(JNIEnv*, jobject) -> void { invertActive(gScene); }
FN(selectNone)(JNIEnv*, jobject) -> void { if (gScene.editMode) gScene.sel.clearSets(); else gScene.selected = 0; }
FN(tap)(JNIEnv*, jobject, jfloat x, jfloat y) -> jint {
    Vec3 o, d; gRenderer.screenRay(x, y, o, d);
    if (gScene.editMode) {
        const float tol = 22.f * 2.f * std::tan(gRenderer.cam.fovY * 0.5f) / (float)gRenderer.height;   // ~22 px pick radius
        int hit = -1;
        if (gScene.sel.mode == 0) { hit = pickActiveVertex(gScene, o, d, tol); if (hit >= 0) gScene.toggleVertex(hit); }
        else if (gScene.sel.mode == 1) { Edge e; if (pickActiveEdge(gScene, o, d, tol, &e)) { gScene.toggleEdge(e); hit = 1; } }
        else { hit = pickActiveFace(gScene, o, d); if (hit >= 0) gScene.toggleFace(hit); }
        if (hit < 0) gScene.sel.clearSets();
        return hit;
    }
    gScene.selected = pickObject(gScene, o, d); return (jint)gScene.selected;
}
FN(setMode)(JNIEnv*, jobject, jint m) -> jboolean { cancelDrag(); return setEditMode(gScene, m == 1); }
FN(mode)(JNIEnv*, jobject) -> jint { return gScene.editMode ? 1 : 0; }
FN(setSelectMode)(JNIEnv*, jobject, jint m) -> jboolean { cancelDrag(); return setSelectMode(gScene, m); }
FN(selectMode)(JNIEnv*, jobject) -> jint { return gScene.sel.mode; }
FN(extrude)(JNIEnv*, jobject, jfloat dist) -> jboolean { cancelDrag(); return extrudeSelected(gScene, dist); }
FN(deleteSelection)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return deleteSelection(gScene); }
FN(insetFaces)(JNIEnv*, jobject, jfloat amount) -> jboolean { cancelDrag(); return insetSelected(gScene, amount); }
FN(subdivide)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return subdivideSelected(gScene); }
FN(mergeCenter)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return mergeSelectedAtCenter(gScene); }
FN(loopCut)(JNIEnv*, jobject, jfloat t) -> jboolean { cancelDrag(); return loopCutSelected(gScene, t); }
FN(selectLoop)(JNIEnv*, jobject) -> jboolean { return selectLoopActive(gScene); }
FN(flipNormals)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return flipSelectedFaces(gScene); }

// ---- interactive transform ----
FN(beginTransform)(JNIEnv*, jobject, jint tool, jint axis) -> jboolean { return beginDrag(tool, axis); }
FN(dragStep)(JNIEnv*, jobject, jfloat tdx, jfloat tdy, jfloat sdx, jfloat sdy) -> void {
    if (gDrag.active) updateDrag(tdx, tdy);
    else {
        Camera& c = gRenderer.cam; c.yaw -= sdx * 0.01f; c.pitch += sdy * 0.01f;
        if (c.pitch > 1.55f) c.pitch = 1.55f;
        if (c.pitch < -1.55f) c.pitch = -1.55f;
    }
}
FN(endTransform)(JNIEnv*, jobject) -> void { endDrag(); }
FN(cancelTransform)(JNIEnv*, jobject) -> void { cancelDrag(); }

// ---- history & files ----
FN(undo)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return gScene.undo(); }
FN(redo)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return gScene.redo(); }
FN(save)(JNIEnv* env, jobject, jstring path) -> jboolean {
    const char* p = env->GetStringUTFChars(path, nullptr);
    bool ok = saveProject(gScene, p); env->ReleaseStringUTFChars(path, p); return ok;
}
FN(load)(JNIEnv* env, jobject, jstring path) -> jboolean {
    cancelDrag();
    const char* p = env->GetStringUTFChars(path, nullptr);
    bool ok = loadProject(gScene, p); env->ReleaseStringUTFChars(path, p); return ok;
}

// ---- state for the UI ----
FN(outliner)(JNIEnv* env, jobject) -> jstring {
    std::string s;
    for (const auto& o : gScene.objects) {
        if (!s.empty()) s += "\n";
        s += std::to_string(o.id) + "\t" + o.name + "\t" + (o.id == gScene.selected ? "1" : "0");
    }
    return env->NewStringUTF(s.c_str());
}
FN(stats)(JNIEnv* env, jobject) -> jstring {
    size_t v = 0, f = 0;
    for (const auto& o : gScene.objects) { v += o.mesh.v.size(); f += o.mesh.f.size(); }
    std::string s = "Objetos " + std::to_string(gScene.objects.size()) + "  Verts " + std::to_string(v) + "  Faces " + std::to_string(f);
    if (gScene.editMode) {
        const Object* a = gScene.find(gScene.selected);
        size_t tot = 0;
        if (a) tot = gScene.sel.mode == 0 ? a->mesh.v.size() : gScene.sel.mode == 1 ? uniqueEdges(a->mesh).size() : a->mesh.f.size();
        s += "  Sel " + std::to_string(selectionCount(gScene.sel)) + "/" + std::to_string(tot);
    }
    return env->NewStringUTF(s.c_str());
}
FN(activeTransform)(JNIEnv* env, jobject) -> jfloatArray {
    const Object* o = gScene.find(gScene.selected);
    if (!o) return env->NewFloatArray(0);
    float v[9]; for (int i = 0; i < 3; ++i) { v[i] = o->pos[i]; v[3 + i] = o->rot[i]; v[6 + i] = o->scale[i]; }
    jfloatArray a = env->NewFloatArray(9); env->SetFloatArrayRegion(a, 0, 9, v); return a;
}
FN(setActiveTransform)(JNIEnv* env, jobject, jfloatArray arr) -> jboolean {
    if (env->GetArrayLength(arr) != 9) return false;
    float v[9]; env->GetFloatArrayRegion(arr, 0, 9, v);
    for (float x : v) if (!std::isfinite(x)) return false;
    Xf a; for (int i = 0; i < 3; ++i) { a.pos[i] = v[i]; a.rot[i] = v[3 + i]; a.scale[i] = v[6 + i]; }
    return setObjectTransform(gScene, a);
}
}
