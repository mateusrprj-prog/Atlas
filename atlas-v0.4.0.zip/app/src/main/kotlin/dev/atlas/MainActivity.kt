package dev.atlas

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

private data class Item(val title: String, val enabled: Boolean = true, val action: () -> Unit = {})
private class Snap(val outliner: String, val xf: FloatArray, val stats: String, val mode: Int, val selMode: Int)

class MainActivity : Activity() {
    private lateinit var gl: GLSurfaceView
    private lateinit var root: LinearLayout
    private val projectPath get() = File(filesDir, "project.atlas").absolutePath

    // palette inspired by a dark desktop 3D editor
    private val cTop = Color.parseColor("#181818")
    private val cHeader = Color.parseColor("#303030")
    private val cPanel = Color.parseColor("#282828")
    private val cField = Color.parseColor("#1d1d1d")
    private val cText = Color.parseColor("#D9D9D9")
    private val cDim = Color.parseColor("#8A8A8A")
    private val cAccent = Color.parseColor("#4772B3")
    private val cRowSel = Color.parseColor("#334C75")
    private val cTabActive = Color.parseColor("#3D3D3D")

    private var tool = 0          // 0 select, 1 move, 2 rotate, 3 scale
    private var axis = 0          // 0 free, 1 X, 2 Y, 3 Z
    private var mode = 0          // 0 object, 1 edit
    private var selMode = 0       // edit-mode elements: 0 vertex, 1 edge, 2 face
    private var shading = 0
    private var fullscreen = false

    private val toolButtons = ArrayList<TextView>()
    private val axisButtons = ArrayList<TextView>()
    private val shadeButtons = ArrayList<TextView>()
    private val selModeButtons = ArrayList<TextView>()
    private lateinit var selModeBox: LinearLayout
    private lateinit var editHint: TextView
    private lateinit var insetField: EditText
    private lateinit var cutField: EditText
    private val tabViews = LinkedHashMap<String, TextView>()
    private val xfFields = ArrayList<EditText>()
    private lateinit var modeBtn: TextView
    private lateinit var addBtn: TextView
    private lateinit var objBtn: TextView
    private lateinit var meshBtn: TextView
    private lateinit var outlinerBox: LinearLayout
    private lateinit var nameLabel: TextView
    private lateinit var extrudeRow: LinearLayout
    private lateinit var extrudeField: EditText
    private lateinit var statusLeft: TextView
    private lateinit var toolbar: View
    private lateinit var rightPanel: View
    private lateinit var statusBar: View

    private val workspaces = listOf("Layout", "Modeling", "Sculpting", "UV Editing", "Texture Paint", "Shading",
        "Animation", "Rendering", "Compositing", "Geometry Nodes", "Scripting")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cTop)
            isFocusableInTouchMode = true
        }
        gl = ViewportView()
        toolbar = buildToolbar()
        rightPanel = buildRightPanel()
        statusBar = buildStatusBar()

        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        center.addView(buildHeader(), LinearLayout.LayoutParams(-1, dp(34)))
        center.addView(gl, LinearLayout.LayoutParams(-1, 0, 1f))

        val main = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        main.addView(toolbar, LinearLayout.LayoutParams(dp(44), -1))
        main.addView(center, LinearLayout.LayoutParams(0, -1, 1f))
        main.addView(rightPanel, LinearLayout.LayoutParams(dp(250), -1))

        root.addView(buildTopBar(), LinearLayout.LayoutParams(-1, dp(36)))
        root.addView(main, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(statusBar, LinearLayout.LayoutParams(-1, dp(24)))
        setContentView(root)
        selectTool(0); refreshAxis(); refreshShading()
        root.requestFocus()
        act { NativeBridge.ensureScene() }
    }

    override fun onPause() { super.onPause(); gl.onPause() }
    override fun onResume() { super.onResume(); gl.onResume() }

    // ---------------------------------------------------------------- helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    private fun fmt(v: Float) = String.format(Locale.US, "%.3f", v)

    private fun roundBg(color: Int, radius: Int = 4) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun label(t: String, size: Float = 12f, color: Int = cText): TextView = TextView(this).apply {
        this.text = t; textSize = size; setTextColor(color)
        setPadding(dp(9), dp(4), dp(9), dp(4)); gravity = Gravity.CENTER_VERTICAL
    }

    /** Runs [block] on the GL thread (the only thread allowed to touch the scene), then refreshes the panels. */
    private fun act(block: () -> Unit) {
        gl.queueEvent {
            block()
            val snap = Snap(NativeBridge.outliner(), NativeBridge.activeTransform(), NativeBridge.stats(), NativeBridge.mode(), NativeBridge.selectMode())
            runOnUiThread { applySnap(snap) }
        }
    }

    private fun popup(anchor: View, items: List<Item>) {
        val pm = PopupMenu(this, anchor)
        items.forEachIndexed { i, item -> pm.menu.add(0, i, i, item.title).isEnabled = item.enabled }
        pm.setOnMenuItemClickListener { mi -> items[mi.itemId].action(); true }
        pm.show()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        currentFocus?.let { imm.hideSoftInputFromWindow(it.windowToken, 0); it.clearFocus() }
        root.requestFocus()
    }

    // ---------------------------------------------------------------- top bar (menus + workspace tabs)
    private fun buildTopBar(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(label("Atlas", 14f, Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD })
        fun menu(name: String, items: () -> List<Item>) {
            val b = label(name, 13f); b.setOnClickListener { popup(b, items()) }; row.addView(b)
        }
        menu("File") { fileItems() }
        menu("Edit") { editItems() }
        menu("Render") { listOf(Item("Render Image… (Fase 7)", enabled = false)) }
        menu("Window") { listOf(Item("Alternar viewport em tela cheia") { toggleFullscreen() }) }
        menu("Help") { listOf(Item("Sobre o Atlas") { showAbout() }) }
        row.addView(View(this), LinearLayout.LayoutParams(dp(14), 1))
        for (name in workspaces) {
            val t = label(name, 13f)
            tabViews[name] = t
            t.setOnClickListener {
                when (name) {
                    "Layout" -> act { NativeBridge.setMode(0) }
                    "Modeling" -> act { if (!NativeBridge.setMode(1)) toast("Selecione um objeto primeiro") }
                    else -> toast("$name: ainda não implementado")
                }
            }
            row.addView(t)
        }
        return HorizontalScrollView(this).apply {
            setBackgroundColor(cTop); isHorizontalScrollBarEnabled = false; addView(row)
        }
    }

    private fun fileItems() = listOf(
        Item("New") {
            AlertDialog.Builder(this).setMessage("Descartar a cena atual?")
                .setPositiveButton("Sim") { _, _ -> act { NativeBridge.newScene() } }
                .setNegativeButton("Não", null).show()
        },
        Item("Open") { act { toast(if (NativeBridge.load(projectPath)) "Projeto aberto" else "Falha ao abrir (ou não há projeto salvo)") } },
        Item("Save") { act { toast(if (NativeBridge.save(projectPath)) "Projeto salvo" else "Falha ao salvar") } },
        Item("Import… (Fase 3)", enabled = false),
        Item("Export… (Fase 3)", enabled = false))

    private fun editItems() = listOf(
        Item("Undo") { act { if (!NativeBridge.undo()) toast("Nada para desfazer") } },
        Item("Redo") { act { if (!NativeBridge.redo()) toast("Nada para refazer") } })

    private fun toggleFullscreen() {
        fullscreen = !fullscreen
        val vis = if (fullscreen) View.GONE else View.VISIBLE
        toolbar.visibility = vis; rightPanel.visibility = vis; statusBar.visibility = vis
    }

    private fun showAbout() {
        AlertDialog.Builder(this).setTitle("Atlas 0.4.0")
            .setMessage("Aplicativo 3D independente para Android.\nMotor, formato de projeto e interface próprios, sem código do Blender.")
            .setPositiveButton("OK", null).show()
    }

    // ---------------------------------------------------------------- tool column
    private fun buildToolbar(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cPanel); setPadding(dp(4), dp(6), dp(4), dp(6)) }
        val icons = listOf("⬚" to "Select", "✥" to "Move", "⟳" to "Rotate", "⤢" to "Scale")
        icons.forEachIndexed { i, (ic, _) ->
            val b = label(ic, 20f).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, 0) }
            b.setOnClickListener { selectTool(i) }
            toolButtons.add(b)
            col.addView(b, LinearLayout.LayoutParams(dp(36), dp(36)).apply { bottomMargin = dp(4) })
        }
        return col
    }

    private fun selectTool(i: Int) {
        tool = i
        toolButtons.forEachIndexed { k, b -> b.background = roundBg(if (k == i) cAccent else cHeader) }
    }

    // ---------------------------------------------------------------- viewport header
    private fun buildHeader(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun drop(t: String, items: () -> List<Item>): TextView {
            val b = label("$t ▾", 12f); b.setOnClickListener { popup(b, items()) }; row.addView(b); return b
        }
        modeBtn = drop("Object Mode") {
            listOf(Item("Object Mode") { act { NativeBridge.setMode(0) } },
                   Item("Edit Mode") { act { if (!NativeBridge.setMode(1)) toast("Selecione um objeto primeiro") } })
        }
        modeBtn.background = roundBg(cField)
        drop("View") { viewItems() }
        drop("Select") { selectItems() }
        addBtn = drop("Add") { addItems() }
        objBtn = drop("Object") { objectItems() }
        meshBtn = drop("Mesh") { meshItems() }
        // vertex / edge / face select mode (edit mode only)
        selModeBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf("●" to "Vertex", "╱" to "Edge", "▣" to "Face").forEachIndexed { i, (ic, _) ->
            val b = label(ic, 15f).apply { gravity = Gravity.CENTER }
            b.setOnClickListener { act { NativeBridge.setSelectMode(i) } }
            selModeButtons.add(b); selModeBox.addView(b)
        }
        row.addView(selModeBox)
        row.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        listOf("X" to "#D9494D", "Y" to "#7FBF3F", "Z" to "#4080F2").forEachIndexed { i, (n, c) ->
            val b = label(n, 13f, Color.parseColor(c)).apply { gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD }
            b.setOnClickListener { axis = if (axis == i + 1) 0 else i + 1; refreshAxis() }
            axisButtons.add(b); row.addView(b)
        }
        row.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        listOf("◼" to 0, "▦" to 1).forEach { (ic, m) ->
            val b = label(ic, 14f).apply { gravity = Gravity.CENTER }
            b.setOnClickListener { shading = m; refreshShading(); act { NativeBridge.setShading(m) } }
            shadeButtons.add(b); row.addView(b)
        }
        return HorizontalScrollView(this).apply { setBackgroundColor(cHeader); isHorizontalScrollBarEnabled = false; addView(row) }
    }

    private fun refreshAxis() = axisButtons.forEachIndexed { i, b -> b.background = roundBg(if (axis == i + 1) cAccent else Color.TRANSPARENT) }
    private fun refreshShading() = shadeButtons.forEachIndexed { i, b -> b.background = roundBg(if (shading == i) cAccent else Color.TRANSPARENT) }

    private fun viewItems() = listOf(
        Item("Front") { act { NativeBridge.viewPreset(0) } }, Item("Back") { act { NativeBridge.viewPreset(1) } },
        Item("Right") { act { NativeBridge.viewPreset(2) } }, Item("Left") { act { NativeBridge.viewPreset(3) } },
        Item("Top") { act { NativeBridge.viewPreset(4) } }, Item("Bottom") { act { NativeBridge.viewPreset(5) } },
        Item("Frame Selected") { act { if (!NativeBridge.frameSelected()) toast("Nada selecionado") } },
        Item("Reset View") { act { NativeBridge.resetView() } })

    private fun selectItems() =
        if (mode == 1) listOf(Item("All") { act { NativeBridge.selectAll() } }, Item("None") { act { NativeBridge.selectNone() } },
            Item("Invert") { act { NativeBridge.selectInvert() } })
        else listOf(Item("None") { act { NativeBridge.selectNone() } })

    private fun addItems() = listOf("Cube", "Plane", "Cylinder", "UV Sphere").mapIndexed { i, n ->
        Item(n) { act { NativeBridge.addPrimitive(i) } }
    }

    private fun objectItems() = listOf(
        Item("Duplicate") { act { if (!NativeBridge.duplicateSelected()) toast("Nada selecionado") } },
        Item("Delete") { act { if (!NativeBridge.deleteSelected()) toast("Nada selecionado") } })

    private fun floatOf(f: EditText, def: Float) = f.text.toString().replace(',', '.').toFloatOrNull() ?: def

    private fun meshItems() = listOf(
        Item("Extrude (vértices/arestas/faces)") {
            val d = floatOf(extrudeField, 0.5f)
            act { if (!NativeBridge.extrude(d)) toast("Selecione arestas ou faces completas e use distância ≠ 0") }
        },
        Item("Inset Faces") {
            val a = floatOf(insetField, 0.3f)
            act { if (!NativeBridge.insetFaces(a)) toast("Selecione faces e use um valor entre 0 e 1 (exclusivo)") }
        },
        Item("Loop Cut (1 aresta selecionada)") {
            val t = floatOf(cutField, 0.5f)
            act { if (!NativeBridge.loopCut(t)) toast("Selecione uma aresta (ou 2 vértices) e use um valor entre 0 e 1 (exclusivo)") }
        },
        Item("Select Edge Loop") { act { if (!NativeBridge.selectLoop()) toast("Selecione uma aresta primeiro") } },
        Item("Subdivide") { act { if (!NativeBridge.subdivide()) toast("Selecione faces (ou vértices/arestas que formem faces)") } },
        Item("Merge at Center") { act { if (!NativeBridge.mergeCenter()) toast("Selecione 2 ou mais vértices") } },
        Item("Flip Normals") { act { if (!NativeBridge.flipNormals()) toast("Selecione faces") } },
        Item("Delete") { act { if (!NativeBridge.deleteSelection()) toast("Nada selecionado") } })

    // ---------------------------------------------------------------- right panel: outliner + properties
    private fun buildRightPanel(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cPanel) }
        col.addView(label("Outliner", 12f, cDim).apply { setBackgroundColor(cHeader) }, LinearLayout.LayoutParams(-1, dp(28)))
        outlinerBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(ScrollView(this).apply { addView(outlinerBox) }, LinearLayout.LayoutParams(-1, 0, 1f))
        col.addView(label("Properties", 12f, cDim).apply { setBackgroundColor(cHeader) }, LinearLayout.LayoutParams(-1, dp(28)))

        val props = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(8)) }
        nameLabel = label("Nenhum objeto selecionado", 13f)
        props.addView(nameLabel)
        props.addView(label("Transform", 11f, cDim))
        props.addView(transformRow("Location"))
        props.addView(transformRow("Rotation (°)"))
        props.addView(transformRow("Scale"))
        extrudeRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), 0) }
        editHint = TextView(this).apply { textSize = 11f; setTextColor(cDim) }
        extrudeRow.addView(editHint)
        extrudeRow.addView(TextView(this).apply { text = "Extrude Distance"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(6), 0, 0) })
        extrudeField = numberField(); extrudeField.setText("0.5")
        extrudeRow.addView(extrudeField, LinearLayout.LayoutParams(-1, -2))
        extrudeRow.addView(TextView(this).apply { text = "Inset Amount (0–1)"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(6), 0, 0) })
        insetField = numberField(); insetField.setText("0.3")
        extrudeRow.addView(insetField, LinearLayout.LayoutParams(-1, -2))
        extrudeRow.addView(TextView(this).apply { text = "Loop Cut Position (0–1)"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(6), 0, 0) })
        cutField = numberField(); cutField.setText("0.5")
        extrudeRow.addView(cutField, LinearLayout.LayoutParams(-1, -2))
        props.addView(extrudeRow)
        col.addView(ScrollView(this).apply { addView(props) }, LinearLayout.LayoutParams(-1, 0, 1.6f))
        return col
    }

    private fun numberField(): EditText = EditText(this).apply {
        textSize = 12f; setTextColor(cText); background = roundBg(cField)
        setPadding(dp(6), dp(4), dp(6), dp(4)); setSingleLine(true)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        imeOptions = EditorInfo.IME_ACTION_DONE
    }

    private fun transformRow(title: String): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(2)) }
        col.addView(TextView(this).apply { text = title; textSize = 11f; setTextColor(cDim) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until 3) {
            val et = numberField()
            et.setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) { commitTransform(); hideKeyboard(); true } else false
            }
            et.setOnFocusChangeListener { _, has -> if (!has) commitTransform() }
            xfFields.add(et)
            row.addView(et, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = if (i < 2) dp(3) else 0 })
        }
        col.addView(row)
        return col
    }

    private fun commitTransform() {
        val arr = FloatArray(9)
        for (i in 0 until 9) {
            val v = xfFields[i].text.toString().replace(',', '.').toFloatOrNull()
            if (v == null) { act { }; return }
            arr[i] = v
        }
        act { NativeBridge.setActiveTransform(arr) }
    }

    private fun buildStatusBar(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(cTop); gravity = Gravity.CENTER_VERTICAL }
        statusLeft = label("", 11f, cDim)
        row.addView(statusLeft, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(label("Atlas 0.4.0", 11f, cDim))
        return row
    }

    // ---------------------------------------------------------------- state -> UI
    private fun applySnap(s: Snap) {
        mode = s.mode
        tabViews.forEach { (n, v) ->
            val active = (n == "Layout" && mode == 0) || (n == "Modeling" && mode == 1)
            v.background = roundBg(if (active) cTabActive else Color.TRANSPARENT)
            v.alpha = if (n == "Layout" || n == "Modeling") 1f else 0.4f
        }
        modeBtn.text = if (mode == 0) "Object Mode ▾" else "Edit Mode ▾"
        addBtn.visibility = if (mode == 0) View.VISIBLE else View.GONE
        objBtn.visibility = if (mode == 0) View.VISIBLE else View.GONE
        meshBtn.visibility = if (mode == 1) View.VISIBLE else View.GONE
        extrudeRow.visibility = if (mode == 1) View.VISIBLE else View.GONE
        selModeBox.visibility = if (mode == 1) View.VISIBLE else View.GONE
        selMode = s.selMode
        selModeButtons.forEachIndexed { i, b -> b.background = roundBg(if (selMode == i) cAccent else Color.TRANSPARENT) }
        editHint.text = when (selMode) {
            0 -> "Edit Mode (vértices) · toque num vértice; toque de novo para desmarcar"
            1 -> "Edit Mode (arestas) · toque numa aresta"
            else -> "Edit Mode (faces) · toque numa face"
        }

        outlinerBox.removeAllViews()
        outlinerBox.addView(label("▾ Scene Collection", 12f))
        outlinerBox.addView(label("   ▾ Collection", 12f).apply { setPadding(dp(18), dp(4), dp(9), dp(4)) })
        var selName = ""
        if (s.outliner.isNotEmpty()) for (line in s.outliner.split("\n")) {
            val p = line.split("\t"); if (p.size < 3) continue
            val id = p[0].toIntOrNull() ?: continue
            val sel = p[2] == "1"; if (sel) selName = p[1]
            val row = label("▽  ${p[1]}", 12f, if (sel) Color.WHITE else cText).apply {
                setPadding(dp(34), dp(5), dp(9), dp(5)); background = roundBg(if (sel) cRowSel else Color.TRANSPARENT, 3)
            }
            row.setOnClickListener { act { NativeBridge.selectObject(id) } }
            outlinerBox.addView(row)
        }

        val has = s.xf.size == 9
        nameLabel.text = if (has) selName else "Nenhum objeto selecionado"
        for (i in 0 until 9) {
            val et = xfFields[i]
            et.isEnabled = has && mode == 0
            if (!et.hasFocus()) et.setText(if (has) fmt(s.xf[i]) else "")
        }
        statusLeft.text = (if (has) "$selName  ·  " else "") + s.stats + "  ·  " +
            (if (mode == 0) "Object Mode" else "Edit Mode (" + listOf("vértices", "arestas", "faces")[selMode] + ")")
    }

    // ---------------------------------------------------------------- viewport + touch
    inner class ViewportView : GLSurfaceView(this@MainActivity) {
        private var lastX = 0f; private var lastY = 0f; private var downX = 0f; private var downY = 0f
        private var downT = 0L; private var multi = false; private var dragging = false
        private var lastMidX = 0f; private var lastMidY = 0f
        private val scale = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val f = d.scaleFactor; queueEvent { NativeBridge.zoom(f) }; return true
            }
        })
        init {
            setEGLContextClientVersion(3)
            setRenderer(object : Renderer {
                override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) = NativeBridge.init()
                override fun onSurfaceChanged(g: GL10?, w: Int, h: Int) = NativeBridge.resize(w, h)
                override fun onDrawFrame(g: GL10?) = NativeBridge.draw()
            })
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            scale.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    hideKeyboard()
                    lastX = e.x; lastY = e.y; downX = e.x; downY = e.y; downT = e.eventTime
                    multi = false; dragging = false
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    if (dragging) { dragging = false; queueEvent { NativeBridge.cancelTransform() } }
                    multi = true
                    if (e.pointerCount >= 2) { lastMidX = (e.getX(0) + e.getX(1)) / 2; lastMidY = (e.getY(0) + e.getY(1)) / 2 }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (e.pointerCount >= 2) {
                        val mx = (e.getX(0) + e.getX(1)) / 2; val my = (e.getY(0) + e.getY(1)) / 2
                        val dx = mx - lastMidX; val dy = my - lastMidY
                        lastMidX = mx; lastMidY = my
                        if (tool == 0) queueEvent { NativeBridge.pan(dx, dy) }
                        else queueEvent { NativeBridge.orbit(dx, dy) }
                    } else if (!multi) {
                        val tdx = e.x - downX; val tdy = e.y - downY
                        val sdx = e.x - lastX; val sdy = e.y - lastY
                        if (!dragging && Math.hypot(tdx.toDouble(), tdy.toDouble()) > 16) {
                            dragging = true
                            val t = tool; val a = axis
                            if (t != 0) queueEvent { NativeBridge.beginTransform(t, a) }
                        }
                        if (dragging) {
                            if (tool == 0) queueEvent { NativeBridge.orbit(sdx, sdy) }
                            else queueEvent { NativeBridge.dragStep(tdx, tdy, sdx, sdy) }
                        }
                        lastX = e.x; lastY = e.y
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!multi) {
                        val x = e.x; val y = e.y
                        if (!dragging && e.eventTime - downT < 400) act { NativeBridge.tap(x, y) }
                        else if (dragging && tool != 0) act { NativeBridge.endTransform() }
                    }
                    dragging = false; multi = false
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (dragging) queueEvent { NativeBridge.cancelTransform() }
                    dragging = false; multi = false
                }
            }
            return true
        }
    }
}
