// Atlas core: scene model, transforms, selection state, command-based undo/redo. No GL, no JNI.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <map>
#include <memory>
#include <set>
#include <string>
#include <vector>
#include "mesh.hpp"
#include "modifiers.hpp"

namespace atlas {

// Monotonic revision stamp: renderers cache GPU data per (object id, meshRev).
inline uint64_t nextRev() { static uint64_t r = 0; return ++r; }

struct Xf { float pos[3] = {0, 0, 0}; float rot[3] = {0, 0, 0}; float scale[3] = {1, 1, 1}; };

struct Object {
    uint32_t id = 0;
    std::string name;
    float pos[3] = {0, 0, 0};
    float rot[3] = {0, 0, 0};   // Euler XYZ in degrees, R = Rz*Ry*Rx
    float scale[3] = {1, 1, 1};
    Mesh mesh;
    uint64_t meshRev = 0;
    std::vector<Modifier> mods;
    uint64_t modsRev = 0;
    // evaluated-mesh cache (valid while both revisions match)
    mutable Mesh evalMesh; mutable uint64_t evalMeshRev = ~0ull, evalModsRev = ~0ull;
};

// What the viewport shows and picks: the base mesh, or the modifier-stack result.
inline const Mesh& displayMesh(const Object& o) {
    if (!anyEnabled(o.mods)) return o.mesh;
    if (o.evalMeshRev != o.meshRev || o.evalModsRev != o.modsRev) {
        o.evalMesh = evaluateStack(o.mesh, o.mods); o.evalMeshRev = o.meshRev; o.evalModsRev = o.modsRev;
    }
    return o.evalMesh;
}

inline Xf getXf(const Object& o) {
    Xf x; for (int i = 0; i < 3; ++i) { x.pos[i] = o.pos[i]; x.rot[i] = o.rot[i]; x.scale[i] = o.scale[i]; } return x;
}
inline void setXf(Object& o, const Xf& x) {
    for (int i = 0; i < 3; ++i) { o.pos[i] = x.pos[i]; o.rot[i] = x.rot[i]; o.scale[i] = x.scale[i]; }
}
inline bool sameXf(const Xf& a, const Xf& b) {
    for (int i = 0; i < 3; ++i) if (a.pos[i] != b.pos[i] || a.rot[i] != b.rot[i] || a.scale[i] != b.scale[i]) return false;
    return true;
}

// Row-major 3x3 rotation matrix from Euler degrees.
inline void eulerToMat(const float* d, float* R) {
    const float k = 0.01745329252f;
    float cx = std::cos(d[0] * k), sx = std::sin(d[0] * k), cy = std::cos(d[1] * k), sy = std::sin(d[1] * k),
          cz = std::cos(d[2] * k), sz = std::sin(d[2] * k);
    R[0] = cz * cy; R[1] = cz * sy * sx - sz * cx; R[2] = cz * sy * cx + sz * sx;
    R[3] = sz * cy; R[4] = sz * sy * sx + cz * cx; R[5] = sz * sy * cx - cz * sx;
    R[6] = -sy;     R[7] = cy * sx;                R[8] = cy * cx;
}
// Column-major 4x4 (T * R * S).
inline void modelMatrix(const Object& o, float* M) {
    float R[9]; eulerToMat(o.rot, R);
    for (int c = 0; c < 3; ++c) for (int r = 0; r < 3; ++r) M[c * 4 + r] = R[r * 3 + c] * o.scale[c];
    M[3] = M[7] = M[11] = 0; M[12] = o.pos[0]; M[13] = o.pos[1]; M[14] = o.pos[2]; M[15] = 1;
}
inline float safeScale(float s) { return std::fabs(s) < 1e-6f ? 1e-6f : s; }
inline Vec3 worldToLocalDir(const Object& o, Vec3 d) {
    float R[9]; eulerToMat(o.rot, R);
    return {(R[0] * d.x + R[3] * d.y + R[6] * d.z) / safeScale(o.scale[0]),
            (R[1] * d.x + R[4] * d.y + R[7] * d.z) / safeScale(o.scale[1]),
            (R[2] * d.x + R[5] * d.y + R[8] * d.z) / safeScale(o.scale[2])};
}
inline Vec3 worldToLocalPoint(const Object& o, Vec3 p) {
    return worldToLocalDir(o, p - Vec3{o.pos[0], o.pos[1], o.pos[2]});
}

// ---------- element selection (edit mode) ----------
// mode: 0 = vertex, 1 = edge, 2 = face. Only the set that matches `mode` is meaningful.
struct SelState {
    int mode = 0;
    std::set<int> v; std::set<Edge> e; std::set<int> f;
    void clearSets() { v.clear(); e.clear(); f.clear(); }
};

inline std::set<Edge> meshEdgeSet(const Mesh& m) { auto u = uniqueEdges(m); return std::set<Edge>(u.begin(), u.end()); }

// Re-express the selection in another element mode (vertex->edge keeps edges whose ends are both selected, etc.).
inline void convertSelection(SelState& s, const Mesh& m, int to) {
    if (to == s.mode) return;
    std::set<int> V, F; std::set<Edge> E;
    if (s.mode == 0) {
        V = s.v;
        for (const auto& e : meshEdgeSet(m)) if (V.count(e.first) && V.count(e.second)) E.insert(e);
        for (size_t fi = 0; fi < m.f.size(); ++fi) {
            bool all = true; for (int vi : m.f[fi]) if (!V.count(vi)) { all = false; break; }
            if (all) F.insert((int)fi);
        }
    } else if (s.mode == 1) {
        E = s.e; for (const auto& e : E) { V.insert(e.first); V.insert(e.second); }
        for (size_t fi = 0; fi < m.f.size(); ++fi) {
            const auto& fc = m.f[fi]; bool all = true;
            for (size_t i = 0; i < fc.size(); ++i) if (!E.count(mkEdge(fc[i], fc[(i + 1) % fc.size()]))) { all = false; break; }
            if (all) F.insert((int)fi);
        }
    } else {
        F = s.f;
        for (int fi : F) if (fi >= 0 && fi < (int)m.f.size()) {
            const auto& fc = m.f[fi];
            for (size_t i = 0; i < fc.size(); ++i) { V.insert(fc[i]); E.insert(mkEdge(fc[i], fc[(i + 1) % fc.size()])); }
        }
    }
    s.clearSets(); s.mode = to;
    if (to == 0) s.v = V; else if (to == 1) s.e = E; else s.f = F;
}

// Vertices affected by the selection, whatever the mode.
inline std::vector<char> selectedVertexMask(const SelState& s, const Mesh& m) {
    std::vector<char> mask(m.v.size(), 0); const int nv = (int)m.v.size();
    if (s.mode == 0) { for (int i : s.v) if (i >= 0 && i < nv) mask[i] = 1; }
    else if (s.mode == 1) { for (const auto& e : s.e) { if (e.first >= 0 && e.first < nv) mask[e.first] = 1; if (e.second >= 0 && e.second < nv) mask[e.second] = 1; } }
    else for (int fi : s.f) if (fi >= 0 && fi < (int)m.f.size()) for (int vi : m.f[fi]) mask[vi] = 1;
    return mask;
}

// Faces that are completely covered by the selection (face mode: the selected faces themselves).
inline std::vector<int> selectedFaces(const SelState& s, const Mesh& m) {
    if (s.mode == 2) { std::vector<int> r; for (int fi : s.f) if (fi >= 0 && fi < (int)m.f.size()) r.push_back(fi); return r; }
    SelState t = s; convertSelection(t, m, 2);
    return std::vector<int>(t.f.begin(), t.f.end());
}

inline void invertSelection(SelState& s, const Mesh& m) {
    if (s.mode == 0) { std::set<int> n; for (int i = 0; i < (int)m.v.size(); ++i) if (!s.v.count(i)) n.insert(i); s.v = n; }
    else if (s.mode == 1) { std::set<Edge> n; for (const auto& e : meshEdgeSet(m)) if (!s.e.count(e)) n.insert(e); s.e = n; }
    else { std::set<int> n; for (int i = 0; i < (int)m.f.size(); ++i) if (!s.f.count(i)) n.insert(i); s.f = n; }
}
inline void selectAllElements(SelState& s, const Mesh& m) {
    s.clearSets();
    if (s.mode == 0) for (int i = 0; i < (int)m.v.size(); ++i) s.v.insert(i);
    else if (s.mode == 1) s.e = meshEdgeSet(m);
    else for (int i = 0; i < (int)m.f.size(); ++i) s.f.insert(i);
}
inline size_t selectionCount(const SelState& s) { return s.mode == 0 ? s.v.size() : s.mode == 1 ? s.e.size() : s.f.size(); }

class Scene;
struct Command {
    virtual ~Command() = default;
    virtual void apply(Scene&) = 0;
    virtual void revert(Scene&) = 0;
};

class Scene {
public:
    std::vector<Object> objects;
    uint32_t nextId = 1;
    uint32_t selected = 0;          // active object, 0 = none
    bool editMode = false;
    SelState sel;                   // element selection of the active object (edit mode)

    Object* find(uint32_t id) { for (auto& o : objects) if (o.id == id) return &o; return nullptr; }
    const Object* find(uint32_t id) const { for (auto& o : objects) if (o.id == id) return &o; return nullptr; }

    void execute(std::unique_ptr<Command> c) { c->apply(*this); record(std::move(c)); }
    // Push an already-applied command (used by interactive drags).
    void record(std::unique_ptr<Command> c) { undoStack.push_back(std::move(c)); redoStack.clear(); }
    bool undo() {
        if (undoStack.empty()) return false;
        undoStack.back()->revert(*this);
        redoStack.push_back(std::move(undoStack.back())); undoStack.pop_back();
        sanitize(); return true;
    }
    bool redo() {
        if (redoStack.empty()) return false;
        redoStack.back()->apply(*this);
        undoStack.push_back(std::move(redoStack.back())); redoStack.pop_back();
        sanitize(); return true;
    }
    void clearHistory() { undoStack.clear(); redoStack.clear(); }
    size_t undoDepth() const { return undoStack.size(); }

    // Keep selection state valid after history jumps.
    void sanitize() {
        Object* o = find(selected);
        if (!o) { selected = 0; editMode = false; sel.clearSets(); return; }
        if (editMode) {
            const int nv = (int)o->mesh.v.size(), nf = (int)o->mesh.f.size();
            for (auto it = sel.v.begin(); it != sel.v.end();) it = (*it < 0 || *it >= nv) ? sel.v.erase(it) : std::next(it);
            for (auto it = sel.f.begin(); it != sel.f.end();) it = (*it < 0 || *it >= nf) ? sel.f.erase(it) : std::next(it);
            for (auto it = sel.e.begin(); it != sel.e.end();) it = (it->first < 0 || it->second >= nv) ? sel.e.erase(it) : std::next(it);
        }
    }
    template <class T> static void toggleIn(std::set<T>& st, const T& x) { auto it = st.find(x); if (it == st.end()) st.insert(x); else st.erase(it); }
    void toggleFace(int fi) { toggleIn(sel.f, fi); }
    void toggleVertex(int vi) { toggleIn(sel.v, vi); }
    void toggleEdge(const Edge& e) { toggleIn(sel.e, e); }
    void reset() { objects.clear(); nextId = 1; selected = 0; editMode = false; sel.clearSets(); clearHistory(); }

private:
    std::vector<std::unique_ptr<Command>> undoStack, redoStack;
};

struct AddObjectCmd : Command {
    Object obj;
    explicit AddObjectCmd(Object o) : obj(std::move(o)) {}
    void apply(Scene& s) override { s.objects.push_back(obj); s.selected = obj.id; s.editMode = false; s.sel.clearSets(); }
    void revert(Scene& s) override {
        for (size_t i = 0; i < s.objects.size(); ++i) if (s.objects[i].id == obj.id) { s.objects.erase(s.objects.begin() + i); break; }
    }
};
struct DeleteObjectCmd : Command {
    Object obj; size_t index;
    DeleteObjectCmd(Object o, size_t i) : obj(std::move(o)), index(i) {}
    void apply(Scene& s) override {
        for (size_t i = 0; i < s.objects.size(); ++i) if (s.objects[i].id == obj.id) { s.objects.erase(s.objects.begin() + i); break; }
        s.selected = 0; s.editMode = false; s.sel.clearSets();
    }
    void revert(Scene& s) override {
        s.objects.insert(s.objects.begin() + std::min(index, s.objects.size()), obj); s.selected = obj.id;
    }
};
struct TransformCmd : Command {
    uint32_t id; Xf before, after;
    TransformCmd(uint32_t i, const Xf& b, const Xf& a) : id(i), before(b), after(a) {}
    void apply(Scene& s) override { if (Object* o = s.find(id)) setXf(*o, after); }
    void revert(Scene& s) override { if (Object* o = s.find(id)) setXf(*o, before); }
};
struct MeshEditCmd : Command {
    uint32_t id; Mesh before, after; SelState selBefore, selAfter;
    MeshEditCmd(uint32_t i, Mesh b, Mesh a, SelState sb, SelState sa)
        : id(i), before(std::move(b)), after(std::move(a)), selBefore(std::move(sb)), selAfter(std::move(sa)) {}
    void apply(Scene& s) override { if (Object* o = s.find(id)) { o->mesh = after; o->meshRev = nextRev(); s.sel = selAfter; } }
    void revert(Scene& s) override { if (Object* o = s.find(id)) { o->mesh = before; o->meshRev = nextRev(); s.sel = selBefore; } }
};

struct RenameCmd : Command {
    uint32_t id; std::string before, after;
    RenameCmd(uint32_t i, std::string b, std::string a) : id(i), before(std::move(b)), after(std::move(a)) {}
    void apply(Scene& s) override { if (Object* o = s.find(id)) o->name = after; }
    void revert(Scene& s) override { if (Object* o = s.find(id)) o->name = before; }
};
// Mesh + transform changed together (Apply Transform, Origin to Geometry).
struct BakeCmd : Command {
    uint32_t id; Mesh mb, ma; Xf xb, xa;
    BakeCmd(uint32_t i, Mesh b, Mesh a, const Xf& x0, const Xf& x1) : id(i), mb(std::move(b)), ma(std::move(a)), xb(x0), xa(x1) {}
    void apply(Scene& s) override { if (Object* o = s.find(id)) { o->mesh = ma; setXf(*o, xa); o->meshRev = nextRev(); } }
    void revert(Scene& s) override { if (Object* o = s.find(id)) { o->mesh = mb; setXf(*o, xb); o->meshRev = nextRev(); } }
};

struct ModStackCmd : Command {
    uint32_t id; std::vector<Modifier> modsBefore, modsAfter; bool meshChanged; Mesh meshBefore, meshAfter;
    ModStackCmd(uint32_t i, std::vector<Modifier> mb, std::vector<Modifier> ma, bool mc, Mesh b, Mesh a)
        : id(i), modsBefore(std::move(mb)), modsAfter(std::move(ma)), meshChanged(mc), meshBefore(std::move(b)), meshAfter(std::move(a)) {}
    void set(Scene& s, const std::vector<Modifier>& m, const Mesh& me) {
        if (Object* o = s.find(id)) { o->mods = m; o->modsRev = nextRev(); if (meshChanged) { o->mesh = me; o->meshRev = nextRev(); } }
    }
    void apply(Scene& s) override { set(s, modsAfter, meshAfter); }
    void revert(Scene& s) override { set(s, modsBefore, meshBefore); }
};

// ---------- high-level operations (shared by UI and tests) ----------
inline std::string uniqueName(const Scene& s, std::string base) {
    if (base.size() > 4 && base[base.size() - 4] == '.' && std::isdigit((unsigned char)base[base.size() - 3]) &&
        std::isdigit((unsigned char)base[base.size() - 2]) && std::isdigit((unsigned char)base[base.size() - 1]))
        base.resize(base.size() - 4);
    auto exists = [&](const std::string& n) { for (auto& o : s.objects) if (o.name == n) return true; return false; };
    if (!exists(base)) return base;
    for (int i = 1; i < 100000; ++i) {
        char buf[16]; std::snprintf(buf, sizeof buf, ".%03d", i);
        if (!exists(base + buf)) return base + buf;
    }
    return base;
}
inline uint32_t addPrimitive(Scene& s, int kind) {
    Object o; o.id = s.nextId++; o.name = uniqueName(s, primitiveName(kind));
    o.mesh = makePrimitive(kind); o.meshRev = nextRev();
    uint32_t id = o.id; s.execute(std::make_unique<AddObjectCmd>(std::move(o))); return id;
}
inline uint32_t duplicateSelected(Scene& s) {
    const Object* src = s.find(s.selected);
    if (!src || s.editMode) return 0;
    Object o = *src; o.id = s.nextId++; o.name = uniqueName(s, src->name); o.meshRev = nextRev();
    uint32_t id = o.id; s.execute(std::make_unique<AddObjectCmd>(std::move(o))); return id;
}
inline bool deleteSelectedObject(Scene& s) {
    if (s.editMode) return false;
    for (size_t i = 0; i < s.objects.size(); ++i)
        if (s.objects[i].id == s.selected) { s.execute(std::make_unique<DeleteObjectCmd>(s.objects[i], i)); return true; }
    return false;
}
// Runs a mesh edit on the active object in edit mode as one undoable command.
// `fn(mesh, selBefore, selAfter)` mutates the mesh copy and the new selection; return false to abort.
template <class Fn> inline bool editActiveMesh(Scene& s, Fn fn) {
    Object* o = s.find(s.selected);
    if (!s.editMode || !o) return false;
    Mesh before = o->mesh, after = before; SelState sb = s.sel, sa = s.sel;
    if (!fn(after, sb, sa)) return false;
    if (!validMesh(after)) return false;
    s.execute(std::make_unique<MeshEditCmd>(o->id, std::move(before), std::move(after), std::move(sb), std::move(sa)));
    return true;
}
// Selection holding `faces` (face mode) re-expressed in the user's current mode.
inline SelState selFromFaces(const Mesh& m, const std::vector<int>& faces, int mode) {
    SelState t; t.mode = 2; t.f.insert(faces.begin(), faces.end()); convertSelection(t, m, mode); return t;
}

inline bool extrudeSelected(Scene& s, float dist) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        if (sb.mode != 1) {
            std::vector<int> faces = selectedFaces(sb, m);
            if (!faces.empty()) {
                if (!extrudeFaces(m, faces, dist)) return false;
                sa = selFromFaces(m, faces, sb.mode); return true;
            }
        }
        // edges: edge mode, or vertex mode where only edges (no complete face) are covered
        SelState t = sb; convertSelection(t, m, 1);
        std::set<Edge> made;
        if (t.e.empty() || !extrudeEdges(m, t.e, dist, &made)) return false;
        SelState n; n.mode = 1; n.e = made; convertSelection(n, m, sb.mode); sa = n; return true;
    });
}
inline bool deleteSelection(Scene& s) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        bool ok = sb.mode == 0 ? deleteVertices(m, sb.v) : sb.mode == 1 ? deleteEdges(m, sb.e) : deleteFaces(m, std::vector<int>(sb.f.begin(), sb.f.end()));
        sa.clearSets(); return ok;
    });
}
inline bool insetSelected(Scene& s, float amount) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        std::vector<int> faces = selectedFaces(sb, m);
        if (!insetFaces(m, faces, amount)) return false;
        sa = selFromFaces(m, faces, sb.mode); return true;
    });
}
inline bool subdivideSelected(Scene& s) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        std::vector<int> faces = selectedFaces(sb, m), made;
        if (!subdivideFaces(m, faces, &made)) return false;
        sa = selFromFaces(m, made, sb.mode); return true;
    });
}
inline bool mergeSelectedAtCenter(Scene& s) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        std::vector<char> mask = selectedVertexMask(sb, m); std::set<int> vs;
        for (size_t i = 0; i < mask.size(); ++i) if (mask[i]) vs.insert((int)i);
        int merged = -1; if (!mergeVerticesAtCenter(m, vs, &merged)) return false;
        sa.clearSets(); sa.mode = 0; sa.v.insert(merged); convertSelection(sa, m, sb.mode); return true;
    });
}
inline bool loopCutSelected(Scene& s, float t) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        SelState e = sb; convertSelection(e, m, 1);
        if (e.e.empty()) return false;
        std::set<Edge> made;
        if (!loopCut(m, *e.e.begin(), t, &made)) return false;
        SelState n; n.mode = 1; n.e = made; convertSelection(n, m, sb.mode); sa = n; return true;
    });
}
// Extends the selection with the edge loops through the selected edges (selection only, not an undo step).
inline bool selectLoopActive(Scene& s) {
    Object* o = s.find(s.selected); if (!s.editMode || !o) return false;
    SelState e = s.sel; convertSelection(e, o->mesh, 1);
    if (e.e.empty()) return false;
    std::set<Edge> all; for (const auto& ed : e.e) { auto l = edgeLoop(o->mesh, ed); all.insert(l.begin(), l.end()); }
    SelState n; n.mode = 1; n.e = all; convertSelection(n, o->mesh, s.sel.mode); s.sel = n; return true;
}
inline bool flipSelectedFaces(Scene& s) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState&) { return flipFaces(m, selectedFaces(sb, m)); });
}
inline Vec3 localToWorldPoint(const Object& o, Vec3 p);
// ---- 0.8.0: object operations ----
inline std::string cleanName(std::string n) {
    size_t a = n.find_first_not_of(" \t\r\n"), b = n.find_last_not_of(" \t\r\n");
    if (a == std::string::npos) return "";
    n = n.substr(a, b - a + 1);
    for (auto& c : n) if (c == ' ' || c == '\t' || c == '\r' || c == '\n') c = '_';
    if (n.size() > 40) n.resize(40);
    return n;
}
inline bool renameSelected(Scene& s, const std::string& raw) {
    Object* o = s.find(s.selected); if (!o || s.editMode) return false;
    std::string n = cleanName(raw); if (n.empty() || n == o->name) return false;
    bool taken = false; for (auto& x : s.objects) if (x.id != o->id && x.name == n) taken = true;
    if (taken) { n = uniqueName(s, n); if (n == o->name) return false; }
    s.execute(std::make_unique<RenameCmd>(o->id, o->name, n)); return true;
}
// mode 0: bake location+rotation+scale into the mesh (transform becomes identity); mode 1: bake only the scale.
inline bool applyTransformSelected(Scene& s, int mode) {
    Object* o = s.find(s.selected); if (!o || s.editMode || (mode != 0 && mode != 1)) return false;
    Xf xb = getXf(*o), xa = xb; Mesh after = o->mesh;
    float R[9]; eulerToMat(o->rot, R);
    for (auto& p : after.v) {
        Vec3 q{p.x * o->scale[0], p.y * o->scale[1], p.z * o->scale[2]};
        if (mode == 0) p = {R[0] * q.x + R[1] * q.y + R[2] * q.z + o->pos[0], R[3] * q.x + R[4] * q.y + R[5] * q.z + o->pos[1], R[6] * q.x + R[7] * q.y + R[8] * q.z + o->pos[2]};
        else p = q;
    }
    if (o->scale[0] * o->scale[1] * o->scale[2] < 0) for (auto& fc : after.f) std::reverse(fc.begin(), fc.end());   // mirrored: keep normals outward
    for (int i = 0; i < 3; ++i) xa.scale[i] = 1.f;
    if (mode == 0) for (int i = 0; i < 3; ++i) { xa.pos[i] = 0.f; xa.rot[i] = 0.f; }
    if (sameXf(xa, xb) && sameMesh(after, o->mesh)) return false;
    s.execute(std::make_unique<BakeCmd>(o->id, o->mesh, std::move(after), xb, xa)); return true;
}
// Moves the object origin to the median of its vertices without moving the geometry in the world.
inline bool originToGeometry(Scene& s) {
    Object* o = s.find(s.selected); if (!o || s.editMode || o->mesh.v.empty()) return false;
    Vec3 c; for (const auto& p : o->mesh.v) c = c + p; c = c * (1.f / (float)o->mesh.v.size());
    if (std::fabs(c.x) + std::fabs(c.y) + std::fabs(c.z) < 1e-7f) return false;
    Mesh after = o->mesh; for (auto& p : after.v) p = p - c;
    Xf xb = getXf(*o), xa = xb; Vec3 w = localToWorldPoint(*o, c);
    xa.pos[0] = w.x; xa.pos[1] = w.y; xa.pos[2] = w.z;
    s.execute(std::make_unique<BakeCmd>(o->id, o->mesh, std::move(after), xb, xa)); return true;
}
// ---- 0.8.0: select linked (selection only, not an undo step) ----
inline bool selectLinkedActive(Scene& s) {
    Object* o = s.find(s.selected); if (!s.editMode || !o) return false;
    const Mesh& m = o->mesh; const int nv = (int)m.v.size();
    std::vector<char> mask = selectedVertexMask(s.sel, m); bool any = false; for (char c : mask) if (c) any = true;
    if (!any) return false;
    std::vector<int> par(nv); for (int i = 0; i < nv; ++i) par[i] = i;
    auto root = [&](int x) { while (par[x] != x) { par[x] = par[par[x]]; x = par[x]; } return x; };
    for (const auto& fc : m.f) for (size_t k = 1; k < fc.size(); ++k) { int a = root(fc[0]), b = root(fc[k]); if (a != b) par[a] = b; }
    std::set<int> comps; for (int i = 0; i < nv; ++i) if (mask[i]) comps.insert(root(i));
    SelState n; n.mode = s.sel.mode;
    for (int i = 0; i < nv; ++i) if (comps.count(root(i))) n.v.insert(i);
    for (size_t fi = 0; fi < m.f.size(); ++fi) if (comps.count(root(m.f[fi][0]))) {
        n.f.insert((int)fi); const auto& fc = m.f[fi];
        for (size_t k = 0; k < fc.size(); ++k) n.e.insert(mkEdge(fc[k], fc[(k + 1) % fc.size()]));
    }
    if (n.mode == 0) { n.e.clear(); n.f.clear(); } else if (n.mode == 1) { n.v.clear(); n.f.clear(); } else { n.v.clear(); n.e.clear(); }
    s.sel = n; return true;
}
// ---- 0.9.0: Merge by Distance on the selected vertices (edit mode, one undo step) ----
inline bool weldSelected(Scene& s, float dist) {
    if (!std::isfinite(dist) || dist < 0.f || dist > 1000.f) return false;
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        std::vector<char> mask = selectedVertexMask(sb, m);
        if (weldVertices(m, dist, &mask) == 0 || m.f.empty()) return false;
        sa.clearSets(); return true;
    });
}

// ---- 0.10.0: dissolve + separate ----
// Dissolve Edges on the selection (one undo step). Vertex/edge mode: the selected edges. Face mode: the edges between two
// selected faces, i.e. the selected faces are merged. Result faces become the new selection.
inline bool dissolveSelectedEdges(Scene& s) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        std::set<Edge> es;
        if (sb.mode == 2) {
            std::map<Edge, std::vector<int>> ef;
            for (int fi : sb.f) if (fi >= 0 && fi < (int)m.f.size()) { const auto& fc = m.f[fi]; for (size_t i = 0; i < fc.size(); ++i) ef[mkEdge(fc[i], fc[(i + 1) % fc.size()])].push_back(fi); }
            for (const auto& kv : ef) if (kv.second.size() == 2) es.insert(kv.first);
        } else { SelState t = sb; convertSelection(t, m, 1); es = t.e; }
        std::vector<int> made;
        if (es.empty() || dissolveEdges(m, es, &made) == 0) return false;
        sa = selFromFaces(m, made, sb.mode); return true;
    });
}
// Limited Dissolve on the selected faces (vertex/edge mode: the faces fully covered by the selection). angleDeg in (0, 180].
inline bool limitedDissolveSelected(Scene& s, float angleDeg) {
    if (!std::isfinite(angleDeg) || angleDeg <= 0.f || angleDeg > 180.f) return false;
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        std::vector<int> faces = selectedFaces(sb, m); if (faces.empty()) return false;
        std::vector<char> mask(m.f.size(), 0); for (int fi : faces) mask[fi] = 1;
        std::vector<int> made;
        if (limitedDissolve(m, angleDeg, &mask, &made) == 0) return false;
        sa = selFromFaces(m, made, sb.mode); return true;
    });
}
// Separate Selection: the selected faces become a new object (same transform and modifiers), the rest stays. Leaves Edit Mode
// and selects the new object. One undo step (undo restores the edit-mode selection).
struct SeparateCmd : Command {
    uint32_t srcId; Mesh before, rest; Object made; SelState selBefore;
    SeparateCmd(uint32_t i, Mesh b, Mesh r, Object o, SelState sb) : srcId(i), before(std::move(b)), rest(std::move(r)), made(std::move(o)), selBefore(std::move(sb)) {}
    void apply(Scene& s) override {
        if (Object* o = s.find(srcId)) { o->mesh = rest; o->meshRev = nextRev(); }
        s.objects.push_back(made); s.selected = made.id; s.editMode = false; s.sel.clearSets();
    }
    void revert(Scene& s) override {
        for (size_t i = 0; i < s.objects.size(); ++i) if (s.objects[i].id == made.id) { s.objects.erase(s.objects.begin() + i); break; }
        if (Object* o = s.find(srcId)) { o->mesh = before; o->meshRev = nextRev(); }
        s.selected = srcId; s.editMode = true; s.sel = selBefore;
    }
};
inline uint32_t separateSelected(Scene& s) {
    Object* o = s.find(s.selected); if (!s.editMode || !o) return 0;
    std::vector<int> faces = selectedFaces(s.sel, o->mesh); Mesh picked, rest;
    if (!separateFaces(o->mesh, faces, picked, rest) || !validMesh(picked) || !validMesh(rest)) return 0;
    Object n = *o; n.id = s.nextId++; n.name = uniqueName(s, o->name); n.mesh = picked; n.meshRev = nextRev(); n.modsRev = nextRev();
    n.evalMeshRev = ~0ull; n.evalModsRev = ~0ull; n.evalMesh = Mesh();
    const uint32_t id = n.id;
    s.execute(std::make_unique<SeparateCmd>(o->id, o->mesh, std::move(rest), std::move(n), s.sel)); return id;
}
// ---- 0.12.0: Dissolve Vertices / Dissolve Faces / Separate Loose Parts ----
inline bool dissolveSelectedVertices(Scene& s) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        std::vector<char> mask = selectedVertexMask(sb, m); std::set<int> vs;
        for (size_t i = 0; i < mask.size(); ++i) if (mask[i]) vs.insert((int)i);
        if (vs.empty() || dissolveVertices(m, vs) == 0) return false;
        sa.clearSets(); return true;
    });
}
// Dissolve Faces: merges the selected faces (those fully covered by the selection) into one polygon per connected group.
inline bool dissolveSelectedFaces(Scene& s) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        std::vector<int> faces = selectedFaces(sb, m); if (faces.size() < 2) return false;
        std::map<Edge, std::vector<int>> ef;
        for (int fi : faces) { const auto& fc = m.f[fi]; for (size_t i = 0; i < fc.size(); ++i) ef[mkEdge(fc[i], fc[(i + 1) % fc.size()])].push_back(fi); }
        std::set<Edge> es; for (const auto& kv : ef) if (kv.second.size() == 2) es.insert(kv.first);
        std::vector<int> made;
        if (es.empty() || dissolveEdges(m, es, &made) == 0) return false;
        sa = selFromFaces(m, made, sb.mode); return true;
    });
}
// Splits the active object (Object Mode) into one object per connected part. The first part stays in the original object
// (so its id/name survive); the others become new objects with the same transform and modifiers. One undo step.
struct LooseSplitCmd : Command {
    uint32_t srcId; Mesh before, first; std::vector<Object> made;
    LooseSplitCmd(uint32_t i, Mesh b, Mesh f, std::vector<Object> m) : srcId(i), before(std::move(b)), first(std::move(f)), made(std::move(m)) {}
    void apply(Scene& s) override {
        if (Object* o = s.find(srcId)) { o->mesh = first; o->meshRev = nextRev(); }
        for (const Object& n : made) s.objects.push_back(n);
        s.selected = srcId; s.editMode = false; s.sel.clearSets();
    }
    void revert(Scene& s) override {
        for (const Object& n : made) for (size_t i = 0; i < s.objects.size(); ++i) if (s.objects[i].id == n.id) { s.objects.erase(s.objects.begin() + i); break; }
        if (Object* o = s.find(srcId)) { o->mesh = before; o->meshRev = nextRev(); }
        s.selected = srcId; s.editMode = false; s.sel.clearSets();
    }
};
// Returns how many NEW objects were created (0 = nothing to split / not in Object Mode).
inline int separateLooseParts(Scene& s) {
    if (s.editMode) return 0;
    const Object* o = s.find(s.selected); if (!o) return 0;
    std::vector<Mesh> parts = splitLooseParts(o->mesh);
    if (parts.size() < 2 || parts.size() > 256) return 0;
    const Object src = *o; std::vector<Object> made;
    const size_t base = s.objects.size();
    for (size_t i = 1; i < parts.size(); ++i) {
        Object n = src; n.id = s.nextId++; n.name = uniqueName(s, src.name); n.mesh = parts[i]; n.meshRev = nextRev(); n.modsRev = nextRev();
        n.evalMeshRev = ~0ull; n.evalModsRev = ~0ull; n.evalMesh = Mesh();
        s.objects.push_back(n); made.push_back(n);      // pushed so the next uniqueName sees it
    }
    s.objects.erase(s.objects.begin() + base, s.objects.end());
    s.execute(std::make_unique<LooseSplitCmd>(src.id, src.mesh, parts[0], std::move(made)));
    return (int)parts.size() - 1;
}

// ---- 0.13.0: Fill / Bridge Edge Loops / Bevel Vertices (edit mode, one undo step each) ----
inline bool fillSelected(Scene& s) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        SelState t = sb; convertSelection(t, m, 1); if (t.e.empty()) return false;
        const int fi = fillLoop(m, t.e); if (fi < 0) return false;
        sa = selFromFaces(m, {fi}, sb.mode); return true;
    });
}
inline bool bridgeSelected(Scene& s) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        SelState t = sb; convertSelection(t, m, 1); if (t.e.empty()) return false;
        std::vector<int> made; if (bridgeLoops(m, t.e, &made) == 0) return false;
        sa = selFromFaces(m, made, sb.mode); return true;
    });
}
inline bool bevelSelectedVertices(Scene& s, float width) {
    return editActiveMesh(s, [&](Mesh& m, const SelState& sb, SelState& sa) {
        std::vector<char> mask = selectedVertexMask(sb, m); std::set<int> vs;
        for (size_t i = 0; i < mask.size(); ++i) if (mask[i]) vs.insert((int)i);
        std::vector<int> caps; if (vs.empty() || bevelVertices(m, vs, width, &caps) == 0) return false;
        sa = selFromFaces(m, caps, sb.mode); return true;
    });
}

// ---- modifier stack operations on the active object (undoable) ----
inline bool addModifier(Scene& s, int type) {
    Object* o = s.find(s.selected); if (!o || type < 0 || type > kMaxModType || o->mods.size() >= 16) return false;
    Modifier m; m.type = type; if (type == kArray) { m.count = 2; m.offset[0] = 2.f; }
    if (type == kSmooth) { m.factor = 0.5f; m.iterations = 1; }
    if (type == kSimpleDeform) { m.mode = kTwist; m.axis = 2; m.angle = 45.f; m.factor = 0.5f; }
    if (type == kPlanarDecimate) m.angle = 5.f;
    auto after = o->mods; after.push_back(m);
    s.execute(std::make_unique<ModStackCmd>(o->id, o->mods, after, false, Mesh(), Mesh())); return true;
}
inline bool removeModifier(Scene& s, int idx) {
    Object* o = s.find(s.selected); if (!o || idx < 0 || idx >= (int)o->mods.size()) return false;
    auto after = o->mods; after.erase(after.begin() + idx);
    s.execute(std::make_unique<ModStackCmd>(o->id, o->mods, after, false, Mesh(), Mesh())); return true;
}
inline bool setModifier(Scene& s, int idx, const Modifier& nm) {
    Object* o = s.find(s.selected); if (!o || idx < 0 || idx >= (int)o->mods.size() || !validModifier(nm)) return false;
    Modifier m = nm; m.type = o->mods[idx].type;   // type cannot change
    const Modifier& c = o->mods[idx];
    if (c.enabled == m.enabled && c.axis == m.axis && c.count == m.count && c.merge == m.merge &&
        c.offset[0] == m.offset[0] && c.offset[1] == m.offset[1] && c.offset[2] == m.offset[2] &&
        c.levels == m.levels && c.thickness == m.thickness && c.shift == m.shift && c.factor == m.factor && c.iterations == m.iterations &&
        c.mode == m.mode && c.angle == m.angle) return false;   // no-op: no undo step
    auto after = o->mods; after[idx] = m;
    s.execute(std::make_unique<ModStackCmd>(o->id, o->mods, after, false, Mesh(), Mesh())); return true;
}
inline bool toggleModifier(Scene& s, int idx) {
    Object* o = s.find(s.selected); if (!o || idx < 0 || idx >= (int)o->mods.size()) return false;
    Modifier m = o->mods[idx]; m.enabled = !m.enabled; return setModifier(s, idx, m);
}
inline bool moveModifier(Scene& s, int idx, int delta) {
    Object* o = s.find(s.selected); int j = idx + delta;
    if (!o || idx < 0 || j < 0 || idx >= (int)o->mods.size() || j >= (int)o->mods.size()) return false;
    auto after = o->mods; std::swap(after[idx], after[j]);
    s.execute(std::make_unique<ModStackCmd>(o->id, o->mods, after, false, Mesh(), Mesh())); return true;
}
// Bakes modifiers 0..idx into the base mesh and removes them (object mode only).
inline bool applyModifierAt(Scene& s, int idx) {
    Object* o = s.find(s.selected); if (!o || s.editMode || idx < 0 || idx >= (int)o->mods.size()) return false;
    Mesh m = o->mesh; for (int i = 0; i <= idx; ++i) if (o->mods[i].enabled) m = applyModifier(m, o->mods[i]);
    if (!validMesh(m)) return false;
    auto after = o->mods; after.erase(after.begin(), after.begin() + idx + 1);
    s.execute(std::make_unique<ModStackCmd>(o->id, o->mods, after, true, o->mesh, m)); return true;
}
inline bool setObjectTransform(Scene& s, const Xf& after) {
    Object* o = s.find(s.selected);
    if (!o || s.editMode) return false;
    Xf a = after; for (int i = 0; i < 3; ++i) if (std::fabs(a.scale[i]) < 1e-4f) a.scale[i] = 1e-4f;
    Xf b = getXf(*o); if (sameXf(a, b)) return false;
    s.execute(std::make_unique<TransformCmd>(o->id, b, a)); return true;
}
inline bool setEditMode(Scene& s, bool on) {
    if (on) { if (!s.find(s.selected)) return false; s.editMode = true; s.sel.clearSets(); return true; }
    s.editMode = false; s.sel.clearSets(); return true;
}
inline bool setSelectMode(Scene& s, int mode) {
    if (mode < 0 || mode > 2) return false;
    if (Object* o = s.find(s.selected)) { if (s.editMode) convertSelection(s.sel, o->mesh, mode); else s.sel.mode = mode; }
    else s.sel.mode = mode;
    return true;
}
inline void selectAllActive(Scene& s) { if (Object* o = s.find(s.selected)) if (s.editMode) selectAllElements(s.sel, o->mesh); }
inline void invertActive(Scene& s) { if (Object* o = s.find(s.selected)) if (s.editMode) invertSelection(s.sel, o->mesh); }
inline uint32_t pickObject(const Scene& s, Vec3 org, Vec3 dir) {
    uint32_t best = 0; float bt = 1e30f;
    for (const auto& o : s.objects) {
        float t; Vec3 lo = worldToLocalPoint(o, org), ld = worldToLocalDir(o, dir);
        if (pickFace(displayMesh(o), lo, ld, &t) >= 0 && t < bt) { bt = t; best = o.id; }
    }
    return best;
}
inline int pickActiveFace(const Scene& s, Vec3 org, Vec3 dir) {
    const Object* o = s.find(s.selected);
    if (!o) return -1;
    return pickFace(o->mesh, worldToLocalPoint(*o, org), worldToLocalDir(*o, dir));
}

inline Vec3 localToWorldPoint(const Object& o, Vec3 p) {
    float R[9]; eulerToMat(o.rot, R);
    Vec3 q{p.x * o.scale[0], p.y * o.scale[1], p.z * o.scale[2]};
    return {R[0] * q.x + R[1] * q.y + R[2] * q.z + o.pos[0], R[3] * q.x + R[4] * q.y + R[5] * q.z + o.pos[1],
            R[6] * q.x + R[7] * q.y + R[8] * q.z + o.pos[2]};
}
// True if no face of the object lies between the eye and the world point P.
inline bool visibleFromEye(const Object& o, Vec3 eye, Vec3 P) {
    Vec3 d = P - eye; float dist = length(d); if (dist < 1e-6f) return true;
    float t; int f = pickFace(o.mesh, worldToLocalPoint(o, eye), worldToLocalDir(o, d * (1.f / dist)), &t);
    return f < 0 || t >= dist - (1e-3f * dist + 1e-3f);
}
// `tolAngle` = pick radius as an angle (radians-ish: pixels * 2*tan(fov/2)/viewportHeight).
inline int pickActiveVertex(const Scene& s, Vec3 org, Vec3 dir, float tolAngle) {
    const Object* o = s.find(s.selected); if (!o) return -1;
    std::vector<std::pair<float, int>> cand;
    for (size_t i = 0; i < o->mesh.v.size(); ++i) {
        Vec3 w = localToWorldPoint(*o, o->mesh.v[i]) - org; float t = dot(w, dir); if (t <= 1e-4f) continue;
        float ang = length(w - dir * t) / t; if (ang < tolAngle) cand.push_back({ang, (int)i});
    }
    std::sort(cand.begin(), cand.end());
    int tested = 0;
    for (auto& c : cand) {
        if (++tested > 8) break;
        if (visibleFromEye(*o, org, localToWorldPoint(*o, o->mesh.v[c.second]))) return c.second;
    }
    return -1;
}
inline bool pickActiveEdge(const Scene& s, Vec3 org, Vec3 dir, float tolAngle, Edge* out) {
    const Object* o = s.find(s.selected); if (!o) return false;
    struct C { float ang; Edge e; Vec3 p; }; std::vector<C> cand;
    for (const auto& e : uniqueEdges(o->mesh)) {
        Vec3 A = localToWorldPoint(*o, o->mesh.v[e.first]), B = localToWorldPoint(*o, o->mesh.v[e.second]);
        Vec3 u = B - A, w0 = A - org; float a = dot(u, u), b = dot(u, dir), d = dot(u, w0), eo = dot(dir, w0);
        float D = a - b * b, sc = D > 1e-9f ? (b * eo - d) / D : 0.f;
        sc = std::fmax(0.f, std::fmin(1.f, sc));
        Vec3 P = A + u * sc, w = P - org; float t = dot(w, dir); if (t <= 1e-4f) continue;
        float ang = length(w - dir * t) / t; if (ang < tolAngle) cand.push_back({ang, e, P});
    }
    std::sort(cand.begin(), cand.end(), [](const C& x, const C& y) { return x.ang < y.ang; });
    int tested = 0;
    for (auto& c : cand) {
        if (++tested > 8) break;
        if (visibleFromEye(*o, org, c.p)) { *out = c.e; return true; }
    }
    return false;
}

}  // namespace atlas
