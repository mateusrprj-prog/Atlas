#include <cassert>
#include <map>
#include <set>
#include <cstdio>
#include "../app/src/main/cpp/core/project_io.hpp"
using namespace atlas;

static void checkOutward(const Mesh& m) {
    assert(validMesh(m));
    for (const auto& fc : m.f) {
        Vec3 c; for (int i : fc) c = c + m.v[i]; c = c * (1.f / fc.size());
        assert(dot(faceNormal(m, fc), c) > 0);  // normals point away from the origin
    }
}

// ---- helpers for 0.7.0 tests ----
static double signedVolume(const Mesh& m) {   // divergence theorem over a fan triangulation (positive when normals point outward)
    double vol = 0;
    for (const auto& fc : m.f) for (size_t k = 1; k + 1 < fc.size(); ++k) {
        const Vec3 &a = m.v[fc[0]], &b = m.v[fc[k]], &c = m.v[fc[k + 1]];
        vol += ((double)a.x * ((double)b.y * c.z - (double)b.z * c.y) - (double)a.y * ((double)b.x * c.z - (double)b.z * c.x) + (double)a.z * ((double)b.x * c.y - (double)b.y * c.x)) / 6.0;
    }
    return vol;
}
static bool closedManifold(const Mesh& m, int* edgesOut = nullptr) {   // every directed edge appears once and has its reverse
    std::map<std::pair<int, int>, int> d;
    for (const auto& fc : m.f) for (size_t k = 0; k < fc.size(); ++k) ++d[{fc[k], fc[(k + 1) % fc.size()]}];
    int edges = 0;
    for (auto& kv : d) { if (kv.second != 1 || !d.count({kv.first.second, kv.first.first})) return false; ++edges; }
    if (edgesOut) *edgesOut = edges / 2;
    return true;
}
static bool near(float a, float b, float e = 1e-4f) { return std::fabs(a - b) < e; }

int main() {
    // primitives
    checkOutward(makeCube()); checkOutward(makeCylinder()); checkOutward(makeUVSphere());
    assert(makeCube().v.size() == 8 && makeCube().f.size() == 6);

    // object add / transform / undo / redo
    Scene s; uint32_t a = addPrimitive(s, 0);
    assert(s.objects.size() == 1 && s.selected == a && s.objects[0].name == "Cube");
    uint32_t b = addPrimitive(s, 0); assert(s.find(b)->name == "Cube.001");
    Xf x = getXf(*s.find(a)); x.pos[0] = 3; x.rot[2] = 90; assert(s.selected == b);
    s.selected = a; assert(setObjectTransform(s, x));
    assert(s.find(a)->pos[0] == 3); assert(s.undo()); assert(s.find(a)->pos[0] == 0); assert(s.redo()); assert(s.find(a)->rot[2] == 90);

    // picking respects rotation/scale/translation
    Scene p; uint32_t c1 = addPrimitive(p, 0); uint32_t c2 = addPrimitive(p, 0);
    p.find(c2)->pos[1] = -6;   // behind c1 along the ray from +y? ray goes -y from y=+10
    Vec3 org{0, 10, 0}, dir{0, -1, 0};
    assert(pickObject(p, org, dir) == c1);
    Vec3 miss{5, 10, 0}; assert(pickObject(p, miss, dir) == 0);
    p.find(c1)->scale[0] = 6; assert(pickObject(p, miss, dir) == c1);  // scaled object now hit

    // edit mode: extrude a face, undo restores exact mesh
    Scene e; uint32_t id = addPrimitive(e, 0); assert(setEditMode(e, true)); assert(setSelectMode(e, 2));
    Mesh original = e.find(id)->mesh;
    int topFace = pickActiveFace(e, Vec3{0, 0, 10}, Vec3{0, 0, -1}); assert(topFace == 1);
    e.toggleFace(topFace);
    assert(extrudeSelected(e, 0.5f));
    const Mesh& m = e.find(id)->mesh;
    assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m));
    for (const auto& fc : m.f) { Vec3 n = faceNormal(m, fc); assert(length(n) > 0.99f); }
    float maxz = -9; for (auto& v : m.v) maxz = std::max(maxz, v.z); assert(std::fabs(maxz - 1.5f) < 1e-5f);
    assert(e.undo()); assert(sameMesh(e.find(id)->mesh, original));
    assert(e.redo()); assert(e.find(id)->mesh.f.size() == 10);
    assert(deleteSelection(e)); assert(e.find(id)->mesh.f.size() == 9 && validMesh(e.find(id)->mesh));
    assert(e.undo()); assert(e.find(id)->mesh.f.size() == 10);

    // undoing the creation while in edit mode leaves a consistent state
    Scene g; addPrimitive(g, 3); setEditMode(g, true); g.undo();
    assert(g.objects.empty() && !g.editMode && g.selected == 0);

    // delete / duplicate
    Scene d; addPrimitive(d, 2); assert(duplicateSelected(d) != 0 && d.objects.size() == 2);
    assert(deleteSelectedObject(d) && d.objects.size() == 1); assert(d.undo() && d.objects.size() == 2);

    // project round trip (v2)
    assert(saveProject(e, "/tmp/atlas_t2.atlas"));
    Scene q; assert(loadProject(q, "/tmp/atlas_t2.atlas"));
    assert(q.objects.size() == 1 && sameMesh(q.objects[0].mesh, e.objects[0].mesh) && q.nextId == e.nextId);

    // v1 migration + invalid files leave the scene untouched
    FILE* f1 = fopen("/tmp/atlas_v1.atlas", "w"); fputs("ATLAS 1\nnext 2\ncube 1 1 2 3 1 1 1\nend\n", f1); fclose(f1);
    Scene m1; assert(loadProject(m1, "/tmp/atlas_v1.atlas") && m1.objects.size() == 1);
    assert(m1.objects[0].pos[0] == 1 && m1.objects[0].pos[1] == -3 && m1.objects[0].pos[2] == 2);
    FILE* f2 = fopen("/tmp/atlas_bad.atlas", "w"); fputs("ATLAS 2\nnext 3\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 9\nend\n", f2); fclose(f2);
    Scene r; addPrimitive(r, 0); std::string err;
    assert(!loadProject(r, "/tmp/atlas_bad.atlas", &err)); assert(r.objects.size() == 1);
    // ================= v0.3: element selection and new modeling ops =================
    puts("v0.3 tests...");
    // closed-manifold check: every directed edge appears exactly once and so does its reverse
    auto closed = [](const Mesh& m) {
        std::map<std::pair<int, int>, int> c;
        for (const auto& fc : m.f) for (size_t i = 0; i < fc.size(); ++i) c[{fc[i], fc[(i + 1) % fc.size()]}]++;
        for (auto& kv : c) if (kv.second != 1 || c.count({kv.first.second, kv.first.first}) != 1) return false;
        return true;
    };
    auto totalArea = [](const Mesh& m) { float a = 0; for (auto& fc : m.f) a += faceArea(m, fc); return a; };
    assert(closed(makeCube()) && closed(makeCylinder()) && closed(makeUVSphere()));
    assert(std::fabs(totalArea(makeCube()) - 24.f) < 1e-4f);

    // selection mode conversion: face -> vertex -> edge -> face round trip on the cube's top face
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(setSelectMode(c, 0) && c.sel.mode == 0 && c.sel.v == std::set<int>({4, 5, 6, 7}) && c.sel.f.empty());
        assert(setSelectMode(c, 1) && c.sel.e.size() == 4 && c.sel.v.empty());
        assert(setSelectMode(c, 2) && c.sel.f == std::set<int>({1}));
        // two lone vertices are not enough for a face
        setSelectMode(c, 0); c.sel.v = {4, 5}; assert(setSelectMode(c, 2) && c.sel.f.empty());
        // invert / select all
        setSelectMode(c, 2); c.sel.clearSets(); selectAllActive(c); assert(c.sel.f.size() == 6);
        invertActive(c); assert(c.sel.f.empty()); (void)cid;
    }

    // picking vertices / edges with occlusion
    {
        Scene c; addPrimitive(c, 0); setEditMode(c, true);
        float tol = 0.02f; Vec3 eye{3, 3, 3};
        assert(pickActiveVertex(c, eye, normalized(Vec3{-1, -1, -1}), tol) == 6);       // front corner, not the hidden one behind it
        assert(pickActiveVertex(c, eye, normalized(Vec3{-1, 0.2f, -1}), tol) == -1);      // empty space
        Edge ed; Vec3 e2{0, -5, 5};
        assert(pickActiveEdge(c, e2, normalized(Vec3{0, 4, -4}), tol, &ed) && ed == mkEdge(4, 5));
        assert(!pickActiveEdge(c, Vec3{0, -5, 5}, normalized(Vec3{0, 1, 0.2f}), 0.001f, &ed));
    }

    // extrude edges of a plane (boundary edge) -> strip of quads, new edge selected, exact undo
    {
        Scene c; uint32_t pid = addPrimitive(c, 1); setEditMode(c, true); setSelectMode(c, 1);
        Mesh orig = c.find(pid)->mesh; c.toggleEdge(mkEdge(0, 1));
        assert(extrudeSelected(c, 0.5f));
        const Mesh& m = c.find(pid)->mesh;
        assert(m.v.size() == 6 && m.f.size() == 2 && validMesh(m));
        assert(m.v[4].z == 0.5f && m.v[5].z == 0.5f && c.sel.e.size() == 1 && *c.sel.e.begin() == mkEdge(4, 5));
        assert(c.undo() && sameMesh(c.find(pid)->mesh, orig) && c.sel.e.count(mkEdge(0, 1)) == 1);  // selection restored too
        assert(c.redo() && c.find(pid)->mesh.f.size() == 2);
        assert(!extrudeSelected(c, 0.f));
    }
    // extrude from vertex mode: 4 verts of a face extrude as a face; 2 verts extrude as an edge
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0);
        c.sel.v = {4, 5, 6, 7}; assert(extrudeSelected(c, 1.f));
        const Mesh& m = c.find(cid)->mesh; assert(m.v.size() == 12 && m.f.size() == 10 && closed(m) && c.sel.v.size() == 4);
        float maxz = -9; for (auto& v : m.v) maxz = std::max(maxz, v.z); assert(std::fabs(maxz - 2.f) < 1e-5f);
        setSelectMode(c, 0); c.sel.v = {0, 1}; assert(extrudeSelected(c, 0.3f)); assert(c.find(cid)->mesh.f.size() == 11);
    }
    // delete vertices / edges
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0);
        c.sel.v = {0}; assert(deleteSelection(c)); const Mesh& m = c.find(cid)->mesh;   // 3 faces touch a corner
        assert(m.f.size() == 3 && validMesh(m) && c.sel.v.empty()); assert(c.undo() && c.find(cid)->mesh.f.size() == 6 && c.sel.v.count(0));
        setSelectMode(c, 1); c.sel.clearSets(); c.toggleEdge(mkEdge(0, 1)); assert(deleteSelection(c) && c.find(cid)->mesh.f.size() == 4);
    }
    // inset: ring of quads, inner face keeps its index and orientation, area drops as expected
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(!insetSelected(c, 0.f) && !insetSelected(c, 1.f));
        assert(insetSelected(c, 0.5f)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m) && closed(m) && c.sel.f == std::set<int>({1}));
        assert(std::fabs(faceArea(m, m.f[1]) - 1.f) < 1e-5f);           // 2x2 face scaled by 0.5 -> 1x1
        assert(std::fabs(totalArea(m) - (20.f + 1.f + 3.f)) < 1e-4f);   // 5 untouched faces (20) + inner (1) + ring (4-1=3)
        assert(dot(faceNormal(m, m.f[1]), Vec3{0, 0, 1}) > 0.99f);
    }
    // subdivide: watertight, area preserved, neighbours get the new midpoints
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(subdivideSelected(c)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 13 && m.f.size() == 9 && validMesh(m) && closed(m) && c.sel.f.size() == 4);
        assert(std::fabs(totalArea(m) - 24.f) < 1e-4f);
        for (const auto& fc : m.f) assert(dot(faceNormal(m, fc), Vec3{0, 0, 0}) == 0 && length(faceNormal(m, fc)) > 0.99f);
        assert(subdivideSelected(c) && closed(c.find(cid)->mesh) && std::fabs(totalArea(c.find(cid)->mesh) - 24.f) < 1e-3f);  // repeatable
        assert(c.undo() && c.undo() && sameMesh(c.find(cid)->mesh, makeCube()));
    }
    // merge at center collapses a face into a vertex (cube -> pyramid-like, 5 verts / 5 faces)
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0); c.sel.v = {4, 5, 6, 7};
        assert(mergeSelectedAtCenter(c)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 5 && m.f.size() == 5 && validMesh(m) && closed(m) && c.sel.v.size() == 1);
        int tip = *c.sel.v.begin(); assert(std::fabs(m.v[tip].z - 1.f) < 1e-6f && std::fabs(m.v[tip].x) < 1e-6f);
        assert(!mergeSelectedAtCenter(c));   // one vertex is nothing to merge
    }
    // flip normals
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(flipSelectedFaces(c)); assert(dot(faceNormal(c.find(cid)->mesh, c.find(cid)->mesh.f[1]), Vec3{0, 0, 1}) < -0.99f);
        assert(c.undo() && sameMesh(c.find(cid)->mesh, makeCube()));
    }
    // edit-mode transforms about the pivot
    {
        Mesh m = makeCube(); std::vector<char> top(8, 0); for (int i = 4; i < 8; ++i) top[i] = 1;
        assert(moveVertices(m, top, Vec3{0, 0, 2}) && m.v[4].z == 3.f && m.v[0].z == -1.f);
        assert(scaleVertices(m, top, Vec3{0.5f, 0.5f, 1.f}) && std::fabs(m.v[6].x - 0.5f) < 1e-6f && m.v[6].z == 3.f);
        assert(rotateVertices(m, top, 2, 90.f) && std::fabs(m.v[6].x + 0.5f) < 1e-5f && std::fabs(m.v[6].y - 0.5f) < 1e-5f);
        std::vector<char> none(8, 0); assert(!moveVertices(m, none, Vec3{1, 0, 0}) && !rotateVertices(m, none, 0, 10.f));
    }
    // history keeps selection valid after the object is removed
    {
        Scene c; addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0); c.sel.v = {0, 1};
        c.undo(); assert(c.sel.v.empty() && !c.editMode);
    }

    // ================= v0.4: loop cut + edge loops =================
    puts("v0.4 tests...");
    {   // cube: ring of 4 quads is cut at x=-0.5 for EVERY ring edge (direction stays consistent)
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 1); c.toggleEdge(mkEdge(0, 1));
        assert(!loopCutSelected(c, 0.f) && !loopCutSelected(c, 1.f));
        assert(loopCutSelected(c, 0.25f)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m) && closed(m) && c.sel.e.size() == 4);
        for (size_t i = 8; i < 12; ++i) assert(std::fabs(m.v[i].x + 0.5f) < 1e-6f);
        assert(std::fabs(totalArea(m) - 24.f) < 1e-4f);
        assert(c.undo() && sameMesh(c.find(cid)->mesh, makeCube()) && c.sel.e.count(mkEdge(0, 1)));
        // vertex mode: two verts forming an edge work too
        setSelectMode(c, 0); c.sel.clearSets(); c.sel.v = {0, 1}; assert(loopCutSelected(c, 0.5f) && c.sel.v.size() == 4);
    }
    {   // plane: open ring of one quad
        Scene c; uint32_t pid = addPrimitive(c, 1); setEditMode(c, true); setSelectMode(c, 1); c.toggleEdge(mkEdge(0, 1));
        assert(loopCutSelected(c, 0.5f) && c.find(pid)->mesh.v.size() == 6 && c.find(pid)->mesh.f.size() == 2);
    }
    {   // sphere: closed ring around the body, and an open ring ending in cap triangles stays watertight
        Scene c; uint32_t sid = addPrimitive(c, 3); setEditMode(c, true); setSelectMode(c, 1);
        c.toggleEdge(mkEdge(1, 17)); assert(loopCutSelected(c, 0.5f)); assert(c.find(sid)->mesh.v.size() == makeUVSphere().v.size() + 16);
        assert(closed(c.find(sid)->mesh) && std::fabs(totalArea(c.find(sid)->mesh) - totalArea(makeUVSphere())) < 1e-3f);
        Scene d; uint32_t did = addPrimitive(d, 3); setEditMode(d, true); setSelectMode(d, 1);
        d.toggleEdge(mkEdge(1, 2)); assert(loopCutSelected(d, 0.5f)); assert(closed(d.find(did)->mesh) && validMesh(d.find(did)->mesh));
    }
    {   // edge loops on a 4x4 grid (plane subdivided twice): centre line has 4 edges; corner-ish edge stays short
        Scene c; uint32_t pid = addPrimitive(c, 1); setEditMode(c, true); setSelectMode(c, 2);
        selectAllActive(c); assert(subdivideSelected(c)); assert(subdivideSelected(c));
        const Mesh& m = c.find(pid)->mesh; assert(m.f.size() == 16);
        setSelectMode(c, 1); c.sel.clearSets();
        Edge pick{-1, -1};
        for (const auto& e : uniqueEdges(m)) if (std::fabs(m.v[e.first].y) < 1e-6f && std::fabs(m.v[e.second].y) < 1e-6f) { pick = e; break; }
        assert(pick.first >= 0); c.toggleEdge(pick);
        assert(selectLoopActive(c) && c.sel.e.size() == 4);
        for (const auto& e : c.sel.e) assert(std::fabs(m.v[e.first].y) < 1e-6f && std::fabs(m.v[e.second].y) < 1e-6f);
        c.sel.clearSets(); assert(!selectLoopActive(c));
    }
    {   // cube corner edges have valence 3, so the loop is the single edge
        Scene c; addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 1); c.toggleEdge(mkEdge(0, 1));
        assert(selectLoopActive(c) && c.sel.e.size() == 1);
    }

    // ================= v0.5: modifier stack =================
    puts("v0.5 tests...");
    {   // mirror: open half box (cube shifted to x in [0,2] without its x=0 face) becomes a closed 4x2x2 box
        Scene c; uint32_t id = addPrimitive(c, 0); Object* o = c.find(id);
        for (auto& v : o->mesh.v) v.x += 1.f;
        assert(deleteFaces(o->mesh, {4}));          // face {0,4,7,3} lies on x=0
        o->meshRev = nextRev();
        assert(o->mesh.f.size() == 5 && o->mesh.v.size() == 8);
        assert(addModifier(c, kMirror)); assert(c.find(id)->mods.size() == 1);
        const Mesh& d = displayMesh(*c.find(id));
        assert(d.v.size() == 12 && d.f.size() == 10 && validMesh(d) && closed(d) && std::fabs(totalArea(d) - 40.f) < 1e-4f);
        float mn = 9; for (auto& v : d.v) mn = std::min(mn, v.x); assert(std::fabs(mn + 2.f) < 1e-6f);
        for (const auto& fc : d.f) { Vec3 cen; for (int i : fc) cen = cen + d.v[i]; cen = cen * (1.f / fc.size()); assert(dot(faceNormal(d, fc), cen) > 0); }
        assert(c.find(id)->mesh.v.size() == 8);     // base mesh untouched (non destructive)
        // toggling off shows the base mesh again; on again re-evaluates
        assert(toggleModifier(c, 0)); assert(displayMesh(*c.find(id)).f.size() == 5);
        assert(toggleModifier(c, 0)); assert(displayMesh(*c.find(id)).f.size() == 10);
        // editing the base mesh updates the evaluated mesh
        c.find(id)->mesh.v[1].z += 1.f; c.find(id)->meshRev = nextRev(); assert(displayMesh(*c.find(id)).v.size() == 12);
        // apply bakes the result into the base mesh and undo restores both
        Mesh baseBefore = c.find(id)->mesh;
        assert(applyModifierAt(c, 0)); assert(c.find(id)->mods.empty() && c.find(id)->mesh.f.size() == 10 && closed(c.find(id)->mesh));
        assert(c.undo()); assert(c.find(id)->mods.size() == 1 && sameMesh(c.find(id)->mesh, baseBefore));
        assert(c.redo() && c.find(id)->mesh.f.size() == 10);
    }
    {   // array: 3 copies, offset 3 along X; stack order matters; limits
        Scene c; uint32_t id = addPrimitive(c, 0); assert(addModifier(c, kArray));
        Modifier m = c.find(id)->mods[0]; m.count = 3; m.offset[0] = 3.f; assert(setModifier(c, 0, m));
        const Mesh& d = displayMesh(*c.find(id));
        assert(d.v.size() == 24 && d.f.size() == 18 && validMesh(d) && closed(d) && std::fabs(totalArea(d) - 72.f) < 1e-3f);
        float mx = -9; for (auto& v : d.v) mx = std::max(mx, v.x); assert(std::fabs(mx - 7.f) < 1e-6f);
        // objects are pickable where the arrayed copies are, not only where the base mesh is
        assert(pickObject(c, Vec3{6, 10, 0}, Vec3{0, -1, 0}) == id);
        c.find(id)->mods[0].enabled = false; c.find(id)->modsRev = nextRev(); assert(pickObject(c, Vec3{6, 10, 0}, Vec3{0, -1, 0}) == 0);
        c.find(id)->mods[0].enabled = true; c.find(id)->modsRev = nextRev();
        Modifier bad = m; bad.count = 0; assert(!setModifier(c, 0, bad)); bad.count = 65; assert(!setModifier(c, 0, bad));
        assert(addModifier(c, kMirror) && moveModifier(c, 1, -1) && c.find(id)->mods[0].type == kMirror && !moveModifier(c, 0, -1));
        assert(removeModifier(c, 0) && c.find(id)->mods.size() == 1 && !removeModifier(c, 5));
        assert(c.undo() && c.undo() && c.undo() && c.find(id)->mods.size() == 1);   // back to the first array state (count 2)
        assert(!applyModifierAt(c, 3));
    }
    {   // project v3 round trip, v2 files still load, corrupt modifiers are rejected
        Scene c; uint32_t id = addPrimitive(c, 0); addModifier(c, kArray); Modifier m = c.find(id)->mods[0]; m.count = 4; m.offset[1] = 2.5f; setModifier(c, 0, m);
        addModifier(c, kMirror); toggleModifier(c, 1);
        assert(saveProject(c, "/tmp/atlas_t3.atlas"));
        Scene q; assert(loadProject(q, "/tmp/atlas_t3.atlas") && q.objects[0].mods.size() == 2);
        assert(q.objects[0].mods[0].count == 4 && q.objects[0].mods[0].offset[1] == 2.5f && !q.objects[0].mods[1].enabled && q.objects[0].mods[1].type == kMirror);
        assert(displayMesh(q.objects[0]).f.size() == 24);
        FILE* f = fopen("/tmp/atlas_v2.atlas", "w"); fputs("ATLAS 2\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nend\n", f); fclose(f);
        Scene o2; assert(loadProject(o2, "/tmp/atlas_v2.atlas") && o2.objects[0].mods.empty());
        f = fopen("/tmp/atlas_badmod.atlas", "w"); fputs("ATLAS 3\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nmods 1\nmod 1 1 0 0.001 0 1 0 0\nend\n", f); fclose(f);
        Scene keep; addPrimitive(keep, 0); std::string err;
        assert(!loadProject(keep, "/tmp/atlas_badmod.atlas", &err) && keep.objects.size() == 1);
        f = fopen("/tmp/atlas_nomods.atlas", "w"); fputs("ATLAS 3\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nend\n", f); fclose(f);
        assert(!loadProject(keep, "/tmp/atlas_nomods.atlas", &err) && keep.objects.size() == 1);
    }

    {   // 0.7.0: Catmull-Clark subdivision surface
        Mesh cu = makeCube(); Modifier sm; sm.type = kSubsurf; sm.levels = 1;
        Mesh l1 = applyModifier(cu, sm); int e1 = 0;
        assert(l1.v.size() == 26 && l1.f.size() == 24 && closedManifold(l1, &e1) && (int)l1.v.size() - e1 + (int)l1.f.size() == 2);
        for (const auto& fc : l1.f) assert(fc.size() == 4);
        bool foundCorner = false, foundEdge = false;
        for (const auto& v : l1.v) { if (near(v.x, 5.f / 9) && near(v.y, 5.f / 9) && near(v.z, 5.f / 9)) foundCorner = true; if (near(v.x, .75f) && near(v.y, .75f) && near(v.z, 0)) foundEdge = true; }
        assert(foundCorner && foundEdge);   // corner rule (F+2R+(n-3)P)/n and edge rule (A+B+F1+F2)/4 checked against hand-computed values
        sm.levels = 2; Mesh l2 = applyModifier(cu, sm); e1 = 0;
        assert(l2.f.size() == 96 && l2.v.size() == 98 && closedManifold(l2, &e1) && (int)l2.v.size() - e1 + (int)l2.f.size() == 2);
        assert(signedVolume(l2) > 2.0 && signedVolume(l2) < 8.0 && signedVolume(l1) < 8.0 && signedVolume(l1) > 2.0);   // smooth, shrinks the cube, outward normals
        float mx = 0; for (const auto& v : l2.v) mx = std::max(mx, std::max(std::fabs(v.x), std::max(std::fabs(v.y), std::fabs(v.z)))); assert(mx < 1.f);
        Mesh sp = makeUVSphere(); sm.levels = 1; Mesh sp1 = applyModifier(sp, sm); assert(closedManifold(sp1) && signedVolume(sp1) > 0 && sp1.f.size() > sp.f.size());
        // boundary rule: a single quad keeps a straight border and corners pull in by the B-spline rule
        Mesh pl = makePlane(); Mesh pl1 = applyModifier(pl, sm);
        assert(pl1.f.size() == 4 && pl1.v.size() == 9);
        float w0 = 0; for (const auto& v : pl.v) w0 = std::max(w0, v.x);
        bool corner = false, border = false;
        for (const auto& v : pl1.v) { if (near(v.x, -0.75f * w0) && near(v.y, -0.75f * w0)) corner = true; if (near(v.x, -w0) && near(v.y, 0)) border = true; }
        assert(corner && border);   // corner -> 0.75P + 0.125(A+B); boundary edge point stays on the border line
        for (const auto& v : pl1.v) assert(near(v.z, 0));
        // no mutation of the input, levels bounded, absurd size guarded
        assert(sameMesh(cu, makeCube()));
        Modifier bad = sm; bad.levels = 0; assert(!validModifier(bad)); bad.levels = 5; assert(!validModifier(bad));
        // stack: mirror then subsurf; object picking + display use the evaluated result; apply bakes with one undo step
        Scene c; uint32_t id = addPrimitive(c, 0); assert(addModifier(c, kSubsurf));
        assert(displayMesh(*c.find(id)).f.size() == 24);
        Modifier m = c.find(id)->mods[0]; m.levels = 3; assert(setModifier(c, 0, m) && displayMesh(*c.find(id)).f.size() == 384);
        assert(!setModifier(c, 0, m));   // no-op: no undo step
        assert(applyModifierAt(c, 0) && c.find(id)->mesh.f.size() == 384 && c.find(id)->mods.empty());
        assert(c.undo() && c.find(id)->mesh.f.size() == 6 && c.find(id)->mods.size() == 1 && c.undo() && c.find(id)->mods[0].levels == 1);
    }
    {   // 0.7.0: Solidify
        Modifier so; so.type = kSolidify; so.thickness = 0.1f; so.shift = -1.f;
        Mesh cu = makeCube(); Mesh sc = applyModifier(cu, so);
        assert(sc.v.size() == 16 && sc.f.size() == 12 && closedManifold(sc));
        // outer shell is the original cube (shift -1), inner shell is 0.1 inside on every face: volume 8 - 1.8^3
        assert(near((float)signedVolume(sc), 8.f - 1.8f * 1.8f * 1.8f, 1e-3f));
        for (int i = 0; i < 8; ++i) assert(near(sc.v[i].x, cu.v[i].x) && near(sc.v[i].y, cu.v[i].y) && near(sc.v[i].z, cu.v[i].z));
        so.shift = 1.f; Mesh out = applyModifier(cu, so); assert(near((float)signedVolume(out), 2.2f * 2.2f * 2.2f - 8.f, 1e-3f));   // grows outward, inner shell = original
        so.shift = 0.f; Mesh mid = applyModifier(cu, so); assert(near((float)signedVolume(mid), 2.1f * 2.1f * 2.1f - 1.9f * 1.9f * 1.9f, 1e-3f));
        // open mesh gets a rim: a plane becomes a closed slab of volume area * thickness
        so.shift = -1.f; so.thickness = 0.2f; Mesh pl = makePlane(); Mesh sp = applyModifier(pl, so);
        assert(sp.v.size() == 8 && sp.f.size() == 6 && closedManifold(sp));
        float w = pl.v[0].x, area = 0; for (const auto& v : pl.v) w = std::max(w, v.x); area = (2 * w) * (2 * w);
        assert(near((float)signedVolume(sp), area * 0.2f, 1e-3f));
        assert(!validModifier([&] { Modifier b = so; b.thickness = 0; return b; }()) && !validModifier([&] { Modifier b = so; b.shift = 2; return b; }()));
        // chaining with subsurf keeps the surface closed and with outward normals
        Modifier sm; sm.type = kSubsurf; sm.levels = 1; Mesh both = applyModifier(sc, sm); assert(closedManifold(both) && signedVolume(both) > 0);
        // scene: undo/redo and apply
        Scene c; uint32_t id = addPrimitive(c, 0); assert(addModifier(c, kSolidify) && c.find(id)->mods[0].thickness == 0.1f);
        Modifier m = c.find(id)->mods[0]; m.thickness = 0.3f; assert(setModifier(c, 0, m) && displayMesh(*c.find(id)).v.size() == 16);
        assert(applyModifierAt(c, 0) && c.find(id)->mesh.f.size() == 12); assert(c.undo() && c.find(id)->mesh.f.size() == 6);
    }
    {   // project v4 round trip keeps subsurf/solidify parameters; v3 files still load with defaults
        Scene c; uint32_t id = addPrimitive(c, 0); addModifier(c, kSubsurf); addModifier(c, kSolidify);
        Modifier a = c.find(id)->mods[0]; a.levels = 3; setModifier(c, 0, a);
        Modifier b = c.find(id)->mods[1]; b.thickness = 0.25f; b.shift = 0.5f; setModifier(c, 1, b);
        assert(saveProject(c, "/tmp/atlas_t4.atlas"));
        Scene q; assert(loadProject(q, "/tmp/atlas_t4.atlas") && q.objects[0].mods.size() == 2);
        assert(q.objects[0].mods[0].type == kSubsurf && q.objects[0].mods[0].levels == 3 && q.objects[0].mods[1].type == kSolidify);
        assert(near(q.objects[0].mods[1].thickness, 0.25f) && near(q.objects[0].mods[1].shift, 0.5f));
        FILE* f = fopen("/tmp/atlas_v3b.atlas", "w"); fputs("ATLAS 3\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nmods 1\nmod 0 1 0 0.001 2 1 0 0\nend\n", f); fclose(f);
        Scene o3; assert(loadProject(o3, "/tmp/atlas_v3b.atlas") && o3.objects[0].mods.size() == 1 && o3.objects[0].mods[0].levels == 1);
        f = fopen("/tmp/atlas_badv4.atlas", "w"); fputs("ATLAS 4\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nmods 1\nmod 2 1 0 0.001 2 1 0 0 9 0.1 -1\nend\n", f); fclose(f);
        Scene keep; addPrimitive(keep, 0); std::string err; assert(!loadProject(keep, "/tmp/atlas_badv4.atlas", &err) && keep.objects.size() == 1);
    }

    puts("all tests passed"); return 0;
}
