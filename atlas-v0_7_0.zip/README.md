# Atlas
Independent 3D creation app for Android (no Blender code). See FEATURES.md for per-feature status and
**ATLAS_HANDOFF.md for the full project context (read it first if you are an AI continuing this work).**

## Build
CI builds the APK (`.github/workflows/build.yml`) and runs the core tests first. Locally: `gradle :app:assembleDebug`.
Core tests (host, no Android needed): `g++ -std=c++17 -Wall -Wextra -O1 tests/test_scene.cpp -o t && ./t`.

## Controls (landscape)
- Select tool: 1 finger orbit, 2 fingers pan, pinch zoom, tap selects (object, or vertex/edge/face in Edit Mode; tap again to deselect).
- Move/Rotate/Scale: 1 finger drag transforms the selection (X/Y/Z buttons constrain), 2 fingers orbit. Works on objects and on mesh selections.
- Modeling tab / Object Mode menu enters Edit Mode. Header buttons ● ╱ ▣ switch vertex / edge / face selection.
- Mesh menu: Extrude (distance field in Properties), Inset Faces (amount field), Loop Cut (position field), Select Edge Loop, Subdivide, Merge at Center, Flip Normals, Delete.

## Modifiers
Properties > Modifiers: `+ Mirror` / `+ Array` / `+ Subsurf` / `+ Solidify`. Each card has On/Off, reorder, Apply (bakes into the mesh, Object Mode) and remove. Mirror: pick the axis. Array: count + offset X/Y/Z. Subsurf: levels 1-4. Solidify: thickness + offset In/Center/Out.
