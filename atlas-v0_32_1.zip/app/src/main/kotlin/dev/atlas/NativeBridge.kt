package dev.atlas

object NativeBridge {
    init { System.loadLibrary("atlas") }
    // lifecycle / render
    external fun init()
    external fun resize(w: Int, h: Int)
    external fun draw()
    external fun ensureScene()
    external fun newScene()
    // camera
    external fun orbit(dx: Float, dy: Float)
    external fun pan(dx: Float, dy: Float)
    external fun zoom(factor: Float)
    external fun viewPreset(p: Int)
    external fun resetView()
    external fun frameSelected(): Boolean
    external fun setShading(m: Int)
    // scene
    external fun addPrimitive(kind: Int): Boolean
    external fun addPreset(kind: Int): Boolean
    external fun duplicateSelected(): Boolean
    external fun deleteSelected(): Boolean
    external fun selectObject(id: Int): Boolean
    external fun selectAll()
    external fun selectNone()
    external fun tap(x: Float, y: Float): Int
    external fun setMode(m: Int): Boolean
    external fun mode(): Int
    external fun extrude(dist: Float): Boolean
    external fun setSelectMode(m: Int): Boolean   // 0 vertex, 1 edge, 2 face
    external fun selectMode(): Int
    external fun selectInvert()
    external fun deleteSelection(): Boolean
    external fun insetFaces(amount: Float): Boolean
    external fun subdivide(): Boolean
    external fun mergeCenter(): Boolean
    external fun flipNormals(): Boolean
    external fun loopCut(t: Float): Boolean
    // modifier stack (0 Mirror, 1 Array, 2 Subsurf, 3 Solidify, 4 Triangulate, 5 Weld, 6 Smooth, 7 Simple Deform, 8 Planar Decimate, 9 Bevel)
    external fun addModifier(type: Int): Boolean
    external fun removeModifier(i: Int): Boolean
    external fun toggleModifier(i: Int): Boolean
    external fun moveModifier(i: Int, delta: Int): Boolean
    external fun applyModifier(i: Int): Boolean
    external fun setModifier(i: Int, axis: Int, count: Int, offset: FloatArray): Boolean
    external fun setModifierParams(i: Int, levels: Int, thickness: Float, shift: Float): Boolean
    external fun setModifierMerge(i: Int, merge: Float): Boolean
    external fun setModifierExtra(i: Int, axis: Int, factor: Float, iterations: Int, mode: Int, angle: Float): Boolean
    external fun renameSelected(name: String): Boolean
    external fun applyTransform(mode: Int): Boolean
    external fun originToGeometry(): Boolean
    external fun selectLinked(): Boolean
    external fun selectMore(): Boolean
    external fun selectLess(): Boolean
    external fun joinAll(): Int              // objects merged into the active one (Object Mode)
    external fun weldSelected(dist: Float): Boolean
    external fun dissolveEdges(): Boolean
    external fun limitedDissolve(angle: Float): Boolean
    external fun separateSelected(): Boolean
    external fun dissolveVertices(): Boolean
    external fun dissolveFaces(): Boolean
    external fun separateLoose(): Int        // number of NEW objects (Object Mode)
    external fun fillSelected(): Boolean
    external fun bridgeLoops(twist: Int): Boolean
    external fun selectSharp(angle: Float): Boolean
    external fun bevelVertices(width: Float): Boolean
    external fun bevelEdges(width: Float): Boolean
    external fun triangulateFaces(): Boolean
    external fun pokeFaces(offset: Float): Boolean
    external fun trisToQuads(maxAngle: Float): Boolean
    external fun selectSimilarNormal(angle: Float): Boolean
    external fun rotateEdges(): Boolean
    external fun duplicateFaces(): Boolean
    external fun spinEdges(axis: Int, angleDeg: Float, steps: Int): Boolean
    external fun selectSimilarPerimeter(tolPercent: Float): Boolean
    external fun selectSimilarArea(tolPercent: Float): Boolean
    external fun recalcNormals(inside: Boolean): Boolean
    external fun selectBoundary(): Boolean
    external fun selectNonManifold(): Boolean
    external fun selectRandom(ratio: Float, seed: Int): Boolean
    external fun setProportional(on: Boolean, radius: Float, falloff: Int, connected: Boolean)
    external fun boxSelect(x0: Float, y0: Float, x1: Float, y1: Float, op: Int, xray: Boolean): Boolean
    external fun edgeSlide(t: Float): Boolean
    external fun modifiers(): String
    external fun selectLoop(): Boolean
    // interactive transform
    external fun beginTransform(tool: Int, axis: Int): Boolean
    external fun dragStep(tdx: Float, tdy: Float, sdx: Float, sdy: Float)
    external fun endTransform()
    external fun cancelTransform()
    // history & files
    external fun undo(): Boolean
    external fun redo(): Boolean
    external fun save(path: String): Boolean
    external fun load(path: String): Boolean
    // UI state
    external fun outliner(): String
    external fun stats(): String
    external fun activeTransform(): FloatArray
    external fun setActiveTransform(v: FloatArray): Boolean
    // rig (0.31.0 / 0.32.0)
    external fun addArmature(): Boolean
    external fun armInfo(): String
    external fun armatures(): String
    external fun armSelectBone(i: Int): Boolean
    external fun armAddBone(hx: Float, hy: Float, hz: Float, tx: Float, ty: Float, tz: Float, parent: Int, connected: Boolean): Int
    external fun armExtrude(dx: Float, dy: Float, dz: Float): Int
    external fun armDelete(): Boolean
    external fun armSetParent(child: Int, parent: Int, connected: Boolean): Boolean
    external fun armRename(i: Int, name: String): Boolean
    external fun armSetRest(i: Int, v: FloatArray): Boolean
    external fun armSetPose(i: Int, v: FloatArray): Boolean
    external fun armSetDeform(i: Int, on: Boolean): Boolean
    external fun armResetPose(all: Boolean): Boolean
    external fun armMirror(all: Boolean): Boolean
    external fun bindToArmature(id: Int): Boolean
    external fun unbindArmature(): Boolean
    external fun assignWeight(bone: Int, w: Float): Boolean
}
