# Features (status per feature)
| Feature | Status |
|---|---|
| Scene graph (flat, single collection), persistent ids, unique names | Implemented and tested (host) |
| Polygon mesh core (n-gon faces), primitives: cube, plane, cylinder, UV sphere | Implemented and tested (host) |
| Edit Mode element selection: vertex / edge / face, mode conversion, select all/none/invert | Implemented and tested (host) |
| Picking of vertices and edges with occlusion test (screen-radius tolerance) | Implemented and tested (host); touch feel untested on device |
| Extrude: faces, edges (strip of quads), from vertex mode (auto-detects faces/edges) | Implemented and tested (host) |
| Inset faces (individual, towards centroid), Subdivide faces (watertight with neighbours), Merge at Center, Flip Normals | Implemented and tested (host) |
| Loop Cut (quad ring, position 0–1, consistent direction, watertight at ring ends) and Select Edge Loop (through valence-4 vertices) | Implemented and tested (host) |
| Non-destructive modifier stack: Mirror (X/Y/Z, welds on-plane vertices) and Array (count + offset); enable/disable, reorder, remove, Apply (bake), one undo step each | Implemented and tested (host); UI untested on device |
| Viewport/picking show the evaluated mesh; edit mode shows the base mesh as cage | Implemented and tested (host picking); rendering untested on device |
| Project format v4 (modifier stacks + subsurf/solidify params), v1/v2/v3 still load, corrupt modifier records rejected (superseded by v5 below) | Implemented and tested (host) |
| Delete vertices / edges / faces | Implemented and tested (host) |
| Edit-mode Move / Rotate / Scale of any selection about its median point | Implemented and tested (host math); drag gesture untested on device |
| Undo/redo restores mesh AND element selection | Implemented and tested (host) |
| Move / Rotate / Scale objects by drag, X/Y/Z constraint, one undo step per gesture | Implemented but untested on device |
| Numeric Location/Rotation/Scale fields (Properties) | Implemented but untested on device |
| Command undo/redo (add, delete, transform, mesh edit) | Implemented and tested (host) |
| Project format (atomic save, migration from older versions) | Implemented and tested (host) |
| Viewport: orbit/pan/zoom, view presets, frame selected, wireframe/solid, axis gizmo | Implemented but untested on device |
| Edit overlay rendering (vertex dots, selected edges, selected faces) | Implemented but untested on device (compiles against stub GL only) |
| Blender-style shell: menus, workspace tabs, Outliner, Properties, header, status bar | Implemented but untested on device |
| Bevel Edges (Mesh menu + Bevel Width field; ONE segment, flat chamfer; closed manifold meshes only; width measured along the edges = exact for 90° corners, approximate otherwise; caps close corners; clamped to 0.49 x edge length) | Implemented and tested (host: exact volumes, Euler, valence 3/4/16); UI untested on device |
| Edge Slide (Mesh menu + Edge Slide Factor field -1..1; selected edge chains/rings slide along the side edges, topology unchanged; sign = side, consistent within a chain; open-border chains only slide inwards) | Implemented and tested (host); UI untested on device |
| Proportional Editing (Properties: radius in LOCAL units, Prop On/Off, falloff Smooth/Linear/Sharp/Constant, Connected On/Off; applies to Move/Rotate/Scale drags in Edit Mode; Connected = distance along mesh edges) | Implemented; weights and weighted move/rotate/scale tested on host, the drag wiring (bridge.cpp) and UI untested on device |
| Box Select (tool ▭ in the left column; drag a rectangle in Edit Mode; Replace/Add/Subtract and X-Ray toggles in Properties; vertices inside / edges with both ends inside and visible midpoint / faces by centroid) | Implemented; projection and selection tested on host (incl. occlusion, X-Ray, all 3 ops), rubber band and gesture untested on device |
| Triangulate Faces (selected faces with 4+ vertices; ear clipping, concave safe) and Poke Faces (centroid + Poke Offset along the normal, fan of triangles; best on convex faces) in the Mesh menu | Implemented and tested (host: counts, exact volumes, undo); UI untested on device |
| Recalculate Normals outside/inside (Mesh menu; whole mesh: consistent winding by flood fill, then each CLOSED component is oriented by its signed volume; open components only made consistent) | Implemented and tested (host); UI untested on device |
| Select > Boundary, Non-Manifold (switch to edge mode) and Random (ratio 0-1 + seed, deterministic, exact count, current mode) | Implemented and tested (host); UI untested on device |
| Knife, region inset, interactive (drag) bevel/slide, multi-segment bevel, bevel profile | Not started |
| Subdivision Surface modifier (Catmull-Clark, levels 1-4, boundary + non-manifold rules, quads out) | Implemented and tested (host); UI untested on device |
| Solidify modifier (even thickness, offset In/Center/Out, rim on open meshes, inner shell flipped) | Implemented and tested (host); UI untested on device |
| Viewport lighting: two-sided, camera headlight + Z-up hemisphere ambient + key light (back faces no longer near-black) | Implemented but untested on device (compiles against stub GL only) |
| UI cleanup: compact header (Solid/Wire text buttons, no clipped glyph), taller Properties panel with bottom padding | Implemented but untested on device |
| Triangulate modifier (ear clipping, concave n-gons OK, winding kept) | Implemented and tested (host); UI untested on device |
| Weld modifier + Mesh > Merge by Distance (selected vertices only, clusters collapse to centroid, degenerate faces dropped) | Implemented and tested (host); UI untested on device |
| Object ops: Rename (tap the name in Properties), Apply All Transforms / Apply Scale (negative scale flips winding), Origin to Geometry, all undoable | Implemented and tested (host); UI untested on device |
| Select > Linked in Edit Mode (whole connected island, vertex/edge/face modes) | Implemented and tested (host); UI untested on device |
| Dissolve Edges (Mesh menu; edge/vertex mode: selected edges, face mode: merges selected faces; chains become one polygon; straight leftover vertices removed) | Implemented and tested (host); UI untested on device |
| Limited Dissolve (Mesh menu; angle field, only the selected faces, removes vertices left straight) | Implemented and tested (host); UI untested on device |
| Separate Selection (Mesh menu; selected faces become a new object with the same transform and modifiers; one undo step) | Implemented and tested (host); UI untested on device |
| Dissolve Vertices (Mesh menu; faces around each selected vertex merge into one polygon, the vertex is removed; border vertices with 2 neighbours are removed from their faces) | Implemented and tested (host); UI untested on device |
| Dissolve Faces (Mesh menu; merges the selected neighbouring faces into one polygon per group) | Implemented and tested (host); UI untested on device |
| Separate Loose Parts (Object menu, Object Mode; one new object per connected part, first part stays in the original; same transform + modifiers; one undo step) | Implemented and tested (host); UI untested on device |
| Fill (Mesh menu; ONE closed loop of selected edges becomes a polygon, winding matches the neighbouring faces so holes close with outward normals) | Implemented and tested (host); UI untested on device |
| Bridge Edge Loops (Mesh menu; exactly two closed loops with the same edge count are joined by a ring of quads, second loop auto-aligned by start/direction) | Implemented and tested (host); UI untested on device |
| Bevel Vertices (Mesh menu + Bevel Width field; chamfer of vertices on closed manifold fans, width clamped to 0.49 x edge length; NOT edge bevel) | Implemented and tested (host); UI untested on device |
| Select More / Select Less (Select menu, Edit Mode; grows across edges / shrinks dropping border + open-edge vertices; all 3 modes) | Implemented and tested (host); UI untested on device |
| Join (Object menu, Object Mode; every other object merged into the active one, baked into its local space incl. rotation/scale/mirror; joined objects' modifiers dropped; one undo step) | Implemented and tested (host); UI untested on device |
| Properties > Modifiers: single "+ Add Modifier" dropdown instead of 9 buttons | Implemented, untested (Kotlin not compiled here) |
| Properties modifier cards: title on its own row (no more "Planar D/ecimate" wrapping); header mode button shortened to Object/Edit | Implemented, untested (Kotlin not compiled here) |
| Smooth modifier (Laplacian, factor 0-1, repeat 1-32) | Implemented and tested (host); UI untested on device |
| Simple Deform modifier (Twist / Bend / Taper / Stretch about X/Y/Z, extent-normalized) | Implemented and tested (host); UI untested on device |
| Planar Decimate modifier (Limited Dissolve over the whole mesh, angle limit) | Implemented and tested (host); UI untested on device |
| Project format v5 (Smooth/Deform/Decimate parameters); v1-v4 still load | Implemented and tested (host) |
| Bridge Edge Loops "Bridge Twist" (integer, any sign, wraps; shifts the second loop after the automatic alignment) | Implemented and tested (host); UI untested on device |
| Select > Sharp Edges (Sharp Angle field; edges shared by 2 faces whose normals differ by MORE than the angle; switches to edge mode; selection only) | Implemented and tested (host); UI untested on device |
| Bevel modifier (type 9; width = factor, sharp limit = angle; bevels every sharp edge with Bevel Edges, skips edges touching open borders/non-manifold seams, passes the mesh through when nothing can be beveled) | Implemented and tested (host); UI untested on device |
| Other modifiers (Boolean, collapse Decimate...) | Not started |
| Parenting, collections, multi-select objects, local orientation, ortho view | Not started |
| Timeline / animation | Not started (Phase 6) |
| Workspaces other than Layout/Modeling | Not started (tabs are disabled) |
| Materials, UV, sculpt, rig, render, import/export | Not started |

Known limits (0.22/0.23): Recalculate Normals works on the WHOLE mesh (not just the selection) and orients every closed component on its own, so a hollow solid (shell inside a shell) is not understood; Poke Faces on concave faces can overlap; Select Random replaces the selection. Known limits (0.20/0.21): proportional radius is in the object's LOCAL units (scaled objects feel different), distance is measured on the mesh before the gesture, there is no on-screen falloff circle, and it does not apply to the numeric fields; Box Select works only in Edit Mode, an edge needs BOTH ends inside the box, and hidden-element tests cost O(faces) per element (fine for small meshes, slow on dense ones). Known limits (0.18/0.19): Bridge Twist does not make a torus out of the two ends of ONE tube by itself (only separate loops were tested); the Bevel modifier is ONE segment, bevels ALL sharp edges (no per-edge weights) and silently skips edges near open borders. Known limits (0.16/0.17): Bevel Edges has ONE segment only, refuses open meshes/non-manifold edges and the whole selection if any touched vertex is not a full closed fan; Edge Slide picks the chain direction from the lowest-index end (or arbitrary start for rings), so the sign of the factor is consistent inside a chain but not predictable across several chains, and it refuses chains with 3+ edges at a vertex. 
Known limits: Dissolve/Limited Dissolve merge a connected group of faces only when its outline is ONE simple loop; otherwise the whole group is left alone (so a closed surface that is entirely within the angle, or a ring of faces around a hole, is not merged), they never create holes, keep no vertex normals/UVs (none exist yet), and the straight-vertex cleanup only removes vertices with exactly two neighbours; Separate Selection copies the modifier stack to the new object and has no "by loose parts" mode yet; Smooth is plain Laplacian (shrinks open meshes and closed ones a little, no volume preservation, no vertex-group mask, no per-axis toggles); Simple Deform has no limits/lock/origin object, bend always curves towards the next axis (Z -> X), and its extent is that of the mesh at that point of the stack; Planar Decimate has no "delimit" options and does not triangulate; Weld does not remove faces that become duplicates of each other after merging, and keeps no selection; Apply Transform leaves the modifier stack untouched (Mirror axes etc. act on the baked mesh); Origin to Geometry uses the vertex median (not the bounding-box centre); Subdivision Surface has no creases, no separate viewport/render levels and no UV/normal smoothing (flat shading only); Solidify uses an averaged vertex normal with an even-thickness correction (clamped, so very sharp spikes thin out) and has no per-face thickness or rim material; Mirror has no clipping/mirror-object/bisect options and uses the object-local plane; Array only supports a constant offset; modifier stack is capped at 16; Apply is object-mode only and bakes modifiers 0..i; Loop Cut uses the first selected edge, one cut per operation, position from a numeric field (no interactive slide yet); edit snapshots copy the whole mesh per undo step (fine for small meshes); n-gon fan
triangulation assumes convex faces; Z-up like Blender (import converters will handle Y-up formats);
Inset is per-face (not region) and uses a centroid-relative amount; edge/face extrude distance comes from a
numeric field (the Move tool then drags the result); edit-mode rotate/scale use local axes; vertex/edge
occlusion test is O(faces) per candidate (fine for small meshes, needs a BVH later); loose vertices/edges
cannot exist (meshes are face-based, deleting faces removes orphan vertices).
| Character presets (Add > Preset: Anime Female / Female Body / Male Body; procedural closed parts, A-pose, exact height, X-symmetric, one undo step) | Implemented and tested (host: geometry, symmetry, volumes, undo, save/load); menu UI and proportions untested on device |
| More presets: Chibi, Anime Head (eyes, ears, nose, hair volume, fringe), Hand (palm, 4 fingers, thumb) | Implemented and tested (host: closed parts, volumes, orientation); looks untested on device |
| Tris to Quads (angle limit, convex quads only, best pairs first) and Select Similar > Normal | Implemented and tested (host); UI untested on device |
| Hair and clothes presets for the Anime Female: Long Hair, Twin Tails, Skirt (fit by numbers) | Implemented and tested (host: closed parts, placement bounds); fit/look untested on device |
| Rotate Edge (convex quads, no duplicate edges), Duplicate Faces (edit mode), Select Similar > Area | Implemented and tested (host); UI untested on device |
| Shirt, Shorts, Boots presets for the Anime Female (fit by numbers) | Implemented and tested (host: closed parts, placement bounds); fit/look untested on device |
| Spin / lathe (edges around local X/Y/Z, angle up to 360, 1-128 steps) and Select Similar > Perimeter | Implemented and tested (host); UI untested on device |

## 0.31.0 / 0.32.0 additions (rig, part 1 of 3 — our own implementation; no Blender/Rigify code)
| Feature | Status |
|---|---|
| Armature objects (Add > Armature): bones with head/tail/roll in armature space, parent + "connected", Deform flag, unique names | Implemented and tested (host) |
| Bone editing: add, extrude from active bone, delete (children re-parented, skin remapped), reparent (cycle-safe), rest head/tail/roll, rename; one undo step each | Implemented and tested (host); UI Kotlin not compiled |
| Mirror bones across X (Mirror Bone = active + children, Mirror All), side names `.L/.R`, `_L/_R`, `Left/Right` flipped | Implemented and tested (host) |
| FK pose: per-bone loc / Euler rot / scale in the bone's own frame, propagates down the chain; Reset Pose (bone / all) | Implemented and tested (host); numeric fields only (no viewport gizmo yet) |
| Bind mesh to armature with automatic weights (bone proximity, up to 4 influences, normalized, respects Deform flag and object transforms), Unbind | Implemented and tested (host); proximity-based, NOT heat-diffusion: expect to fix weights near joints |
| Linear blend skinning shown live in the viewport (before the modifier stack; Edit Mode shows the rest mesh); base mesh never modified | Implemented and tested (host); rendering untested on device |
| Weight assignment (Edit Mode, selected vertices -> bone, weight 0-1, others share the rest) | Implemented and tested (host); no brush painting yet |
| Bone display: octahedral wire, X-ray, active bone orange | Implemented, syntax-checked only (renderer.cpp not run on device) |
| Project format v6 (bones, pose, bindings, weights); v1-v5 still load; corrupt rig records rejected | Implemented and tested (host) |
| Bone picking in the viewport by touch | Not started (bones are selected from the Properties list) |
| IK (two-bone + chain), constraints, pole targets, IK/FK switch | Not started (planned 0.33.0) |
| Rig Pro: human metarig template + one-tap generated control rig (FK/IK limbs, spine, fingers, root, ...) — "Rigify-like" | Not started (planned 0.34.0) |
| Weight painting brush, heat-diffusion weights, Apply Pose / Apply Armature to mesh, keyframes | Not started |
