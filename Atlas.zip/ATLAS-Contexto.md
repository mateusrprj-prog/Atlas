# ATLAS — Contexto Completo (arquivo vivo)

> Atualizado em: 15/11/2026 · Sessão 1 · Versão do documento: 0.2
> Regra do projeto: **toda resposta termina com este arquivo atualizado + o .zip do projeto inteiro.**

## 1. O que estamos fazendo
Um "Blender mobile" **de verdade** para Android: o ambiente profissional de criação 3D
(modelagem, sculpt, UV, texturas, shading, rig, animação, física, render, compositor, vídeo, VFX, scripting),
rodando 100% no celular/tablet. Não é viewer, não é tutorial, não é mockup.
Fonte: `PROJECT_ATLAS_MASTER_PROMPT.md` (9 fases, regras de desenvolvimento nas seções 24–26).

Fluxo de trabalho combinado:
- Código no GitHub, **APK gerado por GitHub Actions** (sem PC).
- Sempre entregar: `.md` atualizado + contexto de tudo + próximos passos + zip do projeto completo.
- Nunca marcar recurso como pronto sem implementado e testado (regra 9 do prompt).

## 2. Estratégia decidida (resultado da investigação — sessão 1)
O Blender oficial **não tem suporte Android**. Mas já existem **portes comunitários ativos** do código real do Blender
(GPL), com C/C++ nativo + Vulkan, que rodam no Android. Reconstruir do zero seria ignorar a regra 11 do prompt.

Portes encontrados (verificados por pesquisa em 15/11/2026):
| Porte | Base | Observações |
|---|---|---|
| `simfeo/blender` (branch `android`) | Blender 5.3 alpha (merge do upstream set/2026) | Releases até `android-alpha-4` (26/09/2026). Builds *lite* e *full*. arm64, Android 12+, Vulkan. Toque, stylus, 2 dedos orbitam, 3 dedos pan, teclado na tela, autosave, Cycles + denoise (full), USD/Alembic/OpenVDB, vídeo (ffmpeg), fluidos. Sem retrato. |
| `Wanderson-Magalhaes/blender_for_android` | Blender 5.3 alpha | Foco Galaxy S24 Ultra (Adreno 750), **funciona em retrato**, build full com áudio nativo. |

Requisitos de build relatados pelo porte simfeo: **NDK r30+** (obrigatório), dependências pré-compiladas
(submódulo `lib/`), sem etapa própria de build de dependências.

**Decisão:** o Atlas será uma **camada sobre o porte real** (upstream fixado por commit + patches nossos em `patches/`),
construída por GitHub Actions. Assim: mantemos as estruturas de dados reais do Blender, reaproveitamos Eevee/Cycles/
sculpt/rig/geometry nodes/Python, e nosso trabalho vai para o que falta de verdade:
1. build reprodutível no GitHub Actions → APK;
2. identidade própria (nome, ícone, package id) — sem sugerir afiliação com a Blender Foundation;
3. UI mobile "de verdade" (retrato, painéis, gestos, workspaces) em cima da UI existente;
4. estabilidade/memória/térmico; compatibilidade Mali/Adreno/Xclipse;
5. lacunas (viewport clipping em Mali, Online Essentials, etc.).

## 3. Problemas conhecidos do porte (herdados — não esconder)
- Primeiro start lento (~100 MB descompactados).
- App pode ser morto pelo Android com cena pesada (recuperar: File > Recover > Auto Save).
- Shader compilation trava frame em cena grande.
- Sem retrato no simfeo (existe no Wanderson).
- Clip distance ausente em Mali: região de clipping do viewport não funciona.
- Online Essentials não funciona (semáforos nomeados no Android).
- Denoise Cycles no celular ≈ 30 s por 1080p.
- Turnip (Adreno) é experimental.

## 4. Estado atual
| Item | Status |
|---|---|
| Investigação do código/portes | ✅ feita (fontes acima) |
| Repositório-base Atlas (este zip) | ✅ criado: docs + mecanismo de patches; `build.yml` agora é um arquivo separado |
| Workflow compila o APK | ⚠️ **NÃO TESTADO** — ainda não foi executado no GitHub |
| APK instalável | ❌ ainda não gerado |
| Identidade Atlas (nome/ícone/package) | ❌ pendente |
| UI mobile Atlas | ❌ pendente |

Não consegui rodar o build aqui (sandbox sem internet); o workflow foi escrito para **descobrir e registrar** o
procedimento exato de build do porte na primeira execução (job `inventory`), em vez de eu inventar comandos.

## 5. Como usar (passo a passo — pelo celular)
1. No repositório do GitHub, envie **dois arquivos na raiz**: o `Atlas.zip` (qualquer nome serve, o workflow pega o `.zip` mais recente) e o `build.yml`.
2. O GitHub só executa workflows em `.github/workflows/`. Sem abrir pastas: **Add file → Create new file**, no campo do nome digite
   `.github/workflows/build.yml` (as barras criam as pastas sozinhas), cole o conteúdo do `build.yml` e faça commit.
3. Aba **Actions → Atlas Android Build → Run workflow** (ou suba um novo `.zip` — o push de qualquer `.zip` na raiz dispara o build sozinho).
4. A 1ª execução gera o artefato **`atlas-inventory`** (docs/scripts de build do porte). Me mande o conteúdo ou o log e eu fecho o comando de build.
5. Defina a variável do repositório `ATLAS_BUILD_CMD` (Settings → Secrets and variables → Actions → Variables). Depois disso o `.apk` sai como artefato.
6. Se estourar disco/tempo no runner gratuito: perfil `lite`, ccache (já configurado) e/ou runner maior.

## 6. Próximos passos (ordem)
1. Rodar o workflow (job inventory) e me trazer o resultado.
2. Fechar `ATLAS_BUILD_CMD`, obter o **primeiro APK real** (lite) e testar no aparelho.
3. Patch de identidade (nome Atlas, ícone, `applicationId`, tela de créditos GPL).
4. Avaliar retrato (portar da abordagem do build do Wanderson) e UI mobile (Fase 1 do roadmap).
5. Salvar/abrir projeto, outliner/propriedades em gavetas, gestos — um item por vez, com teste.
6. Seguir `docs/ROADMAP.md` (fases 2–9).

## 7. Licença
Blender é GPL. O Atlas distribuído deve publicar o código-fonte correspondente, manter avisos de copyright e não
usar o nome/logo Blender como identidade. Ver `docs/LICENSES.md`.

## 8. Diário de sessões
- **Sessão 1 (15/11/2026):** leitura do master prompt; pesquisa de portes existentes; decisão de estratégia;
  criação do repositório-base (workflow + docs + patches); contexto inicial.
- **Sessão 1 (cont.):** `build.yml` separado do zip (uso pelo celular); workflow passou a localizar e extrair qualquer `.zip` da raiz e a disparar em push de `.zip`.
