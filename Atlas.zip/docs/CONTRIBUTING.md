# Contribuindo
Mudanças no Blender entram como patches em `patches/` (um assunto por patch, nome `NNNN-assunto.patch`).
Não quebrar o build; testar em aparelho antes de marcar recurso como completo; atualizar `ATLAS-Contexto.md`.
