# Recursos
Status por recurso: ❌ não testado · ⚠️ existe no porte, não validado por nós · ✅ testado no aparelho.
Nenhum recurso está ✅ ainda (nenhum APK foi gerado). Lista herdada do porte: ver `ATLAS-Contexto.md` §2 e §3.
