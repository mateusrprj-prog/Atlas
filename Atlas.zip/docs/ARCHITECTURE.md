# Arquitetura

```
Atlas (zip)
├─ patches/      # NOSSAS mudanças (*.patch) aplicadas sobre o upstream fixado
├─ docs/
└─ ATLAS-Contexto.md
build.yml (entregue fora do zip; fica em .github/workflows/): localiza o .zip, clona o porte, aplica patches, compila, publica APK
Upstream (clonado no CI, não versionado aqui): simfeo/blender @ branch android (Blender 5.3 alpha, Vulkan, NDK r30+)
```
Princípio: não reimplementar o que o Blender já tem. Mudanças Atlas = patches pequenos, modulares e rastreáveis,
com o commit do upstream fixado em `upstream_ref`. Atualizar upstream = trocar o pin e reaplicar patches.
