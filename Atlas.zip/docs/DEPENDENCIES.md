# Dependências
- Upstream: simfeo/blender (branch android), derivado de blender/blender — GPL.
- Biblioteca pré-compilada Android do projeto Blender (submódulo do upstream), clang 21.
- Android NDK r30+, Android SDK, JDK, CMake/Ninja (instalados no CI).
- Opcional no perfil full: Cycles, OpenImageDenoise, USD, Alembic, OpenVDB, MaterialX, LLVM, ffmpeg, Mantaflow.
