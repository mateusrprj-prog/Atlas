# Roadmap (do master prompt, adaptado à estratégia "camada sobre o porte")
- Fase 1: build reprodutível no CI → APK; identidade Atlas; viewport/navegação/seleção/salvar-carregar validados no aparelho.
- Fase 2: modelagem (Edit Mode, modificadores) — validar o que o porte já entrega; corrigir lacunas de toque.
- Fase 3: import/export (OBJ, FBX, GLB/glTF) — testar fluxos reais.
- Fase 4: sculpt, UV, texture paint, shader editor — validar brushes/assets e desempenho.
- Fase 5: rig e animação — testar IK, pesos, timeline, graph editor.
- Fase 6: geometry nodes, física, partículas, tecido, fluidos (full).
- Fase 7: Eevee/Cycles, compositor, render de animação — ajustar por hardware.
- Fase 8: grease pencil, sequenciador, VFX, scripting, extensões.
- Fase 9: otimização, memória, térmico, compatibilidade (Mali/Adreno/Xclipse), release.
Cada item só vira "completo" após teste em aparelho real.
