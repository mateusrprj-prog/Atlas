# Licenças
Blender: GPL. Obras derivadas distribuídas devem: publicar o código-fonte correspondente, preservar avisos de
copyright, licenciar sob GPL compatível e respeitar as licenças das bibliotecas de terceiros (ver DEPENDENCIES.md).
Nome, logo e identidade do Atlas são independentes; não usar a marca Blender como identidade nem sugerir endosso.
