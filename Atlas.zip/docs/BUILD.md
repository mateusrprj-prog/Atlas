# Build

Coloque o `Atlas.zip` (qualquer nome) na raiz do repositório e o `build.yml` em `.github/workflows/`.
Aba Actions → "Atlas Android Build" → Run workflow (perfil `lite` ou `full`); subir um novo `.zip` também dispara.
Requisitos que o porte declara: NDK r30+, submódulo de bibliotecas pré-compiladas, arm64-v8a, Android 12+.
O comando de build exato é registrado após a 1ª execução (artefato `atlas-inventory`) e guardado na variável `ATLAS_BUILD_CMD`.
