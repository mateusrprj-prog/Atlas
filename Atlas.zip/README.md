# Atlas

Suíte de criação 3D profissional para Android, construída sobre o código real do Blender (GPL) via porte comunitário.
Projeto independente — **não afiliado à Blender Foundation**.

- Contexto completo e estado atual: [`ATLAS-Contexto.md`](ATLAS-Contexto.md)
- Build: [`docs/BUILD.md`](docs/BUILD.md) · Arquitetura: [`docs/ARCHITECTURE.md`](docs/ARCHITECTURE.md)
- Roadmap: [`docs/ROADMAP.md`](docs/ROADMAP.md) · Recursos: [`docs/FEATURES.md`](docs/FEATURES.md)
