# ATLAS_HANDOFF.md — contexto completo do projeto (LEIA PRIMEIRO)

> **Versão do projeto: 0.9.0** (0.8.0 e 0.9.0 entregues juntas a pedido do usuário; 0.6.0 e 0.7.0 também foram juntas) · Atualizado em 2026-11-15
> Este arquivo existe porque o usuário já perdeu contexto uma vez (a IA anterior bateu no limite de uso sem exportar nada).

## 0. REGRAS PARA A IA QUE CONTINUAR (obrigatório)

1. **Toda vez que você fizer uma atualização, entregue DUAS coisas ao usuário:**
   - o projeto inteiro em `.zip` (mesma estrutura deste zip, sem `build/`, `.gradle/`, `.cxx/`);
   - **este arquivo `ATLAS_HANDOFF.md` atualizado**: novo número de versão, changelog, estado real, problemas conhecidos, próximos passos.
2. **Nunca diga que algo funciona no aparelho se você só testou no host.** Use os status do `FEATURES.md`
   (Not started / In development / Implemented but untested / Implemented and tested / Blocked).
3. Mantenha `docs/MASTER_PROMPT.md` (o prompt original do projeto) no repositório. Ele é a visão de longo prazo.
4. Responda ao usuário em **português (BR)**, tom direto e informal (ele escreve "cara", "tlgd"). Código, nomes de arquivos e commits em inglês.
5. Antes de mexer: leia `FEATURES.md`, `docs/ARCHITECTURE.md` e este arquivo. Depois de mexer: rode os testes, atualize docs, atualize este arquivo.
6. Não use código do Blender. O Atlas é independente (veja `docs/MASTER_PROMPT.md`, seções 1–2).

## 1. Quem é o usuário e como ele trabalha

- Desenvolve **pelo celular (Android), com IA + GitHub**. Não compila localmente.
- Fluxo: a IA entrega um `.zip` → o usuário sobe no GitHub → **GitHub Actions** (`.github/workflows/build.yml`) roda os testes do núcleo e compila o APK debug → ele baixa o APK (artifact `atlas-debug-apk`) e testa no celular.
- O workflow aceita um `.zip` na raiz do repo (extrai e compila) ou o projeto direto na raiz.
- Ele manda prints/vídeos do app rodando para guiar a UI. A UI deve se inspirar no **Blender desktop** (menos "mobile genérico"), mas continuar usável em toque.
- Última tela vista (v0.2.0, landscape, celular): barra Atlas/File/Edit/Render/Window/Help + abas de workspace; coluna de ferramentas à esquerda; header do viewport (Object Mode, View, Select, Add, Object, X Y Z, shading); Outliner + Properties à direita; status bar embaixo. Observações dessa tela: as abas/painel direito cortam na lateral (scroll horizontal), e o painel Properties fica pequeno em altura.

## 2. O que é o projeto (resumo do prompt mestre)

Atlas = app 3D profissional independente para Android, com ambição "nível Blender", mas **motor, formato de projeto, UI e arquitetura próprios**.
Prompt completo: `docs/MASTER_PROMPT.md`. Pontos que mais importam:
- Nada de botão sem operação real, nada de mockup, nada de feature "fake". Só marque completo se implementado **e testado**.
- Roadmap em fases (0–10): fundação+viewport → modelagem → import (OBJ/GLB/glTF) → materiais/UV → escultura → rig/animação → render → avançado → vídeo/VFX/scripts → release.
- Dependências: só licenças permissivas (MIT/BSD/Apache/zlib/MPL2). Documentar em `DEPENDENCIES.md` / `LICENSES.md` quando entrarem (ainda **não há dependência externa**).
- Arquitetura alvo: Kotlin (shell/UI/SAF) + C++ NDK (core) + JNI fino. Render alvo: Filament (ou GLES próprio) — reavaliar antes de escultura.

## 3. Estado atual (v0.9.0)

### Stack real hoje
- `app/src/main/kotlin/dev/atlas/` — `MainActivity.kt` (UI em Views programáticas, estilo Blender escuro), `NativeBridge.kt` (declarações JNI).
- `app/src/main/cpp/core/` — **núcleo header-only C++17, sem GL/JNI, testável no host**: `math3.hpp`, `mesh.hpp`, `modifiers.hpp`, `scene.hpp`, `project_io.hpp`.
- `app/src/main/cpp/renderer.*` — GLES 3 próprio (grid, eixos, objetos, overlay de edição, gizmo de eixos). **Ainda não usa Filament.**
- `app/src/main/cpp/bridge.cpp` — ponte JNI + estado de arrasto interativo (um passo de undo por gesto).
- `tests/test_scene.cpp` — testes do núcleo (assert). `g++ -std=c++17 -Wall -Wextra -O1 tests/test_scene.cpp -o t && ./t`
- CI: `.github/workflows/build.yml` (testes do núcleo → APK debug). Gradle 8.9, JDK 17, NDK 26.1.10909125, minSdk 26, ABIs arm64-v8a + x86_64.

### Convenções
Z-up, destro; faces CCW = para fora; Euler XYZ em graus (R = Rz·Ry·Rx); formato de projeto v4 (texto, salvamento atômico tmp+rename, migra v1).
Todo acesso à cena pelo Kotlin passa por `act { }` (roda na thread GL, depois atualiza Outliner/Properties/status).

### Changelog
- **0.9.0 (esta versão; entregue junto com a 0.8.0)** — modificadores utilitários + limpeza de malha:
  - **Triangulate** (modificador): ear clipping no plano da face (n-gons côncavos OK, winding da face mantido; cai para leque só em caso degenerado). Testes: cubo → 12 tris com volume 8, hexágono em L com todas as 6 rotações de início × 2 windings (área 3), esfera.
  - **Weld** (modificador) e **Mesh > Merge by Distance** (op de Edit Mode, 1 passo de undo): hash espacial + union-find, só nos vértices selecionados, cluster vira o centróide, faces degeneradas somem e vértices órfãos são removidos. Campo "Merge Distance" no painel de Edit Mode; cartão do Weld tem campo "Distance" (`merge`, 5 casas decimais para não arredondar para 0).
  - Tipos 4/5 reaproveitam o registro `mod` do **formato v4** (Weld usa a coluna `merge`); builds ≤0.7.0 rejeitam esses arquivos como "invalid modifier".
  - UI: 3ª linha de botões de modificador (`+ Triangulate`, `+ Weld`). JNI novo: `setModifierMerge`, `weldSelected`; `modifiers()` ganhou a coluna `merge`.
- **0.8.0** — operações de objeto + seleção:
  - **Rename** (Object > Rename… ou toque no nome em Properties): espaços viram `_` (o formato de projeto separa por espaço), máx. 40 chars, nome repetido vira único, desfazível.
  - **Apply All Transforms / Apply Scale**: assa a transformação na malha (posições no mundo ficam idênticas; escala negativa inverte o winding para as normais continuarem para fora); `BakeCmd` guarda malha + transform num único passo de undo. O stack de modificadores não é mexido.
  - **Origin to Geometry**: origem vai para a mediana dos vértices sem mover a geometria no mundo.
  - **Select > Linked** (Edit Mode): expande para a ilha conectada inteira, nos 3 modos.
  - Testes: 2 blocos novos; rodam limpos com `-fsanitize=address,undefined`; 4 mutantes (ear clipping sem teste de convexidade, weld ignorando a máscara, origem sem checagem de no-op…) são pegos.
- **0.7.0 (esta versão; entregue junto com a 0.6.0)** — o pedido "faça a 0.6.0 junto da 0.7.0" que a IA anterior não terminou (ela bateu no limite de uso no meio):
  - **Subdivision Surface (Catmull-Clark)**, níveis 1–4: regra clássica para vértices internos, regra de borda B-spline `(6P+A+B)/8`, vértices/arestas não-manifold ficam parados/ponto médio, saída só em quads. Conferido no teste contra valores calculados à mão (cubo: canto → 5/9, ponto de aresta → (.75,.75,0)), Euler V−E+F=2, malha fechada, normais para fora.
  - **Solidify**: espessura uniforme (correção por 1/média do cosseno, com piso 0.2), offset In/Center/Out (−1/0/+1), casca interna invertida, **borda (rim) em malhas abertas** (plano vira laje fechada). Testes de volume exato (cubo 8−1.8³ etc.).
  - `Modifier` ganhou `levels`, `thickness`, `shift`. **Formato de projeto v4** (cada `mod` termina com `levels thickness shift`); v1/v2/v3 ainda abrem (defaults); registro corrompido/fora de faixa é rejeitado sem alterar a cena aberta.
  - UI: botões `+ Subsurf` e `+ Solidify` (2×2), cartões com Levels 1–4 e Thickness + In/Center/Out. JNI novo: `setModifierParams`.
  - **0.6.0 (iluminação):** shader agora é de dois lados (normal virada para o observador) com luz da câmera + ambiente hemisférico Z-up + luz de chave → faces de costas não ficam mais quase pretas (feedback da 0.4.0).
  - **0.6.0 (UI):** header mais compacto (botões "Solid"/"Wire" em texto no lugar do ▦ que cortava e deixava o "|"), Properties mais alto (Outliner 0.8 : Properties 2.8) e com folga no fim da rolagem para o "Scale" não ficar cortado.
  - Testes: 3 blocos novos (subsurf, solidify, v4/v3). Rodam limpos com `-fsanitize=address,undefined`; mutantes (regra de vértice errada, rim errado) são pegos pelos asserts.
- **0.5.0 (esta versão)** — **Pilha de modificadores não destrutivos** (fecha a Fase 2 do roadmap em parte):
  - Novo `core/modifiers.hpp`: **Mirror** (eixo X/Y/Z, solda vértices sobre o plano, não duplica faces que estão no plano) e **Array** (count 1–64 + offset constante). Pilha avaliada de cima para baixo; desativados são ignorados.
  - `displayMesh(Object)` com cache (`meshRev`/`modsRev`): o viewport e o picking de objetos usam a malha avaliada; no Edit Mode a malha base é a "gaiola" (arestas escuras, seleção e ops continuam na base).
  - Operações (todas desfazíveis, via `ModStackCmd`): adicionar, remover, ligar/desligar, reordenar, editar parâmetros, **Apply** (assa 0..i na malha base, só Object Mode).
  - **Formato de projeto v3** (registros `mods`/`mod`); v1 e v2 ainda abrem; modificador corrompido é rejeitado sem alterar a cena aberta.
  - UI: seção "Modifiers" em Properties (cartões com On/Off, ▲▼, Apply, ✕, eixo do Mirror, count/offset do Array). Painel Properties ficou mais alto.
  - Testes novos: mirror (caixa fechada, área 40, normais para fora, base intocada, toggle, apply+undo/redo), array (24 verts, área 72, picking nas cópias), limites, reordenar, round-trip v3, arquivo v2, modificador inválido.
  - **Feedback do usuário na 0.4.0 (prints):** build compilou e rodou no aparelho; pontos de vértice, modo vértice/face, loop cut e painel de edição funcionam visualmente (malha chegou a 31 verts / 27 faces). Pontos a melhorar: o header ainda corta à direita (aparece um "|" no canto), o painel Properties rolou e mostra "Scale" cortado, e faces de costas ficam bem escuras.
- 0.4.0 — **Loop Cut** e **Select Edge Loop**:
  - Loop Cut: percorre o anel de quads da aresta selecionada (ou 2 vértices) e corta todos com um novo loop; a posição (0–1) vem do campo "Loop Cut Position" e fica consistente em todo o anel; triângulos/n-gons no fim de um anel aberto recebem o ponto (malha continua fechada). Seleciona o novo loop. Um passo de undo (restaura malha + seleção).
  - Select Edge Loop: estende a seleção atravessando vértices de valência 4 nos dois sentidos.
  - Testes novos: cubo (posição 0.25 em todas as arestas), plano (anel aberto), esfera (anel fechado e anel terminando nos polos), grade 4x4 (loop de 4 arestas), canto de cubo (loop = 1 aresta).
  - Menu Mesh ganhou os dois itens; versão 0.4.0 / versionCode 4.
- 0.3.0 — Modelagem com seleção por elemento:
  - Edit Mode com seleção **vértice / aresta / face** (botões ● ╱ ▣ no header), conversão entre modos como no Blender (vértice→aresta mantém arestas com as duas pontas selecionadas, etc.), Select All / None / Invert.
  - Picking de vértice e aresta com tolerância em pixels (~22 px) e teste de oclusão (não seleciona o que está atrás da malha).
  - Operações: **Extrude** (faces, arestas, e a partir de vértices — detecta faces completas, senão arestas), **Inset Faces**, **Subdivide** (sem T-junction: vizinhas recebem os pontos médios), **Merge at Center**, **Flip Normals**, **Delete** (vértices/arestas/faces).
  - **Mover / Rotacionar / Escalar** qualquer seleção em Edit Mode (pivô = ponto médio; rotação/escala em eixos locais).
  - Undo/redo agora restaura **malha + seleção** (`MeshEditCmd` guarda os dois).
  - Overlay no renderer: pontos de vértice, arestas selecionadas, faces selecionadas.
  - CI roda os testes do núcleo antes do APK. `docs/MASTER_PROMPT.md` agora faz parte do repo.
- 0.2.0 — Núcleo de malha poligonal (n-gons), primitivas (cubo/plano/cilindro/esfera UV), seleção de faces, extrude/delete de faces, undo/redo, formato v2, shell estilo Blender, viewport com orbit/pan/zoom/presets/gizmo.
- 0.1.0 — Esqueleto Android + viewport + cubos + save/load v1.

### O que foi verificado e o que NÃO foi
- ✅ Núcleo (`core/`) compila com `-Wall -Wextra` e **todos os testes passam** no host (inclui um teste mutante para garantir que os asserts realmente falham quando deveriam).
- ✅ `renderer.cpp` e `bridge.cpp` passavam em checagem de sintaxe com headers GLES/JNI *stub* até a 0.5.0. ⚠️ As edições da 0.7.0 nesses dois arquivos (uniform `uEye` + shader novo; `setModifierParams`; colunas extras em `modifiers()`) **não** foram re-checadas (sem stubs no ambiente) — são pequenas e seguem os mesmos padrões, mas o CI é quem confirma.
- ✅ A 0.4.0 compilou e rodou no aparelho do usuário (prints). ⚠️ **Kotlin da 0.5.0 e das mudanças da 0.7.0/0.8.0/0.9.0 NÃO foram compilados** (não havia kotlinc/SDK no ambiente da IA). Reescrito com cuidado, mas o primeiro build do CI pode apontar erro de compilação — se acontecer, o log do Actions diz a linha; corrigir é rápido.
- ⚠️ **Nada foi testado no aparelho**: sensação do toque ao selecionar vértices/arestas, desenho dos pontos (`gl_PointSize`), gesto de arrastar em Edit Mode. Peça ao usuário um print/vídeo após instalar.

### Problemas conhecidos / dívida técnica
- Snapshot de malha inteira por passo de undo (ok para malhas pequenas; trocar por deltas antes da escultura).
- Triangulação em leque assume faces convexas.
- Loop Cut usa só a primeira aresta selecionada, um corte por operação.
- Modificadores: Mirror, Array, Subsurf, Solidify, Triangulate e Weld (sem creases/Boolean/Bevel/Decimate); Weld não remove faces duplicadas após o merge; Apply Transform não mexe nos modificadores; Mirror no plano local; ordem de avaliação não tem dependência entre objetos ainda.
- Inset é por face (não por região) e relativo ao centróide.
- Distância do Extrude vem de um campo numérico (Properties); depois o usuário arrasta com Move. Falta o extrude "interativo" estilo Blender (extrude + arrastar num gesto).
- Teste de oclusão do picking é O(faces) por candidato — precisa de BVH para malhas grandes.
- UI: abas de workspace e painel direito cortam em telas estreitas; Properties pequeno em altura; só Layout/Modeling funcionam (demais abas desabilitadas, e dizem isso).
- Objetos: lista plana, sem parent/collections/multi-seleção.
- Seleção não é salva no projeto (é estado de edição).

## 4. Próximos passos sugeridos (em ordem)

1. **Confirmar o build do CI e testar v0.9.0 no aparelho (Rename, Apply/Origin, Select Linked, Merge by Distance, cartões Triangulate/Weld, mais Subsurf/Solidify, iluminação, header/Properties)** (corrigir erros de Kotlin/GL se aparecerem). Pedir vídeo ao usuário.
2. Edit Mode: **Bevel**, **Edge Slide**, loop cut interativo (arrastar para posicionar), extrude interativo (gesto único), seleção linked, box select, loop cut em várias arestas.
3. Mais modificadores: Bevel, Boolean (Manifold), Decimate; Subsurf com creases e smooth shading; Solidify com espessura por face; Mirror com clipping/mirror object.
4. Hierarquia de objetos (parent/child) + Collections no Outliner + multi-seleção; Separate/Join de malhas.
5. UI: refinar para ficar mais "Blender desktop" — painéis redimensionáveis, Properties com abas (Object/Modifiers/Material), menus Add/Select/Mesh completos, atalhos de gesto, tema. Usar os prints do usuário como referência.
6. Fase 3: importadores OBJ/GLB/glTF (tinyobjloader / tinygltf — documentar licença em DEPENDENCIES.md).
7. Reavaliar Filament vs renderer próprio antes da Fase 4/5.

## 5. Como entregar uma atualização (checklist para a próxima IA)

1. Ler este arquivo + `FEATURES.md` + `docs/ARCHITECTURE.md`.
2. Implementar a lógica **no `core/` primeiro** (função pura em `mesh.hpp`, comando/seleção em `scene.hpp`), com teste em `tests/test_scene.cpp`.
3. Expor em `bridge.cpp` + `NativeBridge.kt`, ligar na UI (`MainActivity.kt`). Nomes JNI sem underscore.
4. Rodar: `g++ -std=c++17 -Wall -Wextra -O1 tests/test_scene.cpp -o t && ./t`.
5. Atualizar `FEATURES.md`, `docs/ARCHITECTURE.md`, `README.md`, `versionName/versionCode` (`app/build.gradle.kts`), string "Atlas x.y.z" no Kotlin, e **este arquivo** (changelog + estado + próximos passos).
6. Gerar o `.zip` do projeto e enviar junto com o `ATLAS_HANDOFF.md`. Dizer claramente o que foi testado e o que não foi.
