// Non-destructive modifier stack: pure functions that turn a base mesh into an evaluated mesh.
#pragma once
#include <algorithm>
#include <array>
#include <cmath>
#include <map>
#include <set>
#include <vector>
#include "mesh.hpp"

namespace atlas {

enum ModType { kMirror = 0, kArray = 1, kSubsurf = 2, kSolidify = 3, kTriangulate = 4, kWeld = 5 };

struct Modifier {
    int type = kMirror;
    bool enabled = true;
    int axis = 0;              // mirror: 0 X, 1 Y, 2 Z (object-local plane through the origin)
    float merge = 0.001f;      // mirror: vertices this close to the plane are welded to their mirror image
    int count = 2;             // array: number of copies (1..64)
    float offset[3] = {1, 0, 0};  // array: constant offset between copies (local units)
    int levels = 1;            // subsurf: Catmull-Clark levels (1..4)
    float thickness = 0.1f;    // solidify: shell thickness (> 0, local units)
    float shift = -1.f;        // solidify: -1 grows inward (original = outer surface), +1 outward, 0 centered
};

inline const char* modifierName(int t) {
    return t == kArray ? "Array" : t == kSubsurf ? "Subdivision Surface" : t == kSolidify ? "Solidify" : t == kTriangulate ? "Triangulate" : t == kWeld ? "Weld" : "Mirror";
}
inline bool validModifier(const Modifier& m) {
    if (m.type < 0 || m.type > 5 || m.axis < 0 || m.axis > 2 || m.count < 1 || m.count > 64) return false;
    if (m.levels < 1 || m.levels > 4 || !std::isfinite(m.thickness) || m.thickness <= 0.f || m.thickness > 1000.f) return false;
    if (!std::isfinite(m.shift) || m.shift < -1.f || m.shift > 1.f) return false;
    if (!std::isfinite(m.merge) || m.merge < 0.f || m.merge > 1000.f) return false;
    for (float o : m.offset) if (!std::isfinite(o)) return false;
    return true;
}

inline float& comp(Vec3& v, int a) { return a == 0 ? v.x : a == 1 ? v.y : v.z; }
inline float compOf(const Vec3& v, int a) { return a == 0 ? v.x : a == 1 ? v.y : v.z; }

// Mirror across the local plane. Vertices on the plane are shared; faces lying entirely on the plane are not duplicated.
inline Mesh applyMirror(const Mesh& in, const Modifier& md) {
    Mesh out = in; const int n = (int)in.v.size();
    std::vector<int> mi(n, -1);
    for (int i = 0; i < n; ++i) {
        if (std::fabs(compOf(in.v[i], md.axis)) <= md.merge) { mi[i] = i; continue; }
        Vec3 p = in.v[i]; comp(p, md.axis) = -comp(p, md.axis);
        mi[i] = (int)out.v.size(); out.v.push_back(p);
    }
    for (const auto& fc : in.f) {
        std::vector<int> r; bool same = true;
        for (size_t k = fc.size(); k-- > 0;) { r.push_back(mi[fc[k]]); if (mi[fc[k]] != fc[k]) same = false; }
        if (!same) out.f.push_back(r);
    }
    return out;
}
inline Mesh applyArray(const Mesh& in, const Modifier& md) {
    Mesh out = in; const int n = (int)in.v.size();
    for (int c = 1; c < md.count; ++c) {
        Vec3 d{md.offset[0] * c, md.offset[1] * c, md.offset[2] * c}; const int base = (int)out.v.size();
        for (int i = 0; i < n; ++i) out.v.push_back(in.v[i] + d);
        for (const auto& fc : in.f) { std::vector<int> g = fc; for (int& x : g) x += base; out.f.push_back(g); }
    }
    return out;
}

// Catmull-Clark subdivision (one level). Interior vertices use the classic rule, boundary vertices the cubic B-spline
// boundary rule (6P + A + B)/8, non-manifold edges/vertices stay put / use midpoints. Every output face is a quad.
inline Mesh subdivideOnce(const Mesh& in) {
    const int nv = (int)in.v.size(), nf = (int)in.f.size();
    std::vector<Vec3> fp(nf);
    for (int i = 0; i < nf; ++i) { Vec3 c; for (int k : in.f[i]) c = c + in.v[k]; fp[i] = c * (1.f / (float)in.f[i].size()); }
    struct EInfo { int faces[2] = {-1, -1}; int count = 0; int id = -1; };
    std::map<Edge, EInfo> em;
    for (int i = 0; i < nf; ++i) {
        const auto& fc = in.f[i];
        for (size_t k = 0; k < fc.size(); ++k) { EInfo& e = em[mkEdge(fc[k], fc[(k + 1) % fc.size()])]; if (e.count < 2) e.faces[e.count] = i; ++e.count; }
    }
    Mesh out; out.v.resize(nv);
    std::vector<std::vector<Edge>> vedges(nv); std::vector<int> vfaces(nv, 0);
    for (int i = 0; i < nf; ++i) for (int k : in.f[i]) ++vfaces[k];
    const int fbase = nv; out.v.insert(out.v.end(), fp.begin(), fp.end());
    for (auto& kv : em) {
        EInfo& e = kv.second; e.id = (int)out.v.size();
        const Vec3 mid = (in.v[kv.first.first] + in.v[kv.first.second]) * 0.5f;
        if (e.count == 2) out.v.push_back((in.v[kv.first.first] + in.v[kv.first.second] + fp[e.faces[0]] + fp[e.faces[1]]) * 0.25f);
        else out.v.push_back(mid);
        vedges[kv.first.first].push_back(kv.first); vedges[kv.first.second].push_back(kv.first);
    }
    for (int i = 0; i < nv; ++i) {
        const auto& ve = vedges[i]; const int n = (int)ve.size();
        if (n == 0) { out.v[i] = in.v[i]; continue; }
        bool nonManifold = false; std::vector<int> bnd;
        for (const Edge& e : ve) { const int c = em[e].count; if (c > 2) nonManifold = true; else if (c == 1) bnd.push_back(e.first == i ? e.second : e.first); }
        if (nonManifold) { out.v[i] = in.v[i]; continue; }
        if (!bnd.empty()) {
            if (bnd.size() == 2) out.v[i] = in.v[i] * 0.75f + (in.v[bnd[0]] + in.v[bnd[1]]) * 0.125f; else out.v[i] = in.v[i];
            continue;
        }
        Vec3 F, R;
        std::set<int> fs; for (const Edge& e : ve) { const EInfo& ei = em[e]; fs.insert(ei.faces[0]); fs.insert(ei.faces[1]); R = R + (in.v[e.first] + in.v[e.second]) * 0.5f; }
        for (int f : fs) F = F + fp[f];
        const float nF = (float)fs.size();
        if (nF < 1.f) { out.v[i] = in.v[i]; continue; }
        F = F * (1.f / nF); R = R * (1.f / (float)n);
        out.v[i] = (F + R * 2.f + in.v[i] * (float)(n - 3)) * (1.f / (float)n);
    }
    for (int i = 0; i < nf; ++i) {
        const auto& fc = in.f[i]; const int k = (int)fc.size();
        for (int j = 0; j < k; ++j) {
            const int a = fc[j], b = fc[(j + 1) % k], z = fc[(j + k - 1) % k];
            out.f.push_back({a, em[mkEdge(a, b)].id, fbase + i, em[mkEdge(z, a)].id});
        }
    }
    return out;
}
// Face count after n levels (used to refuse absurd sizes before evaluating).
inline size_t subsurfFaces(const Mesh& m, int levels) {
    size_t quads = 0; for (const auto& f : m.f) quads += f.size();
    size_t total = quads;  // after level 1 every face is a quad; each further level multiplies by 4
    for (int i = 1; i < levels; ++i) total *= 4;
    return total;
}
inline Mesh applySubsurf(const Mesh& in, const Modifier& md) {
    Mesh cur = in;
    for (int i = 0; i < md.levels; ++i) { if (subsurfFaces(cur, 1) > 4000000) break; cur = subdivideOnce(cur); }
    return cur;
}

// Solidify: duplicates the surface along its vertex normals (even thickness) and flips the inner copy. Open meshes get a rim.
inline Mesh applySolidify(const Mesh& in, const Modifier& md) {
    const int n = (int)in.v.size();
    if (in.f.empty() || n == 0) return in;
    std::vector<Vec3> nsum(n); std::vector<std::vector<Vec3>> fns(n);
    for (const auto& fc : in.f) {
        Vec3 fn = faceNormal(in, fc);
        for (int k : fc) { nsum[k] = nsum[k] + fn; fns[k].push_back(fn); }
    }
    Mesh out; out.v.resize(2 * (size_t)n);
    const float outerK = md.thickness * (1.f + md.shift) * 0.5f, innerK = md.thickness * (1.f - md.shift) * 0.5f;
    for (int i = 0; i < n; ++i) {
        Vec3 nn = nsum[i]; const float len = std::sqrt(nn.x * nn.x + nn.y * nn.y + nn.z * nn.z);
        if (len < 1e-8f) { out.v[i] = in.v[i]; out.v[i + n] = in.v[i]; continue; }
        nn = nn * (1.f / len);
        float avg = 0.f; for (const Vec3& f : fns[i]) avg += f.x * nn.x + f.y * nn.y + f.z * nn.z;
        avg /= (float)fns[i].size();
        const float even = 1.f / std::max(avg, 0.2f);   // keep the wall thickness constant on slanted faces
        out.v[i] = in.v[i] + nn * (outerK * even);
        out.v[i + n] = in.v[i] - nn * (innerK * even);
    }
    out.f = in.f;
    std::set<std::pair<int, int>> directed;
    for (const auto& fc : in.f) for (size_t k = 0; k < fc.size(); ++k) directed.insert({fc[k], fc[(k + 1) % fc.size()]});
    for (const auto& fc : in.f) {
        std::vector<int> r; for (size_t k = fc.size(); k-- > 0;) r.push_back(fc[k] + n);
        out.f.push_back(r);
    }
    for (const auto& fc : in.f) for (size_t k = 0; k < fc.size(); ++k) {
        const int a = fc[k], b = fc[(k + 1) % fc.size()];
        if (!directed.count({b, a})) out.f.push_back({a, a + n, b + n, b});
    }
    return out;
}

// Splits every face into triangles by ear clipping in the face plane (handles concave n-gons; falls back to a fan on degenerate input).
// Triangles keep the winding of the source face.
inline void triangulateFace(const Mesh& m, const std::vector<int>& fc, std::vector<std::vector<int>>& out) {
    const int n = (int)fc.size();
    if (n == 3) { out.push_back(fc); return; }
    const Vec3 nn = faceNormal(m, fc);
    const float ax[3] = {std::fabs(nn.x), std::fabs(nn.y), std::fabs(nn.z)};
    const int drop = ax[0] >= ax[1] && ax[0] >= ax[2] ? 0 : ax[1] >= ax[2] ? 1 : 2;
    auto uv = [&](int vi, float& u, float& v) {
        const Vec3& p = m.v[vi];
        if (drop == 0) { u = p.y; v = p.z; } else if (drop == 1) { u = p.z; v = p.x; } else { u = p.x; v = p.y; }
    };
    std::vector<float> U(n), V(n);
    for (int i = 0; i < n; ++i) uv(fc[i], U[i], V[i]);
    double area = 0; for (int i = 0; i < n; ++i) { int j = (i + 1) % n; area += (double)U[i] * V[j] - (double)U[j] * V[i]; }
    const float sg = area >= 0 ? 1.f : -1.f;
    auto cross = [&](int a, int b, int c) { return ((U[b] - U[a]) * (V[c] - V[a]) - (V[b] - V[a]) * (U[c] - U[a])) * sg; };
    std::vector<int> idx(n); for (int i = 0; i < n; ++i) idx[i] = i;
    while (idx.size() > 3) {
        const int k = (int)idx.size(); bool clipped = false;
        for (int i = 0; i < k && !clipped; ++i) {
            const int a = idx[(i + k - 1) % k], b = idx[i], c = idx[(i + 1) % k];
            if (cross(a, b, c) <= 1e-12f) continue;   // reflex or degenerate corner
            bool inside = false;
            for (int j : idx) {
                if (j == a || j == b || j == c) continue;
                if (cross(a, b, j) >= -1e-12f && cross(b, c, j) >= -1e-12f && cross(c, a, j) >= -1e-12f) { inside = true; break; }
            }
            if (inside) continue;
            out.push_back({fc[a], fc[b], fc[c]}); idx.erase(idx.begin() + i); clipped = true;
        }
        if (!clipped) { for (size_t i = 1; i + 1 < idx.size(); ++i) out.push_back({fc[idx[0]], fc[idx[i]], fc[idx[i + 1]]}); return; }
    }
    out.push_back({fc[idx[0]], fc[idx[1]], fc[idx[2]]});
}
inline Mesh triangulateMesh(const Mesh& in) {
    Mesh out; out.v = in.v;
    for (const auto& fc : in.f) triangulateFace(in, fc, out.f);
    return out;
}

// Merge by distance: vertices closer than `dist` (only those flagged in `mask`, if given) collapse to their cluster centroid.
// Faces lose repeated corners; faces left with < 3 corners are dropped; vertices no face uses are removed. Returns merged count (0 = untouched).
inline int weldVertices(Mesh& m, float dist, const std::vector<char>* mask = nullptr) {
    const int n = (int)m.v.size(); if (n < 2) return 0;
    std::vector<int> par(n); for (int i = 0; i < n; ++i) par[i] = i;
    auto root = [&](int x) { while (par[x] != x) { par[x] = par[par[x]]; x = par[x]; } return x; };
    const float cell = std::max(dist, 1e-6f);
    typedef std::array<long long, 3> Key;
    auto keyOf = [&](const Vec3& p) { return Key{(long long)std::floor(p.x / cell), (long long)std::floor(p.y / cell), (long long)std::floor(p.z / cell)}; };
    std::map<Key, std::vector<int>> grid; const double d2 = (double)dist * dist;
    for (int i = 0; i < n; ++i) {
        if (mask && !(*mask)[i]) continue;
        const Key k = keyOf(m.v[i]);
        for (long long dx = -1; dx <= 1; ++dx) for (long long dy = -1; dy <= 1; ++dy) for (long long dz = -1; dz <= 1; ++dz) {
            auto it = grid.find(Key{k[0] + dx, k[1] + dy, k[2] + dz}); if (it == grid.end()) continue;
            for (int j : it->second) {
                const double ex = (double)m.v[i].x - m.v[j].x, ey = (double)m.v[i].y - m.v[j].y, ez = (double)m.v[i].z - m.v[j].z;
                if (ex * ex + ey * ey + ez * ez <= d2) { int a = root(i), b = root(j); if (a != b) par[std::max(a, b)] = std::min(a, b); }
            }
        }
        grid[k].push_back(i);
    }
    int merged = 0; for (int i = 0; i < n; ++i) if (root(i) != i) ++merged;
    if (merged == 0) return 0;
    std::vector<Vec3> sum(n); std::vector<int> cnt(n, 0);
    for (int i = 0; i < n; ++i) { int r = root(i); sum[r] = sum[r] + m.v[i]; ++cnt[r]; }
    std::vector<std::vector<int>> faces;
    for (const auto& fc : m.f) {
        std::vector<int> g;
        for (int vi : fc) { int r = root(vi); if (g.empty() || g.back() != r) g.push_back(r); }
        while (g.size() > 1 && g.front() == g.back()) g.pop_back();
        if (g.size() >= 3) faces.push_back(g);
    }
    std::vector<int> remap(n, -1); Mesh out;
    for (auto& g : faces) for (int& vi : g) {
        if (remap[vi] < 0) { remap[vi] = (int)out.v.size(); out.v.push_back(sum[vi] * (1.f / (float)cnt[vi])); }
        vi = remap[vi];
    }
    out.f = std::move(faces); m = std::move(out); return merged;
}
inline Mesh applyWeld(const Mesh& in, const Modifier& md) { Mesh out = in; weldVertices(out, md.merge); return out; }
inline Mesh applyModifier(const Mesh& in, const Modifier& md) {
    switch (md.type) {
        case kTriangulate: return triangulateMesh(in);
        case kWeld: return applyWeld(in, md);
        case kArray: return applyArray(in, md);
        case kSubsurf: return applySubsurf(in, md);
        case kSolidify: return applySolidify(in, md);
        default: return applyMirror(in, md);
    }
}

inline bool anyEnabled(const std::vector<Modifier>& mods) { for (auto& m : mods) if (m.enabled) return true; return false; }

// Evaluates the stack top to bottom (disabled modifiers are skipped). Guards against absurd sizes.
inline Mesh evaluateStack(const Mesh& base, const std::vector<Modifier>& mods) {
    Mesh cur = base;
    for (const auto& m : mods) {
        if (!m.enabled) continue;
        size_t est = cur.f.size() * (size_t)(m.type == kArray ? m.count : 2);
        if (m.type == kSubsurf) est = subsurfFaces(cur, m.levels);
        if (est > 4000000) break;
        cur = applyModifier(cur, m);
    }
    return cur;
}

}  // namespace atlas
