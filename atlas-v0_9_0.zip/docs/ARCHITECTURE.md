# Architecture (v0.9)
- `core/` (header-only C++17, no GL/JNI):
  - `math3` – Vec3.
  - `mesh` – polygon mesh, primitives, picking, modeling ops (extrude faces/edges, delete, inset, subdivide, merge, flip, loop cut, edge loops),
    vertex-mask transforms (move/rotate/scale about the median point).
  - `modifiers` – `Modifier` data + pure evaluators (Mirror, Array, Subdivision Surface = `subdivideOnce`/`applySubsurf`, Solidify = `applySolidify`, Triangulate = `triangulateMesh`/`triangulateFace` (ear clipping), Weld = `weldVertices` (spatial hash + union-find; also used by Mesh > Merge by Distance)) and `evaluateStack` (guards absurd sizes before evaluating). `displayMesh(Object)` (in `scene.hpp`) returns the base mesh or the cached evaluated mesh (cache keyed by `meshRev`/`modsRev`). The renderer and object picking use it; edit-mode selection/picking/ops use the base mesh (the "cage").
  - `scene` – objects, transforms, `SelState` (vertex/edge/face selection + mode conversion), command history,
    high-level ops (`editActiveMesh` wraps every mesh edit into ONE undoable `MeshEditCmd` that also stores selection before/after),
    vertex/edge picking with occlusion.
  - `project_io` – v4 text format (v2: meshes, v3: + `mods`/`mod` records, v4: each `mod` record ends with `levels thickness shift`; v3 files load with defaults), atomic save (tmp + rename), v1 migration.
- `renderer.*`: GLES3. Per-object GPU buffers keyed by (object id, meshRev); edit overlay (`drawEditOverlay`); axis gizmo.
- `bridge.cpp`: thin JNI layer + interactive drag state (one undo entry per gesture).
- `kotlin/dev/atlas`: Android shell. All scene access goes through `act {}` which runs on the GL thread,
  then refreshes Outliner/Properties/status from native state.
Conventions: Z-up, right-handed, CCW faces are outward, Euler XYZ degrees (R = Rz*Ry*Rx).
Rule for new mesh ops: write a pure function in `mesh.hpp` (testable), wrap it with `editActiveMesh` in `scene.hpp`
(selection + undo), expose it in `bridge.cpp` + `NativeBridge.kt`, add a menu item, add a host test in `tests/test_scene.cpp`.
Rule for new modifiers: add the type to `ModType`, an evaluator in `modifiers.hpp`, validation in `validModifier`, a test, and a card in `rebuildModifiers` (Kotlin). Any change to `mods` must bump `modsRev` (use the `ModStackCmd` ops in `scene.hpp`).

Lighting (renderer.cpp fragment shader): flat normal from screen derivatives, flipped toward the viewer (two-sided), shaded with a camera headlight + Z-up hemisphere ambient + a fixed key light; `uEye` is set once per frame.
JNI for modifiers: `modifiers()` returns one tab-separated line per modifier (type, enabled, axis, count, ox, oy, oz, levels, thickness, shift); `setModifier` (axis/count/offset) and `setModifierParams` (levels/thickness/shift) edit a card.

Object-level commands in `scene.hpp`: `RenameCmd`, `BakeCmd` (mesh + transform together: Apply Transform, Origin to Geometry). `selectLinkedActive` and `weldSelected` live next to them (weld is a normal `editActiveMesh` op). Modifier JNI: `setModifierMerge(i, merge)` edits the Weld distance (the `merge` field is shared with Mirror); `modifiers()` has an 11th column with it.
Project format is still v4: Triangulate/Weld reuse the existing `mod` record (type 4/5, Weld distance in the `merge` column), so no version bump; older builds (<=0.7.0) reject such files as "invalid modifier".
