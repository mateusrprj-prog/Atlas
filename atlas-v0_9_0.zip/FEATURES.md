# Features (status per feature)
| Feature | Status |
|---|---|
| Scene graph (flat, single collection), persistent ids, unique names | Implemented and tested (host) |
| Polygon mesh core (n-gon faces), primitives: cube, plane, cylinder, UV sphere | Implemented and tested (host) |
| Edit Mode element selection: vertex / edge / face, mode conversion, select all/none/invert | Implemented and tested (host) |
| Picking of vertices and edges with occlusion test (screen-radius tolerance) | Implemented and tested (host); touch feel untested on device |
| Extrude: faces, edges (strip of quads), from vertex mode (auto-detects faces/edges) | Implemented and tested (host) |
| Inset faces (individual, towards centroid), Subdivide faces (watertight with neighbours), Merge at Center, Flip Normals | Implemented and tested (host) |
| Loop Cut (quad ring, position 0–1, consistent direction, watertight at ring ends) and Select Edge Loop (through valence-4 vertices) | Implemented and tested (host) |
| Non-destructive modifier stack: Mirror (X/Y/Z, welds on-plane vertices) and Array (count + offset); enable/disable, reorder, remove, Apply (bake), one undo step each | Implemented and tested (host); UI untested on device |
| Viewport/picking show the evaluated mesh; edit mode shows the base mesh as cage | Implemented and tested (host picking); rendering untested on device |
| Project format v4 (modifier stacks + subsurf/solidify params), v1/v2/v3 still load, corrupt modifier records rejected | Implemented and tested (host) |
| Delete vertices / edges / faces | Implemented and tested (host) |
| Edit-mode Move / Rotate / Scale of any selection about its median point | Implemented and tested (host math); drag gesture untested on device |
| Undo/redo restores mesh AND element selection | Implemented and tested (host) |
| Move / Rotate / Scale objects by drag, X/Y/Z constraint, one undo step per gesture | Implemented but untested on device |
| Numeric Location/Rotation/Scale fields (Properties) | Implemented but untested on device |
| Command undo/redo (add, delete, transform, mesh edit) | Implemented and tested (host) |
| Project format (atomic save, migration from older versions) | Implemented and tested (host) |
| Viewport: orbit/pan/zoom, view presets, frame selected, wireframe/solid, axis gizmo | Implemented but untested on device |
| Edit overlay rendering (vertex dots, selected edges, selected faces) | Implemented but untested on device (compiles against stub GL only) |
| Blender-style shell: menus, workspace tabs, Outliner, Properties, header, status bar | Implemented but untested on device |
| Bevel, knife, bridge, edge slide, region inset, proportional editing | Not started |
| Subdivision Surface modifier (Catmull-Clark, levels 1-4, boundary + non-manifold rules, quads out) | Implemented and tested (host); UI untested on device |
| Solidify modifier (even thickness, offset In/Center/Out, rim on open meshes, inner shell flipped) | Implemented and tested (host); UI untested on device |
| Viewport lighting: two-sided, camera headlight + Z-up hemisphere ambient + key light (back faces no longer near-black) | Implemented but untested on device (compiles against stub GL only) |
| UI cleanup: compact header (Solid/Wire text buttons, no clipped glyph), taller Properties panel with bottom padding | Implemented but untested on device |
| Triangulate modifier (ear clipping, concave n-gons OK, winding kept) | Implemented and tested (host); UI untested on device |
| Weld modifier + Mesh > Merge by Distance (selected vertices only, clusters collapse to centroid, degenerate faces dropped) | Implemented and tested (host); UI untested on device |
| Object ops: Rename (tap the name in Properties), Apply All Transforms / Apply Scale (negative scale flips winding), Origin to Geometry, all undoable | Implemented and tested (host); UI untested on device |
| Select > Linked in Edit Mode (whole connected island, vertex/edge/face modes) | Implemented and tested (host); UI untested on device |
| Other modifiers (Boolean, Bevel, Decimate...) | Not started |
| Parenting, collections, multi-select objects, local orientation, ortho view | Not started |
| Timeline / animation | Not started (Phase 6) |
| Workspaces other than Layout/Modeling | Not started (tabs are disabled) |
| Materials, UV, sculpt, rig, render, import/export | Not started |

Known limits: Weld does not remove faces that become duplicates of each other after merging, and keeps no selection; Apply Transform leaves the modifier stack untouched (Mirror axes etc. act on the baked mesh); Origin to Geometry uses the vertex median (not the bounding-box centre); Subdivision Surface has no creases, no separate viewport/render levels and no UV/normal smoothing (flat shading only); Solidify uses an averaged vertex normal with an even-thickness correction (clamped, so very sharp spikes thin out) and has no per-face thickness or rim material; Mirror has no clipping/mirror-object/bisect options and uses the object-local plane; Array only supports a constant offset; modifier stack is capped at 16; Apply is object-mode only and bakes modifiers 0..i; Loop Cut uses the first selected edge, one cut per operation, position from a numeric field (no interactive slide yet); edit snapshots copy the whole mesh per undo step (fine for small meshes); n-gon fan
triangulation assumes convex faces; Z-up like Blender (import converters will handle Y-up formats);
Inset is per-face (not region) and uses a centroid-relative amount; edge/face extrude distance comes from a
numeric field (the Move tool then drags the result); edit-mode rotate/scale use local axes; vertex/edge
occlusion test is O(faces) per candidate (fine for small meshes, needs a BVH later); loose vertices/edges
cannot exist (meshes are face-based, deleting faces removes orphan vertices).
