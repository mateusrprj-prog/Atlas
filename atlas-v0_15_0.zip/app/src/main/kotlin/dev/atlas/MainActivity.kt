package dev.atlas

import android.app.Activity
import android.app.AlertDialog
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.text.InputType
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.View
import android.view.inputmethod.EditorInfo
import android.view.inputmethod.InputMethodManager
import android.widget.EditText
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.PopupMenu
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import java.io.File
import java.util.Locale
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

private data class Item(val title: String, val enabled: Boolean = true, val action: () -> Unit = {})
private class Snap(val outliner: String, val xf: FloatArray, val stats: String, val mode: Int, val selMode: Int, val mods: String)

class MainActivity : Activity() {
    private lateinit var gl: GLSurfaceView
    private lateinit var root: LinearLayout
    private val projectPath get() = File(filesDir, "project.atlas").absolutePath

    // palette inspired by a dark desktop 3D editor
    private val cTop = Color.parseColor("#181818")
    private val cHeader = Color.parseColor("#303030")
    private val cPanel = Color.parseColor("#282828")
    private val cField = Color.parseColor("#1d1d1d")
    private val cText = Color.parseColor("#D9D9D9")
    private val cDim = Color.parseColor("#8A8A8A")
    private val cAccent = Color.parseColor("#4772B3")
    private val cRowSel = Color.parseColor("#334C75")
    private val cTabActive = Color.parseColor("#3D3D3D")

    private var tool = 0          // 0 select, 1 move, 2 rotate, 3 scale
    private var axis = 0          // 0 free, 1 X, 2 Y, 3 Z
    private var mode = 0          // 0 object, 1 edit
    private var selMode = 0       // edit-mode elements: 0 vertex, 1 edge, 2 face
    private var shading = 0
    private var fullscreen = false

    private val toolButtons = ArrayList<TextView>()
    private val axisButtons = ArrayList<TextView>()
    private val shadeButtons = ArrayList<TextView>()
    private val selModeButtons = ArrayList<TextView>()
    private lateinit var selModeBox: LinearLayout
    private lateinit var editHint: TextView
    private lateinit var insetField: EditText
    private lateinit var cutField: EditText
    private lateinit var weldField: EditText
    private lateinit var dissolveField: EditText
    private lateinit var bevelField: EditText
    private lateinit var modBox: LinearLayout
    private var lastMods: String? = null
    private val tabViews = LinkedHashMap<String, TextView>()
    private val xfFields = ArrayList<EditText>()
    private lateinit var modeBtn: TextView
    private lateinit var addBtn: TextView
    private lateinit var objBtn: TextView
    private lateinit var meshBtn: TextView
    private lateinit var outlinerBox: LinearLayout
    private lateinit var nameLabel: TextView
    private lateinit var extrudeRow: LinearLayout
    private lateinit var extrudeField: EditText
    private lateinit var statusLeft: TextView
    private lateinit var toolbar: View
    private lateinit var rightPanel: View
    private lateinit var statusBar: View

    private val workspaces = listOf("Layout", "Modeling", "Sculpting", "UV Editing", "Texture Paint", "Shading",
        "Animation", "Rendering", "Compositing", "Geometry Nodes", "Scripting")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setBackgroundColor(cTop)
            isFocusableInTouchMode = true
        }
        gl = ViewportView()
        toolbar = buildToolbar()
        rightPanel = buildRightPanel()
        statusBar = buildStatusBar()

        val center = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        center.addView(buildHeader(), LinearLayout.LayoutParams(-1, dp(34)))
        center.addView(gl, LinearLayout.LayoutParams(-1, 0, 1f))

        val main = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        main.addView(toolbar, LinearLayout.LayoutParams(dp(44), -1))
        main.addView(center, LinearLayout.LayoutParams(0, -1, 1f))
        main.addView(rightPanel, LinearLayout.LayoutParams(dp(250), -1))

        root.addView(buildTopBar(), LinearLayout.LayoutParams(-1, dp(36)))
        root.addView(main, LinearLayout.LayoutParams(-1, 0, 1f))
        root.addView(statusBar, LinearLayout.LayoutParams(-1, dp(24)))
        setContentView(root)
        selectTool(0); refreshAxis(); refreshShading()
        root.requestFocus()
        act { NativeBridge.ensureScene() }
    }

    override fun onPause() { super.onPause(); gl.onPause() }
    override fun onResume() { super.onResume(); gl.onResume() }

    // ---------------------------------------------------------------- helpers
    private fun dp(v: Int) = (v * resources.displayMetrics.density).toInt()
    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    private fun fmt(v: Float) = String.format(Locale.US, "%.3f", v)

    private fun roundBg(color: Int, radius: Int = 4) = GradientDrawable().apply {
        setColor(color); cornerRadius = dp(radius).toFloat()
    }

    private fun label(t: String, size: Float = 12f, color: Int = cText): TextView = TextView(this).apply {
        this.text = t; textSize = size; setTextColor(color)
        setPadding(dp(9), dp(4), dp(9), dp(4)); gravity = Gravity.CENTER_VERTICAL
    }

    /** Runs [block] on the GL thread (the only thread allowed to touch the scene), then refreshes the panels. */
    private fun act(block: () -> Unit) {
        gl.queueEvent {
            block()
            val snap = Snap(NativeBridge.outliner(), NativeBridge.activeTransform(), NativeBridge.stats(), NativeBridge.mode(), NativeBridge.selectMode(), NativeBridge.modifiers())
            runOnUiThread { applySnap(snap) }
        }
    }

    private fun popup(anchor: View, items: List<Item>) {
        val pm = PopupMenu(this, anchor)
        items.forEachIndexed { i, item -> pm.menu.add(0, i, i, item.title).isEnabled = item.enabled }
        pm.setOnMenuItemClickListener { mi -> items[mi.itemId].action(); true }
        pm.show()
    }

    private fun hideKeyboard() {
        val imm = getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager
        currentFocus?.let { imm.hideSoftInputFromWindow(it.windowToken, 0); it.clearFocus() }
        root.requestFocus()
    }

    // ---------------------------------------------------------------- top bar (menus + workspace tabs)
    private fun buildTopBar(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        row.addView(label("Atlas", 14f, Color.WHITE).apply { typeface = Typeface.DEFAULT_BOLD })
        fun menu(name: String, items: () -> List<Item>) {
            val b = label(name, 13f); b.setOnClickListener { popup(b, items()) }; row.addView(b)
        }
        menu("File") { fileItems() }
        menu("Edit") { editItems() }
        menu("Render") { listOf(Item("Render Image… (Fase 7)", enabled = false)) }
        menu("Window") { listOf(Item("Alternar viewport em tela cheia") { toggleFullscreen() }) }
        menu("Help") { listOf(Item("Sobre o Atlas") { showAbout() }) }
        row.addView(View(this), LinearLayout.LayoutParams(dp(14), 1))
        for (name in workspaces) {
            val t = label(name, 13f)
            tabViews[name] = t
            t.setOnClickListener {
                when (name) {
                    "Layout" -> act { NativeBridge.setMode(0) }
                    "Modeling" -> act { if (!NativeBridge.setMode(1)) toast("Selecione um objeto primeiro") }
                    else -> toast("$name: ainda não implementado")
                }
            }
            row.addView(t)
        }
        return HorizontalScrollView(this).apply {
            setBackgroundColor(cTop); isHorizontalScrollBarEnabled = false; addView(row)
        }
    }

    private fun fileItems() = listOf(
        Item("New") {
            AlertDialog.Builder(this).setMessage("Descartar a cena atual?")
                .setPositiveButton("Sim") { _, _ -> act { NativeBridge.newScene() } }
                .setNegativeButton("Não", null).show()
        },
        Item("Open") { act { toast(if (NativeBridge.load(projectPath)) "Projeto aberto" else "Falha ao abrir (ou não há projeto salvo)") } },
        Item("Save") { act { toast(if (NativeBridge.save(projectPath)) "Projeto salvo" else "Falha ao salvar") } },
        Item("Import… (Fase 3)", enabled = false),
        Item("Export… (Fase 3)", enabled = false))

    private fun editItems() = listOf(
        Item("Undo") { act { if (!NativeBridge.undo()) toast("Nada para desfazer") } },
        Item("Redo") { act { if (!NativeBridge.redo()) toast("Nada para refazer") } })

    private fun toggleFullscreen() {
        fullscreen = !fullscreen
        val vis = if (fullscreen) View.GONE else View.VISIBLE
        toolbar.visibility = vis; rightPanel.visibility = vis; statusBar.visibility = vis
    }

    private fun showAbout() {
        AlertDialog.Builder(this).setTitle("Atlas 0.15.0")
            .setMessage("Aplicativo 3D independente para Android.\nMotor, formato de projeto e interface próprios, sem código do Blender.")
            .setPositiveButton("OK", null).show()
    }

    // ---------------------------------------------------------------- tool column
    private fun buildToolbar(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cPanel); setPadding(dp(4), dp(6), dp(4), dp(6)) }
        val icons = listOf("⬚" to "Select", "✥" to "Move", "⟳" to "Rotate", "⤢" to "Scale")
        icons.forEachIndexed { i, (ic, _) ->
            val b = label(ic, 20f).apply { gravity = Gravity.CENTER; setPadding(0, 0, 0, 0) }
            b.setOnClickListener { selectTool(i) }
            toolButtons.add(b)
            col.addView(b, LinearLayout.LayoutParams(dp(36), dp(36)).apply { bottomMargin = dp(4) })
        }
        return col
    }

    private fun selectTool(i: Int) {
        tool = i
        toolButtons.forEachIndexed { k, b -> b.background = roundBg(if (k == i) cAccent else cHeader) }
    }

    // ---------------------------------------------------------------- viewport header
    private fun buildHeader(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        fun drop(t: String, items: () -> List<Item>): TextView {
            val b = label("$t ▾", 12f).apply { setPadding(dp(7), dp(4), dp(7), dp(4)) }; b.setOnClickListener { popup(b, items()) }; row.addView(b); return b
        }
        modeBtn = drop("Object") {
            listOf(Item("Object Mode") { act { NativeBridge.setMode(0) } },
                   Item("Edit Mode") { act { if (!NativeBridge.setMode(1)) toast("Selecione um objeto primeiro") } })
        }
        modeBtn.background = roundBg(cField)
        drop("View") { viewItems() }
        drop("Select") { selectItems() }
        addBtn = drop("Add") { addItems() }
        objBtn = drop("Object") { objectItems() }
        meshBtn = drop("Mesh") { meshItems() }
        // vertex / edge / face select mode (edit mode only)
        selModeBox = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        listOf("●" to "Vertex", "╱" to "Edge", "▣" to "Face").forEachIndexed { i, (ic, _) ->
            val b = label(ic, 15f).apply { gravity = Gravity.CENTER }
            b.setOnClickListener { act { NativeBridge.setSelectMode(i) } }
            selModeButtons.add(b); selModeBox.addView(b)
        }
        row.addView(selModeBox)
        row.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        listOf("X" to "#D9494D", "Y" to "#7FBF3F", "Z" to "#4080F2").forEachIndexed { i, (n, c) ->
            val b = label(n, 13f, Color.parseColor(c)).apply { gravity = Gravity.CENTER; typeface = Typeface.DEFAULT_BOLD }
            b.setOnClickListener { axis = if (axis == i + 1) 0 else i + 1; refreshAxis() }
            axisButtons.add(b); row.addView(b)
        }
        row.addView(View(this), LinearLayout.LayoutParams(dp(10), 1))
        listOf("Solid" to 0, "Wire" to 1).forEach { (ic, m) ->
            val b = label(ic, 11f).apply { gravity = Gravity.CENTER; setPadding(dp(7), dp(4), dp(7), dp(4)) }
            b.setOnClickListener { shading = m; refreshShading(); act { NativeBridge.setShading(m) } }
            shadeButtons.add(b); row.addView(b)
        }
        row.setPadding(dp(2), 0, dp(10), 0)
        return HorizontalScrollView(this).apply { setBackgroundColor(cHeader); isHorizontalScrollBarEnabled = false; isHorizontalFadingEdgeEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER; addView(row) }
    }

    private fun refreshAxis() = axisButtons.forEachIndexed { i, b -> b.background = roundBg(if (axis == i + 1) cAccent else Color.TRANSPARENT) }
    private fun refreshShading() = shadeButtons.forEachIndexed { i, b -> b.background = roundBg(if (shading == i) cAccent else Color.TRANSPARENT) }

    private fun viewItems() = listOf(
        Item("Front") { act { NativeBridge.viewPreset(0) } }, Item("Back") { act { NativeBridge.viewPreset(1) } },
        Item("Right") { act { NativeBridge.viewPreset(2) } }, Item("Left") { act { NativeBridge.viewPreset(3) } },
        Item("Top") { act { NativeBridge.viewPreset(4) } }, Item("Bottom") { act { NativeBridge.viewPreset(5) } },
        Item("Frame Selected") { act { if (!NativeBridge.frameSelected()) toast("Nada selecionado") } },
        Item("Reset View") { act { NativeBridge.resetView() } })

    private fun selectItems() =
        if (mode == 1) listOf(Item("All") { act { NativeBridge.selectAll() } }, Item("None") { act { NativeBridge.selectNone() } },
            Item("Invert") { act { NativeBridge.selectInvert() } },
            Item("More") { act { if (!NativeBridge.selectMore()) toast("Nada para expandir (selecione algo primeiro)") } },
            Item("Less") { act { if (!NativeBridge.selectLess()) toast("Nada para reduzir (sem borda interna ou nada selecionado)") } },
            Item("Linked (toda a ilha)") { act { if (!NativeBridge.selectLinked()) toast("Selecione algo primeiro") } })
        else listOf(Item("None") { act { NativeBridge.selectNone() } })

    private fun addItems() = listOf("Cube", "Plane", "Cylinder", "UV Sphere").mapIndexed { i, n ->
        Item(n) { act { NativeBridge.addPrimitive(i) } }
    }

    private fun promptRename() {
        if (nameLabel.text.toString() == "Nenhum objeto selecionado") return
        val et = EditText(this).apply { setSingleLine(true); setText(nameLabel.text.toString()); setSelection(text.length) }
        AlertDialog.Builder(this).setTitle("Renomear objeto").setView(et)
            .setPositiveButton("OK") { _, _ ->
                val n = et.text.toString()
                act { if (!NativeBridge.renameSelected(n)) toast("Nome vazio, igual ao atual ou Edit Mode ativo") }
            }
            .setNegativeButton("Cancelar", null).show()
    }

    private fun objectItems() = listOf(
        Item("Rename…") { promptRename() },
        Item("Duplicate") { act { if (!NativeBridge.duplicateSelected()) toast("Nada selecionado") } },
        Item("Apply All Transforms") { act { if (!NativeBridge.applyTransform(0)) toast("Só no Object Mode, e a transformação não pode estar já zerada") } },
        Item("Apply Scale") { act { if (!NativeBridge.applyTransform(1)) toast("Só no Object Mode, e a escala não pode estar já em 1") } },
        Item("Join (todos no ativo)") { act { val n = NativeBridge.joinAll(); toast(if (n > 0) "$n objeto(s) unidos ao ativo" else "Só no Object Mode e com 2 ou mais objetos") } },
        Item("Separate Loose Parts") { act { val n = NativeBridge.separateLoose(); toast(if (n > 0) "$n novo(s) objeto(s)" else "Só no Object Mode e o objeto precisa ter 2 ou mais partes soltas") } },
        Item("Origin to Geometry") { act { if (!NativeBridge.originToGeometry()) toast("Só no Object Mode, e a origem não pode estar já no centro") } },
        Item("Delete") { act { if (!NativeBridge.deleteSelected()) toast("Nada selecionado") } })

    private fun floatOf(f: EditText, def: Float) = f.text.toString().replace(',', '.').toFloatOrNull() ?: def

    private fun meshItems() = listOf(
        Item("Extrude (vértices/arestas/faces)") {
            val d = floatOf(extrudeField, 0.5f)
            act { if (!NativeBridge.extrude(d)) toast("Selecione arestas ou faces completas e use distância ≠ 0") }
        },
        Item("Inset Faces") {
            val a = floatOf(insetField, 0.3f)
            act { if (!NativeBridge.insetFaces(a)) toast("Selecione faces e use um valor entre 0 e 1 (exclusivo)") }
        },
        Item("Loop Cut (1 aresta selecionada)") {
            val t = floatOf(cutField, 0.5f)
            act { if (!NativeBridge.loopCut(t)) toast("Selecione uma aresta (ou 2 vértices) e use um valor entre 0 e 1 (exclusivo)") }
        },
        Item("Select Edge Loop") { act { if (!NativeBridge.selectLoop()) toast("Selecione uma aresta primeiro") } },
        Item("Subdivide") { act { if (!NativeBridge.subdivide()) toast("Selecione faces (ou vértices/arestas que formem faces)") } },
        Item("Merge at Center") { act { if (!NativeBridge.mergeCenter()) toast("Selecione 2 ou mais vértices") } },
        Item("Merge by Distance") {
            val d = floatOf(weldField, 0.001f)
            act { if (!NativeBridge.weldSelected(d)) toast("Selecione vértices; nada dentro dessa distância (ou distância inválida)") }
        },
        Item("Dissolve Edges") { act { if (!NativeBridge.dissolveEdges()) toast("Selecione arestas entre duas faces (no modo face: faces vizinhas para fundir)") } },
        Item("Limited Dissolve") {
            val a = floatOf(dissolveField, 5f)
            act { if (!NativeBridge.limitedDissolve(a)) toast("Selecione faces; use um ângulo entre 0 (exclusivo) e 180; nada para fundir dentro desse ângulo") }
        },
        Item("Dissolve Vertices") { act { if (!NativeBridge.dissolveVertices()) toast("Selecione vértices (ou arestas/faces) para dissolver") } },
        Item("Dissolve Faces") { act { if (!NativeBridge.dissolveFaces()) toast("Selecione 2 ou mais faces vizinhas para fundir") } },
        Item("Fill (criar face)") { act { if (!NativeBridge.fillSelected()) toast("Selecione arestas que formem UM laço fechado (sem arestas que já tenham 2 faces)") } },
        Item("Bridge Edge Loops") { act { if (!NativeBridge.bridgeLoops()) toast("Selecione exatamente 2 laços fechados de arestas com o mesmo número de arestas") } },
        Item("Bevel Vertices") {
            val w = floatOf(bevelField, 0.2f)
            act { if (!NativeBridge.bevelVertices(w)) toast("Selecione vértices de malha fechada e use largura > 0 (vértices de borda são ignorados)") }
        },
        Item("Separate Selection") { act { if (NativeBridge.separateSelected()) toast("Novo objeto criado") else toast("Selecione faces, mas não todas") } },
        Item("Flip Normals") { act { if (!NativeBridge.flipNormals()) toast("Selecione faces") } },
        Item("Delete") { act { if (!NativeBridge.deleteSelection()) toast("Nada selecionado") } })

    // ---------------------------------------------------------------- right panel: outliner + properties
    private fun buildRightPanel(): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setBackgroundColor(cPanel) }
        col.addView(label("Outliner", 12f, cDim).apply { setBackgroundColor(cHeader) }, LinearLayout.LayoutParams(-1, dp(28)))
        outlinerBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(ScrollView(this).apply { addView(outlinerBox) }, LinearLayout.LayoutParams(-1, 0, 0.8f))
        col.addView(label("Properties", 12f, cDim).apply { setBackgroundColor(cHeader) }, LinearLayout.LayoutParams(-1, dp(28)))

        val props = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(4), 0, dp(48)) }
        nameLabel = label("Nenhum objeto selecionado", 13f)
        nameLabel.setOnClickListener { promptRename() }
        props.addView(nameLabel)
        props.addView(label("Transform", 11f, cDim))
        props.addView(transformRow("Location"))
        props.addView(transformRow("Rotation (°)"))
        props.addView(transformRow("Scale"))
        extrudeRow = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(6), dp(8), 0) }
        editHint = TextView(this).apply { textSize = 11f; setTextColor(cDim) }
        extrudeRow.addView(editHint)
        extrudeRow.addView(TextView(this).apply { text = "Extrude Distance"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(6), 0, 0) })
        extrudeField = numberField(); extrudeField.setText("0.5")
        extrudeRow.addView(extrudeField, LinearLayout.LayoutParams(-1, -2))
        extrudeRow.addView(TextView(this).apply { text = "Inset Amount (0–1)"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(6), 0, 0) })
        insetField = numberField(); insetField.setText("0.3")
        extrudeRow.addView(insetField, LinearLayout.LayoutParams(-1, -2))
        extrudeRow.addView(TextView(this).apply { text = "Loop Cut Position (0–1)"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(6), 0, 0) })
        cutField = numberField(); cutField.setText("0.5")
        extrudeRow.addView(cutField, LinearLayout.LayoutParams(-1, -2))
        extrudeRow.addView(TextView(this).apply { text = "Merge Distance"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(6), 0, 0) })
        weldField = numberField(); weldField.setText("0.001")
        extrudeRow.addView(weldField, LinearLayout.LayoutParams(-1, -2))
        extrudeRow.addView(TextView(this).apply { text = "Bevel Width"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(6), 0, 0) })
        bevelField = numberField(); bevelField.setText("0.2")
        extrudeRow.addView(bevelField, LinearLayout.LayoutParams(-1, -2))
        extrudeRow.addView(TextView(this).apply { text = "Limited Dissolve Angle (°)"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(6), 0, 0) })
        dissolveField = numberField(); dissolveField.setText("5")
        extrudeRow.addView(dissolveField, LinearLayout.LayoutParams(-1, -2))
        props.addView(extrudeRow)
        modBox = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(0, dp(8), 0, 0) }
        props.addView(modBox)
        col.addView(ScrollView(this).apply { addView(props); isVerticalScrollBarEnabled = false; overScrollMode = View.OVER_SCROLL_NEVER }, LinearLayout.LayoutParams(-1, 0, 2.8f))
        return col
    }

    private fun numberField(): EditText = EditText(this).apply {
        textSize = 12f; setTextColor(cText); background = roundBg(cField)
        setPadding(dp(6), dp(4), dp(6), dp(4)); setSingleLine(true)
        inputType = InputType.TYPE_CLASS_NUMBER or InputType.TYPE_NUMBER_FLAG_DECIMAL or InputType.TYPE_NUMBER_FLAG_SIGNED
        imeOptions = EditorInfo.IME_ACTION_DONE
    }

    private fun transformRow(title: String): View {
        val col = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(2)) }
        col.addView(TextView(this).apply { text = title; textSize = 11f; setTextColor(cDim) })
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        for (i in 0 until 3) {
            val et = numberField()
            et.setOnEditorActionListener { _, actionId, _ ->
                if (actionId == EditorInfo.IME_ACTION_DONE) { commitTransform(); hideKeyboard(); true } else false
            }
            et.setOnFocusChangeListener { _, has -> if (!has) commitTransform() }
            xfFields.add(et)
            row.addView(et, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = if (i < 2) dp(3) else 0 })
        }
        col.addView(row)
        return col
    }

    private fun commitTransform() {
        val arr = FloatArray(9)
        for (i in 0 until 9) {
            val v = xfFields[i].text.toString().replace(',', '.').toFloatOrNull()
            if (v == null) { act { }; return }
            arr[i] = v
        }
        act { NativeBridge.setActiveTransform(arr) }
    }

    private fun buildStatusBar(): View {
        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setBackgroundColor(cTop); gravity = Gravity.CENTER_VERTICAL }
        statusLeft = label("", 11f, cDim)
        row.addView(statusLeft, LinearLayout.LayoutParams(0, -2, 1f))
        row.addView(label("Atlas 0.15.0", 11f, cDim))
        return row
    }

    // ---------------------------------------------------------------- modifier stack UI
    private fun smallBtn(t: String, on: Boolean = false, click: () -> Unit): TextView = label(t, 11f).apply {
        gravity = Gravity.CENTER; setPadding(dp(7), dp(3), dp(7), dp(3)); background = roundBg(if (on) cAccent else cHeader)
        setOnClickListener { click() }
    }

    private fun rebuildModifiers(raw: String, has: Boolean) {
        modBox.removeAllViews()
        if (!has) return
        modBox.addView(label("Modifiers", 11f, cDim))
        val add = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(2), dp(8), dp(2)) }
        val names = listOf("Mirror", "Array", "Subdivision Surface", "Solidify", "Triangulate", "Weld", "Smooth", "Simple Deform", "Planar Decimate")
        val addBtnMod = smallBtn("+ Add Modifier ▾") { }
        addBtnMod.gravity = Gravity.CENTER
        addBtnMod.setOnClickListener {
            popup(addBtnMod, names.mapIndexed { k, nm -> Item(nm) { act { if (!NativeBridge.addModifier(k)) toast("Não foi possível adicionar") } } })
        }
        add.addView(addBtnMod, LinearLayout.LayoutParams(-1, dp(34)).apply { bottomMargin = dp(3) })
        modBox.addView(add)
        if (raw.isEmpty()) return
        raw.split("\n").forEachIndexed { i, line ->
            val p = line.split("\t"); if (p.size < 7) return@forEachIndexed
            val type = p[0].toIntOrNull() ?: return@forEachIndexed
            val enabled = p[1] == "1"; val axis = p[2].toIntOrNull() ?: 0; val count = p[3].toIntOrNull() ?: 2
            val levels = p.getOrNull(7)?.toIntOrNull() ?: 1
            val thick = p.getOrNull(8)?.toFloatOrNull() ?: 0.1f
            val shift = p.getOrNull(9)?.toFloatOrNull() ?: -1f
            val merge = p.getOrNull(10)?.toFloatOrNull() ?: 0.001f
            val factor = p.getOrNull(11)?.toFloatOrNull() ?: 0.5f
            val iterations = p.getOrNull(12)?.toIntOrNull() ?: 1
            val dmode = p.getOrNull(13)?.toIntOrNull() ?: 0
            val angle = p.getOrNull(14)?.toFloatOrNull() ?: 45f
            val card = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(dp(8), dp(4), dp(8), dp(6)); background = roundBg(cField) }
            val head = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
            card.addView(label(when (type) { 1 -> "Array"; 2 -> "Subdivision Surface"; 3 -> "Solidify"; 4 -> "Triangulate"; 5 -> "Weld"; 6 -> "Smooth"; 7 -> "Simple Deform"; 8 -> "Planar Decimate"; else -> "Mirror" }, 12f, if (enabled) Color.WHITE else cDim))
            head.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
            head.addView(smallBtn(if (enabled) "On" else "Off", enabled) { act { NativeBridge.toggleModifier(i) } })
            head.addView(smallBtn("▲") { act { NativeBridge.moveModifier(i, -1) } })
            head.addView(smallBtn("▼") { act { NativeBridge.moveModifier(i, 1) } })
            head.addView(smallBtn("Apply") {
                act { if (!NativeBridge.applyModifier(i)) toast("Apply só funciona no Object Mode") }
            })
            head.addView(smallBtn("✕") { act { NativeBridge.removeModifier(i) } })
            card.addView(head)
            if (type == 2) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, 0) }
                row.addView(label("Levels", 11f, cDim))
                for (lv in 1..4) row.addView(smallBtn(lv.toString(), levels == lv) { act { NativeBridge.setModifierParams(i, lv, thick, shift) } })
                card.addView(row)
                if (levels >= 3) card.addView(TextView(this).apply { text = "Níveis altos pesam em malhas grandes"; textSize = 10f; setTextColor(cDim) })
            } else if (type == 3) {
                card.addView(TextView(this).apply { text = "Thickness"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(4), 0, 0) })
                val tf = numberField(); tf.setText(fmt(thick))
                fun commitThickness() {
                    val t = tf.text.toString().replace(',', '.').toFloatOrNull()
                    if (t == null || t <= 0f) { act { }; return }
                    act { NativeBridge.setModifierParams(i, levels, t, shift) }
                }
                tf.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { commitThickness(); hideKeyboard(); true } else false }
                tf.setOnFocusChangeListener { _, f -> if (!f) commitThickness() }
                card.addView(tf, LinearLayout.LayoutParams(-1, -2))
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, 0) }
                row.addView(label("Offset", 11f, cDim))
                listOf("In" to -1f, "Center" to 0f, "Out" to 1f).forEach { (n, sv) ->
                    row.addView(smallBtn(n, shift == sv) { act { NativeBridge.setModifierParams(i, levels, thick, sv) } })
                }
                card.addView(row)
            } else if (type == 4) {
                card.addView(TextView(this).apply { text = "Todas as faces viram triângulos"; textSize = 10f; setTextColor(cDim); setPadding(0, dp(4), 0, 0) })
            } else if (type == 5) {
                card.addView(TextView(this).apply { text = "Distance"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(4), 0, 0) })
                val df = numberField(); df.setText(String.format(Locale.US, "%.5f", merge))
                fun commitMerge() {
                    val d = df.text.toString().replace(',', '.').toFloatOrNull()
                    if (d == null || d < 0f) { act { }; return }
                    act { NativeBridge.setModifierMerge(i, d) }
                }
                df.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { commitMerge(); hideKeyboard(); true } else false }
                df.setOnFocusChangeListener { _, f -> if (!f) commitMerge() }
                card.addView(df, LinearLayout.LayoutParams(-1, -2))
            } else if (type == 6) {
                card.addView(TextView(this).apply { text = "Factor (0–1) / Repeat (1–32)"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(4), 0, 0) })
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val ff = numberField(); ff.setText(fmt(factor))
                val rf = numberField(); rf.inputType = InputType.TYPE_CLASS_NUMBER; rf.setText(iterations.toString())
                fun commitSmooth() {
                    val fv = ff.text.toString().replace(',', '.').toFloatOrNull(); val rv = rf.text.toString().toIntOrNull()
                    if (fv == null || rv == null || fv < 0f || fv > 1f || rv < 1 || rv > 32) { toast("Factor entre 0 e 1 e repetições entre 1 e 32"); act { }; return }
                    act { NativeBridge.setModifierExtra(i, axis, fv, rv, dmode, angle) }
                }
                for (et in listOf(ff, rf)) {
                    et.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { commitSmooth(); hideKeyboard(); true } else false }
                    et.setOnFocusChangeListener { _, f -> if (!f) commitSmooth() }
                }
                row.addView(ff, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = dp(3) })
                row.addView(rf, LinearLayout.LayoutParams(0, -2, 1f))
                card.addView(row)
                card.addView(TextView(this).apply { text = "Bordas abertas encolhem um pouco"; textSize = 10f; setTextColor(cDim); setPadding(0, dp(2), 0, 0) })
            } else if (type == 7) {
                val mrow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, 0) }
                mrow.addView(label("Mode", 11f, cDim))
                listOf("Twist", "Bend", "Taper", "Stretch").forEachIndexed { k, n ->
                    mrow.addView(smallBtn(n, dmode == k) { act { NativeBridge.setModifierExtra(i, axis, factor, iterations, k, angle) } })
                }
                card.addView(mrow)
                val arow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, 0) }
                arow.addView(label("Axis", 11f, cDim))
                listOf("X", "Y", "Z").forEachIndexed { a, n ->
                    arow.addView(smallBtn(n, axis == a) { act { NativeBridge.setModifierExtra(i, a, factor, iterations, dmode, angle) } })
                }
                card.addView(arow)
                val useAngle = dmode <= 1
                card.addView(TextView(this).apply { text = if (useAngle) "Angle (°)" else "Factor"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(4), 0, 0) })
                val vf = numberField(); vf.setText(fmt(if (useAngle) angle else factor))
                fun commitDeform() {
                    val v = vf.text.toString().replace(',', '.').toFloatOrNull()
                    if (v == null) { act { }; return }
                    act { if (useAngle) NativeBridge.setModifierExtra(i, axis, factor, iterations, dmode, v) else NativeBridge.setModifierExtra(i, axis, v, iterations, dmode, angle) }
                }
                vf.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { commitDeform(); hideKeyboard(); true } else false }
                vf.setOnFocusChangeListener { _, f -> if (!f) commitDeform() }
                card.addView(vf, LinearLayout.LayoutParams(-1, -2))
            } else if (type == 8) {
                card.addView(TextView(this).apply { text = "Angle limit (°, 0–180)"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(4), 0, 0) })
                val af = numberField(); af.setText(fmt(angle))
                fun commitAngle() {
                    val v = af.text.toString().replace(',', '.').toFloatOrNull()
                    if (v == null || v <= 0f || v > 180f) { act { }; return }
                    act { NativeBridge.setModifierExtra(i, axis, factor, iterations, dmode, v) }
                }
                af.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { commitAngle(); hideKeyboard(); true } else false }
                af.setOnFocusChangeListener { _, f -> if (!f) commitAngle() }
                card.addView(af, LinearLayout.LayoutParams(-1, -2))
                card.addView(TextView(this).apply { text = "Funde faces quase planas (como Limited Dissolve)"; textSize = 10f; setTextColor(cDim); setPadding(0, dp(2), 0, 0) })
            } else if (type == 0) {
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; setPadding(0, dp(4), 0, 0) }
                row.addView(label("Axis", 11f, cDim))
                listOf("X", "Y", "Z").forEachIndexed { a, n ->
                    row.addView(smallBtn(n, axis == a) { act { NativeBridge.setModifier(i, a, count, floatArrayOf(1f, 0f, 0f)) } })
                }
                card.addView(row)
            } else {
                card.addView(TextView(this).apply { text = "Count / Offset"; textSize = 11f; setTextColor(cDim); setPadding(0, dp(4), 0, 0) })
                val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
                val fields = ArrayList<EditText>()
                fun commit() {
                    val c = fields[0].text.toString().toIntOrNull()
                    val o = FloatArray(3) { k -> fields[k + 1].text.toString().replace(',', '.').toFloatOrNull() ?: Float.NaN }
                    if (c == null || o.any { it.isNaN() }) { act { }; return }
                    act { NativeBridge.setModifier(i, 0, c, o) }
                }
                for (k in 0 until 4) {
                    val et = numberField()
                    if (k == 0) et.inputType = InputType.TYPE_CLASS_NUMBER
                    et.setText(if (k == 0) count.toString() else p[3 + k].toFloatOrNull()?.let { fmt(it) } ?: "0")
                    et.setOnEditorActionListener { _, id, _ -> if (id == EditorInfo.IME_ACTION_DONE) { commit(); hideKeyboard(); true } else false }
                    et.setOnFocusChangeListener { _, f -> if (!f) commit() }
                    fields.add(et)
                    row.addView(et, LinearLayout.LayoutParams(0, -2, 1f).apply { rightMargin = if (k < 3) dp(3) else 0 })
                }
                card.addView(row)
            }
            modBox.addView(card, LinearLayout.LayoutParams(-1, -2).apply { setMargins(dp(8), dp(2), dp(8), dp(4)) })
        }
    }

    // ---------------------------------------------------------------- state -> UI
    private fun applySnap(s: Snap) {
        mode = s.mode
        tabViews.forEach { (n, v) ->
            val active = (n == "Layout" && mode == 0) || (n == "Modeling" && mode == 1)
            v.background = roundBg(if (active) cTabActive else Color.TRANSPARENT)
            v.alpha = if (n == "Layout" || n == "Modeling") 1f else 0.4f
        }
        modeBtn.text = if (mode == 0) "Object ▾" else "Edit ▾"
        addBtn.visibility = if (mode == 0) View.VISIBLE else View.GONE
        objBtn.visibility = if (mode == 0) View.VISIBLE else View.GONE
        meshBtn.visibility = if (mode == 1) View.VISIBLE else View.GONE
        extrudeRow.visibility = if (mode == 1) View.VISIBLE else View.GONE
        selModeBox.visibility = if (mode == 1) View.VISIBLE else View.GONE
        selMode = s.selMode
        selModeButtons.forEachIndexed { i, b -> b.background = roundBg(if (selMode == i) cAccent else Color.TRANSPARENT) }
        editHint.text = when (selMode) {
            0 -> "Edit Mode (vértices) · toque num vértice; toque de novo para desmarcar"
            1 -> "Edit Mode (arestas) · toque numa aresta"
            else -> "Edit Mode (faces) · toque numa face"
        }

        outlinerBox.removeAllViews()
        outlinerBox.addView(label("▾ Scene Collection", 12f))
        outlinerBox.addView(label("   ▾ Collection", 12f).apply { setPadding(dp(18), dp(4), dp(9), dp(4)) })
        var selName = ""
        if (s.outliner.isNotEmpty()) for (line in s.outliner.split("\n")) {
            val p = line.split("\t"); if (p.size < 3) continue
            val id = p[0].toIntOrNull() ?: continue
            val sel = p[2] == "1"; if (sel) selName = p[1]
            val row = label("▽  ${p[1]}", 12f, if (sel) Color.WHITE else cText).apply {
                setPadding(dp(34), dp(5), dp(9), dp(5)); background = roundBg(if (sel) cRowSel else Color.TRANSPARENT, 3)
            }
            row.setOnClickListener { act { NativeBridge.selectObject(id) } }
            outlinerBox.addView(row)
        }

        val has = s.xf.size == 9
        val modKey = (if (has) "1" else "0") + s.mods
        if (modKey != lastMods) { lastMods = modKey; rebuildModifiers(s.mods, has) }
        nameLabel.text = if (has) selName else "Nenhum objeto selecionado"
        for (i in 0 until 9) {
            val et = xfFields[i]
            et.isEnabled = has && mode == 0
            if (!et.hasFocus()) et.setText(if (has) fmt(s.xf[i]) else "")
        }
        statusLeft.text = (if (has) "$selName  ·  " else "") + s.stats + "  ·  " +
            (if (mode == 0) "Object Mode" else "Edit Mode (" + listOf("vértices", "arestas", "faces")[selMode] + ")")
    }

    // ---------------------------------------------------------------- viewport + touch
    inner class ViewportView : GLSurfaceView(this@MainActivity) {
        private var lastX = 0f; private var lastY = 0f; private var downX = 0f; private var downY = 0f
        private var downT = 0L; private var multi = false; private var dragging = false
        private var lastMidX = 0f; private var lastMidY = 0f
        private val scale = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val f = d.scaleFactor; queueEvent { NativeBridge.zoom(f) }; return true
            }
        })
        init {
            setEGLContextClientVersion(3)
            setRenderer(object : Renderer {
                override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) = NativeBridge.init()
                override fun onSurfaceChanged(g: GL10?, w: Int, h: Int) = NativeBridge.resize(w, h)
                override fun onDrawFrame(g: GL10?) = NativeBridge.draw()
            })
        }

        override fun onTouchEvent(e: MotionEvent): Boolean {
            scale.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    hideKeyboard()
                    lastX = e.x; lastY = e.y; downX = e.x; downY = e.y; downT = e.eventTime
                    multi = false; dragging = false
                }
                MotionEvent.ACTION_POINTER_DOWN -> {
                    if (dragging) { dragging = false; queueEvent { NativeBridge.cancelTransform() } }
                    multi = true
                    if (e.pointerCount >= 2) { lastMidX = (e.getX(0) + e.getX(1)) / 2; lastMidY = (e.getY(0) + e.getY(1)) / 2 }
                }
                MotionEvent.ACTION_MOVE -> {
                    if (e.pointerCount >= 2) {
                        val mx = (e.getX(0) + e.getX(1)) / 2; val my = (e.getY(0) + e.getY(1)) / 2
                        val dx = mx - lastMidX; val dy = my - lastMidY
                        lastMidX = mx; lastMidY = my
                        if (tool == 0) queueEvent { NativeBridge.pan(dx, dy) }
                        else queueEvent { NativeBridge.orbit(dx, dy) }
                    } else if (!multi) {
                        val tdx = e.x - downX; val tdy = e.y - downY
                        val sdx = e.x - lastX; val sdy = e.y - lastY
                        if (!dragging && Math.hypot(tdx.toDouble(), tdy.toDouble()) > 16) {
                            dragging = true
                            val t = tool; val a = axis
                            if (t != 0) queueEvent { NativeBridge.beginTransform(t, a) }
                        }
                        if (dragging) {
                            if (tool == 0) queueEvent { NativeBridge.orbit(sdx, sdy) }
                            else queueEvent { NativeBridge.dragStep(tdx, tdy, sdx, sdy) }
                        }
                        lastX = e.x; lastY = e.y
                    }
                }
                MotionEvent.ACTION_UP -> {
                    if (!multi) {
                        val x = e.x; val y = e.y
                        if (!dragging && e.eventTime - downT < 400) act { NativeBridge.tap(x, y) }
                        else if (dragging && tool != 0) act { NativeBridge.endTransform() }
                    }
                    dragging = false; multi = false
                }
                MotionEvent.ACTION_CANCEL -> {
                    if (dragging) queueEvent { NativeBridge.cancelTransform() }
                    dragging = false; multi = false
                }
            }
            return true
        }
    }
}
