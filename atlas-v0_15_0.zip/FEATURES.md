# Features (status per feature)
| Feature | Status |
|---|---|
| Scene graph (flat, single collection), persistent ids, unique names | Implemented and tested (host) |
| Polygon mesh core (n-gon faces), primitives: cube, plane, cylinder, UV sphere | Implemented and tested (host) |
| Edit Mode element selection: vertex / edge / face, mode conversion, select all/none/invert | Implemented and tested (host) |
| Picking of vertices and edges with occlusion test (screen-radius tolerance) | Implemented and tested (host); touch feel untested on device |
| Extrude: faces, edges (strip of quads), from vertex mode (auto-detects faces/edges) | Implemented and tested (host) |
| Inset faces (individual, towards centroid), Subdivide faces (watertight with neighbours), Merge at Center, Flip Normals | Implemented and tested (host) |
| Loop Cut (quad ring, position 0–1, consistent direction, watertight at ring ends) and Select Edge Loop (through valence-4 vertices) | Implemented and tested (host) |
| Non-destructive modifier stack: Mirror (X/Y/Z, welds on-plane vertices) and Array (count + offset); enable/disable, reorder, remove, Apply (bake), one undo step each | Implemented and tested (host); UI untested on device |
| Viewport/picking show the evaluated mesh; edit mode shows the base mesh as cage | Implemented and tested (host picking); rendering untested on device |
| Project format v4 (modifier stacks + subsurf/solidify params), v1/v2/v3 still load, corrupt modifier records rejected (superseded by v5 below) | Implemented and tested (host) |
| Delete vertices / edges / faces | Implemented and tested (host) |
| Edit-mode Move / Rotate / Scale of any selection about its median point | Implemented and tested (host math); drag gesture untested on device |
| Undo/redo restores mesh AND element selection | Implemented and tested (host) |
| Move / Rotate / Scale objects by drag, X/Y/Z constraint, one undo step per gesture | Implemented but untested on device |
| Numeric Location/Rotation/Scale fields (Properties) | Implemented but untested on device |
| Command undo/redo (add, delete, transform, mesh edit) | Implemented and tested (host) |
| Project format (atomic save, migration from older versions) | Implemented and tested (host) |
| Viewport: orbit/pan/zoom, view presets, frame selected, wireframe/solid, axis gizmo | Implemented but untested on device |
| Edit overlay rendering (vertex dots, selected edges, selected faces) | Implemented but untested on device (compiles against stub GL only) |
| Blender-style shell: menus, workspace tabs, Outliner, Properties, header, status bar | Implemented but untested on device |
| Bevel, knife, bridge, edge slide, region inset, proportional editing | Not started |
| Subdivision Surface modifier (Catmull-Clark, levels 1-4, boundary + non-manifold rules, quads out) | Implemented and tested (host); UI untested on device |
| Solidify modifier (even thickness, offset In/Center/Out, rim on open meshes, inner shell flipped) | Implemented and tested (host); UI untested on device |
| Viewport lighting: two-sided, camera headlight + Z-up hemisphere ambient + key light (back faces no longer near-black) | Implemented but untested on device (compiles against stub GL only) |
| UI cleanup: compact header (Solid/Wire text buttons, no clipped glyph), taller Properties panel with bottom padding | Implemented but untested on device |
| Triangulate modifier (ear clipping, concave n-gons OK, winding kept) | Implemented and tested (host); UI untested on device |
| Weld modifier + Mesh > Merge by Distance (selected vertices only, clusters collapse to centroid, degenerate faces dropped) | Implemented and tested (host); UI untested on device |
| Object ops: Rename (tap the name in Properties), Apply All Transforms / Apply Scale (negative scale flips winding), Origin to Geometry, all undoable | Implemented and tested (host); UI untested on device |
| Select > Linked in Edit Mode (whole connected island, vertex/edge/face modes) | Implemented and tested (host); UI untested on device |
| Dissolve Edges (Mesh menu; edge/vertex mode: selected edges, face mode: merges selected faces; chains become one polygon; straight leftover vertices removed) | Implemented and tested (host); UI untested on device |
| Limited Dissolve (Mesh menu; angle field, only the selected faces, removes vertices left straight) | Implemented and tested (host); UI untested on device |
| Separate Selection (Mesh menu; selected faces become a new object with the same transform and modifiers; one undo step) | Implemented and tested (host); UI untested on device |
| Dissolve Vertices (Mesh menu; faces around each selected vertex merge into one polygon, the vertex is removed; border vertices with 2 neighbours are removed from their faces) | Implemented and tested (host); UI untested on device |
| Dissolve Faces (Mesh menu; merges the selected neighbouring faces into one polygon per group) | Implemented and tested (host); UI untested on device |
| Separate Loose Parts (Object menu, Object Mode; one new object per connected part, first part stays in the original; same transform + modifiers; one undo step) | Implemented and tested (host); UI untested on device |
| Fill (Mesh menu; ONE closed loop of selected edges becomes a polygon, winding matches the neighbouring faces so holes close with outward normals) | Implemented and tested (host); UI untested on device |
| Bridge Edge Loops (Mesh menu; exactly two closed loops with the same edge count are joined by a ring of quads, second loop auto-aligned by start/direction) | Implemented and tested (host); UI untested on device |
| Bevel Vertices (Mesh menu + Bevel Width field; chamfer of vertices on closed manifold fans, width clamped to 0.49 x edge length; NOT edge bevel) | Implemented and tested (host); UI untested on device |
| Select More / Select Less (Select menu, Edit Mode; grows across edges / shrinks dropping border + open-edge vertices; all 3 modes) | Implemented and tested (host); UI untested on device |
| Join (Object menu, Object Mode; every other object merged into the active one, baked into its local space incl. rotation/scale/mirror; joined objects' modifiers dropped; one undo step) | Implemented and tested (host); UI untested on device |
| Properties > Modifiers: single "+ Add Modifier" dropdown instead of 9 buttons | Implemented, untested (Kotlin not compiled here) |
| Properties modifier cards: title on its own row (no more "Planar D/ecimate" wrapping); header mode button shortened to Object/Edit | Implemented, untested (Kotlin not compiled here) |
| Smooth modifier (Laplacian, factor 0-1, repeat 1-32) | Implemented and tested (host); UI untested on device |
| Simple Deform modifier (Twist / Bend / Taper / Stretch about X/Y/Z, extent-normalized) | Implemented and tested (host); UI untested on device |
| Planar Decimate modifier (Limited Dissolve over the whole mesh, angle limit) | Implemented and tested (host); UI untested on device |
| Project format v5 (Smooth/Deform/Decimate parameters); v1-v4 still load | Implemented and tested (host) |
| Other modifiers (Boolean, Bevel, collapse Decimate...) | Not started |
| Parenting, collections, multi-select objects, local orientation, ortho view | Not started |
| Timeline / animation | Not started (Phase 6) |
| Workspaces other than Layout/Modeling | Not started (tabs are disabled) |
| Materials, UV, sculpt, rig, render, import/export | Not started |

Known limits: Dissolve/Limited Dissolve merge a connected group of faces only when its outline is ONE simple loop; otherwise the whole group is left alone (so a closed surface that is entirely within the angle, or a ring of faces around a hole, is not merged), they never create holes, keep no vertex normals/UVs (none exist yet), and the straight-vertex cleanup only removes vertices with exactly two neighbours; Separate Selection copies the modifier stack to the new object and has no "by loose parts" mode yet; Smooth is plain Laplacian (shrinks open meshes and closed ones a little, no volume preservation, no vertex-group mask, no per-axis toggles); Simple Deform has no limits/lock/origin object, bend always curves towards the next axis (Z -> X), and its extent is that of the mesh at that point of the stack; Planar Decimate has no "delimit" options and does not triangulate; Weld does not remove faces that become duplicates of each other after merging, and keeps no selection; Apply Transform leaves the modifier stack untouched (Mirror axes etc. act on the baked mesh); Origin to Geometry uses the vertex median (not the bounding-box centre); Subdivision Surface has no creases, no separate viewport/render levels and no UV/normal smoothing (flat shading only); Solidify uses an averaged vertex normal with an even-thickness correction (clamped, so very sharp spikes thin out) and has no per-face thickness or rim material; Mirror has no clipping/mirror-object/bisect options and uses the object-local plane; Array only supports a constant offset; modifier stack is capped at 16; Apply is object-mode only and bakes modifiers 0..i; Loop Cut uses the first selected edge, one cut per operation, position from a numeric field (no interactive slide yet); edit snapshots copy the whole mesh per undo step (fine for small meshes); n-gon fan
triangulation assumes convex faces; Z-up like Blender (import converters will handle Y-up formats);
Inset is per-face (not region) and uses a centroid-relative amount; edge/face extrude distance comes from a
numeric field (the Move tool then drags the result); edit-mode rotate/scale use local axes; vertex/edge
occlusion test is O(faces) per candidate (fine for small meshes, needs a BVH later); loose vertices/edges
cannot exist (meshes are face-based, deleting faces removes orphan vertices).
