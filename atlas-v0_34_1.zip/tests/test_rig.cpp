// Rig core tests (0.31.0 armature/pose, 0.32.0 skinning). g++ -std=c++17 -Wall -Wextra -O1 tests/test_rig.cpp -o t_rig && ./t_rig
#include <cassert>
#include <cstdio>
#include "../app/src/main/cpp/core/rig.hpp"
using namespace atlas;
static bool nr(float a, float b, float e = 1e-4f) { return std::fabs(a - b) < e; }
static bool nv(Vec3 a, Vec3 b, float e = 1e-4f) { return nr(a.x, b.x, e) && nr(a.y, b.y, e) && nr(a.z, b.z, e); }

static Armature chain3() {   // root (0,0,0)->(0,0,1), mid ->(0,0,2), tip ->(0,0,3), all connected
    Armature a; int r = addBone(a, "Root", {0, 0, 0}, {0, 0, 1}); int m = extrudeBone(a, r, {0, 0, 2}, "Mid"); extrudeBone(a, m, {0, 0, 3}, "Tip"); return a;
}

int main() {
    // ---- matrices
    { Mat4 t = trsMatrix({1, 2, 3}, {10, 20, 30}, {2, 1, 0.5f}); Mat4 i = mmul(t, affineInverse(t)); for (int k = 0; k < 16; ++k) assert(nr(i.m[k], k % 5 == 0 ? 1.f : 0.f, 1e-4f));
      Mat4 z; z.m[0] = 0; z.m[5] = 0; z.m[10] = 0; Mat4 zi = affineInverse(z); assert(nr(zi.m[0], 1.f));   // singular -> identity
      Mat4 rz = rotFromEuler({0, 0, 90}); assert(nv(xfDir(rz, {1, 0, 0}), {0, 1, 0}));
      Mat4 ax = axisAngleMatrix({0, 0, 1}, 1.5707963f); assert(nv(xfDir(ax, {1, 0, 0}), {0, 1, 0}) && nv(xfDir(axisAngleMatrix({0, 0, 0}, 1.f), {1, 2, 3}), {1, 2, 3})); }
    // ---- rest frame: bone along +Y has identity basis; every bone frame is orthonormal; Y points head->tail; roll turns X/Z only
    { Bone b; b.head = {0, 0, 0}; b.tail = {0, 2, 0}; Mat4 r = boneRestMatrix(b); for (int k = 0; k < 16; ++k) assert(nr(r.m[k], k % 5 == 0 ? 1.f : 0.f));
      const Vec3 dirs[] = {{1, 0, 0}, {0, 0, 1}, {0, 0, -1}, {1, 1, 1}, {-2, 0.5f, 0.1f}};
      for (Vec3 d : dirs) for (float roll : {0.f, 37.f, 90.f}) { b.tail = d; b.roll = roll; Mat4 m = boneRestMatrix(b);
          Vec3 x = xfDir(m, {1, 0, 0}), y = xfDir(m, {0, 1, 0}), z = xfDir(m, {0, 0, 1});
          assert(nv(y, normalized(d)) && nr(length(x), 1.f) && nr(dot(x, y), 0.f) && nr(dot(x, z), 0.f) && nv(cross(x, y), z)); }
      b.tail = {0, 1, 0}; b.roll = 0; Vec3 x0 = xfDir(boneRestMatrix(b), {1, 0, 0}); b.roll = 90; Vec3 x1 = xfDir(boneRestMatrix(b), {1, 0, 0});
      assert(nv(x0, {1, 0, 0}) && nv(x1, {0, 0, 1}));   // positive roll turns the bone's X axis toward its Z axis
      b.roll = -90; assert(nv(xfDir(boneRestMatrix(b), {1, 0, 0}), {0, 0, -1})); }
    // ---- adding / extruding / validity
    { Armature a = chain3(); assert(a.bones.size() == 3 && validArmature(a) && a.bones[1].parent == 0 && a.bones[1].connected && nv(a.bones[1].head, a.bones[0].tail) && a.bones[2].parent == 1);
      Armature b = a; assert(addBone(a, "x", {0, 0, 0}, {0, 0, 0}) == -1 && addBone(a, "x", {0, 0, 0}, {NAN, 0, 1}) == -1 && addBone(a, "x", {0, 0, 0}, {1, 0, 0}, 9) == -1 && addBone(a, "x", {0, 0, 0}, {1, 0, 0}, -2) == -1
             && extrudeBone(a, 7, {0, 0, 5}) == -1 && extrudeBone(a, 2, a.bones[2].tail) == -1 && a.bones.size() == b.bones.size());
      int n = addBone(a, "Root", {1, 0, 0}, {1, 0, 1}); assert(n == 3 && a.bones[3].name == "Root.1" && validArmature(a));     // unique name
      int sp = addBone(a, "my bone", {0, 0, 0}, {1, 1, 0}); assert(a.bones[sp].name == "my_bone");
      Armature c = chain3(); c.bones[1].name = "Root"; assert(!validArmature(c)); c = chain3(); c.bones[0].parent = 2; assert(!validArmature(c)); c = chain3(); c.bones[0].parent = 0; assert(!validArmature(c)); }
    // ---- reparenting
    { Armature a = chain3(); assert(!setBoneParent(a, 0, 2, false) && !setBoneParent(a, 0, 1, false) && !setBoneParent(a, 1, 1, false) && !setBoneParent(a, 5, 0, false) && !setBoneParent(a, 1, 7, false));
      int s = addBone(a, "Side", {5, 0, 0}, {5, 0, 1}); assert(setBoneParent(a, s, 1, true) && a.bones[s].connected && nv(a.bones[s].head, a.bones[1].tail) && a.bones[s].parent == 1);
      assert(setBoneParent(a, s, -1, false) && a.bones[s].parent == -1 && !a.bones[s].connected && validArmature(a));
      // order independence: parent index higher than child
      Armature b; addBone(b, "A", {0, 0, 0}, {0, 0, 1}); addBone(b, "B", {3, 0, 0}, {3, 0, 1}); assert(setBoneParent(b, 0, 1, false) && validArmature(b) && boneOrder(b) == std::vector<int>({1, 0})); }
    // ---- rest pose = identity skin; FK propagation
    { Armature a = chain3(); for (const auto& m : skinMatrices(a)) for (int k = 0; k < 16; ++k) assert(nr(m.m[k], k % 5 == 0 ? 1.f : 0.f, 1e-5f)); assert(poseIsRest(a));
      // rotate Mid by 90 deg about its local X: the tip (at z=3) swings; Mid's head stays at z=1
      assert(setBonePose(a, 1, {}, {90, 0, 0}, {1, 1, 1}) && !poseIsRest(a));
      auto w = poseMatrices(a); assert(nv(xfPoint(w[1], {0, 0, 0}), {0, 0, 1}));
      Vec3 tipHead = xfPoint(w[2], {0, 0, 0}); assert(nv(tipHead, {0, 1, 1}));   // local X of a vertical bone is world -X; +90 deg swings the tip toward +Y
      assert(nr(length(tipHead - Vec3{0, 0, 1}), 1.f, 1e-4f));
      Vec3 tipEnd = xfPoint(w[2], {0, 1, 0}); assert(nr(length(tipEnd - Vec3{0, 0, 1}), 2.f, 1e-4f) && nr(tipEnd.z, 1.f, 1e-4f));   // the whole child chain is rigid
      assert(nv(xfPoint(w[0], {0, 1, 0}), {0, 0, 1}));     // parent untouched
      // translation channel is in the bone's own frame (Y = along the bone)
      Armature b = chain3(); setBonePose(b, 2, {0, 0.5f, 0}, {}, {1, 1, 1}); assert(nv(xfPoint(poseMatrices(b)[2], {0, 0, 0}), {0, 0, 2.5f}));
      // scale on the root scales children's positions with it
      Armature c = chain3(); setBonePose(c, 0, {}, {}, {1, 2, 1}); assert(nv(xfPoint(poseMatrices(c)[1], {0, 0, 0}), {0, 0, 2}) && nv(xfPoint(poseMatrices(c)[2], {0, 0, 0}), {0, 0, 4}));   // Y scale on the root stretches the chain along the bone
      assert(!setBonePose(c, 0, {}, {}, {0, 1, 1}) && !setBonePose(c, 0, {NAN, 0, 0}, {}, {1, 1, 1}) && !setBonePose(c, 9, {}, {}, {1, 1, 1}));
      resetPose(a); assert(poseIsRest(a)); }
    // ---- delete: children re-parent, indices shift, map is right
    { Armature a = chain3(); std::vector<int> map; assert(deleteBone(a, 1, &map) && a.bones.size() == 2 && map == std::vector<int>({0, -1, 1}) && a.bones[1].name == "Tip" && a.bones[1].parent == 0 && !a.bones[1].connected && validArmature(a));
      assert(!deleteBone(a, 5) && !deleteBone(a, -1) && deleteBone(a, 0) && a.bones.size() == 1 && a.bones[0].parent == -1 && validArmature(a)); }
    // ---- rename / rest editing
    { Armature a = chain3(); assert(renameBone(a, 0, "Hip") && a.bones[0].name == "Hip" && !renameBone(a, 0, "Tip") && !renameBone(a, 0, "") && renameBone(a, 0, "Hip") && !renameBone(a, 9, "q"));
      assert(setBoneRest(a, 0, {0, 0, 0}, {0, 1, 1}, 15.f) && nv(a.bones[1].head, {0, 1, 1}) && nr(a.bones[0].roll, 15.f) && !setBoneRest(a, 0, {1, 1, 1}, {1, 1, 1}, 0.f) && !setBoneRest(a, 0, {0, 0, 0}, {NAN, 0, 0}, 0.f));
      assert(!setBoneRest(a, 0, {0, 0, 0}, a.bones[1].tail, 0.f)); }     // would collapse the connected child
    // ---- mirror
    { Armature a; int r = addBone(a, "Spine", {0, 0, 1}, {0, 0, 2}); int u = extrudeBone(a, r, {1, 0, 2.5f}, "Arm.L"); extrudeBone(a, u, {2, 0, 2.5f}, "Hand.L");
      a.bones[u].roll = 20.f; auto nw = mirrorBonesX(a, {1, 2}); assert(nw.size() == 2 && a.bones.size() == 5 && a.bones[3].name == "Arm.R" && a.bones[4].name == "Hand.R");
      assert(nv(a.bones[3].tail, {-1, 0, 2.5f}) && nv(a.bones[3].head, {0, 0, 2}) && a.bones[3].parent == 0 && a.bones[3].connected && a.bones[4].parent == 3 && a.bones[4].connected && nr(a.bones[3].roll, -20.f) && validArmature(a));
      assert(mirrorBonesX(a, {99, -1}).empty() && a.bones.size() == 5);
      auto nm = mirrorBonesX(a, {0}); assert(a.bones[nm[0]].name == "Spine.mirror");
      assert(flipSideName("Leg_L") == "Leg_R" && flipSideName("Leg.r") == "Leg.l" && flipSideName("LeftFoot") == "RightFoot" && flipSideName("Head").empty()); }
    // ---- skin: normalize, set weight, auto weights
    { Influence in; in.bone[0] = 2; in.w[0] = 3; in.bone[1] = 5; in.w[1] = 1; in.bone[2] = 7; in.w[2] = -1; normalizeInfluence(in);
      assert(in.bone[0] == 2 && nr(in.w[0], 0.75f) && in.bone[1] == 5 && nr(in.w[1], 0.25f) && in.bone[2] == -1 && nr(weightSum(in), 1.f));
      Skin s; s.v.resize(2); s.v[0] = in;
      assert(setVertexWeight(s, 0, 5, 0.5f) && nr(vertexWeight(s, 0, 5), 0.5f) && nr(vertexWeight(s, 0, 2), 0.5f));
      assert(setVertexWeight(s, 0, 9, 0.2f) && nr(weightSum(s.v[0]), 1.f) && nr(vertexWeight(s, 0, 9), 0.2f) && nr(vertexWeight(s, 0, 5), 0.4f));
      assert(setVertexWeight(s, 0, 9, 0.f) && vertexWeight(s, 0, 9) == 0.f && nr(weightSum(s.v[0]), 1.f));
      assert(setVertexWeight(s, 1, 3, 1.f) && nr(vertexWeight(s, 1, 3), 1.f) && !setVertexWeight(s, 2, 3, 1.f) && !setVertexWeight(s, 0, -1, 1.f) && !setVertexWeight(s, 0, 3, 1.5f) && !setVertexWeight(s, 0, 3, NAN));
      Skin f; f.v.resize(1); for (int b = 0; b < 4; ++b) { f.v[0].bone[b] = b; f.v[0].w[b] = 0.25f; } assert(setVertexWeight(f, 0, 8, 0.4f) && nr(vertexWeight(f, 0, 8), 0.4f) && nr(weightSum(f.v[0]), 1.f)); }   // 5th bone replaces the weakest
    { Armature a = chain3(); Mesh m; m.v = {{0.1f, 0, 0.5f}, {0.1f, 0, 1.5f}, {0.1f, 0, 2.5f}, {0.1f, 0, 1.0f}}; Skin s;
      assert(autoWeights(m, a, Mat4{}, s) && s.v.size() == 4 && validSkin(s, 3));
      for (const auto& in : s.v) assert(nr(weightSum(in), 1.f, 1e-4f));
      assert(s.v[0].bone[0] == 0 && s.v[1].bone[0] == 1 && s.v[2].bone[0] == 2 && s.v[0].w[0] > 0.6f);
      assert(nr(vertexWeight(s, 3, 0), vertexWeight(s, 3, 1), 1e-3f));      // joint between root and mid: equal share
      Armature none = a; for (auto& b : none.bones) b.deform = false; Skin keep = s; assert(!autoWeights(m, none, Mat4{}, s) && s.v.size() == keep.v.size());
      Mesh empty; assert(!autoWeights(empty, a, Mat4{}, s));
      a.bones[1].deform = false; assert(autoWeights(m, a, Mat4{}, s) && vertexWeight(s, 1, 1) == 0.f);
      // mesh-to-armature transform is honoured: shift the mesh by +10 in x and give the inverse as toArm
      Armature b = chain3(); Mesh mm = m; for (auto& v : mm.v) v.x += 10.f; Mat4 t = trsMatrix({-10, 0, 0}, {}, {1, 1, 1}); Skin s2; assert(autoWeights(mm, b, t, s2) && s2.v[0].bone[0] == 0 && s2.v[2].bone[0] == 2); }
    // ---- remap after delete
    { Skin s; s.v.resize(1); s.v[0].bone[0] = 1; s.v[0].w[0] = 0.5f; s.v[0].bone[1] = 2; s.v[0].w[1] = 0.5f;
      remapSkin(s, {0, -1, 1}); assert(s.v[0].bone[0] == 1 && nr(s.v[0].w[0], 1.f) && s.v[0].bone[1] == -1);
      Skin e; e.v.resize(1); e.v[0].bone[0] = 1; e.v[0].w[0] = 1.f; remapSkin(e, {0, -1}); assert(e.v[0].bone[0] == -1 && weightSum(e.v[0]) == 0.f);
      assert(validSkin(s, 2) && !validSkin(s, 1) && validSkin(e, 1)); }
    // ---- LBS: neutral pose keeps the mesh; rotating a bone moves only its vertices; blending is a convex mix; toArm is honoured
    { Armature a = chain3(); Mesh m; m.v = {{0.2f, 0, 0.5f}, {0.2f, 0, 1.5f}, {0.2f, 0, 2.5f}}; m.f = {{0, 1, 2}}; Skin s; assert(autoWeights(m, a, Mat4{}, s));
      Mesh same = skinMesh(m, s, a, Mat4{}); for (size_t i = 0; i < m.v.size(); ++i) assert(nv(same.v[i], m.v[i], 1e-5f));
      setBonePose(a, 2, {}, {90, 0, 0}, {1, 1, 1});   // bend the tip bone about its own head (0,0,2)
      Mesh bent = skinMesh(m, s, a, Mat4{}); assert(nv(bent.v[0], m.v[0], 1e-2f) && nr(bent.v[2].z, 2.f, 0.1f) && !nv(bent.v[2], m.v[2], 0.2f));
      assert(bent.f == m.f);
      for (size_t i = 0; i < 3; ++i) assert(length(bent.v[i] - Vec3{0.2f, 0, 2.f}) <= length(m.v[i] - Vec3{0.2f, 0, 2.f}) + 1e-3f);   // rotation about the pivot never moves a point away from it...
      Skin hard; hard.v.resize(3); hard.v[0].bone[0] = 0; hard.v[0].w[0] = 1; hard.v[1].bone[0] = 1; hard.v[1].w[0] = 1; hard.v[2].bone[0] = 2; hard.v[2].w[0] = 1;
      Mesh hb = skinMesh(m, hard, a, Mat4{}); assert(nv(hb.v[0], m.v[0], 1e-5f) && nv(hb.v[1], m.v[1], 1e-5f) && nr(hb.v[2].z, 2.f, 1e-4f) && nr(length(hb.v[2] - Vec3{0, 0, 2}), length(m.v[2] - Vec3{0, 0, 2}), 1e-4f));
      Skin half; half.v.resize(1); half.v[0].bone[0] = 1; half.v[0].w[0] = 0.5f; half.v[0].bone[1] = 2; half.v[0].w[1] = 0.5f; Mesh one; one.v = {{0.2f, 0, 2.5f}};
      Mesh mix = skinMesh(one, half, a, Mat4{}); Mesh pure = skinMesh(one, hard, a, Mat4{}); (void)pure; Skin h2; h2.v.resize(1); h2.v[0].bone[0] = 2; h2.v[0].w[0] = 1; Mesh full = skinMesh(one, h2, a, Mat4{});
      assert(nv(mix.v[0], (one.v[0] + full.v[0]) * 0.5f, 1e-4f));      // 50/50 between the untouched bone (rest position) and the rotated one
      // unbound / mismatched / empty
      Skin wrong; wrong.v.resize(5); assert(skinMesh(m, wrong, a, Mat4{}).v.size() == 3 && nv(skinMesh(m, wrong, a, Mat4{}).v[1], m.v[1]));
      Armature none; assert(nv(skinMesh(m, s, none, Mat4{}).v[1], m.v[1]));
      Skin zero; zero.v.resize(3); assert(nv(skinMesh(m, zero, a, Mat4{}).v[2], m.v[2]));   // no influence -> stays
      // armature moved in the world: mesh local -> armature space via toArm; a neutral pose still gives identity, a bent one is consistent
      Mat4 toArm = trsMatrix({0, 0, 5}, {0, 0, 0}, {1, 1, 1}); Mesh m2 = m; for (auto& v : m2.v) v.z -= 5.f; Skin s3; assert(autoWeights(m2, a, toArm, s3) && s3.v[0].bone[0] == 0);
      Mesh b2 = skinMesh(m2, s3, a, toArm); for (size_t i = 0; i < 3; ++i) assert(nv(xfPoint(toArm, b2.v[i]), bent.v[i], 1e-4f)); }
    puts("rig tests passed"); return 0;
}
