#include <array>
#include <cassert>
#include <limits>
#include <map>
#include <set>
#include <cstdio>
#include "../app/src/main/cpp/core/project_io.hpp"
using namespace atlas;

static void checkOutward(const Mesh& m) {
    assert(validMesh(m));
    for (const auto& fc : m.f) {
        Vec3 c; for (int i : fc) c = c + m.v[i]; c = c * (1.f / fc.size());
        assert(dot(faceNormal(m, fc), c) > 0);  // normals point away from the origin
    }
}

// ---- helpers for 0.7.0 tests ----
static double signedVolume(const Mesh& m) {   // divergence theorem over a fan triangulation (positive when normals point outward)
    double vol = 0;
    for (const auto& fc : m.f) for (size_t k = 1; k + 1 < fc.size(); ++k) {
        const Vec3 &a = m.v[fc[0]], &b = m.v[fc[k]], &c = m.v[fc[k + 1]];
        vol += ((double)a.x * ((double)b.y * c.z - (double)b.z * c.y) - (double)a.y * ((double)b.x * c.z - (double)b.z * c.x) + (double)a.z * ((double)b.x * c.y - (double)b.y * c.x)) / 6.0;
    }
    return vol;
}
static bool closedManifold(const Mesh& m, int* edgesOut = nullptr) {   // every directed edge appears once and has its reverse
    std::map<std::pair<int, int>, int> d;
    for (const auto& fc : m.f) for (size_t k = 0; k < fc.size(); ++k) ++d[{fc[k], fc[(k + 1) % fc.size()]}];
    int edges = 0;
    for (auto& kv : d) { if (kv.second != 1 || !d.count({kv.first.second, kv.first.first})) return false; ++edges; }
    if (edgesOut) *edgesOut = edges / 2;
    return true;
}
static bool near(float a, float b, float e = 1e-4f) { return std::fabs(a - b) < e; }

int main() {
    // primitives
    checkOutward(makeCube()); checkOutward(makeCylinder()); checkOutward(makeUVSphere());
    assert(makeCube().v.size() == 8 && makeCube().f.size() == 6);

    // object add / transform / undo / redo
    Scene s; uint32_t a = addPrimitive(s, 0);
    assert(s.objects.size() == 1 && s.selected == a && s.objects[0].name == "Cube");
    uint32_t b = addPrimitive(s, 0); assert(s.find(b)->name == "Cube.001");
    Xf x = getXf(*s.find(a)); x.pos[0] = 3; x.rot[2] = 90; assert(s.selected == b);
    s.selected = a; assert(setObjectTransform(s, x));
    assert(s.find(a)->pos[0] == 3); assert(s.undo()); assert(s.find(a)->pos[0] == 0); assert(s.redo()); assert(s.find(a)->rot[2] == 90);

    // picking respects rotation/scale/translation
    Scene p; uint32_t c1 = addPrimitive(p, 0); uint32_t c2 = addPrimitive(p, 0);
    p.find(c2)->pos[1] = -6;   // behind c1 along the ray from +y? ray goes -y from y=+10
    Vec3 org{0, 10, 0}, dir{0, -1, 0};
    assert(pickObject(p, org, dir) == c1);
    Vec3 miss{5, 10, 0}; assert(pickObject(p, miss, dir) == 0);
    p.find(c1)->scale[0] = 6; assert(pickObject(p, miss, dir) == c1);  // scaled object now hit

    // edit mode: extrude a face, undo restores exact mesh
    Scene e; uint32_t id = addPrimitive(e, 0); assert(setEditMode(e, true)); assert(setSelectMode(e, 2));
    Mesh original = e.find(id)->mesh;
    int topFace = pickActiveFace(e, Vec3{0, 0, 10}, Vec3{0, 0, -1}); assert(topFace == 1);
    e.toggleFace(topFace);
    assert(extrudeSelected(e, 0.5f));
    const Mesh& m = e.find(id)->mesh;
    assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m));
    for (const auto& fc : m.f) { Vec3 n = faceNormal(m, fc); assert(length(n) > 0.99f); }
    float maxz = -9; for (auto& v : m.v) maxz = std::max(maxz, v.z); assert(std::fabs(maxz - 1.5f) < 1e-5f);
    assert(e.undo()); assert(sameMesh(e.find(id)->mesh, original));
    assert(e.redo()); assert(e.find(id)->mesh.f.size() == 10);
    assert(deleteSelection(e)); assert(e.find(id)->mesh.f.size() == 9 && validMesh(e.find(id)->mesh));
    assert(e.undo()); assert(e.find(id)->mesh.f.size() == 10);

    // undoing the creation while in edit mode leaves a consistent state
    Scene g; addPrimitive(g, 3); setEditMode(g, true); g.undo();
    assert(g.objects.empty() && !g.editMode && g.selected == 0);

    // delete / duplicate
    Scene d; addPrimitive(d, 2); assert(duplicateSelected(d) != 0 && d.objects.size() == 2);
    assert(deleteSelectedObject(d) && d.objects.size() == 1); assert(d.undo() && d.objects.size() == 2);

    // project round trip (v2)
    assert(saveProject(e, "/tmp/atlas_t2.atlas"));
    Scene q; assert(loadProject(q, "/tmp/atlas_t2.atlas"));
    assert(q.objects.size() == 1 && sameMesh(q.objects[0].mesh, e.objects[0].mesh) && q.nextId == e.nextId);

    // v1 migration + invalid files leave the scene untouched
    FILE* f1 = fopen("/tmp/atlas_v1.atlas", "w"); fputs("ATLAS 1\nnext 2\ncube 1 1 2 3 1 1 1\nend\n", f1); fclose(f1);
    Scene m1; assert(loadProject(m1, "/tmp/atlas_v1.atlas") && m1.objects.size() == 1);
    assert(m1.objects[0].pos[0] == 1 && m1.objects[0].pos[1] == -3 && m1.objects[0].pos[2] == 2);
    FILE* f2 = fopen("/tmp/atlas_bad.atlas", "w"); fputs("ATLAS 2\nnext 3\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 9\nend\n", f2); fclose(f2);
    Scene r; addPrimitive(r, 0); std::string err;
    assert(!loadProject(r, "/tmp/atlas_bad.atlas", &err)); assert(r.objects.size() == 1);
    // ================= v0.3: element selection and new modeling ops =================
    puts("v0.3 tests...");
    // closed-manifold check: every directed edge appears exactly once and so does its reverse
    auto closed = [](const Mesh& m) {
        std::map<std::pair<int, int>, int> c;
        for (const auto& fc : m.f) for (size_t i = 0; i < fc.size(); ++i) c[{fc[i], fc[(i + 1) % fc.size()]}]++;
        for (auto& kv : c) if (kv.second != 1 || c.count({kv.first.second, kv.first.first}) != 1) return false;
        return true;
    };
    auto totalArea = [](const Mesh& m) { float a = 0; for (auto& fc : m.f) a += faceArea(m, fc); return a; };
    assert(closed(makeCube()) && closed(makeCylinder()) && closed(makeUVSphere()));
    assert(std::fabs(totalArea(makeCube()) - 24.f) < 1e-4f);

    // selection mode conversion: face -> vertex -> edge -> face round trip on the cube's top face
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(setSelectMode(c, 0) && c.sel.mode == 0 && c.sel.v == std::set<int>({4, 5, 6, 7}) && c.sel.f.empty());
        assert(setSelectMode(c, 1) && c.sel.e.size() == 4 && c.sel.v.empty());
        assert(setSelectMode(c, 2) && c.sel.f == std::set<int>({1}));
        // two lone vertices are not enough for a face
        setSelectMode(c, 0); c.sel.v = {4, 5}; assert(setSelectMode(c, 2) && c.sel.f.empty());
        // invert / select all
        setSelectMode(c, 2); c.sel.clearSets(); selectAllActive(c); assert(c.sel.f.size() == 6);
        invertActive(c); assert(c.sel.f.empty()); (void)cid;
    }

    // picking vertices / edges with occlusion
    {
        Scene c; addPrimitive(c, 0); setEditMode(c, true);
        float tol = 0.02f; Vec3 eye{3, 3, 3};
        assert(pickActiveVertex(c, eye, normalized(Vec3{-1, -1, -1}), tol) == 6);       // front corner, not the hidden one behind it
        assert(pickActiveVertex(c, eye, normalized(Vec3{-1, 0.2f, -1}), tol) == -1);      // empty space
        Edge ed; Vec3 e2{0, -5, 5};
        assert(pickActiveEdge(c, e2, normalized(Vec3{0, 4, -4}), tol, &ed) && ed == mkEdge(4, 5));
        assert(!pickActiveEdge(c, Vec3{0, -5, 5}, normalized(Vec3{0, 1, 0.2f}), 0.001f, &ed));
    }

    // extrude edges of a plane (boundary edge) -> strip of quads, new edge selected, exact undo
    {
        Scene c; uint32_t pid = addPrimitive(c, 1); setEditMode(c, true); setSelectMode(c, 1);
        Mesh orig = c.find(pid)->mesh; c.toggleEdge(mkEdge(0, 1));
        assert(extrudeSelected(c, 0.5f));
        const Mesh& m = c.find(pid)->mesh;
        assert(m.v.size() == 6 && m.f.size() == 2 && validMesh(m));
        assert(m.v[4].z == 0.5f && m.v[5].z == 0.5f && c.sel.e.size() == 1 && *c.sel.e.begin() == mkEdge(4, 5));
        assert(c.undo() && sameMesh(c.find(pid)->mesh, orig) && c.sel.e.count(mkEdge(0, 1)) == 1);  // selection restored too
        assert(c.redo() && c.find(pid)->mesh.f.size() == 2);
        assert(!extrudeSelected(c, 0.f));
    }
    // extrude from vertex mode: 4 verts of a face extrude as a face; 2 verts extrude as an edge
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0);
        c.sel.v = {4, 5, 6, 7}; assert(extrudeSelected(c, 1.f));
        const Mesh& m = c.find(cid)->mesh; assert(m.v.size() == 12 && m.f.size() == 10 && closed(m) && c.sel.v.size() == 4);
        float maxz = -9; for (auto& v : m.v) maxz = std::max(maxz, v.z); assert(std::fabs(maxz - 2.f) < 1e-5f);
        setSelectMode(c, 0); c.sel.v = {0, 1}; assert(extrudeSelected(c, 0.3f)); assert(c.find(cid)->mesh.f.size() == 11);
    }
    // delete vertices / edges
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0);
        c.sel.v = {0}; assert(deleteSelection(c)); const Mesh& m = c.find(cid)->mesh;   // 3 faces touch a corner
        assert(m.f.size() == 3 && validMesh(m) && c.sel.v.empty()); assert(c.undo() && c.find(cid)->mesh.f.size() == 6 && c.sel.v.count(0));
        setSelectMode(c, 1); c.sel.clearSets(); c.toggleEdge(mkEdge(0, 1)); assert(deleteSelection(c) && c.find(cid)->mesh.f.size() == 4);
    }
    // inset: ring of quads, inner face keeps its index and orientation, area drops as expected
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(!insetSelected(c, 0.f) && !insetSelected(c, 1.f));
        assert(insetSelected(c, 0.5f)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m) && closed(m) && c.sel.f == std::set<int>({1}));
        assert(std::fabs(faceArea(m, m.f[1]) - 1.f) < 1e-5f);           // 2x2 face scaled by 0.5 -> 1x1
        assert(std::fabs(totalArea(m) - (20.f + 1.f + 3.f)) < 1e-4f);   // 5 untouched faces (20) + inner (1) + ring (4-1=3)
        assert(dot(faceNormal(m, m.f[1]), Vec3{0, 0, 1}) > 0.99f);
    }
    // subdivide: watertight, area preserved, neighbours get the new midpoints
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(subdivideSelected(c)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 13 && m.f.size() == 9 && validMesh(m) && closed(m) && c.sel.f.size() == 4);
        assert(std::fabs(totalArea(m) - 24.f) < 1e-4f);
        for (const auto& fc : m.f) assert(dot(faceNormal(m, fc), Vec3{0, 0, 0}) == 0 && length(faceNormal(m, fc)) > 0.99f);
        assert(subdivideSelected(c) && closed(c.find(cid)->mesh) && std::fabs(totalArea(c.find(cid)->mesh) - 24.f) < 1e-3f);  // repeatable
        assert(c.undo() && c.undo() && sameMesh(c.find(cid)->mesh, makeCube()));
    }
    // merge at center collapses a face into a vertex (cube -> pyramid-like, 5 verts / 5 faces)
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0); c.sel.v = {4, 5, 6, 7};
        assert(mergeSelectedAtCenter(c)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 5 && m.f.size() == 5 && validMesh(m) && closed(m) && c.sel.v.size() == 1);
        int tip = *c.sel.v.begin(); assert(std::fabs(m.v[tip].z - 1.f) < 1e-6f && std::fabs(m.v[tip].x) < 1e-6f);
        assert(!mergeSelectedAtCenter(c));   // one vertex is nothing to merge
    }
    // flip normals
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(flipSelectedFaces(c)); assert(dot(faceNormal(c.find(cid)->mesh, c.find(cid)->mesh.f[1]), Vec3{0, 0, 1}) < -0.99f);
        assert(c.undo() && sameMesh(c.find(cid)->mesh, makeCube()));
    }
    // edit-mode transforms about the pivot
    {
        Mesh m = makeCube(); std::vector<char> top(8, 0); for (int i = 4; i < 8; ++i) top[i] = 1;
        assert(moveVertices(m, top, Vec3{0, 0, 2}) && m.v[4].z == 3.f && m.v[0].z == -1.f);
        assert(scaleVertices(m, top, Vec3{0.5f, 0.5f, 1.f}) && std::fabs(m.v[6].x - 0.5f) < 1e-6f && m.v[6].z == 3.f);
        assert(rotateVertices(m, top, 2, 90.f) && std::fabs(m.v[6].x + 0.5f) < 1e-5f && std::fabs(m.v[6].y - 0.5f) < 1e-5f);
        std::vector<char> none(8, 0); assert(!moveVertices(m, none, Vec3{1, 0, 0}) && !rotateVertices(m, none, 0, 10.f));
    }
    // history keeps selection valid after the object is removed
    {
        Scene c; addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0); c.sel.v = {0, 1};
        c.undo(); assert(c.sel.v.empty() && !c.editMode);
    }

    // ================= v0.4: loop cut + edge loops =================
    puts("v0.4 tests...");
    {   // cube: ring of 4 quads is cut at x=-0.5 for EVERY ring edge (direction stays consistent)
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 1); c.toggleEdge(mkEdge(0, 1));
        assert(!loopCutSelected(c, 0.f) && !loopCutSelected(c, 1.f));
        assert(loopCutSelected(c, 0.25f)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m) && closed(m) && c.sel.e.size() == 4);
        for (size_t i = 8; i < 12; ++i) assert(std::fabs(m.v[i].x + 0.5f) < 1e-6f);
        assert(std::fabs(totalArea(m) - 24.f) < 1e-4f);
        assert(c.undo() && sameMesh(c.find(cid)->mesh, makeCube()) && c.sel.e.count(mkEdge(0, 1)));
        // vertex mode: two verts forming an edge work too
        setSelectMode(c, 0); c.sel.clearSets(); c.sel.v = {0, 1}; assert(loopCutSelected(c, 0.5f) && c.sel.v.size() == 4);
    }
    {   // plane: open ring of one quad
        Scene c; uint32_t pid = addPrimitive(c, 1); setEditMode(c, true); setSelectMode(c, 1); c.toggleEdge(mkEdge(0, 1));
        assert(loopCutSelected(c, 0.5f) && c.find(pid)->mesh.v.size() == 6 && c.find(pid)->mesh.f.size() == 2);
    }
    {   // sphere: closed ring around the body, and an open ring ending in cap triangles stays watertight
        Scene c; uint32_t sid = addPrimitive(c, 3); setEditMode(c, true); setSelectMode(c, 1);
        c.toggleEdge(mkEdge(1, 17)); assert(loopCutSelected(c, 0.5f)); assert(c.find(sid)->mesh.v.size() == makeUVSphere().v.size() + 16);
        assert(closed(c.find(sid)->mesh) && std::fabs(totalArea(c.find(sid)->mesh) - totalArea(makeUVSphere())) < 1e-3f);
        Scene d; uint32_t did = addPrimitive(d, 3); setEditMode(d, true); setSelectMode(d, 1);
        d.toggleEdge(mkEdge(1, 2)); assert(loopCutSelected(d, 0.5f)); assert(closed(d.find(did)->mesh) && validMesh(d.find(did)->mesh));
    }
    {   // edge loops on a 4x4 grid (plane subdivided twice): centre line has 4 edges; corner-ish edge stays short
        Scene c; uint32_t pid = addPrimitive(c, 1); setEditMode(c, true); setSelectMode(c, 2);
        selectAllActive(c); assert(subdivideSelected(c)); assert(subdivideSelected(c));
        const Mesh& m = c.find(pid)->mesh; assert(m.f.size() == 16);
        setSelectMode(c, 1); c.sel.clearSets();
        Edge pick{-1, -1};
        for (const auto& e : uniqueEdges(m)) if (std::fabs(m.v[e.first].y) < 1e-6f && std::fabs(m.v[e.second].y) < 1e-6f) { pick = e; break; }
        assert(pick.first >= 0); c.toggleEdge(pick);
        assert(selectLoopActive(c) && c.sel.e.size() == 4);
        for (const auto& e : c.sel.e) assert(std::fabs(m.v[e.first].y) < 1e-6f && std::fabs(m.v[e.second].y) < 1e-6f);
        c.sel.clearSets(); assert(!selectLoopActive(c));
    }
    {   // cube corner edges have valence 3, so the loop is the single edge
        Scene c; addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 1); c.toggleEdge(mkEdge(0, 1));
        assert(selectLoopActive(c) && c.sel.e.size() == 1);
    }

    // ================= v0.5: modifier stack =================
    puts("v0.5 tests...");
    {   // mirror: open half box (cube shifted to x in [0,2] without its x=0 face) becomes a closed 4x2x2 box
        Scene c; uint32_t id = addPrimitive(c, 0); Object* o = c.find(id);
        for (auto& v : o->mesh.v) v.x += 1.f;
        assert(deleteFaces(o->mesh, {4}));          // face {0,4,7,3} lies on x=0
        o->meshRev = nextRev();
        assert(o->mesh.f.size() == 5 && o->mesh.v.size() == 8);
        assert(addModifier(c, kMirror)); assert(c.find(id)->mods.size() == 1);
        const Mesh& d = displayMesh(*c.find(id));
        assert(d.v.size() == 12 && d.f.size() == 10 && validMesh(d) && closed(d) && std::fabs(totalArea(d) - 40.f) < 1e-4f);
        float mn = 9; for (auto& v : d.v) mn = std::min(mn, v.x); assert(std::fabs(mn + 2.f) < 1e-6f);
        for (const auto& fc : d.f) { Vec3 cen; for (int i : fc) cen = cen + d.v[i]; cen = cen * (1.f / fc.size()); assert(dot(faceNormal(d, fc), cen) > 0); }
        assert(c.find(id)->mesh.v.size() == 8);     // base mesh untouched (non destructive)
        // toggling off shows the base mesh again; on again re-evaluates
        assert(toggleModifier(c, 0)); assert(displayMesh(*c.find(id)).f.size() == 5);
        assert(toggleModifier(c, 0)); assert(displayMesh(*c.find(id)).f.size() == 10);
        // editing the base mesh updates the evaluated mesh
        c.find(id)->mesh.v[1].z += 1.f; c.find(id)->meshRev = nextRev(); assert(displayMesh(*c.find(id)).v.size() == 12);
        // apply bakes the result into the base mesh and undo restores both
        Mesh baseBefore = c.find(id)->mesh;
        assert(applyModifierAt(c, 0)); assert(c.find(id)->mods.empty() && c.find(id)->mesh.f.size() == 10 && closed(c.find(id)->mesh));
        assert(c.undo()); assert(c.find(id)->mods.size() == 1 && sameMesh(c.find(id)->mesh, baseBefore));
        assert(c.redo() && c.find(id)->mesh.f.size() == 10);
    }
    {   // array: 3 copies, offset 3 along X; stack order matters; limits
        Scene c; uint32_t id = addPrimitive(c, 0); assert(addModifier(c, kArray));
        Modifier m = c.find(id)->mods[0]; m.count = 3; m.offset[0] = 3.f; assert(setModifier(c, 0, m));
        const Mesh& d = displayMesh(*c.find(id));
        assert(d.v.size() == 24 && d.f.size() == 18 && validMesh(d) && closed(d) && std::fabs(totalArea(d) - 72.f) < 1e-3f);
        float mx = -9; for (auto& v : d.v) mx = std::max(mx, v.x); assert(std::fabs(mx - 7.f) < 1e-6f);
        // objects are pickable where the arrayed copies are, not only where the base mesh is
        assert(pickObject(c, Vec3{6, 10, 0}, Vec3{0, -1, 0}) == id);
        c.find(id)->mods[0].enabled = false; c.find(id)->modsRev = nextRev(); assert(pickObject(c, Vec3{6, 10, 0}, Vec3{0, -1, 0}) == 0);
        c.find(id)->mods[0].enabled = true; c.find(id)->modsRev = nextRev();
        Modifier bad = m; bad.count = 0; assert(!setModifier(c, 0, bad)); bad.count = 65; assert(!setModifier(c, 0, bad));
        assert(addModifier(c, kMirror) && moveModifier(c, 1, -1) && c.find(id)->mods[0].type == kMirror && !moveModifier(c, 0, -1));
        assert(removeModifier(c, 0) && c.find(id)->mods.size() == 1 && !removeModifier(c, 5));
        assert(c.undo() && c.undo() && c.undo() && c.find(id)->mods.size() == 1);   // back to the first array state (count 2)
        assert(!applyModifierAt(c, 3));
    }
    {   // project v3 round trip, v2 files still load, corrupt modifiers are rejected
        Scene c; uint32_t id = addPrimitive(c, 0); addModifier(c, kArray); Modifier m = c.find(id)->mods[0]; m.count = 4; m.offset[1] = 2.5f; setModifier(c, 0, m);
        addModifier(c, kMirror); toggleModifier(c, 1);
        assert(saveProject(c, "/tmp/atlas_t3.atlas"));
        Scene q; assert(loadProject(q, "/tmp/atlas_t3.atlas") && q.objects[0].mods.size() == 2);
        assert(q.objects[0].mods[0].count == 4 && q.objects[0].mods[0].offset[1] == 2.5f && !q.objects[0].mods[1].enabled && q.objects[0].mods[1].type == kMirror);
        assert(displayMesh(q.objects[0]).f.size() == 24);
        FILE* f = fopen("/tmp/atlas_v2.atlas", "w"); fputs("ATLAS 2\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nend\n", f); fclose(f);
        Scene o2; assert(loadProject(o2, "/tmp/atlas_v2.atlas") && o2.objects[0].mods.empty());
        f = fopen("/tmp/atlas_badmod.atlas", "w"); fputs("ATLAS 3\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nmods 1\nmod 1 1 0 0.001 0 1 0 0\nend\n", f); fclose(f);
        Scene keep; addPrimitive(keep, 0); std::string err;
        assert(!loadProject(keep, "/tmp/atlas_badmod.atlas", &err) && keep.objects.size() == 1);
        f = fopen("/tmp/atlas_nomods.atlas", "w"); fputs("ATLAS 3\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nend\n", f); fclose(f);
        assert(!loadProject(keep, "/tmp/atlas_nomods.atlas", &err) && keep.objects.size() == 1);
    }

    {   // 0.7.0: Catmull-Clark subdivision surface
        Mesh cu = makeCube(); Modifier sm; sm.type = kSubsurf; sm.levels = 1;
        Mesh l1 = applyModifier(cu, sm); int e1 = 0;
        assert(l1.v.size() == 26 && l1.f.size() == 24 && closedManifold(l1, &e1) && (int)l1.v.size() - e1 + (int)l1.f.size() == 2);
        for (const auto& fc : l1.f) assert(fc.size() == 4);
        bool foundCorner = false, foundEdge = false;
        for (const auto& v : l1.v) { if (near(v.x, 5.f / 9) && near(v.y, 5.f / 9) && near(v.z, 5.f / 9)) foundCorner = true; if (near(v.x, .75f) && near(v.y, .75f) && near(v.z, 0)) foundEdge = true; }
        assert(foundCorner && foundEdge);   // corner rule (F+2R+(n-3)P)/n and edge rule (A+B+F1+F2)/4 checked against hand-computed values
        sm.levels = 2; Mesh l2 = applyModifier(cu, sm); e1 = 0;
        assert(l2.f.size() == 96 && l2.v.size() == 98 && closedManifold(l2, &e1) && (int)l2.v.size() - e1 + (int)l2.f.size() == 2);
        assert(signedVolume(l2) > 2.0 && signedVolume(l2) < 8.0 && signedVolume(l1) < 8.0 && signedVolume(l1) > 2.0);   // smooth, shrinks the cube, outward normals
        float mx = 0; for (const auto& v : l2.v) mx = std::max(mx, std::max(std::fabs(v.x), std::max(std::fabs(v.y), std::fabs(v.z)))); assert(mx < 1.f);
        Mesh sp = makeUVSphere(); sm.levels = 1; Mesh sp1 = applyModifier(sp, sm); assert(closedManifold(sp1) && signedVolume(sp1) > 0 && sp1.f.size() > sp.f.size());
        // boundary rule: a single quad keeps a straight border and corners pull in by the B-spline rule
        Mesh pl = makePlane(); Mesh pl1 = applyModifier(pl, sm);
        assert(pl1.f.size() == 4 && pl1.v.size() == 9);
        float w0 = 0; for (const auto& v : pl.v) w0 = std::max(w0, v.x);
        bool corner = false, border = false;
        for (const auto& v : pl1.v) { if (near(v.x, -0.75f * w0) && near(v.y, -0.75f * w0)) corner = true; if (near(v.x, -w0) && near(v.y, 0)) border = true; }
        assert(corner && border);   // corner -> 0.75P + 0.125(A+B); boundary edge point stays on the border line
        for (const auto& v : pl1.v) assert(near(v.z, 0));
        // no mutation of the input, levels bounded, absurd size guarded
        assert(sameMesh(cu, makeCube()));
        Modifier bad = sm; bad.levels = 0; assert(!validModifier(bad)); bad.levels = 5; assert(!validModifier(bad));
        // stack: mirror then subsurf; object picking + display use the evaluated result; apply bakes with one undo step
        Scene c; uint32_t id = addPrimitive(c, 0); assert(addModifier(c, kSubsurf));
        assert(displayMesh(*c.find(id)).f.size() == 24);
        Modifier m = c.find(id)->mods[0]; m.levels = 3; assert(setModifier(c, 0, m) && displayMesh(*c.find(id)).f.size() == 384);
        assert(!setModifier(c, 0, m));   // no-op: no undo step
        assert(applyModifierAt(c, 0) && c.find(id)->mesh.f.size() == 384 && c.find(id)->mods.empty());
        assert(c.undo() && c.find(id)->mesh.f.size() == 6 && c.find(id)->mods.size() == 1 && c.undo() && c.find(id)->mods[0].levels == 1);
    }
    {   // 0.7.0: Solidify
        Modifier so; so.type = kSolidify; so.thickness = 0.1f; so.shift = -1.f;
        Mesh cu = makeCube(); Mesh sc = applyModifier(cu, so);
        assert(sc.v.size() == 16 && sc.f.size() == 12 && closedManifold(sc));
        // outer shell is the original cube (shift -1), inner shell is 0.1 inside on every face: volume 8 - 1.8^3
        assert(near((float)signedVolume(sc), 8.f - 1.8f * 1.8f * 1.8f, 1e-3f));
        for (int i = 0; i < 8; ++i) assert(near(sc.v[i].x, cu.v[i].x) && near(sc.v[i].y, cu.v[i].y) && near(sc.v[i].z, cu.v[i].z));
        so.shift = 1.f; Mesh out = applyModifier(cu, so); assert(near((float)signedVolume(out), 2.2f * 2.2f * 2.2f - 8.f, 1e-3f));   // grows outward, inner shell = original
        so.shift = 0.f; Mesh mid = applyModifier(cu, so); assert(near((float)signedVolume(mid), 2.1f * 2.1f * 2.1f - 1.9f * 1.9f * 1.9f, 1e-3f));
        // open mesh gets a rim: a plane becomes a closed slab of volume area * thickness
        so.shift = -1.f; so.thickness = 0.2f; Mesh pl = makePlane(); Mesh sp = applyModifier(pl, so);
        assert(sp.v.size() == 8 && sp.f.size() == 6 && closedManifold(sp));
        float w = pl.v[0].x, area = 0; for (const auto& v : pl.v) w = std::max(w, v.x); area = (2 * w) * (2 * w);
        assert(near((float)signedVolume(sp), area * 0.2f, 1e-3f));
        assert(!validModifier([&] { Modifier b = so; b.thickness = 0; return b; }()) && !validModifier([&] { Modifier b = so; b.shift = 2; return b; }()));
        // chaining with subsurf keeps the surface closed and with outward normals
        Modifier sm; sm.type = kSubsurf; sm.levels = 1; Mesh both = applyModifier(sc, sm); assert(closedManifold(both) && signedVolume(both) > 0);
        // scene: undo/redo and apply
        Scene c; uint32_t id = addPrimitive(c, 0); assert(addModifier(c, kSolidify) && c.find(id)->mods[0].thickness == 0.1f);
        Modifier m = c.find(id)->mods[0]; m.thickness = 0.3f; assert(setModifier(c, 0, m) && displayMesh(*c.find(id)).v.size() == 16);
        assert(applyModifierAt(c, 0) && c.find(id)->mesh.f.size() == 12); assert(c.undo() && c.find(id)->mesh.f.size() == 6);
    }
    {   // project v4 round trip keeps subsurf/solidify parameters; v3 files still load with defaults
        Scene c; uint32_t id = addPrimitive(c, 0); addModifier(c, kSubsurf); addModifier(c, kSolidify);
        Modifier a = c.find(id)->mods[0]; a.levels = 3; setModifier(c, 0, a);
        Modifier b = c.find(id)->mods[1]; b.thickness = 0.25f; b.shift = 0.5f; setModifier(c, 1, b);
        assert(saveProject(c, "/tmp/atlas_t4.atlas"));
        Scene q; assert(loadProject(q, "/tmp/atlas_t4.atlas") && q.objects[0].mods.size() == 2);
        assert(q.objects[0].mods[0].type == kSubsurf && q.objects[0].mods[0].levels == 3 && q.objects[0].mods[1].type == kSolidify);
        assert(near(q.objects[0].mods[1].thickness, 0.25f) && near(q.objects[0].mods[1].shift, 0.5f));
        FILE* f = fopen("/tmp/atlas_v3b.atlas", "w"); fputs("ATLAS 3\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nmods 1\nmod 0 1 0 0.001 2 1 0 0\nend\n", f); fclose(f);
        Scene o3; assert(loadProject(o3, "/tmp/atlas_v3b.atlas") && o3.objects[0].mods.size() == 1 && o3.objects[0].mods[0].levels == 1);
        f = fopen("/tmp/atlas_badv4.atlas", "w"); fputs("ATLAS 4\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nmods 1\nmod 2 1 0 0.001 2 1 0 0 9 0.1 -1\nend\n", f); fclose(f);
        Scene keep; addPrimitive(keep, 0); std::string err; assert(!loadProject(keep, "/tmp/atlas_badv4.atlas", &err) && keep.objects.size() == 1);
    }

    {   // 0.8.0: rename, apply transform, origin to geometry, select linked
        Scene c; uint32_t a = addPrimitive(c, 0); uint32_t b = addPrimitive(c, 0); c.selected = a;
        assert(renameSelected(c, "  My Cube  ") && c.find(a)->name == "My_Cube");
        assert(!renameSelected(c, "My Cube") && !renameSelected(c, "   ") && !renameSelected(c, ""));   // same name / empty: no-op, no undo step
        assert(renameSelected(c, "Cube.001") && c.find(a)->name == "Cube" && c.find(b)->name == "Cube.001");   // clash with b -> made unique
        assert(c.undo() && c.find(a)->name == "My_Cube" && c.undo() && c.find(a)->name == "Cube" && c.redo() && c.find(a)->name == "My_Cube");
        // apply all transforms: world positions of every vertex stay, transform becomes identity, undo restores
        Scene t; uint32_t id = addPrimitive(t, 0); Xf x = getXf(*t.find(id)); x.pos[0] = 3; x.pos[1] = -1; x.rot[2] = 90; x.rot[0] = 30; x.scale[0] = 2; x.scale[2] = 0.5f;
        assert(setObjectTransform(t, x));
        std::vector<Vec3> w0; for (const auto& p : t.find(id)->mesh.v) w0.push_back(localToWorldPoint(*t.find(id), p));
        assert(applyTransformSelected(t, 0));
        const Object& o = *t.find(id);
        for (int i = 0; i < 3; ++i) assert(o.pos[i] == 0 && o.rot[i] == 0 && o.scale[i] == 1);
        for (size_t i = 0; i < w0.size(); ++i) assert(near(o.mesh.v[i].x, w0[i].x) && near(o.mesh.v[i].y, w0[i].y) && near(o.mesh.v[i].z, w0[i].z));
        assert(!applyTransformSelected(t, 0));   // already identity: no-op
        assert(t.undo() && t.find(id)->pos[0] == 3 && t.find(id)->scale[0] == 2 && near(t.find(id)->mesh.v[0].x, makeCube().v[0].x));
        assert(t.redo() && t.find(id)->pos[0] == 0);
        // scale-only bake, with a negative scale: winding is flipped so normals stay outward
        Scene n; uint32_t nid = addPrimitive(n, 0); Xf nx = getXf(*n.find(nid)); nx.scale[0] = -2; nx.scale[1] = 3; assert(setObjectTransform(n, nx));
        assert(applyTransformSelected(n, 1) && n.find(nid)->scale[0] == 1 && n.find(nid)->scale[1] == 1);
        checkOutward(n.find(nid)->mesh); assert(near((float)signedVolume(n.find(nid)->mesh), 8.f * 2 * 3, 1e-3f));
        // object mode only
        setEditMode(n, true); assert(!applyTransformSelected(n, 0) && !originToGeometry(n) && !renameSelected(n, "Zzz")); setEditMode(n, false);
        // origin to geometry: mesh recentred, geometry does not move in the world
        Scene g; uint32_t gid = addPrimitive(g, 0); Object* go = g.find(gid);
        for (auto& p : go->mesh.v) { p = p + Vec3{1, 2, 3}; }
        go->meshRev = nextRev();
        Xf gx = getXf(*go); gx.pos[0] = 5; gx.rot[2] = 90; gx.scale[0] = 2; assert(setObjectTransform(g, gx));
        std::vector<Vec3> gw; for (const auto& p : g.find(gid)->mesh.v) gw.push_back(localToWorldPoint(*g.find(gid), p));
        assert(originToGeometry(g));
        Vec3 med; for (const auto& p : g.find(gid)->mesh.v) med = med + p; assert(near(med.x, 0, 1e-4f) && near(med.y, 0, 1e-4f) && near(med.z, 0, 1e-4f));
        for (size_t i = 0; i < gw.size(); ++i) { Vec3 q = localToWorldPoint(*g.find(gid), g.find(gid)->mesh.v[i]); assert(near(q.x, gw[i].x) && near(q.y, gw[i].y) && near(q.z, gw[i].z)); }
        assert(!originToGeometry(g));   // already centred
        assert(g.undo() && near(g.find(gid)->mesh.v[0].x, makeCube().v[0].x + 1));
        // select linked: two disjoint cubes (array, baked)
        Scene l; uint32_t lid = addPrimitive(l, 0); addModifier(l, kArray); Modifier am = l.find(lid)->mods[0]; am.count = 2; am.offset[0] = 5; setModifier(l, 0, am); applyModifierAt(l, 0);
        assert(l.find(lid)->mesh.f.size() == 12 && setEditMode(l, true));
        setSelectMode(l, 2); l.sel.f = {0}; assert(selectLinkedActive(l) && l.sel.f.size() == 6 && l.sel.f.count(0) && !l.sel.f.count(6));
        setSelectMode(l, 0); l.sel.clearSets(); l.sel.v = {9}; assert(selectLinkedActive(l) && l.sel.v.size() == 8 && l.sel.v.count(9) && !l.sel.v.count(0));
        setSelectMode(l, 1); l.sel.clearSets(); l.sel.e = {mkEdge(l.find(lid)->mesh.f[0][0], l.find(lid)->mesh.f[0][1])};
        assert(selectLinkedActive(l) && l.sel.e.size() == 12);
        l.sel.clearSets(); assert(!selectLinkedActive(l));
    }
    {   // 0.9.0: Triangulate (ear clipping), Weld / Merge by Distance
        Modifier tm; tm.type = kTriangulate;
        Mesh cu = makeCube(); Mesh tc = applyModifier(cu, tm);
        assert(tc.f.size() == 12 && closedManifold(tc) && near((float)signedVolume(tc), 8.f, 1e-4f)); for (const auto& fc : tc.f) assert(fc.size() == 3);
        // concave L-shaped hexagon (area 3), both windings
        for (int flip = 0; flip < 2; ++flip) for (int rot = 0; rot < 6; ++rot) {   // every start corner, including the reflex one
            Mesh L; L.v = {{0, 0, 0}, {2, 0, 0}, {2, 1, 0}, {1, 1, 0}, {1, 2, 0}, {0, 2, 0}}; L.f = {{0, 1, 2, 3, 4, 5}};
            std::rotate(L.f[0].begin(), L.f[0].begin() + rot, L.f[0].end());
            if (flip) std::reverse(L.f[0].begin(), L.f[0].end());
            Mesh tl = triangulateMesh(L); assert(tl.f.size() == 4);
            float area = 0; for (const auto& fc : tl.f) {
                assert(fc.size() == 3);
                Vec3 a = tl.v[fc[0]], b = tl.v[fc[1]], d = tl.v[fc[2]];
                float az = ((b.x - a.x) * (d.y - a.y) - (b.y - a.y) * (d.x - a.x)) * 0.5f;
                assert(flip ? az < 0 : az > 0);   // winding of the source face is kept
                area += std::fabs(az);
            }
            assert(near(area, 3.f, 1e-4f));
        }
        // sphere keeps volume and stays closed; triangle count = sum(k-2)
        Mesh sp = makeUVSphere(); size_t expect = 0; for (const auto& fc : sp.f) expect += fc.size() - 2;
        Mesh ts = triangulateMesh(sp); assert(ts.f.size() == expect && closedManifold(ts) && near((float)signedVolume(ts), (float)signedVolume(sp), 1e-3f));
        // weld: two touching cubes share 4 vertex pairs
        Modifier am; am.type = kArray; am.count = 2; am.offset[0] = 2.f; Mesh two = applyModifier(cu, am); assert(two.v.size() == 16);
        Mesh w = two; assert(weldVertices(w, 0.001f) == 4 && w.v.size() == 12 && validMesh(w) && w.f.size() == 12);
        Mesh far = applyModifier(cu, [] { Modifier a; a.type = kArray; a.count = 2; a.offset[0] = 2.5f; return a; }()); Mesh f2 = far; assert(weldVertices(f2, 0.001f) == 0 && sameMesh(f2, far));
        std::vector<char> half(16, 0); for (int i = 0; i < 8; ++i) half[i] = 1; Mesh hm = two; assert(weldVertices(hm, 0.001f, &half) == 0);   // partners are not selected
        std::vector<char> all(16, 1); Mesh am2 = two; assert(weldVertices(am2, 0.001f, &all) == 4);
        // collapsing a tiny face drops it and leaves no stray vertices
        Mesh q; q.v = {{0, 0, 0}, {0.0004f, 0, 0}, {0.0004f, 0.0004f, 0}, {0, 0.0004f, 0}, {5, 5, 0}, {6, 5, 0}, {5, 6, 0}}; q.f = {{0, 1, 2, 3}, {4, 5, 6}};
        assert(weldVertices(q, 0.001f) == 3 && q.f.size() == 1 && q.v.size() == 3 && validMesh(q));
        // modifier in a stack: mirror then weld(0) removes nothing extra; weld as modifier on baked doubles
        Scene c; uint32_t id = addPrimitive(c, 0); addModifier(c, kArray); Modifier m = c.find(id)->mods[0]; m.count = 2; m.offset[0] = 2; setModifier(c, 0, m);
        assert(addModifier(c, kWeld) && c.find(id)->mods[1].type == kWeld && displayMesh(*c.find(id)).v.size() == 12);
        assert(addModifier(c, kTriangulate) && displayMesh(*c.find(id)).f.size() == 24);
        Modifier wm = c.find(id)->mods[1]; wm.merge = 0; assert(setModifier(c, 1, wm) && displayMesh(*c.find(id)).v.size() == 12);   // distance 0 still merges exact duplicates
        wm.merge = -1; assert(!validModifier(wm)); wm.merge = 2000; assert(!validModifier(wm));
        // edit op: Merge by Distance on the selection, one undo step
        Scene e; uint32_t eid = addPrimitive(e, 0); addModifier(e, kArray); Modifier em = e.find(eid)->mods[0]; em.count = 2; em.offset[0] = 2; setModifier(e, 0, em); applyModifierAt(e, 0);
        assert(setEditMode(e, true)); setSelectMode(e, 0); selectAllActive(e);
        assert(weldSelected(e, 0.001f) && e.find(eid)->mesh.v.size() == 12 && selectionCount(e.sel) == 0 && !weldSelected(e, 0.001f));
        assert(!weldSelected(e, -1.f) && e.undo() && e.find(eid)->mesh.v.size() == 16);
        // project round trip keeps the new modifier types and the weld distance
        addModifier(c, kWeld); Modifier w2 = c.find(id)->mods[3]; w2.merge = 0.02f; setModifier(c, 3, w2);
        assert(saveProject(c, "/tmp/atlas_t9.atlas")); Scene q2; assert(loadProject(q2, "/tmp/atlas_t9.atlas") && q2.objects[0].mods.size() == 4);
        assert(q2.objects[0].mods[2].type == kTriangulate && q2.objects[0].mods[3].type == kWeld && near(q2.objects[0].mods[3].merge, 0.02f));
    }

    {   // 0.10.0: Dissolve Edges, Limited Dissolve, Separate Selection
        // helper: nx x ny grid of quads on z = 0 (CCW seen from +Z), 1 unit cells
        auto grid = [](int nx, int ny) {
            Mesh g;
            for (int y = 0; y <= ny; ++y) for (int x = 0; x <= nx; ++x) g.v.push_back({(float)x, (float)y, 0});
            for (int y = 0; y < ny; ++y) for (int x = 0; x < nx; ++x) {
                int a = y * (nx + 1) + x; g.f.push_back({a, a + 1, a + nx + 2, a + nx + 1});
            }
            return g;
        };
        // loop cut a cube, then dissolve the new loop: back to a plain cube (8 verts, 6 faces, volume 8)
        Mesh cu = makeCube(); std::set<Edge> cut;
        assert(loopCut(cu, mkEdge(0, 4), 0.5f, &cut) && cu.v.size() == 12 && cu.f.size() == 10 && cut.size() == 4);
        Mesh d = cu; std::vector<int> made;
        assert(dissolveEdges(d, cut, &made) == 4 && made.size() == 4);
        assert(d.v.size() == 8 && d.f.size() == 6 && closedManifold(d) && near((float)signedVolume(d), 8.f, 1e-4f)); checkOutward(d);
        for (const auto& fc : d.f) assert(fc.size() == 4);
        // boundary edges and edges that are not in the mesh do nothing and leave the mesh untouched
        Mesh pl = makePlane(); Mesh pl0 = pl; assert(dissolveEdges(pl, {mkEdge(0, 1)}) == 0 && sameMesh(pl, pl0));
        assert(dissolveEdges(pl, {mkEdge(0, 2)}) == 0 && sameMesh(pl, pl0));
        // 2x1 strip: dissolving the middle edge gives one 2x1 quad (the two middle vertices were straight, so they go too)
        Mesh st = grid(2, 1); assert(dissolveEdges(st, {mkEdge(1, 4)}) == 1 && st.f.size() == 1 && st.v.size() == 4 && near(faceArea(st, st.f[0]), 2.f));
        // L-shape from a 2x2 grid: dissolving two edges of the L keeps the real corner (not straight) and the area
        Mesh g22 = grid(2, 2);   // cells 0,1 / 2,3 ; vertex 4 is the centre
        Mesh L = g22; assert(dissolveEdges(L, {mkEdge(1, 4), mkEdge(3, 4)}) == 1);   // merges cells 0|1 and 0|2 -> one L polygon of 3 cells... plus keep cell 3
        assert(L.f.size() == 2 && validMesh(L));
        float tot = 0; for (const auto& fc : L.f) tot += faceArea(L, fc); assert(near(tot, 4.f));
        size_t big = 0; for (const auto& fc : L.f) big = std::max(big, fc.size()); assert(big == 6);   // L hexagon: corner kept
        // chain of three cells merges into ONE polygon, not pairs
        Mesh row = grid(3, 1); assert(dissolveEdges(row, {mkEdge(1, 5), mkEdge(2, 6)}) == 1 && row.f.size() == 1 && row.v.size() == 4 && near(faceArea(row, row.f[0]), 3.f));
        // dissolving all four interior edges of a 2x2 grid leaves a single quad (centre vertex disappears)
        Mesh all4 = g22; assert(dissolveEdges(all4, {mkEdge(1, 4), mkEdge(3, 4), mkEdge(4, 5), mkEdge(4, 7)}) == 1 && all4.f.size() == 1 && all4.v.size() == 4 && near(faceArea(all4, all4.f[0]), 4.f));
        // a ring of faces around a hole would leave a polygon with a hole: refused, mesh unchanged
        Mesh g33 = grid(3, 3); Mesh ring = g33;   // dissolve every edge shared by the 8 outer cells -> hole in the middle cell
        std::set<Edge> re = {mkEdge(1, 5), mkEdge(2, 6), mkEdge(4, 5), mkEdge(8, 9), mkEdge(9, 10), mkEdge(6, 10), mkEdge(5, 9), mkEdge(6, 7), mkEdge(10, 11), mkEdge(4, 8), mkEdge(7, 11), mkEdge(8, 12), mkEdge(9, 13), mkEdge(10, 14), mkEdge(11, 15)};
        Mesh before = ring; int nring = dissolveEdges(ring, re);
        assert(nring == 0 ? sameMesh(ring, before) : validMesh(ring));   // either refused or a valid merge, never a broken mesh
        // two faces that walk the shared edge in the SAME direction (inconsistent winding) are not merged
        Mesh wrong; wrong.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}, {2, 0, 0}, {2, 1, 0}}; wrong.f = {{0, 1, 2, 3}, {1, 2, 5, 4}};
        Mesh wrong0 = wrong; assert(dissolveEdges(wrong, {mkEdge(1, 2)}) == 0 && sameMesh(wrong, wrong0));
        // Limited Dissolve: flat 4x4 grid collapses to a single quad
        Mesh g44 = grid(4, 4); assert(limitedDissolve(g44, 5.f) == 1 && g44.f.size() == 1 && g44.v.size() == 4 && near(faceArea(g44, g44.f[0]), 16.f));
        // a cube is not dissolved (90 degree faces), but a coplanar subdivided cube face is
        Mesh c2 = makeCube(); assert(limitedDissolve(c2, 5.f) == 0 && sameMesh(c2, makeCube()));
        Mesh sub = makeCube(); subdivideFaces(sub, {0});   // face 0 -> 4 quads (bottom face), neighbours get extra vertices (n-gons)
        assert(sub.f.size() == 9 && limitedDissolve(sub, 5.f) == 1 && sub.f.size() == 6 && sub.v.size() == 8 && closedManifold(sub) && near((float)signedVolume(sub), 8.f, 1e-4f));
        // angle limit: a slightly bent strip (10 degrees) merges at 15 but not at 5
        float k = 10.f * 0.01745329252f; Mesh bent; bent.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}, {1 + std::cos(k), 0, std::sin(k)}, {1 + std::cos(k), 1, std::sin(k)}};
        bent.f = {{0, 1, 2, 3}, {1, 4, 5, 2}};
        Mesh b5 = bent; assert(limitedDissolve(b5, 5.f) == 0 && sameMesh(b5, bent));
        Mesh b15 = bent; assert(limitedDissolve(b15, 15.f) == 1 && b15.f.size() == 1);
        // mask: faces outside the mask are never merged
        Mesh gm = grid(2, 1); std::vector<char> only0 = {1, 0}; assert(limitedDissolve(gm, 5.f, &only0) == 0);
        std::vector<char> both = {1, 1}; assert(limitedDissolve(gm, 5.f, &both) == 1);
        assert(limitedDissolve(gm, -1.f) == 0 && limitedDissolve(gm, 181.f) == 0);
        // scene ops: edge mode, face mode (merge faces), vertex mode, undo/redo restores mesh + selection
        {
            Scene s; uint32_t id = addPrimitive(s, 1); assert(setEditMode(s, true));
            for (int i = 0; i < 2; ++i) { setSelectMode(s, 2); selectAllActive(s); assert(subdivideSelected(s)); }   // plane -> 16 quads
            assert(s.find(id)->mesh.f.size() == 16);
            setSelectMode(s, 2); selectAllActive(s);
            const Mesh m0 = s.find(id)->mesh;
            assert(limitedDissolveSelected(s, 5.f) && s.find(id)->mesh.f.size() == 1 && s.find(id)->mesh.v.size() == 4 && s.sel.f.size() == 1 && s.sel.f.count(0));
            assert(!limitedDissolveSelected(s, 5.f));   // nothing left to merge: no undo step
            assert(s.undo() && sameMesh(s.find(id)->mesh, m0) && s.sel.f.size() == 16 && s.redo() && s.find(id)->mesh.f.size() == 1);
            assert(s.undo());
            assert(!limitedDissolveSelected(s, 0.f) && !limitedDissolveSelected(s, 200.f));
            // face mode dissolve edges: two neighbouring faces merge; one face alone does nothing
            s.sel.clearSets(); s.sel.f = {0}; assert(!dissolveSelectedEdges(s));
            int fa = -1, fb = -1; Edge shared = {-1, -1};   // find two faces that share an edge
            { auto efm = detail::edgeFaces(s.find(id)->mesh); for (const auto& kv : efm) if (kv.second.size() == 2) { fa = kv.second[0]; fb = kv.second[1]; shared = kv.first; break; } }
            assert(fa >= 0);
            s.sel.f = {fa, fb}; assert(dissolveSelectedEdges(s) && s.find(id)->mesh.f.size() == 15 && s.sel.f.size() == 1);
            // edge mode: the picked edge between two faces
            assert(s.undo()); setSelectMode(s, 1); s.sel.clearSets();
            s.sel.e = {shared};
            assert(dissolveSelectedEdges(s) && s.find(id)->mesh.f.size() == 15 && s.sel.f.empty() && s.sel.e.size() >= 4);
            assert(s.undo() && s.find(id)->mesh.f.size() == 16);
            // outside edit mode: refused
            setEditMode(s, false); assert(!dissolveSelectedEdges(s) && !limitedDissolveSelected(s, 5.f));
        }
        // Separate: a cube with an extruded top face; separate the extrusion's faces into a new object
        {
            Scene s; uint32_t id = addPrimitive(s, 0); s.find(id)->pos[0] = 3.f; s.find(id)->scale[2] = 2.f; addModifier(s, kTriangulate);
            assert(setEditMode(s, true)); setSelectMode(s, 2);
            s.sel.f = {0, 1, 2, 3, 4, 5}; assert(separateSelected(s) == 0);   // everything selected: refused
            s.sel.clearSets(); assert(separateSelected(s) == 0);              // nothing selected: refused
            s.sel.f = {1}; const Mesh m0 = s.find(id)->mesh; const size_t nobj = s.objects.size();
            uint32_t nid = separateSelected(s);
            assert(nid != 0 && nid != id && s.objects.size() == nobj + 1 && s.selected == nid && !s.editMode);
            const Object* a = s.find(id); const Object* b = s.find(nid);
            assert(a->mesh.f.size() == 5 && a->mesh.v.size() == 8 && b->mesh.f.size() == 1 && b->mesh.v.size() == 4 && validMesh(a->mesh) && validMesh(b->mesh));
            assert(b->name != a->name && near(b->pos[0], 3.f) && near(b->scale[2], 2.f) && b->mods.size() == 1);   // same transform and modifiers
            assert(near(faceArea(b->mesh, b->mesh.f[0]), 4.f));
            assert(s.undo() && s.objects.size() == nobj && s.find(nid) == nullptr && sameMesh(s.find(id)->mesh, m0) && s.editMode && s.selected == id && s.sel.f.count(1));
            assert(s.redo() && s.objects.size() == nobj + 1 && s.selected == nid && s.find(nid)->mesh.f.size() == 1);
            // vertex mode: only fully covered faces move
            assert(s.undo()); setSelectMode(s, 0); s.sel.clearSets(); for (int vi : s.find(id)->mesh.f[1]) s.sel.v.insert(vi);
            assert(separateSelected(s) != 0 && s.objects.size() == nobj + 1);
            // project round trip with the separated object
            assert(saveProject(s, "/tmp/atlas_t10.atlas")); Scene q; assert(loadProject(q, "/tmp/atlas_t10.atlas") && q.objects.size() == nobj + 1);
        }
    }
    {   // 0.11.0: Smooth, Simple Deform, Planar Decimate, project format v5
        // --- Smooth ---
        Modifier sm; sm.type = kSmooth; sm.factor = 0.5f; sm.iterations = 1;
        Mesh cu = makeCube(); Mesh s1 = applyModifier(cu, sm);
        assert(s1.v.size() == 8 && s1.f == cu.f && near(s1.v[6].x, 2.f / 3.f) && near(s1.v[6].y, 2.f / 3.f) && near(s1.v[6].z, 2.f / 3.f));   // corner moves halfway to the mean of its 3 neighbours
        assert(near(s1.v[0].x, -2.f / 3.f));
        assert(sameMesh(cu, makeCube()));   // input untouched
        Modifier s2m = sm; s2m.iterations = 2; Mesh s2 = applyModifier(cu, s2m); Mesh s11 = applyModifier(s1, sm);
        for (size_t i = 0; i < s2.v.size(); ++i) assert(near(s2.v[i].x, s11.v[i].x) && near(s2.v[i].y, s11.v[i].y) && near(s2.v[i].z, s11.v[i].z));   // 2 passes = 2 applications
        Modifier s0 = sm; s0.factor = 0.f; assert(sameMesh(applyModifier(cu, s0), cu));
        Modifier sf = sm; sf.factor = 1.f; Mesh sf1 = applyModifier(cu, sf); assert(near(sf1.v[6].x, 1.f / 3.f) && near(sf1.v[6].z, 1.f / 3.f));
        assert(signedVolume(s1) > 0 && signedVolume(s1) < signedVolume(cu) && closedManifold(s1));
        // a flat grid stays flat; a bump relaxes towards its neighbours
        Mesh flat; for (int y = 0; y < 5; ++y) for (int x = 0; x < 5; ++x) flat.v.push_back({(float)x, (float)y, 0});
        for (int y = 0; y < 4; ++y) for (int x = 0; x < 4; ++x) { int a = y * 5 + x; flat.f.push_back({a, a + 1, a + 6, a + 5}); }
        Mesh bump = flat; bump.v[12].z = 1.f; Mesh sb = applyModifier(bump, sm);
        assert(sb.v[12].z < 1.f && sb.v[12].z > 0.f && sb.v[7].z > 0.f && sb.v[11].z > 0.f);
        Mesh sflat = applyModifier(flat, sm); for (const auto& p : sflat.v) assert(near(p.z, 0.f));
        Mesh iso; iso.v = {{0, 0, 0}, {1, 0, 0}, {0, 1, 0}, {5, 5, 5}}; iso.f = {{0, 1, 2}}; Mesh isoS = applyModifier(iso, sm); assert(isoS.v[3].x == 5.f && isoS.v[3].y == 5.f && isoS.v[3].z == 5.f);   // vertex with no edges does not move
        // --- Simple Deform ---
        Mesh bar; bar.v = {{-0.5f, -0.5f, 0}, {0.5f, -0.5f, 0}, {0.5f, 0.5f, 0}, {-0.5f, 0.5f, 0}, {-0.5f, -0.5f, 4}, {0.5f, -0.5f, 4}, {0.5f, 0.5f, 4}, {-0.5f, 0.5f, 4}};
        bar.f = makeCube().f;
        Modifier tw; tw.type = kSimpleDeform; tw.mode = kTwist; tw.axis = 2; tw.angle = 90.f;
        Mesh bt = applyModifier(bar, tw);
        for (int i = 0; i < 4; ++i) assert(near(bt.v[i].x, bar.v[i].x) && near(bt.v[i].y, bar.v[i].y) && near(bt.v[i].z, bar.v[i].z));   // low end fixed
        assert(near(bt.v[4].x, 0.5f) && near(bt.v[4].y, -0.5f) && near(bt.v[4].z, 4.f));   // (-.5,-.5) rotated 90 deg -> (.5,-.5)
        for (size_t i = 0; i < bt.v.size(); ++i) assert(near(std::sqrt(bt.v[i].x * bt.v[i].x + bt.v[i].y * bt.v[i].y), std::sqrt(bar.v[i].x * bar.v[i].x + bar.v[i].y * bar.v[i].y)) && near(bt.v[i].z, bar.v[i].z));
        Modifier tw0 = tw; tw0.angle = 0.f; assert(sameMesh(applyModifier(bar, tw0), bar));
        // twist about X uses the X extent: a bar along X with its low end fixed
        Mesh barX; for (auto p : bar.v) barX.v.push_back({p.z, p.x, p.y}); barX.f = bar.f;
        Modifier twx = tw; twx.axis = 0; Mesh btx = applyModifier(barX, twx); assert(near(btx.v[0].y, barX.v[0].y) && near(btx.v[4].x, 4.f) && near(std::sqrt(btx.v[4].y * btx.v[4].y + btx.v[4].z * btx.v[4].z), std::sqrt(0.5f)));
        // bend: neutral line (x = 0) of a straight bar bent 90 degrees ends on the arc of radius L / (pi/2)
        Mesh line; line.v = {{0, 0, 0}, {0, 0, 1}, {0, 0, 2}, {0, 0, 4}, {1, 0, 4}}; line.f = {{0, 1, 2}};
        Modifier bd; bd.type = kSimpleDeform; bd.mode = kBend; bd.axis = 2; bd.angle = 90.f; Mesh bb = applyModifier(line, bd);
        const float R = 4.f / (3.14159265f / 2.f);
        assert(near(bb.v[0].x, 0.f) && near(bb.v[0].z, 0.f) && near(bb.v[3].x, R, 1e-3f) && near(bb.v[3].z, R, 1e-3f));   // end of the neutral axis: (R, R)
        for (int i = 0; i < 4; ++i) {   // every neutral-axis point lies on the circle of radius R around (x = R, z = 0)
            const float dx = bb.v[i].x - R; assert(near(std::sqrt(dx * dx + bb.v[i].z * bb.v[i].z), R, 1e-3f));
        }
        // arc length preserved on the neutral axis (segment 0 -> 1 is ~1 long for a 90 degree total bend)
        { Vec3 a = bb.v[0], b2 = bb.v[1]; float chord = length(b2 - a); assert(chord > 0.9f && chord < 1.0f); }
        // a point offset towards the inside of the bend (x = +1 at the end) lands at radius R - 1 from the centre of curvature (R, 0 side)
        { const float rr = R - 1.f, th = 3.14159265f / 2.f; assert(near(bb.v[4].x, R - rr * std::cos(th), 1e-3f) && near(bb.v[4].z, rr * std::sin(th), 1e-3f)); }
        Modifier bd0 = bd; bd0.angle = 0.f; assert(sameMesh(applyModifier(line, bd0), line));
        // taper: low end unchanged, high end scaled by 1 + factor
        Modifier tp; tp.type = kSimpleDeform; tp.mode = kTaper; tp.axis = 2; tp.factor = -0.5f; Mesh tpm = applyModifier(bar, tp);
        assert(near(tpm.v[0].x, -0.5f) && near(tpm.v[4].x, -0.25f) && near(tpm.v[4].y, -0.25f) && near(tpm.v[4].z, 4.f));
        tp.factor = -3.f; Mesh tpz = applyModifier(bar, tp); assert(near(tpz.v[4].x, 0.f) && near(tpz.v[4].y, 0.f));   // never mirrors through the axis
        // stretch: volume preserved for a box, length grows by (1 + factor) about the middle
        Modifier stc; stc.type = kSimpleDeform; stc.mode = kStretch; stc.axis = 2; stc.factor = 1.f; Mesh stm = applyModifier(bar, stc);
        assert(near(stm.v[4].z - stm.v[0].z, 8.f) && near(stm.v[0].z, -2.f) && near(std::fabs(stm.v[0].x), 0.5f / std::sqrt(2.f)));
        assert(near((float)signedVolume(stm), (float)signedVolume(bar), 1e-3f));
        // flat mesh along the axis (zero extent) is left alone
        Mesh pl = makePlane(); assert(sameMesh(applyModifier(pl, tw), pl));
        // --- Planar Decimate ---
        Modifier pd; pd.type = kPlanarDecimate; pd.angle = 5.f;
        Mesh sub = makeCube(); subdivideFaces(sub, {0, 1, 2, 3, 4, 5});   // 24 quads on the cube
        assert(sub.f.size() == 24); Mesh dec = applyModifier(sub, pd);
        assert(dec.f.size() == 6 && dec.v.size() == 8 && closedManifold(dec) && near((float)signedVolume(dec), 8.f, 1e-4f));
        Mesh sph = makeUVSphere(); Mesh sd = applyModifier(sph, pd);   // curved surface: only the two nearly flat polar caps (16 triangles each) merge into a 16-gon
        assert(sd.f.size() == sph.f.size() - 30 && sd.v.size() == sph.v.size() - 2 && closedManifold(sd) && validMesh(sd));
        { size_t gon = 0; for (const auto& fc : sd.f) if (fc.size() == 16) ++gon; assert(gon == 2); }
        Modifier pdBig = pd; pdBig.angle = 180.f; Mesh whole = applyModifier(makeCube(), pdBig); assert(sameMesh(whole, makeCube()));   // a closed group has no outline: refused, mesh untouched
        Modifier pd0 = pd; pd0.angle = 0.f; assert(!validModifier(pd0)); pd0.angle = 181.f; assert(!validModifier(pd0));
        // --- validation of the new fields ---
        Modifier bad = sm; bad.factor = 1.5f; assert(!validModifier(bad)); bad = sm; bad.factor = -0.1f; assert(!validModifier(bad));
        bad = sm; bad.iterations = 0; assert(!validModifier(bad)); bad.iterations = 33; assert(!validModifier(bad));
        bad = tw; bad.mode = 4; assert(!validModifier(bad)); bad = tw; bad.angle = std::numeric_limits<float>::quiet_NaN(); assert(!validModifier(bad));
        bad = tw; bad.angle = 4000.f; assert(!validModifier(bad)); bad = tw; bad.type = 10; assert(!validModifier(bad));
        // --- scene: add, defaults, edit, stack, apply, undo ---
        Scene c; uint32_t id = addPrimitive(c, 0);
        assert(addModifier(c, kSmooth) && addModifier(c, kSimpleDeform) && addModifier(c, kPlanarDecimate) && !addModifier(c, 10));
        const auto& md = c.find(id)->mods;
        assert(md[0].type == kSmooth && near(md[0].factor, 0.5f) && md[0].iterations == 1);
        assert(md[1].type == kSimpleDeform && md[1].mode == kTwist && md[1].axis == 2 && near(md[1].angle, 45.f));
        assert(md[2].type == kPlanarDecimate && near(md[2].angle, 5.f));
        Modifier e = md[0]; e.iterations = 3; assert(setModifier(c, 0, e) && c.find(id)->mods[0].iterations == 3 && !setModifier(c, 0, e));   // second identical set is a no-op
        e.factor = 2.f; assert(!setModifier(c, 0, e));
        Modifier e1 = c.find(id)->mods[1]; e1.mode = kBend; e1.angle = 30.f; assert(setModifier(c, 1, e1) && c.find(id)->mods[1].mode == kBend);
        const Mesh shown = displayMesh(*c.find(id)); assert(shown.v.size() == 8 && !sameMesh(shown, c.find(id)->mesh));
        assert(c.undo() && c.find(id)->mods[1].mode == kTwist);
        assert(c.redo());
        // apply bakes smooth into the mesh
        assert(applyModifierAt(c, 0) && c.find(id)->mods.size() == 2 && near(c.find(id)->mesh.v[6].x, 8.f / 27.f) && near(c.find(id)->mesh.v[0].z, -8.f / 27.f));   // 3 passes: corner * (2/3)^3
        assert(c.undo() && c.find(id)->mods.size() == 3);
        // --- project format v5 round trip and v4 compatibility ---
        { Modifier r = c.find(id)->mods[1]; r.axis = 1; r.angle = -37.5f; r.factor = 0.25f; r.mode = kStretch; assert(setModifier(c, 1, r)); }
        assert(saveProject(c, "/tmp/atlas_t11.atlas")); Scene q; assert(loadProject(q, "/tmp/atlas_t11.atlas") && q.objects[0].mods.size() == 3);
        const auto& qm = q.objects[0].mods;
        assert(qm[0].type == kSmooth && qm[0].iterations == 3 && qm[1].type == kSimpleDeform && qm[1].mode == kStretch && qm[1].axis == 1 && near(qm[1].angle, -37.5f) && near(qm[1].factor, 0.25f) && qm[2].type == kPlanarDecimate && near(qm[2].angle, 5.f));
        {   // a v4 file (no new columns) still loads with defaults
            FILE* f = fopen("/tmp/atlas_v4.atlas", "w");
            fputs("ATLAS 4\nnext 2\nobject 1 Cube 0 0 0 0 0 0 1 1 1 4 1\nv -1 -1 0\nv 1 -1 0\nv 1 1 0\nv -1 1 0\nf 4 0 1 2 3\nmods 1\nmod 3 1 0 0.001 2 1 0 0 1 0.2 -1\nend\n", f); fclose(f);
            Scene o; assert(loadProject(o, "/tmp/atlas_v4.atlas") && o.objects[0].mods.size() == 1 && o.objects[0].mods[0].type == kSolidify && near(o.objects[0].mods[0].thickness, 0.2f) && o.objects[0].mods[0].iterations == 1);
        }
        {   // corrupt / out of range v5 records are rejected without touching the open scene
            Scene keep; addPrimitive(keep, 0); const size_t n = keep.objects.size();
            FILE* f = fopen("/tmp/atlas_bad5.atlas", "w");
            fputs("ATLAS 5\nnext 2\nobject 1 Cube 0 0 0 0 0 0 1 1 1 4 1\nv -1 -1 0\nv 1 -1 0\nv 1 1 0\nv -1 1 0\nf 4 0 1 2 3\nmods 1\nmod 6 1 0 0.001 2 1 0 0 1 0.1 -1 5 1 0 45\nend\n", f); fclose(f);   // smooth with factor 5
            assert(!loadProject(keep, "/tmp/atlas_bad5.atlas") && keep.objects.size() == n);
            f = fopen("/tmp/atlas_bad5b.atlas", "w");
            fputs("ATLAS 5\nnext 2\nobject 1 Cube 0 0 0 0 0 0 1 1 1 4 1\nv -1 -1 0\nv 1 -1 0\nv 1 1 0\nv -1 1 0\nf 4 0 1 2 3\nmods 1\nmod 7 1 2 0.001 2 1 0 0 1 0.1 -1 0.5\nend\n", f); fclose(f);   // truncated record
            assert(!loadProject(keep, "/tmp/atlas_bad5b.atlas") && keep.objects.size() == n);
        }
    }

    // ======== 0.12.0 ========
    puts("v0.12 tests...");
    {
        auto gridMesh = [](int n) { Mesh g; for (int y = 0; y <= n; ++y) for (int x = 0; x <= n; ++x) g.v.push_back({(float)x, (float)y, 0});
            for (int y = 0; y < n; ++y) { for (int x = 0; x < n; ++x) { const int a = y * (n + 1) + x; g.f.push_back({a, a + 1, a + n + 2, a + n + 1}); } }
            return g; };
        // dissolve a cube corner: three faces merge into a hexagon, the corner disappears
        { Mesh m = makeCube(); assert(dissolveVertices(m, {0}) == 1); int e = 0;
          assert(m.v.size() == 7 && m.f.size() == 4 && closedManifold(m, &e) && e == 9 && (int)m.v.size() - e + (int)m.f.size() == 2);
          size_t big = 0; for (auto& f : m.f) big = std::max(big, f.size()); assert(big == 6); }
        // interior vertex of a 3x3 quad grid: 4 faces -> 1 octagon
        { Mesh m = gridMesh(3); assert(dissolveVertices(m, {5}) == 1 && m.v.size() == 15 && m.f.size() == 6); size_t big = 0; for (auto& f : m.f) big = std::max(big, f.size()); assert(big == 8); }
        // corner of a lone quad (valence 2): becomes a triangle
        { Mesh m = makePlane(); assert(dissolveVertices(m, {0}) == 1 && m.v.size() == 3 && m.f.size() == 1 && m.f[0].size() == 3); }
        // nothing selected / out of range: untouched
        { Mesh m = makeCube(), o = m; assert(dissolveVertices(m, {}) == 0 && dissolveVertices(m, {99, -1}) == 0 && sameMesh(m, o)); }
        // scene: undoable, one step
        { Scene c; const uint32_t id = addPrimitive(c, 0); assert(setEditMode(c, true) && setSelectMode(c, 0)); c.sel.v = {0};
          const size_t d = c.undoDepth(); assert(dissolveSelectedVertices(c) && c.undoDepth() == d + 1 && c.find(id)->mesh.v.size() == 7 && c.sel.v.empty());
          assert(c.undo() && c.find(id)->mesh.v.size() == 8 && c.sel.v.size() == 1 && c.redo() && c.find(id)->mesh.v.size() == 7);
          c.sel.clearSets(); assert(!dissolveSelectedVertices(c)); }
        // Dissolve Faces: all nine faces of a grid -> a single quad with 4 vertices
        { Scene c; const uint32_t id = addPrimitive(c, 0); Object* o = c.find(id); o->mesh = gridMesh(3); o->meshRev = nextRev();
          assert(setEditMode(c, true) && setSelectMode(c, 2)); selectAllActive(c);
          assert(dissolveSelectedFaces(c) && c.find(id)->mesh.f.size() == 1 && c.find(id)->mesh.v.size() == 4 && c.sel.f.size() == 1);
          assert(near((float)std::fabs(signedVolume(c.find(id)->mesh)), 0.f) && c.undo() && c.find(id)->mesh.f.size() == 9);
          c.sel.f = {4}; assert(!dissolveSelectedFaces(c)); /* a single face has nothing to merge */ }
        // loose parts
        { Mesh two = makeCube(); Mesh b = makeCube(); for (auto& p : b.v) p.x += 5.f; const int off = (int)two.v.size();
          for (auto& p : b.v) { two.v.push_back(p); }
          for (auto f : b.f) { for (int& i : f) i += off; two.f.push_back(f); }
          auto parts = splitLooseParts(two); assert(parts.size() == 2 && parts[0].v.size() == 8 && parts[1].v.size() == 8 && parts[1].f.size() == 6);
          assert(closedManifold(parts[0]) && closedManifold(parts[1]) && near((float)signedVolume(parts[0]), 8.f) && near((float)signedVolume(parts[1]), 8.f));
          { float mn = 99; for (auto& p : parts[1].v) mn = std::min(mn, p.x); assert(near(mn, 4.f)); }
          assert(splitLooseParts(makeCube()).size() == 1 && splitLooseParts(Mesh()).empty());
          Mesh stray = makeCube(); stray.v.push_back({9, 9, 9}); assert(splitLooseParts(stray).size() == 1 && splitLooseParts(stray)[0].v.size() == 8);   // unused vertex is dropped
          Scene c; const uint32_t id = addPrimitive(c, 0); Object* o = c.find(id); o->mesh = two; o->meshRev = nextRev(); o->pos[1] = 3.f; addModifier(c, 4);
          assert(separateLooseParts(c) == 1 && c.objects.size() == 2 && c.selected == id && c.find(id)->mesh.v.size() == 8);
          assert(c.objects[1].name != c.objects[0].name && near(c.objects[1].pos[1], 3.f) && c.objects[1].mods.size() == 1 && c.objects[1].id != id);
          assert(c.undo() && c.objects.size() == 1 && c.find(id)->mesh.v.size() == 16 && c.redo() && c.objects.size() == 2);
          { const size_t dd = c.undoDepth(); assert(separateLooseParts(c) == 0 && c.undoDepth() == dd); }   // each object is one piece now: no empty undo step
          setEditMode(c, true); assert(separateLooseParts(c) == 0); }
    }
    // ======== 0.13.0 ========
    puts("v0.13 tests...");
    {
        auto borderEdges = [](const Mesh& m) { std::set<Edge> r; for (auto& kv : detail::edgeFaces(m)) if (kv.second.size() == 1) r.insert(kv.first); return r; };
        // fill: close the hole of a cube whose top face was deleted -> original cube again (normals outward, closed)
        { Mesh m = makeCube(); int top = -1; for (size_t i = 0; i < m.f.size(); ++i) { bool all = true; for (int v : m.f[i]) if (m.v[v].z < 0.5f) all = false; if (all) top = (int)i; }
          assert(top >= 0 && deleteFaces(m, {top})); assert(!closedManifold(m));
          auto be = borderEdges(m); assert(be.size() == 4); const int fi = fillLoop(m, be);
          assert(fi >= 0 && closedManifold(m) && near((float)signedVolume(m), 8.f) && m.f.size() == 6); checkOutward(m); }
        // fill refuses: open chain, edges that already have two faces, a face that already exists
        { Mesh m = makeCube(); int top = -1; for (size_t i = 0; i < m.f.size(); ++i) { bool all = true; for (int v : m.f[i]) if (m.v[v].z < 0.5f) all = false; if (all) top = (int)i; }
          deleteFaces(m, {top}); auto be = borderEdges(m); std::set<Edge> three(be); three.erase(three.begin()); Mesh o = m;
          assert(fillLoop(m, three) == -1 && sameMesh(m, o));
          Mesh full = makeCube(); Mesh fo = full; std::set<Edge> ring; for (auto& fc : full.f) { for (size_t i = 0; i < 4; ++i) ring.insert(mkEdge(fc[i], fc[(i + 1) % 4])); break; }
          assert(fillLoop(full, ring) == -1 && sameMesh(full, fo));
          assert(fillLoop(m, {}) == -1); }
        // fill a free loop (no neighbours): keeps traversal winding, 1 polygon
        { Mesh m; m.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}}; assert(fillLoop(m, {{0, 1}, {1, 2}, {2, 3}, {0, 3}}) == 0 && m.f.size() == 1 && m.f[0].size() == 4); }
        // bridge: two open tubes (end rings facing each other) become one longer tube; no edge is walked twice the same way
        { Mesh t1 = makeCylinder(8); deleteFaces(t1, {8, 9}); Mesh m = t1; const int off = (int)m.v.size();
          for (auto p : t1.v) { p.z += 3.f; m.v.push_back(p); } for (auto f : t1.f) { for (int& i : f) i += off; m.f.push_back(f); }
          std::set<Edge> es; for (const Edge& e : borderEdges(m)) { const float z0 = m.v[e.first].z, z1 = m.v[e.second].z; if ((z0 == 1.f && z1 == 1.f) || (z0 == 2.f && z1 == 2.f)) es.insert(e); }
          assert(es.size() == 16); std::vector<int> made; assert(bridgeLoops(m, es, &made) == 8 && made.size() == 8 && m.f.size() == 24);
          std::map<std::pair<int, int>, int> d; for (const auto& fc : m.f) for (size_t k = 0; k < fc.size(); ++k) ++d[{fc[k], fc[(k + 1) % fc.size()]}];
          for (auto& kv : d) assert(kv.second == 1);
          std::map<Edge, int> cnt; for (auto& kv : d) ++cnt[mkEdge(kv.first.first, kv.first.second)];
          int border = 0; for (auto& kv : cnt) { assert(kv.second <= 2); if (kv.second == 1) ++border; }
          assert(border == 16 && (int)m.v.size() - (int)cnt.size() + (int)m.f.size() == 0);   // open tube: two border rings, chi = 0
          for (int fi : made) { float zmin = 9, zmax = -9; for (int v : m.f[fi]) { zmin = std::min(zmin, m.v[v].z); zmax = std::max(zmax, m.v[v].z); } assert(zmin == 1.f && zmax == 2.f); } }
        // bridge: two separate rings (offset copy, rotated start index) get aligned and form a straight quad ring
        { Mesh m; const int n = 6; for (int i = 0; i < n; ++i) { float a = 6.2831853f * i / n; m.v.push_back({std::cos(a), std::sin(a), 0}); }
          for (int i = 0; i < n; ++i) { float a = 6.2831853f * ((i + 2) % n) / n; m.v.push_back({std::cos(a), std::sin(a), 1}); }   // second ring starts 2 steps later
          std::set<Edge> es; for (int i = 0; i < n; ++i) { es.insert(mkEdge(i, (i + 1) % n)); es.insert(mkEdge(n + i, n + (i + 1) % n)); }
          assert(bridgeLoops(m, es) == n && m.f.size() == (size_t)n);
          for (auto& q : m.f) assert(q.size() == 4);
          for (auto& q : m.f) { float zmin = 9, zmax = -9; for (int v : q) { zmin = std::min(zmin, m.v[v].z); zmax = std::max(zmax, m.v[v].z); } assert(zmin == 0.f && zmax == 1.f); }
          // aligned: every quad's vertical edge connects points with equal x,y
          for (auto& q : m.f) { int lo[2], hi[2], a = 0, b = 0; for (int v : q) { if (m.v[v].z < 0.5f) lo[a++] = v; else hi[b++] = v; }
              bool ok = false; for (int i = 0; i < 2; ++i) for (int j = 0; j < 2; ++j) if (near(m.v[lo[i]].x, m.v[hi[j]].x) && near(m.v[lo[i]].y, m.v[hi[j]].y)) ok = true; assert(ok); } }
        // bridge refuses: one loop only, unequal loops, shared vertex
        { Mesh m = makeCylinder(8); deleteFaces(m, {8}); Mesh o = m; assert(bridgeLoops(m, borderEdges(m)) == 0 && sameMesh(m, o));
          Mesh w; for (int i = 0; i < 7; ++i) w.v.push_back({(float)i, 0, 0}); std::set<Edge> sq = {{0, 1}, {1, 2}, {2, 3}, {0, 3}, {4, 5}, {5, 6}, {4, 6}}; assert(bridgeLoops(w, sq) == 0 && w.f.empty()); }
        // bevel vertices: one cube corner (legs 0.5) -> chamfer, removed volume = 0.5^3 / 6
        { Mesh m = makeCube(); std::vector<int> caps; assert(bevelVertices(m, {0}, 0.5f, &caps) == 1 && caps.size() == 1); int e = 0;
          assert(m.v.size() == 10 && m.f.size() == 7 && closedManifold(m, &e) && e == 15 && m.f[caps[0]].size() == 3);
          assert(near((float)signedVolume(m), 8.f - 0.5f * 0.5f * 0.5f / 6.f, 1e-4f));
          // winding of the cap is outward: normal points away from the removed corner's centre
          Vec3 c; for (int i : m.f[caps[0]]) c = c + m.v[i]; c = c * (1.f / 3.f); assert(dot(faceNormal(m, m.f[caps[0]]), c) > 0); }
        // all eight corners -> truncated cube
        { Mesh m = makeCube(); assert(bevelVertices(m, {0, 1, 2, 3, 4, 5, 6, 7}, 0.5f) == 8); int e = 0;
          assert(m.v.size() == 24 && m.f.size() == 14 && closedManifold(m, &e) && e == 36 && near((float)signedVolume(m), 8.f - 8.f / 48.f, 1e-4f));
          size_t tri = 0, oct = 0; for (auto& f : m.f) { if (f.size() == 3) ++tri; if (f.size() == 8) ++oct; } assert(tri == 8 && oct == 6); }
        // adjacent selected vertices share an edge: width is clamped so the points never cross
        { Mesh m = makeCube(); assert(bevelVertices(m, {0, 1}, 50.f) == 2 && closedManifold(m) && signedVolume(m) > 0.0); }
        // a UV sphere pole (many faces around it) and Euler characteristic
        { Mesh m = makeUVSphere(); const int pole = 0; const size_t fan = [&] { size_t k = 0; for (auto& f : m.f) for (int v : f) if (v == pole) ++k; return k; }();
          assert(bevelVertices(m, {pole}, 0.1f) == 1); int e = 0; assert(closedManifold(m, &e) && (int)m.v.size() - e + (int)m.f.size() == 2 && m.f.back().size() == fan); }
        // refuses: open border vertex, bad width, nothing selected
        { Mesh m = makePlane(), o = m; assert(bevelVertices(m, {0}, 0.1f) == 0 && sameMesh(m, o));
          Mesh c = makeCube(), co = c; assert(bevelVertices(c, {0}, 0.f) == 0 && bevelVertices(c, {0}, -1.f) == 0 && bevelVertices(c, {0}, std::numeric_limits<float>::quiet_NaN()) == 0 && bevelVertices(c, {}, 0.1f) == 0 && sameMesh(c, co)); }
        // scene level: bevel / fill / bridge are one undo step each and keep the selection valid
        { Scene c; const uint32_t id = addPrimitive(c, 0); assert(setEditMode(c, true) && setSelectMode(c, 0)); c.sel.v = {0, 7};
          const size_t d = c.undoDepth(); assert(bevelSelectedVertices(c, 0.4f) && c.undoDepth() == d + 1 && c.find(id)->mesh.v.size() == 12 && c.sel.mode == 0);
          assert(c.undo() && c.find(id)->mesh.v.size() == 8 && c.sel.v.size() == 2 && c.redo() && c.find(id)->mesh.v.size() == 12);
          c.sel.v = {}; assert(!bevelSelectedVertices(c, 0.4f) && !bevelSelectedVertices(c, 0.f));
          Scene f; const uint32_t fid = addPrimitive(f, 0); Object* o = f.find(fid); int top = -1;
          for (size_t i = 0; i < o->mesh.f.size(); ++i) { bool all = true; for (int v : o->mesh.f[i]) if (o->mesh.v[v].z < 0.5f) all = false; if (all) top = (int)i; }
          deleteFaces(o->mesh, {top}); o->meshRev = nextRev(); assert(setEditMode(f, true) && setSelectMode(f, 1)); f.sel.e = borderEdges(o->mesh);
          assert(fillSelected(f) && f.find(fid)->mesh.f.size() == 6 && f.sel.mode == 1 && !f.sel.e.empty() && near((float)signedVolume(f.find(fid)->mesh), 8.f));
          assert(f.undo() && f.find(fid)->mesh.f.size() == 5 && f.sel.e.size() == 4 && f.redo());
          f.sel.clearSets(); assert(!fillSelected(f) && !bridgeSelected(f));
          Scene t; const uint32_t tid = addPrimitive(t, 3); Object* ot = t.find(tid); Mesh t1 = makeCylinder(8); deleteFaces(t1, {8, 9}); Mesh two = t1; const int off = (int)two.v.size();
          for (auto p : t1.v) { p.z += 3.f; two.v.push_back(p); } for (auto fc : t1.f) { for (int& i : fc) i += off; two.f.push_back(fc); }
          ot->mesh = two; ot->meshRev = nextRev(); assert(setEditMode(t, true) && setSelectMode(t, 1));
          for (const Edge& e : borderEdges(two)) { const float z0 = two.v[e.first].z, z1 = two.v[e.second].z; if ((z0 == 1.f && z1 == 1.f) || (z0 == 2.f && z1 == 2.f)) t.sel.e.insert(e); }
          assert(bridgeSelected(t) && t.find(tid)->mesh.f.size() == 24 && t.sel.mode == 1 && !t.sel.e.empty() && t.undo() && t.find(tid)->mesh.f.size() == 16 && t.sel.e.size() == 16); }
    }

    // ======== 0.14.0 / 0.15.0 ========
    puts("v0.14/0.15 tests...");
    {
        auto grid = [](int n) { Mesh g; for (int y = 0; y <= n; ++y) { for (int x = 0; x <= n; ++x) g.v.push_back({(float)x, (float)y, 0}); }
            for (int y = 0; y < n; ++y) { for (int x = 0; x < n; ++x) { const int a = y * (n + 1) + x; g.f.push_back({a, a + 1, a + n + 2, a + n + 1}); } } return g; };
        Scene c; const uint32_t id = addPrimitive(c, 0); Object* o = c.find(id); o->mesh = grid(3); o->meshRev = nextRev();
        assert(!selectMoreLess(c, true));                                   // not in edit mode
        assert(setEditMode(c, true) && setSelectMode(c, 0) && !selectMoreLess(c, true));   // nothing selected
        c.sel.v = {5};
        assert(selectMoreLess(c, true) && c.sel.v == std::set<int>({1, 4, 5, 6, 9}));      // grows across edges only
        assert(selectMoreLess(c, false) && c.sel.v == std::set<int>({5}));                 // and shrinks back
        assert(selectMoreLess(c, false) == false || c.sel.v.empty());
        // face mode: centre face -> all 9 faces touch its corners; shrinking everything leaves the centre (border vertices go)
        c.sel.clearSets(); assert(setSelectMode(c, 2)); c.sel.f = {4};
        assert(selectMoreLess(c, true) && c.sel.f.size() == 9);
        assert(selectMoreLess(c, false) && c.sel.f == std::set<int>({4}));
        // edge mode: one edge grows to include it and its neighbours
        c.sel.clearSets(); assert(setSelectMode(c, 1)); c.sel.e = {mkEdge(5, 6)};
        assert(selectMoreLess(c, true) && c.sel.e.size() > 1 && c.sel.e.count(mkEdge(5, 6)));
        // closed mesh: selecting everything and shrinking changes nothing (no border); growing everything changes nothing
        Scene k; addPrimitive(k, 0); setEditMode(k, true); setSelectMode(k, 0); selectAllActive(k);
        assert(!selectMoreLess(k, false) && !selectMoreLess(k, true) && k.sel.v.size() == 8);
        k.sel.clearSets(); k.sel.v = {0}; assert(selectMoreLess(k, true) && k.sel.v.size() == 4 && selectMoreLess(k, true) && k.sel.v.size() == 7);
        // ---- join ----
        Scene j; const uint32_t a = addPrimitive(j, 0); const uint32_t b = addPrimitive(j, 0);
        { Object* oa = j.find(a); oa->pos[0] = 1.f; oa->rot[2] = 90.f; oa->scale[0] = oa->scale[1] = oa->scale[2] = 2.f; Object* ob = j.find(b); ob->pos[0] = 5.f; ob->pos[2] = 3.f; ob->rot[2] = 90.f; ob->scale[0] = 3.f; }
        assert(j.selected == b); j.selected = a;
        const size_t d = j.undoDepth(); assert(joinAllObjects(j) == 1 && j.objects.size() == 1 && j.undoDepth() == d + 1 && j.selected == a);
        { const Mesh& jm = j.find(a)->mesh; assert(jm.v.size() == 16 && jm.f.size() == 12 && validMesh(jm) && closedManifold(jm));
          // second cube: local (x,y,z)=(-1,-1,-1) -> scaled (-3,-1,-1) -> rot z 90: (1,-3,-1) -> world + (5,0,3) = (6,-3,2) -> minus active pos (5,-3,2) -> Rz(90)^T = (-3,-5,2) -> / scale 2
          assert(near(jm.v[8].x, -1.5f) && near(jm.v[8].y, -2.5f) && near(jm.v[8].z, 1.f));
          // volumes (local * 2^3): 8 * 8 + cube b world volume 8 * 3 = 24 -> local total = 8 + 24/8 = 11
          assert(near((float)signedVolume(jm), 11.f, 1e-3f)); }
        assert(j.undo() && j.objects.size() == 2 && j.find(a)->mesh.v.size() == 8 && j.find(b) && j.redo() && j.objects.size() == 1);
        assert(joinAllObjects(j) == 0);                                     // single object
        // mirrored object keeps outward normals after joining; edit mode refuses
        Scene m2; const uint32_t p = addPrimitive(m2, 0); const uint32_t q = addPrimitive(m2, 0); m2.find(q)->scale[0] = -1.f; m2.find(q)->pos[0] = 4.f; m2.selected = p;
        assert(joinAllObjects(m2) == 1 && near((float)signedVolume(m2.find(p)->mesh), 16.f, 1e-3f));
        Scene e2; addPrimitive(e2, 0); addPrimitive(e2, 0); setEditMode(e2, true); assert(joinAllObjects(e2) == 0 && e2.objects.size() == 2);
    }

    puts("v0.16 tests...");
    {
        // ---- bevel edges ----
        auto edgeAt = [&](const Mesh& m, int axis, float s1, float s2) {      // cube edge parallel to `axis` at the other two coords (s1, s2)
            for (const auto& e : uniqueEdges(m)) { const Vec3 a = m.v[e.first], b = m.v[e.second]; const float da[3] = {b.x - a.x, b.y - a.y, b.z - a.z}, pa[3] = {a.x, a.y, a.z};
                bool ok = std::fabs(da[axis]) > 1.f; int k = 0; for (int i = 0; i < 3; ++i) { if (i == axis) continue; ok = ok && std::fabs(da[i]) < 1e-6f && near(pa[i], k == 0 ? s1 : s2); ++k; }
                if (ok) return mkEdge(e.first, e.second); }
            assert(false); return Edge{0, 0}; };
        auto chi = [&](const Mesh& m) { int e = 0; assert(closedManifold(m, &e)); return (int)m.v.size() - e + (int)m.f.size(); };
        // one edge of the cube (legs 0.5): 8 - 2 + 4 vertices, 7 faces, volume 8 - w^2 (triangle w^2/2 times length 2)
        { Mesh m = makeCube(); std::vector<int> st; assert(bevelEdges(m, {edgeAt(m, 2, 1.f, 1.f)}, 0.5f, &st) == 1 && st.size() == 1);
          assert(m.v.size() == 10 && m.f.size() == 7 && chi(m) == 2 && near((float)signedVolume(m), 7.75f, 1e-4f) && m.f[st[0]].size() == 4); }
        // all 12 edges: 24 vertices, 6 + 12 + 8 faces, volume 8 - 12 w^2 + 16/3 w^3 (derived by hand: prisms + corner tetrahedra)
        for (float w : {0.5f, 0.25f}) { Mesh m = makeCube(); std::set<Edge> all; for (const auto& e : uniqueEdges(m)) all.insert(mkEdge(e.first, e.second)); assert(all.size() == 12);
          std::vector<int> st; assert(bevelEdges(m, all, w, &st) == 12 && st.size() == 12 && m.v.size() == 24 && m.f.size() == 26 && chi(m) == 2);
          assert(near((float)signedVolume(m), 8.f - 12.f * w * w + 16.f / 3.f * w * w * w, 1e-3f)); checkOutward(m); }
        // the 4 edges of the top face (two selected edges per corner): volume 4(2-w) + 4(1-(1-w)^3)/3
        for (float w : {0.5f, 0.3f}) { Mesh m = makeCube(); std::set<Edge> top{edgeAt(m, 0, 1.f, 1.f), edgeAt(m, 0, -1.f, 1.f), edgeAt(m, 1, 1.f, 1.f), edgeAt(m, 1, -1.f, 1.f)};
          assert(top.size() == 4 && bevelEdges(m, top, w) == 4 && m.v.size() == 12 && m.f.size() == 10 && chi(m) == 2);
          assert(near((float)signedVolume(m), 4.f * (2.f - w) + 4.f * (1.f - std::pow(1.f - w, 3.f)) / 3.f, 1e-3f)); }
        // two opposite parallel edges (valence-3 corners with one selected edge each, no caps)
        { Mesh m = makeCube(); assert(bevelEdges(m, {edgeAt(m, 2, 1.f, 1.f), edgeAt(m, 2, -1.f, -1.f)}, 0.4f) == 2 && chi(m) == 2 && near((float)signedVolume(m), 8.f - 2.f * 0.4f * 0.4f, 1e-4f)); }
        // width far too large is clamped (stays a valid closed mesh with positive volume)
        { Mesh m = makeCube(); std::set<Edge> all; for (const auto& e : uniqueEdges(m)) all.insert(mkEdge(e.first, e.second)); assert(bevelEdges(m, all, 50.f) == 12 && chi(m) == 2 && signedVolume(m) > 0.0); for (const Vec3& p : m.v) assert(std::fabs(p.x) <= 1.0001f && std::fabs(p.y) <= 1.0001f && std::fabs(p.z) <= 1.0001f); }   // clamped points stay on the original edges
        // valence > 3: UV sphere (interior vertices have 4 edges, poles have 16): one ring edge, one meridian edge from a pole, and a whole ring
        { Mesh base = makeUVSphere(16, 8); int pole = -1; for (size_t i = 0; i < base.v.size(); ++i) if (std::fabs(base.v[i].z) > 0.99f) { pole = (int)i; break; } assert(pole >= 0);
          std::map<int, int> val; for (const auto& e : uniqueEdges(base)) { val[e.first]++; val[e.second]++; }
          Edge ring{-1, -1}, mer{-1, -1}; std::set<Edge> ringAll;
          for (const auto& e : uniqueEdges(base)) { const Vec3 a = base.v[e.first], b = base.v[e.second];
              if (val[e.first] == 4 && val[e.second] == 4 && near(a.z, b.z, 1e-5f)) { if (ring.first < 0) ring = mkEdge(e.first, e.second); if (near(a.z, base.v[ring.first].z, 1e-5f)) ringAll.insert(mkEdge(e.first, e.second)); }
              if ((e.first == pole || e.second == pole) && mer.first < 0) mer = mkEdge(e.first, e.second); }
          assert(ring.first >= 0 && mer.first >= 0 && ringAll.size() == 16);
          for (const std::set<Edge>& es : {std::set<Edge>{ring}, std::set<Edge>{mer}, ringAll}) { Mesh m = base; const double v0 = signedVolume(base);
              assert(bevelEdges(m, es, 0.05f) == (int)es.size() && chi(m) == 2 && signedVolume(m) > 0.0 && signedVolume(m) < v0); } }
        // cylinder cap ring: n-gon cap + two side faces per corner
        { Mesh m = makeCylinder(12); std::map<int, int> val; for (const auto& e : uniqueEdges(m)) { val[e.first]++; val[e.second]++; } float zmax = -1e9f; for (const Vec3& p : m.v) zmax = std::max(zmax, p.z);
          std::set<Edge> ringE; for (const auto& e : uniqueEdges(m)) if (near(m.v[e.first].z, zmax) && near(m.v[e.second].z, zmax) && val[e.first] == 3 && val[e.second] == 3) ringE.insert(mkEdge(e.first, e.second));
          assert(ringE.size() == 12); const double v0 = signedVolume(m); assert(bevelEdges(m, ringE, 0.1f) == 12 && chi(m) == 2 && signedVolume(m) < v0 && signedVolume(m) > 0.9 * v0); }
        // refusals leave the mesh untouched: open mesh, edge that does not exist, bad widths, empty set
        { Mesh pl = makePlane(), po = pl; assert(bevelEdges(pl, {mkEdge(0, 1)}, 0.1f) == 0 && sameMesh(pl, po));
          Mesh c = makeCube(), co = c; const Edge e0 = edgeAt(c, 2, 1.f, 1.f);
          assert(bevelEdges(c, {mkEdge(0, 6)}, 0.1f) == 0 && bevelEdges(c, {e0}, 0.f) == 0 && bevelEdges(c, {e0}, -1.f) == 0 && bevelEdges(c, {e0}, std::numeric_limits<float>::quiet_NaN()) == 0 && bevelEdges(c, {}, 0.1f) == 0 && sameMesh(c, co)); }
        // scene level: one undo step, vertex selection converts to edges, selection ends on the strips, wrong mode/object refused
        { Scene s; addPrimitive(s, 0); assert(!bevelSelectedEdges(s, 0.2f)); setEditMode(s, true); setSelectMode(s, 1); assert(!bevelSelectedEdges(s, 0.2f));
          s.sel.clearSets(); const Mesh& m0 = s.find(s.selected)->mesh; s.sel.e = {edgeAt(m0, 2, 1.f, 1.f)}; const size_t d = s.undoDepth();
          assert(bevelSelectedEdges(s, 0.2f) && s.undoDepth() == d + 1 && s.find(s.selected)->mesh.f.size() == 7 && s.sel.e.size() == 4);
          assert(s.undo() && s.find(s.selected)->mesh.f.size() == 6 && s.redo() && s.find(s.selected)->mesh.f.size() == 7);
          Scene v; addPrimitive(v, 0); setEditMode(v, true); setSelectMode(v, 0); selectAllActive(v);
          assert(bevelSelectedEdges(v, 0.2f) && v.find(v.selected)->mesh.f.size() == 26 && near((float)signedVolume(v.find(v.selected)->mesh), 8.f - 12.f * 0.04f + 16.f / 3.f * 0.008f, 1e-3f)); }
    }

    puts("v0.17 tests...");
    {
        // ---- edge slide ----
        auto chi = [&](const Mesh& m) { int e = 0; assert(closedManifold(m, &e)); return (int)m.v.size() - e + (int)m.f.size(); };
        // cube + loop cut across the vertical edges at z = 0, then slide the new ring
        auto cutCube = [&](Mesh& m, std::set<Edge>& ring) { Edge st{-1, -1}; for (const auto& e : uniqueEdges(m)) if (near(m.v[e.first].x, 1.f) && near(m.v[e.first].y, 1.f) && near(m.v[e.second].x, 1.f) && near(m.v[e.second].y, 1.f)) st = mkEdge(e.first, e.second);
            assert(st.first >= 0 && loopCut(m, st, 0.5f, &ring) && ring.size() == 4); };
        for (float tt : {0.5f, -0.5f, 0.25f}) { Mesh m = makeCube(); std::set<Edge> ring; cutCube(m, ring); std::set<int> ids; for (const Edge& e : ring) { ids.insert(e.first); ids.insert(e.second); }
            std::set<int> moved; assert(edgeSlide(m, ring, tt, &moved) == 4 && moved == ids);
            float z0 = m.v[*ids.begin()].z; assert(near(std::fabs(z0), std::fabs(tt)));
            for (int i : ids) assert(near(m.v[i].z, z0));                       // whole ring on the SAME side
            assert(chi(m) == 2 && near((float)signedVolume(m), 8.f, 1e-4f)); checkOutward(m); }
        { Mesh a = makeCube(), b = makeCube(); std::set<Edge> ra, rb; cutCube(a, ra); cutCube(b, rb); assert(edgeSlide(a, ra, 0.5f) == 4 && edgeSlide(b, rb, -0.5f) == 4);
          int i = ra.begin()->first; assert(a.v[i].z * b.v[i].z < 0.f); }                    // opposite signs go to opposite sides
        // UV sphere ring (all vertices valence 4): every vertex moves along its meridian towards the same neighbouring ring
        { Mesh m = makeUVSphere(16, 8); std::map<int, int> val; for (const auto& e : uniqueEdges(m)) { val[e.first]++; val[e.second]++; }
          std::set<Edge> ring; float z = 0.f; bool got = false;
          for (const auto& e : uniqueEdges(m)) if (val[e.first] == 4 && val[e.second] == 4 && near(m.v[e.first].z, m.v[e.second].z, 1e-5f)) { if (!got) { z = m.v[e.first].z; got = true; } if (near(m.v[e.first].z, z, 1e-5f)) ring.insert(mkEdge(e.first, e.second)); }
          assert(ring.size() == 16); Mesh o = m; assert(edgeSlide(m, ring, 0.3f) == 16);
          std::set<int> ids; for (const Edge& e : ring) { ids.insert(e.first); ids.insert(e.second); } const float d0 = m.v[*ids.begin()].z - o.v[*ids.begin()].z; assert(std::fabs(d0) > 1e-3f);
          for (int i : ids) assert(near(m.v[i].z - o.v[i].z, d0, 1e-5f));
          assert(sameMesh(Mesh{o.v, m.f}, Mesh{o.v, o.f}) && chi(m) == 2 && signedVolume(m) > 0.0); }
        // open chain on a 3x3 grid (4x4 vertices, z = 0, CCW from +Z): middle row y = 1, vertex index = j*4 + i
        { Mesh g; for (int j = 0; j < 4; ++j) for (int i = 0; i < 4; ++i) g.v.push_back({(float)i, (float)j, 0.f});
          for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) g.f.push_back({j * 4 + i, j * 4 + i + 1, (j + 1) * 4 + i + 1, (j + 1) * 4 + i});
          std::set<Edge> row{mkEdge(4, 5), mkEdge(5, 6), mkEdge(6, 7)};
          Mesh up = g; assert(edgeSlide(up, row, 0.5f) == 4); for (int i = 4; i < 8; ++i) assert(near(up.v[i].y, 1.5f) && near(up.v[i].x, g.v[i].x));
          Mesh dn = g; assert(edgeSlide(dn, row, -0.5f) == 4); for (int i = 4; i < 8; ++i) assert(near(dn.v[i].y, 0.5f));
          assert(up.f == g.f && validMesh(up));                                 // topology untouched
          // a border chain can only slide inwards
          std::set<Edge> border{mkEdge(0, 1), mkEdge(1, 2)}; Mesh b = g; assert(edgeSlide(b, border, -0.5f) == 0 && sameMesh(b, g)); assert(edgeSlide(b, border, 0.5f) == 3 && near(b.v[1].y, 0.5f));
          // refusals: bad factor, empty, branching (3 selected edges at one vertex), edge not in the mesh
          Mesh c = g; assert(edgeSlide(c, row, 0.f) == 0 && edgeSlide(c, row, 1.f) == 0 && edgeSlide(c, row, -1.f) == 0 && edgeSlide(c, row, std::numeric_limits<float>::quiet_NaN()) == 0 && edgeSlide(c, {}, 0.5f) == 0);
          assert(edgeSlide(c, {mkEdge(5, 4), mkEdge(5, 6), mkEdge(5, 1)}, 0.5f) == 0 && edgeSlide(c, {mkEdge(4, 5), mkEdge(5, 6), mkEdge(5, 9)}, 0.5f) == 0 && edgeSlide(c, {mkEdge(0, 15)}, 0.5f) == 0 && sameMesh(c, g)); }
        // scene level: one undo step, selection survives, vertex-mode selection converts to edges
        { Scene s; addPrimitive(s, 0); setEditMode(s, true); setSelectMode(s, 1); s.sel.clearSets(); Mesh& m0 = s.find(s.selected)->mesh; std::set<Edge> ring; Edge st{-1, -1};
          for (const auto& e : uniqueEdges(m0)) if (near(m0.v[e.first].x, 1.f) && near(m0.v[e.first].y, 1.f) && near(m0.v[e.second].x, 1.f) && near(m0.v[e.second].y, 1.f)) st = mkEdge(e.first, e.second);
          assert(loopCutSelected(s, 0.5f) == false);                           // nothing selected yet
          s.sel.e = {st}; assert(loopCutSelected(s, 0.5f) && s.sel.e.size() == 4);
          const size_t d = s.undoDepth(); const SelState before = s.sel; const Mesh m1 = s.find(s.selected)->mesh;
          assert(edgeSlideSelected(s, 0.5f) && s.undoDepth() == d + 1 && s.sel.e == before.e && !sameMesh(s.find(s.selected)->mesh, m1));
          assert(s.undo() && sameMesh(s.find(s.selected)->mesh, m1) && s.redo() && !sameMesh(s.find(s.selected)->mesh, m1));
          Scene n; addPrimitive(n, 0); assert(!edgeSlideSelected(n, 0.5f)); setEditMode(n, true); n.sel.clearSets(); assert(!edgeSlideSelected(n, 0.5f)); }
    }

    puts("v0.18/0.19 tests...");
    {
        auto chi = [&](const Mesh& m) { int e = 0; assert(closedManifold(m, &e)); return (int)m.v.size() - e + (int)m.f.size(); };
        // ---- bridge twist: two separate rings, hexagons; the partner of A[0] moves by `twist` vertices (60 degrees each) ----
        {   const int n = 6; Mesh base; for (int i = 0; i < n; ++i) { float a = 6.2831853f * i / n; base.v.push_back({std::cos(a), std::sin(a), 0}); }
            for (int i = 0; i < n; ++i) { float a = 6.2831853f * i / n; base.v.push_back({std::cos(a), std::sin(a), 1}); }
            std::set<Edge> es; for (int i = 0; i < n; ++i) { es.insert(mkEdge(i, (i + 1) % n)); es.insert(mkEdge(n + i, n + (i + 1) % n)); }
            auto partnerAngle = [&](const Mesh& m) { for (const auto& q : m.f) for (size_t k = 0; k < 4; ++k) if (q[k] == 0) { for (int nb : {q[(k + 1) % 4], q[(k + 3) % 4]}) if (nb >= n) return std::atan2(m.v[nb].y, m.v[nb].x); } return 99.f; };
            Mesh m0 = base; assert(bridgeLoops(m0, es) == n && near(partnerAngle(m0), 0.f, 1e-4f));
            const float step = 6.2831853f / n;
            for (int tw : {1, 2, -1, 7}) { Mesh m = base; assert(bridgeLoops(m, es, nullptr, tw) == n && m.f.size() == (size_t)n && validMesh(m));
                float d = partnerAngle(m); const int k = ((tw % n) + n) % n; float want = k * step; if (want > 3.14159f) want -= 6.2831853f;
                assert(near(std::fabs(d), std::fabs(want), 1e-3f) && std::fabs(d) > 1e-3f); }
            Mesh a = base, b = base; assert(bridgeLoops(a, es, nullptr, 6) == n && bridgeLoops(b, es, nullptr, 0) == n && sameMesh(a, b));   // full turn = no twist
            Mesh c = base, d = base; assert(bridgeLoops(c, es, nullptr, -1) == n && bridgeLoops(d, es, nullptr, 5) == n && sameMesh(c, d)); }   // -1 == n-1
        // twisted bridge between two open tubes stays a clean manifold tube (chi = 0, every edge <= 2 faces)
        for (int tw = 0; tw < 8; ++tw) { Mesh t1 = makeCylinder(8); deleteFaces(t1, {8, 9}); Mesh m = t1; const int off = (int)m.v.size();
            for (auto p : t1.v) { p.z += 3.f; m.v.push_back(p); } for (auto f : t1.f) { for (int& i : f) i += off; m.f.push_back(f); }
            std::set<Edge> es; for (const auto& kv : detail::edgeFaces(m)) if (kv.second.size() == 1) { const float z0 = m.v[kv.first.first].z, z1 = m.v[kv.first.second].z; if ((z0 == 1.f && z1 == 1.f) || (z0 == 2.f && z1 == 2.f)) es.insert(kv.first); }
            assert(es.size() == 16 && bridgeLoops(m, es, nullptr, tw) == 8); int cnt1 = 0; for (const auto& kv : detail::edgeFaces(m)) { assert(kv.second.size() <= 2); if (kv.second.size() == 1) ++cnt1; }
            assert(cnt1 == 16); }
        // ---- sharp edges ----
        { Mesh c = makeCube(); assert(sharpEdges(c, 30.f).size() == 12 && sharpEdges(c, 89.f).size() == 12 && sharpEdges(c, 90.f).empty() && sharpEdges(c, 100.f).empty());
          assert(sharpEdges(c, -1.f).empty() && sharpEdges(c, 180.f).empty() && sharpEdges(c, std::numeric_limits<float>::quiet_NaN()).empty());
          assert(sharpEdges(makePlane(), 10.f).empty());                                  // border edges are never sharp
          Mesh cut = makeCube(); Edge st{-1, -1}; for (const auto& e : uniqueEdges(cut)) if (near(cut.v[e.first].x, 1.f) && near(cut.v[e.first].y, 1.f) && near(cut.v[e.second].x, 1.f) && near(cut.v[e.second].y, 1.f)) st = mkEdge(e.first, e.second);
          assert(loopCut(cut, st, 0.5f) && sharpEdges(cut, 30.f).size() == 16);          // 8 horizontal + 4 vertical edges split in two
          Mesh sp = makeUVSphere(16, 8); const size_t s30 = sharpEdges(sp, 30.f).size(), s10 = sharpEdges(sp, 10.f).size(); assert(s30 == 0 && s10 > 0 && s10 <= uniqueEdges(sp).size());
          // scene level: switches to edge mode, selection only (no undo step), refuses outside edit mode or when nothing is sharp
          Scene s; addPrimitive(s, 0); assert(!selectSharpEdgesActive(s, 30.f)); setEditMode(s, true); const size_t d = s.undoDepth();
          assert(selectSharpEdgesActive(s, 30.f) && s.sel.mode == 1 && s.sel.e.size() == 12 && s.undoDepth() == d && !selectSharpEdgesActive(s, 95.f)); }
        // scene bridge with twist: one undo step, refuses like before
        { Scene s; addPrimitive(s, 0); setEditMode(s, true); assert(!bridgeSelectedTwist(s, 1)); }
        // ---- Bevel modifier ----
        { Modifier bv; bv.type = kBevel; bv.factor = 0.25f; bv.angle = 30.f; assert(validModifier(bv));
          Modifier bad = bv; bad.factor = 0.f; assert(!validModifier(bad)); bad = bv; bad.factor = -1.f; assert(!validModifier(bad)); bad = bv; bad.angle = 0.f; assert(!validModifier(bad)); bad = bv; bad.angle = 180.f; assert(!validModifier(bad));
          Mesh c = makeCube(); Mesh r = applyModifier(c, bv); const float w = 0.25f;
          assert(r.v.size() == 24 && r.f.size() == 26 && chi(r) == 2 && near((float)signedVolume(r), 8.f - 12.f * w * w + 16.f / 3.f * w * w * w, 1e-3f));
          Modifier hi = bv; hi.angle = 100.f; assert(sameMesh(applyModifier(c, hi), c));      // nothing sharper than 100 degrees: pass-through
          assert(sameMesh(applyModifier(makePlane(), bv), makePlane()));                     // open mesh: pass-through, no crash
          Mesh cyl = makeCylinder(12); Mesh rc = applyModifier(cyl, bv); assert(rc.f.size() > cyl.f.size() && chi(rc) == 2);   // cap rims bevel, smooth sides stay
          // an open box (cube minus top): the edges that touch the open border are skipped, bottom edges still bevel
          Mesh box = makeCube(); int top = -1; for (size_t i = 0; i < box.f.size(); ++i) { Vec3 n = faceNormal(box, box.f[i]); if (n.z > 0.9f) top = (int)i; } assert(top >= 0 && deleteFaces(box, {top}));
          Mesh rb = applyModifier(box, bv); assert(validMesh(rb) && rb.f.size() == box.f.size() + 4); for (const auto& kv : detail::edgeFaces(rb)) assert(kv.second.size() <= 2);   // 4 bottom edges bevel, the border-touching ones are skipped
          // scene: add defaults, stack evaluation, base mesh untouched, undo/redo, project round trip, old-build rejection is by type range
          Scene sc; uint32_t id = addPrimitive(sc, 0); assert(addModifier(sc, kBevel) && sc.find(id)->mods.size() == 1);
          assert(sc.find(id)->mods[0].type == kBevel && near(sc.find(id)->mods[0].factor, 0.1f) && near(sc.find(id)->mods[0].angle, 30.f));
          { const Mesh& dm = displayMesh(*sc.find(id)); assert(dm.v.size() == 24 && dm.f.size() == 26 && sc.find(id)->mesh.v.size() == 8); }
          assert(sc.undo() && sc.find(id)->mods.empty() && sc.redo() && sc.find(id)->mods.size() == 1);
          assert(!addModifier(sc, 10));
          // Apply bakes it into the base mesh
          assert(applyModifierAt(sc, 0) && sc.find(id)->mods.empty() && sc.find(id)->mesh.f.size() == 26);
          const std::string path = "/tmp/atlas_bevel_test.atlas"; Scene s2; uint32_t i2 = addPrimitive(s2, 0); assert(addModifier(s2, kBevel));
          assert(saveProject(s2, path)); Scene s3; assert(loadProject(s3, path) && s3.objects.size() == 1 && s3.objects[0].mods.size() == 1 && s3.objects[0].mods[0].type == kBevel && near(s3.objects[0].mods[0].factor, 0.1f)); (void)i2; }
    }

    puts("v0.20/0.21 tests...");
    {
        // ---- proportional editing ----
        Mesh strip; for (int i = 0; i <= 5; ++i) { strip.v.push_back({(float)i, 0, 0}); strip.v.push_back({(float)i, 1, 0}); }
        for (int i = 0; i < 5; ++i) strip.f.push_back({2 * i, 2 * i + 2, 2 * i + 3, 2 * i + 1});
        std::vector<char> m0(strip.v.size(), 0); m0[0] = m0[1] = 1;                     // the two vertices at x = 0
        assert(near(falloffWeight(1, 1.f, 2.f), 0.5f) && near(falloffWeight(0, 1.f, 2.f), 0.5f) && near(falloffWeight(2, 1.f, 2.f), 0.25f) && near(falloffWeight(3, 1.f, 2.f), 1.f));
        assert(falloffWeight(0, 2.f, 2.f) == 0.f && falloffWeight(1, 5.f, 2.f) == 0.f && falloffWeight(0, 0.f, 0.f) == 0.f && falloffWeight(0, 0.f, -1.f) == 0.f);
        { auto w = proportionalWeights(strip, m0, 4.f, 1, false); assert(near(w[0], 1.f) && near(w[1], 1.f) && near(w[2], 0.75f) && near(w[4], 0.5f) && near(w[6], 0.25f) && near(w[8], 0.f) && near(w[10], 0.f)); }
        { auto w = proportionalWeights(strip, m0, 4.f, 0, false); assert(near(w[2], 0.84375f, 1e-5f) && near(w[4], 0.5f)); }
        { auto w = proportionalWeights(strip, m0, 4.f, 2, false); assert(near(w[2], 0.5625f, 1e-5f)); }
        { auto w = proportionalWeights(strip, m0, 4.f, 3, false); assert(near(w[2], 1.f) && near(w[6], 1.f) && near(w[8], 0.f)); }
        { auto w = proportionalWeights(strip, m0, 0.f, 0, false); for (size_t i = 0; i < w.size(); ++i) assert(near(w[i], i < 2 ? 1.f : 0.f)); }          // radius 0: selection only
        { auto w = proportionalWeights(strip, m0, std::numeric_limits<float>::quiet_NaN(), 0, false); assert(near(w[0], 1.f) && near(w[2], 0.f)); }
        { auto w = proportionalWeights(strip, std::vector<char>(strip.v.size(), 0), 4.f, 0, false); for (float f : w) assert(f == 0.f); }                  // nothing selected: nothing moves
        // connected: an L-shaped strip. Straight-line distance cuts the corner, the path along the mesh does not.
        { Mesh L; L.v = {{0,0,0},{1,0,0},{2,0,0},{2,1,0},{2,2,0},{1,2,0},{0,2,0}}; for (int i = 0; i < 6; ++i) L.f.push_back({i, i + 1, i + 1});   // degenerate faces: only the edge list matters here
          std::vector<char> mk(L.v.size(), 0); mk[0] = 1;
          auto we = proportionalWeights(L, mk, 3.f, 1, false), wc = proportionalWeights(L, mk, 3.f, 1, true);
          assert(near(we[6], 1.f / 3.f, 1e-4f) && near(wc[6], 0.f) && near(wc[2], 1.f / 3.f, 1e-4f) && near(wc[1], 2.f / 3.f, 1e-4f) && near(we[1], wc[1]));
          // two islands: the far island is close in space but unreachable
          Mesh two = strip; const int off = (int)two.v.size(); for (auto p : strip.v) { p.y += 0.5f; p.z += 0.0f; two.v.push_back(p); } for (auto f : strip.f) { for (int& i : f) i += off; two.f.push_back(f); }
          std::vector<char> mt(two.v.size(), 0); mt[0] = mt[1] = 1; auto wa = proportionalWeights(two, mt, 4.f, 1, false), wb = proportionalWeights(two, mt, 4.f, 1, true);
          assert(wa[off] > 0.5f && near(wb[off], 0.f) && near(wb[2], wa[2])); }
        // weighted ops: weights == mask reproduce the old behaviour exactly; weight scales the effect
        { std::vector<float> wm(strip.v.size(), 0.f); wm[0] = wm[1] = 1.f; Mesh a = strip, b = strip;
          moveVertices(a, m0, {0, 0, 2}); moveVerticesW(b, wm, {0, 0, 2}); assert(sameMesh(a, b));
          a = strip; b = strip; rotateVertices(a, m0, 2, 30.f); rotateVerticesW(b, m0, wm, 2, 30.f); assert(sameMesh(a, b));
          a = strip; b = strip; scaleVertices(a, m0, {2, 1, 1}); scaleVerticesW(b, m0, wm, {2, 1, 1}); assert(sameMesh(a, b));
          auto w = proportionalWeights(strip, m0, 4.f, 1, false); Mesh p = strip; moveVerticesW(p, w, {0, 0, 4}); assert(near(p.v[0].z, 4.f) && near(p.v[2].z, 3.f) && near(p.v[4].z, 2.f) && near(p.v[8].z, 0.f));
          Mesh r = strip; rotateVerticesW(r, m0, w, 2, 90.f); const Vec3 c{0, 0.5f, 0}; for (size_t i = 0; i < r.v.size(); ++i) { assert(near(length(r.v[i] - c), length(strip.v[i] - c), 1e-4f)); }   // rotation keeps the distance to the pivot
          Mesh half = strip; std::vector<float> wh(strip.v.size(), 0.f); wh[4] = 0.5f; rotateVerticesW(half, m0, wh, 2, 90.f);                      // weight .5 = 45 degrees
          { Vec3 q = strip.v[4] - c; float a45 = 0.78539816f; assert(near(half.v[4].x, c.x + q.x * std::cos(a45) - q.y * std::sin(a45), 1e-4f) && near(half.v[4].y, c.y + q.x * std::sin(a45) + q.y * std::cos(a45), 1e-4f)); }
          Mesh sc = strip; scaleVerticesW(sc, m0, wh, {3, 1, 1}); assert(near(sc.v[4].x, 2.f * 2.f, 1e-4f) && near(sc.v[2].x, 1.f) && near(sc.v[4].y, strip.v[4].y));   // k = 1 + (3-1)*.5 = 2 about x = 0
          assert(!moveVerticesW(a, std::vector<float>(a.v.size(), 0.f), {1, 1, 1})); }
        // ---- box select ----
        { const int W = 800, H = 600; const ViewInfo vw = makeView({0, -10, 0}, {0, 0, 0}, 0.9f, W, H);
          float px, py; assert(projectToScreen(vw, {0, 0, 0}, &px, &py) && near(px, W / 2.f, 1e-3f) && near(py, H / 2.f, 1e-3f));
          assert(projectToScreen(vw, {1, 0, 0}, &px, &py) && px > W / 2.f && near(py, H / 2.f, 1e-3f) && projectToScreen(vw, {0, 0, 1}, &px, &py) && py < H / 2.f && near(px, W / 2.f, 1e-3f));   // +x right, +z up
          assert(!projectToScreen(vw, {0, -20, 0}, &px, &py));                                                     // behind the camera
          { const float yaw = 0.3f, pitch = 0.4f, dist = 7.f, fovY = 0.9f; const Vec3 target{1, 2, 0.5f};                                       // Renderer's Camera::eye()/basis() formulas, copied (GL code can't build on the host)
            const Vec3 eye = target + Vec3{dist * std::cos(pitch) * std::cos(yaw), dist * std::cos(pitch) * std::sin(yaw), dist * std::sin(pitch)};
            const Vec3 f = normalized(target - eye), r = normalized(cross(f, Vec3{0, 0, 1})), u = cross(r, f);
            const ViewInfo v2 = makeView(eye, target, fovY, W, H); assert(near(length(v2.f - f), 0.f, 1e-5f) && near(length(v2.r - r), 0.f, 1e-5f) && near(length(v2.u - u), 0.f, 1e-5f));
            float qx, qy; assert(projectToScreen(v2, target, &qx, &qy) && near(qx, W / 2.f, 1e-2f) && near(qy, H / 2.f, 1e-2f));
            const float sx = 123.f, sy = 456.f, nx = 2.f * sx / W - 1.f, ny = 1.f - 2.f * sy / H, t = std::tan(fovY * 0.5f);                         // Renderer::screenRay
            const Vec3 dir = normalized(f + r * (nx * t * ((float)W / H)) + u * (ny * t));
            assert(projectToScreen(v2, eye + dir * 5.f, &qx, &qy) && near(qx, sx, 1e-2f) && near(qy, sy, 1e-2f)); }   // projecting a screen-ray point returns the pixel
          Scene s; addPrimitive(s, 0); setEditMode(s, true); setSelectMode(s, 0); s.sel.clearSets(); const size_t d0 = s.undoDepth();
          // whole screen: front 4 vertices (the back ones are hidden behind the front face) / x-ray: all 8
          assert(boxSelectActive(s, vw, 0, 0, W, H, 0, false) && s.sel.v.size() == 4 && s.undoDepth() == d0);
          for (int v : s.sel.v) assert(s.find(s.selected)->mesh.v[v].y < 0.f);
          assert(boxSelectActive(s, vw, W, H, 0, 0, 0, true) && s.sel.v.size() == 8);                              // corners given in any order
          // upper-left quadrant: 1 visible vertex, 2 with x-ray (front + back share the pixel area)
          assert(boxSelectActive(s, vw, 0, 0, W / 2.f, H / 2.f, 0, false) && s.sel.v.size() == 1 && boxSelectActive(s, vw, 0, 0, W / 2.f, H / 2.f, 0, true) && s.sel.v.size() == 2);
          // add / subtract
          assert(boxSelectActive(s, vw, 0, 0, W / 2.f, H / 2.f, 0, false) && boxSelectActive(s, vw, W / 2.f, 0, W, H / 2.f, 1, false) && s.sel.v.size() == 2);
          assert(boxSelectActive(s, vw, 0, 0, W / 2.f, H / 2.f, 2, false) && s.sel.v.size() == 1 && !boxSelectActive(s, vw, 0, 0, 1, 1, 2, false) && s.sel.v.size() == 1);   // subtract with an empty box: false, nothing changes
          assert(boxSelectActive(s, vw, 0, 0, 1, 1, 0, false) && s.sel.v.empty());                                  // replace with an empty box clears
          s.sel.v = {0}; assert(!boxSelectActive(s, vw, 0, 0, 1, 1, 1, false) && s.sel.v.size() == 1);              // add with no hit: unchanged, false
          // edge mode: front face edges only (both ends visible, midpoint visible)
          setSelectMode(s, 1); s.sel.clearSets(); assert(boxSelectActive(s, vw, 0, 0, W, H, 0, false) && s.sel.e.size() == 4 && boxSelectActive(s, vw, 0, 0, W, H, 0, true) && s.sel.e.size() == 12);   // on-axis camera: only the front face edges are visible
          // face mode: only the front face centroid is visible near the centre; x-ray also gets the back one
          setSelectMode(s, 2); s.sel.clearSets(); assert(boxSelectActive(s, vw, W / 2.f - 20, H / 2.f - 20, W / 2.f + 20, H / 2.f + 20, 0, false) && s.sel.f.size() == 1);
          assert(boxSelectActive(s, vw, W / 2.f - 20, H / 2.f - 20, W / 2.f + 20, H / 2.f + 20, 0, true) && s.sel.f.size() == 2);
          // outside edit mode, bad op, NaN rectangle
          setEditMode(s, false); assert(!boxSelectActive(s, vw, 0, 0, W, H, 0, true)); setEditMode(s, true);
          assert(!boxSelectActive(s, vw, 0, 0, W, H, 3, true) && !boxSelectActive(s, vw, 0, 0, std::numeric_limits<float>::quiet_NaN(), H, 0, true)); }
    }

    puts("v0.22/0.23 tests...");
    {
        auto chi = [&](const Mesh& m) { int e = 0; assert(closedManifold(m, &e)); return (int)m.v.size() - e + (int)m.f.size(); };
        // ---- triangulate ----
        { Mesh c = makeCube(); std::set<int> all; for (size_t i = 0; i < c.f.size(); ++i) all.insert((int)i); std::vector<int> mk;
          assert(triangulateFaces(c, all, &mk) == 6 && c.f.size() == 12 && c.v.size() == 8 && mk.size() == 12 && chi(c) == 2 && near((float)signedVolume(c), 8.f)); for (const auto& f : c.f) assert(f.size() == 3); checkOutward(c);
          Mesh one = makeCube(); assert(triangulateFaces(one, {2}, &mk) == 1 && one.f.size() == 7 && mk.size() == 2 && chi(one) == 2 && near((float)signedVolume(one), 8.f));
          Mesh again = c; assert(triangulateFaces(again, {0, 1, 2}) == 0 && sameMesh(again, c));                    // triangles are left alone
          Mesh bad = makeCube(); assert(triangulateFaces(bad, {-1, 99}) == 0 && sameMesh(bad, makeCube()));
          // concave quad (dart): the two triangles must cover exactly the dart area (1.0, shoelace), no overlap
          Mesh d; d.v = {{0, 0, 0}, {2, 0, 0}, {0.5f, 0.5f, 0}, {0, 2, 0}}; d.f = {{0, 1, 2, 3}}; assert(triangulateFaces(d, {0}) == 1 && d.f.size() == 2);
          float area = 0; for (const auto& f : d.f) { Vec3 nn = faceNormal(d, f); assert(nn.z > 0.f); area += faceArea(d, f); } assert(near(area, 1.0f, 1e-4f)); }
        // ---- poke ----
        { for (float off : {0.5f, 0.f, -0.5f}) { Mesh c = makeCube(); std::set<int> all; for (size_t i = 0; i < c.f.size(); ++i) all.insert((int)i); std::vector<int> mk;
              assert(pokeFaces(c, all, off, &mk) == 6 && c.v.size() == 14 && c.f.size() == 24 && mk.size() == 24 && chi(c) == 2);
              assert(near((float)signedVolume(c), 8.f + 6.f * (4.f * off / 3.f), 1e-3f)); }                                // 6 pyramids of base 4 and height `off`
          Mesh one = makeCube(); std::vector<int> mk; assert(pokeFaces(one, {0}, 1.f, &mk) == 1 && one.v.size() == 9 && one.f.size() == 9 && mk.size() == 4 && chi(one) == 2 && near((float)signedVolume(one), 8.f + 4.f / 3.f, 1e-3f));
          Mesh pn = makePlane(); assert(pokeFaces(pn, {0}, 0.3f) == 1 && pn.f.size() == 4 && pn.v.size() == 5 && near(pn.v[4].z, 0.3f, 1e-5f));   // apex along the (+Z) normal
          Mesh nan = makeCube(); assert(pokeFaces(nan, {0}, std::numeric_limits<float>::quiet_NaN()) == 0 && sameMesh(nan, makeCube()));
          Mesh tri; tri.v = {{0, 0, 0}, {3, 0, 0}, {0, 3, 0}}; tri.f = {{0, 1, 2}}; assert(pokeFaces(tri, {0}, 0.f) == 1 && tri.f.size() == 3 && near(tri.v[3].x, 1.f) && near(tri.v[3].y, 1.f)); }   // centroid of a triangle
        // scene level: one undo step, selection = the new triangles, refuses without a face selection
        { Scene s; addPrimitive(s, 0); setEditMode(s, true); setSelectMode(s, 2); s.sel.clearSets(); assert(!triangulateSelectedFaces(s) && !pokeSelectedFaces(s, 0.5f));
          s.sel.f = {0, 1}; const size_t d = s.undoDepth(); assert(triangulateSelectedFaces(s) && s.undoDepth() == d + 1 && s.find(s.selected)->mesh.f.size() == 8 && s.sel.f.size() == 4);
          assert(s.undo() && s.find(s.selected)->mesh.f.size() == 6 && s.redo() && s.find(s.selected)->mesh.f.size() == 8);
          Scene p; addPrimitive(p, 0); setEditMode(p, true); setSelectMode(p, 2); p.sel.clearSets(); p.sel.f = {3}; assert(pokeSelectedFaces(p, 0.5f) && p.find(p.selected)->mesh.f.size() == 9 && p.sel.f.size() == 4);
          Scene v; addPrimitive(v, 0); setEditMode(v, true); setSelectMode(v, 0); selectAllActive(v); assert(pokeSelectedFaces(v, 0.5f) && v.find(v.selected)->mesh.f.size() == 24); }   // vertex selection converts to faces
        // ---- recalculate normals ----
        { Mesh c = makeCube(); const Mesh good = c; flipFaces(c, {0, 3}); assert(signedVolume(c) != signedVolume(good) || !sameMesh(c, good));
          assert(recalcNormals(c) == 2 && chi(c) == 2 && near((float)signedVolume(c), 8.f)); checkOutward(c);
          Mesh all = makeCube(); std::vector<int> every; for (size_t i = 0; i < all.f.size(); ++i) every.push_back((int)i); flipFaces(all, every); assert(signedVolume(all) < 0.0);
          assert(recalcNormals(all) == 6 && near((float)signedVolume(all), 8.f)); checkOutward(all);
          assert(recalcNormals(all) == 0);                                                                       // already right: nothing changes
          Mesh in = makeCube(); assert(recalcNormals(in, true) == 6 && near((float)signedVolume(in), -8.f));     // inside = inward
          Mesh sp = makeUVSphere(16, 8); flipFaces(sp, {0, 5, 17, 40, 41}); assert(recalcNormals(sp) == 5 && signedVolume(sp) > 0.0 && chi(sp) == 2); checkOutward(sp);
          // two separate cubes, each broken differently: each is fixed on its own
          Mesh a = makeCube(), b = makeCube(); for (auto& p : b.v) p.x += 5.f; Mesh two = a; const int off = (int)two.v.size(); for (auto p : b.v) two.v.push_back(p); for (auto f : b.f) { for (int& i : f) i += off; two.f.push_back(f); }
          std::vector<int> inv; for (size_t i = 6; i < 12; ++i) inv.push_back((int)i); flipFaces(two, inv); flipFaces(two, {1}); assert(recalcNormals(two) == 7 && near((float)signedVolume(two), 16.f)); { int e = 0; assert(closedManifold(two, &e)); }
          // open grid with one reversed quad: becomes consistent, no crash, nothing flipped as a whole
          Mesh g; for (int j = 0; j < 4; ++j) for (int i = 0; i < 4; ++i) g.v.push_back({(float)i, (float)j, 0.f}); for (int j = 0; j < 3; ++j) for (int i = 0; i < 3; ++i) g.f.push_back({j * 4 + i, j * 4 + i + 1, (j + 1) * 4 + i + 1, (j + 1) * 4 + i});
          Mesh g2 = g; flipFaces(g2, {4}); assert(recalcNormals(g2) == 1);
          for (const auto& f : g2.f) assert(faceNormal(g2, f).z > 0.f);
          // an OPEN box turned completely inside out is already consistent: only closed surfaces are oriented by volume, so it is left alone
          { Mesh ob = makeCube(); int tp = -1; for (size_t i = 0; i < ob.f.size(); ++i) if (faceNormal(ob, ob.f[i]).z > 0.9f) tp = (int)i; assert(tp >= 0 && deleteFaces(ob, {tp}));
            std::vector<int> ev; for (size_t i = 0; i < ob.f.size(); ++i) ev.push_back((int)i); flipFaces(ob, ev); const Mesh before = ob; assert(recalcNormals(ob) == 0 && sameMesh(ob, before)); }
          Mesh empty; assert(recalcNormals(empty) == 0);
          // scene level
          Scene s; addPrimitive(s, 0); setEditMode(s, true); assert(!recalcNormalsActive(s, false));              // already fine: refused, no undo step
          { Mesh& m = s.find(s.selected)->mesh; flipFaces(m, {2}); } const size_t d = s.undoDepth(); assert(recalcNormalsActive(s, false) && s.undoDepth() == d + 1); checkOutward(s.find(s.selected)->mesh);
          assert(s.undo() && s.redo() && near((float)signedVolume(s.find(s.selected)->mesh), 8.f)); }
        // ---- boundary / non-manifold / random ----
        { assert(boundaryEdges(makeCube()).empty() && nonManifoldEdges(makeCube()).empty() && boundaryEdges(makePlane()).size() == 4 && nonManifoldEdges(makePlane()).size() == 4);
          Mesh box = makeCube(); int top = -1; for (size_t i = 0; i < box.f.size(); ++i) if (faceNormal(box, box.f[i]).z > 0.9f) top = (int)i; assert(top >= 0 && deleteFaces(box, {top}) && boundaryEdges(box).size() == 4);
          Mesh fin; fin.v = {{0, 0, 0}, {1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}}; fin.f = {{0, 1, 2}, {1, 0, 3}, {0, 1, 4}};     // three faces share edge (0,1)
          assert(nonManifoldEdges(fin).count(mkEdge(0, 1)) == 1 && boundaryEdges(fin).count(mkEdge(0, 1)) == 0 && nonManifoldEdges(fin).size() == 7 && boundaryEdges(fin).size() == 6);
          Scene s; addPrimitive(s, 0); setEditMode(s, true); assert(!selectBoundaryActive(s) && !selectNonManifoldActive(s));          // closed cube: nothing
          { Mesh& m = s.find(s.selected)->mesh; int tp = -1; for (size_t i = 0; i < m.f.size(); ++i) if (faceNormal(m, m.f[i]).z > 0.9f) tp = (int)i; deleteFaces(m, {tp}); }
          assert(selectBoundaryActive(s) && s.sel.mode == 1 && s.sel.e.size() == 4 && selectNonManifoldActive(s) && s.sel.e.size() == 4);
          Scene none; assert(!selectBoundaryActive(none));                                                                              // not in edit mode
          // random: deterministic, exact count, ratio bounds, all three modes
          auto r1 = randomSubset(100, 0.25f, 7), r2 = randomSubset(100, 0.25f, 7), r3 = randomSubset(100, 0.25f, 8);
          assert(r1.size() == 25 && r1 == r2 && r1 != r3 && std::is_sorted(r1.begin(), r1.end()) && std::set<int>(r1.begin(), r1.end()).size() == 25 && r1.front() >= 0 && r1.back() < 100);
          assert(randomSubset(10, 0.25f, 1).size() == 3 && randomSubset(10, 0.f, 1).empty() && randomSubset(10, 1.f, 1).size() == 10 && randomSubset(10, 1.5f, 1).empty() && randomSubset(10, -0.1f, 1).empty() && randomSubset(0, 0.5f, 1).empty() && randomSubset(10, std::numeric_limits<float>::quiet_NaN(), 1).empty());
          Scene r; addPrimitive(r, 1); setEditMode(r, true); setSelectMode(r, 0); const int nv = (int)r.find(r.selected)->mesh.v.size();
          assert(selectRandomActive(r, 0.5f, 3) && (int)r.sel.v.size() == (int)std::lround(0.5 * nv) && r.sel.mode == 0);
          Scene q; addPrimitive(q, 0); setEditMode(q, true); setSelectMode(q, 1); assert(selectRandomActive(q, 0.5f, 3) && q.sel.e.size() == 6 && q.sel.v.empty());     // cube: 12 edges
          setSelectMode(q, 2); assert(selectRandomActive(q, 0.5f, 3) && q.sel.f.size() == 3 && q.sel.e.empty());
          assert(selectRandomActive(q, 0.f, 3) && q.sel.f.empty() && !selectRandomActive(q, 2.f, 3) && !selectRandomActive(none, 0.5f, 3)); }
        // ---- 0.24.0: character presets ----
        { std::vector<size_t> partCounts;
          for (int k = 0; k < 3; ++k) {
              const Mesh m = makeBody(k); const BodyStyle st = bodyStyle(k);
              assert(validMesh(m) && closedManifold(m) && !m.f.empty());
              float zmin = 1e9f, zmax = -1e9f; for (const auto& v : m.v) { zmin = std::min(zmin, v.z); zmax = std::max(zmax, v.z); }
              assert(near(zmin, 0.f, 1e-3f) && near(zmax, st.height, 1e-3f));                                   // feet on the floor, exact height
              // X symmetry: mirrored vertex set equals the original
              std::vector<std::array<long, 3>> a, b; for (const auto& v : m.v) { a.push_back({std::lround(v.x * 1e4f), std::lround(v.y * 1e4f), std::lround(v.z * 1e4f)}); b.push_back({std::lround(-v.x * 1e4f), std::lround(v.y * 1e4f), std::lround(v.z * 1e4f)}); }
              std::sort(a.begin(), a.end()); std::sort(b.begin(), b.end());
              size_t bad = 0; for (size_t i = 0; i < a.size(); ++i) for (int c = 0; c < 3; ++c) if (std::labs(a[i][c] - b[i][c]) > 1) { ++bad; break; }
              assert(bad == 0);
              float xmax = -1e9f; for (const auto& v : m.v) xmax = std::max(xmax, v.x); assert(xmax > st.shoulderX + 0.1f);   // A-pose: hands hang OUTSIDE the shoulders
              const auto parts = splitLooseParts(m); partCounts.push_back(parts.size());
              double total = 0; for (const auto& p : parts) { assert(closedManifold(p) && signedVolume(p) > 0.0); total += signedVolume(p); }   // every part closed, normals outward
              assert(total > 0.02 && total < 0.12);                                                              // a plausible human volume (m^3)
              // front is -Y: the head's centre must sit in front of nothing odd, and feet point towards -Y
              float fy = 1e9f; for (const auto& v : m.v) if (v.z < 0.001f) fy = std::min(fy, v.y);
              assert(fy < -0.1f * st.height / 1.7f + 0.01f);
          }
          assert(partCounts[0] == 12 && partCounts[1] == 12 && partCounts[2] == 10);                            // torso, head, 2x(leg, foot, arm, hand[, bust])
          // anime has a bigger head and longer legs relative to height than the realistic female
          { auto headFrac = [&](int k) { const BodyStyle s = bodyStyle(k); return 2.f * s.headRz / s.height; }; assert(headFrac(0) > headFrac(1) && headFrac(0) > headFrac(2)); }
          assert(bodyStyle(2).shoulderX > bodyStyle(1).shoulderX && bodyStyle(0).bust > 0.f && bodyStyle(2).bust == 0.f);
          // scene level: Object Mode only, one undo step, unique names, round trip through the project format
          Scene s; assert(addPreset(s, 0) != 0 && s.objects.size() == 1 && s.find(s.selected)->name == "Anime_Female");
          assert(addPreset(s, 0) != 0 && s.objects[1].name == "Anime_Female.001" && addPreset(s, 2) != 0 && s.objects[2].name == "Male_Body");
          assert(addPreset(s, 12) == 0 && addPreset(s, -1) == 0 && s.objects.size() == 3);
          const size_t d = s.undoDepth(); assert(addPreset(s, 1) != 0 && s.undoDepth() == d + 1 && s.objects.size() == 4);
          assert(s.undo() && s.objects.size() == 3 && s.redo() && s.objects.size() == 4);
          setEditMode(s, true); assert(addPreset(s, 0) == 0 && s.objects.size() == 4); setEditMode(s, false);
          // separate loose parts on a preset: 12 closed parts, one undo step
          assert(s.find(s.selected)->mesh.f.size() == makeBody(1).f.size());
          const std::string path = "/tmp/atlas_preset_test.atlas"; assert(saveProject(s, path));
          Scene l; assert(loadProject(l, path) && l.objects.size() == 4 && sameMesh(l.objects[3].mesh, makeBody(1)) && l.objects[0].name == "Anime_Female"); }
        // ---- 0.25.0: chibi, anime head, hand ----
        { for (int k = 3; k <= 5; ++k) {
              const Mesh m = makePreset(k); assert(validMesh(m) && closedManifold(m));
              const auto parts = splitLooseParts(m); for (const auto& p : parts) { assert(closedManifold(p) && signedVolume(p) > 0.0); }
              if (k == 3) assert(parts.size() == 10);
              if (k == 4) assert(parts.size() == 9);
              if (k == 5) assert(parts.size() == 6);
          }
          { const Mesh c = makeBody(3); const BodyStyle st = bodyStyle(3); float zmin = 1e9f, zmax = -1e9f, xmax = -1e9f; for (const auto& v : c.v) { zmin = std::min(zmin, v.z); zmax = std::max(zmax, v.z); xmax = std::max(xmax, v.x); }
            assert(near(zmin, 0.f, 1e-3f) && near(zmax, 1.f, 1e-3f) && xmax > st.shoulderX + 0.03f && 2.f * st.headRz / st.height > 0.3f);       // 3 heads tall, arms hang outside the shoulders
            assert(2.f * st.headRz / st.height > 2.f * bodyStyle(0).headRz / bodyStyle(0).height * 1.5f); }
          { const Mesh h = makeHand(); float xmax = -1e9f, zmax = -1e9f; for (const auto& v : h.v) { xmax = std::max(xmax, v.x); zmax = std::max(zmax, v.z); }
            assert(xmax > 0.07f && zmax > 0.1f); }                                                                                              // thumb sticks out sideways, fingers up
          { const Mesh h = makeAnimeHead(); float ymin = 1e9f, zmin = 1e9f; for (const auto& v : h.v) { ymin = std::min(ymin, v.y); zmin = std::min(zmin, v.z); }
            assert(near(zmin, 0.f, 1e-3f) && ymin < -0.09f); }                                                                                  // face towards -Y, neck base on z = 0
          Scene s; for (int k = 3; k <= 5; ++k) assert(addPreset(s, k) != 0); assert(s.objects[0].name == "Chibi" && s.objects[1].name == "Anime_Head" && s.objects[2].name == "Hand" && s.objects.size() == 3); }
        // ---- 0.26.0: Tris to Quads, Select Similar Normal ----
        { auto allF = [](const Mesh& m) { std::set<int> s; for (size_t i = 0; i < m.f.size(); ++i) s.insert((int)i); return s; };
          // 3x3 grid of quads, triangulated -> 18 triangles -> back to 9 quads
          Mesh g; for (int y = 0; y < 4; ++y) for (int x = 0; x < 4; ++x) g.v.push_back({(float)x, (float)y, 0});
          for (int y = 0; y < 3; ++y) for (int x = 0; x < 3; ++x) { const int a = y * 4 + x; g.f.push_back({a, a + 1, a + 5, a + 4}); }
          assert(triangulateFaces(g, allF(g)) == 9 && g.f.size() == 18);
          std::vector<int> mk; assert(trisToQuads(g, allF(g), 40.f, &mk) == 9 && g.f.size() == 9 && mk.size() == 9 && g.v.size() == 16);
          for (const auto& fc : g.f) { assert(fc.size() == 4); Mesh one; one.v = g.v; one.f = {fc}; assert(faceNormal(one, fc).z > 0.99f); }
          // cube: 12 triangles -> 6 quads, still a closed outward cube
          Mesh c = makeCube(); triangulateFaces(c, allF(c)); assert(c.f.size() == 12 && trisToQuads(c, allF(c), 40.f) == 6 && c.f.size() == 6);
          assert(closedManifold(c) && near((float)signedVolume(c), 8.f));
          // angle 0 still joins exactly coplanar pairs; invalid limits do nothing
          Mesh c0 = makeCube(); triangulateFaces(c0, allF(c0)); assert(trisToQuads(c0, allF(c0), 0.f) == 6);
          Mesh ci = makeCube(); triangulateFaces(ci, allF(ci)); const Mesh ciBefore = ci;
          assert(trisToQuads(ci, allF(ci), -1.f) == 0 && trisToQuads(ci, allF(ci), 181.f) == 0 && trisToQuads(ci, allF(ci), std::numeric_limits<float>::quiet_NaN()) == 0 && sameMesh(ci, ciBefore));
          // selection mask: only the triangles of the top face are joined
          { Mesh m = makeCube(); triangulateFaces(m, allF(m)); std::set<int> tops; for (size_t i = 0; i < m.f.size(); ++i) if (faceNormal(m, m.f[i]).z > 0.9f) tops.insert((int)i);
            assert(tops.size() == 2 && trisToQuads(m, tops, 10.f) == 1 && m.f.size() == 11); }
          // concave pair (dart) is refused; lone triangle, quads and non-manifold edges are ignored
          { Mesh d; d.v = {{0, 0, 0}, {2, 0, 0}, {.5f, .5f, 0}, {0, 2, 0}}; d.f = {{0, 1, 2}, {0, 2, 3}}; assert(trisToQuads(d, allF(d), 90.f) == 0 && d.f.size() == 2);
            Mesh one; one.v = {{0, 0, 0}, {1, 0, 0}, {0, 1, 0}}; one.f = {{0, 1, 2}}; assert(trisToQuads(one, allF(one), 90.f) == 0);
            Mesh fin; fin.v = {{0, 0, 0}, {1, 0, 0}, {0, 1, 0}, {0, -1, 0}, {0, 0, 1}}; fin.f = {{0, 1, 2}, {1, 0, 3}, {0, 1, 4}}; assert(trisToQuads(fin, allF(fin), 180.f) == 0);
            Mesh q = makeCube(); assert(trisToQuads(q, allF(q), 90.f) == 0);
            Mesh bad; bad.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}}; bad.f = {{0, 1, 2}, {0, 2, 3}}; std::swap(bad.f[1][1], bad.f[1][2]); assert(trisToQuads(bad, allF(bad), 180.f) == 0);
            // folded pair: ~35 degrees between the normals
            Mesh fo; fo.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, .5f}}; fo.f = {{0, 1, 2}, {0, 2, 3}}; Mesh fo2 = fo;
            assert(trisToQuads(fo, allF(fo), 20.f) == 0 && fo.f.size() == 2 && trisToQuads(fo2, allF(fo2), 40.f) == 1 && fo2.f.size() == 1); }   // inconsistent winding
          // scene: one undo step, selection becomes the quads
          { Scene s; addPrimitive(s, 0); setEditMode(s, true); setSelectMode(s, 2); { Mesh& m = s.find(s.selected)->mesh; triangulateFaces(m, allF(m)); }
            s.sel.clearSets(); s.sel.mode = 2; for (int i = 0; i < 12; ++i) s.sel.f.insert(i);
            const size_t d = s.undoDepth(); assert(trisToQuadsSelected(s, 40.f) && s.undoDepth() == d + 1 && s.sel.f.size() == 6 && s.find(s.selected)->mesh.f.size() == 6);
            assert(s.undo() && s.find(s.selected)->mesh.f.size() == 12 && s.redo() && s.find(s.selected)->mesh.f.size() == 6);
            assert(!trisToQuadsSelected(s, 40.f)); Scene o; addPrimitive(o, 0); assert(!trisToQuadsSelected(o, 40.f)); }
          // similar normal
          { const Mesh cu = makeCube(); int top = -1; for (size_t i = 0; i < cu.f.size(); ++i) if (faceNormal(cu, cu.f[i]).z > 0.9f) top = (int)i;
            assert(similarNormalFaces(cu, {top}, 10.f).size() == 1 && similarNormalFaces(cu, {top}, 95.f).size() == 5 && similarNormalFaces(cu, {top}, 180.f).size() == 6
                   && similarNormalFaces(cu, {top}, -1.f).empty() && similarNormalFaces(cu, {}, 90.f).empty());
            Mesh g2 = g; triangulateFaces(g2, allF(g2)); assert(similarNormalFaces(g2, {0}, 5.f).size() == 18);                                    // flat grid: everything
            Scene s; addPrimitive(s, 0); setEditMode(s, true); setSelectMode(s, 2); s.sel.clearSets(); s.sel.f.insert(top);
            assert(selectSimilarNormalActive(s, 10.f) && s.sel.mode == 2 && s.sel.f.size() == 1 && selectSimilarNormalActive(s, 95.f) && s.sel.f.size() == 5);
            s.sel.clearSets(); assert(!selectSimilarNormalActive(s, 40.f)); Scene o; addPrimitive(o, 0); assert(!selectSimilarNormalActive(o, 40.f)); } }
        // ---- 0.27.0: hair and skirt presets (fit the anime female) ----
        { const HeadInfo h = animeFemaleInfo(); const Mesh body = makeBody(0);
          float top = 0; for (const auto& v : body.v) top = std::max(top, v.z); assert(near(top, h.height, 1e-3f) && near(h.c.z + h.r.z, h.height, 2e-3f));   // head info matches the real body
          const int expect[3] = {11, 6, 1};
          for (int k = 6; k <= 8; ++k) {
              const Mesh m = makePreset(k); assert(validMesh(m) && closedManifold(m)); const auto parts = splitLooseParts(m); assert((int)parts.size() == expect[k - 6]);
              for (const auto& p : parts) assert(closedManifold(p) && signedVolume(p) > 0.0);
              float xmin = 1e9f, xmax = -1e9f; for (const auto& v : m.v) { xmin = std::min(xmin, v.x); xmax = std::max(xmax, v.x); } assert(near(xmin, -xmax, 1e-3f));   // symmetric
          }
          { const Mesh hr = makeLongHair(); float zmin = 1e9f, zmax = -1e9f, ymax = -1e9f; for (const auto& v : hr.v) { zmin = std::min(zmin, v.z); zmax = std::max(zmax, v.z); ymax = std::max(ymax, v.y); }
            assert(zmax > h.c.z && zmax < h.height + 0.1f && zmin > h.waistZ && zmin < h.shoulderZ && ymax > h.c.y + h.r.y); }                 // covers the head, hangs behind, ends between shoulder and waist
          { const Mesh tt = makeTwinTails(); float xmax = -1e9f; for (const auto& v : tt.v) xmax = std::max(xmax, v.x); float zl = 1e9f; for (const auto& v : tt.v) zl = std::min(zl, v.z); assert(xmax > h.r.x * 1.4f && near(zl, h.hipZ, 1e-3f)); }     // tails hang beside the head
          { const Mesh sk = makeSkirt(); float zmin = 1e9f, zmax = -1e9f, rmax = 0; for (const auto& v : sk.v) { zmin = std::min(zmin, v.z); zmax = std::max(zmax, v.z); rmax = std::max(rmax, std::fabs(v.x)); }
            assert(near(zmax, h.waistZ, 1e-3f) && zmin < h.hipZ - 0.2f && rmax > bodyStyle(0).torso[2].rx * h.scale + 0.05f); }                  // starts at the waist, flares past the hips
          Scene s; for (int k = 6; k <= 8; ++k) assert(addPreset(s, k) != 0); assert(s.objects[0].name == "Long_Hair" && s.objects[1].name == "Twin_Tails" && s.objects[2].name == "Skirt"); }
        // ---- 0.28.0: Rotate Edge, Duplicate Faces, Select Similar Area ----
        { // rotate edge: unit square split on the 0-2 diagonal -> 1-3 diagonal, area and normals kept
          Mesh q; q.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}}; q.f = {{0, 1, 2}, {0, 2, 3}};
          std::vector<Edge> mk; assert(rotateEdges(q, {mkEdge(0, 2)}, &mk) == 1 && mk.size() == 1 && mk[0] == mkEdge(1, 3) && q.f.size() == 2);
          float area = 0; for (const auto& fc : q.f) { area += faceArea(q, fc); assert(faceNormal(q, fc).z > 0.99f); } assert(near(area, 1.f));
          bool has13 = false; for (const auto& kv : detail::edgeFaces(q)) if (kv.first == mkEdge(1, 3) && kv.second.size() == 2) has13 = true; assert(has13 && !detail::edgeFaces(q).count(mkEdge(0, 2)));
          assert(rotateEdges(q, {mkEdge(1, 3)}) == 1 && detail::edgeFaces(q).count(mkEdge(0, 2)));                                                         // and back
          // refused: boundary edge, concave dart, existing diagonal, quads, nothing selected
          Mesh d; d.v = {{0, 0, 0}, {2, 0, 0}, {.5f, .5f, 0}, {0, 2, 0}}; d.f = {{0, 1, 2}, {0, 2, 3}}; const Mesh db = d; assert(rotateEdges(d, {mkEdge(0, 2)}) == 0 && sameMesh(d, db));
          Mesh q2; q2.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}}; q2.f = {{0, 1, 2}, {0, 2, 3}}; assert(rotateEdges(q2, {mkEdge(0, 1)}) == 0 && rotateEdges(q2, {}) == 0);
          { Mesh tet; tet.v = {{0, 0, 0}, {1, 0, 0}, {0, 1, 0}, {0, 0, 1}}; tet.f = {{0, 2, 1}, {0, 1, 3}, {1, 2, 3}, {0, 3, 2}}; const Mesh tb = tet;       // x-y diagonal already exists -> would be non-manifold
            for (const Edge& e : {mkEdge(0, 1), mkEdge(1, 2), mkEdge(0, 2), mkEdge(0, 3), mkEdge(1, 3), mkEdge(2, 3)}) { assert(rotateEdges(tet, {e}) == 0); }
            assert(sameMesh(tet, tb)); }
          { Mesh pe; pe.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}, {.5f, .5f, 1}}; pe.f = {{0, 1, 2}, {0, 2, 3}, {3, 1, 4}}; const Mesh pb = pe;   // flat convex quad whose OTHER diagonal already exists
            assert(rotateEdges(pe, {mkEdge(0, 2)}) == 0 && sameMesh(pe, pb)); }
          { Mesh tq; tq.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {.5f, 2, 0}, {-.5f, 1, 0}}; tq.f = {{0, 1, 2}, {0, 2, 3, 4}}; const Mesh tb = tq; assert(rotateEdges(tq, {mkEdge(0, 2)}) == 0 && sameMesh(tq, tb)); }   // triangle + quad
          Mesh cu = makeCube(); assert(rotateEdges(cu, {mkEdge(0, 1)}) == 0);                                                                              // quads are not touched
          // closed triangulated cube: rotating an in-face diagonal keeps it closed, volume 8, outward
          Mesh tc = makeCube(); { std::set<int> all; for (size_t i = 0; i < tc.f.size(); ++i) all.insert((int)i); triangulateFaces(tc, all); }
          std::set<Edge> diag; for (const auto& kv : detail::edgeFaces(tc)) { const auto &a = tc.f[kv.second[0]], &b = tc.f[kv.second[1]]; if (near(dot(faceNormal(tc, a), faceNormal(tc, b)), 1.f)) diag.insert(kv.first); }
          assert(diag.size() == 6 && rotateEdges(tc, diag) == 6 && closedManifold(tc) && near((float)signedVolume(tc), 8.f));
          // scene: one undo step, selection = the new diagonal
          Scene s; addPrimitive(s, 1); setEditMode(s, true); { Mesh& m = s.find(s.selected)->mesh; triangulateFaces(m, {0}); } setSelectMode(s, 1); s.sel.clearSets(); s.sel.mode = 1;
          { const Mesh& m = s.find(s.selected)->mesh; for (const auto& kv : detail::edgeFaces(m)) if (kv.second.size() == 2) s.sel.e.insert(kv.first); }
          const size_t dep = s.undoDepth(); assert(rotateSelectedEdges(s) && s.undoDepth() == dep + 1 && s.sel.e.size() == 1 && s.undo() && s.redo());
          Scene o; addPrimitive(o, 1); assert(!rotateSelectedEdges(o));
          // duplicate faces: new vertices, original untouched, shared vertices stay shared among the copies
          Mesh g = makeCube(); const Mesh gb = g; std::vector<int> dm; assert(duplicateFaces(g, {0, 1}, &dm) == 2 && dm.size() == 2 && g.f.size() == 8 && g.v.size() == 16);
          assert(dm[0] == 6 && dm[1] == 7 && g.f[6].size() == 4 && validMesh(g));
          for (int i = 0; i < 6; ++i) assert(g.f[i] == gb.f[i]);
          for (int vi : g.f[6]) assert(vi >= 8);
          for (int vi : g.f[7]) assert(vi >= 8);
          Mesh g2 = makePlane(); assert(duplicateFaces(g2, {5, -1}) == 0 && sameMesh(g2, makePlane()));
          Mesh pl; pl.v = {{0, 0, 0}, {1, 0, 0}, {2, 0, 0}, {0, 1, 0}, {1, 1, 0}, {2, 1, 0}}; pl.f = {{0, 1, 4, 3}, {1, 2, 5, 4}}; assert(duplicateFaces(pl, {0, 1}) == 2 && pl.v.size() == 12 && pl.f[2][1] == pl.f[3][0] && pl.f[2][2] == pl.f[3][3]);   // shared edge stays shared in the copy
          Scene sd; addPrimitive(sd, 0); setEditMode(sd, true); setSelectMode(sd, 2); sd.sel.clearSets(); sd.sel.f.insert(0);
          const size_t d2 = sd.undoDepth(); assert(duplicateSelectedFaces(sd) && sd.undoDepth() == d2 + 1 && sd.find(sd.selected)->mesh.f.size() == 7 && sd.sel.f.size() == 1 && sd.sel.f.count(6) == 1);
          assert(sd.undo() && sd.find(sd.selected)->mesh.f.size() == 6); sd.sel.clearSets(); assert(!duplicateSelectedFaces(sd));
          // similar area
          Mesh ar; ar.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}, {3, 0, 0}, {5, 0, 0}, {5, 2, 0}, {3, 2, 0}, {6, 0, 0}, {7.05f, 0, 0}, {7.05f, 1, 0}, {6, 1, 0}};
          ar.f = {{0, 1, 2, 3}, {4, 5, 6, 7}, {8, 9, 10, 11}};
          assert(similarAreaFaces(ar, {0}, 0.f).size() == 1 && similarAreaFaces(ar, {0}, 10.f).size() == 2 && similarAreaFaces(ar, {0}, 500.f).size() == 3 && similarAreaFaces(ar, {0}, -1.f).empty() && similarAreaFaces(ar, {}, 10.f).empty());
          assert(similarAreaFaces(ar, {1}, 10.f).size() == 1 && similarAreaFaces(ar, {0}, 4.f).size() == 1 && similarAreaFaces(ar, {0}, 6.f).size() == 2);
          Scene sa; addPrimitive(sa, 0); setEditMode(sa, true); setSelectMode(sa, 2); sa.sel.clearSets(); sa.sel.f.insert(0);
          assert(selectSimilarAreaActive(sa, 1.f) && sa.sel.f.size() == 6 && sa.sel.mode == 2); sa.sel.clearSets(); assert(!selectSimilarAreaActive(sa, 1.f)); Scene so; addPrimitive(so, 0); assert(!selectSimilarAreaActive(so, 1.f)); }
    }

    // ---- 0.29.0: shirt, shorts, boots (fit the anime female) ----
    {
        const HeadInfo h = animeFemaleInfo(); const int expect[3] = {5, 3, 4};
        assert(kPresetCount == 12);
        for (int k = 9; k <= 11; ++k) {
            const Mesh m = makePreset(k); assert(validMesh(m) && closedManifold(m)); const auto parts = splitLooseParts(m); assert((int)parts.size() == expect[k - 9]);
            for (const auto& p : parts) assert(closedManifold(p) && signedVolume(p) > 0.0);
            float xmin = 1e9f, xmax = -1e9f; for (const auto& v : m.v) { xmin = std::min(xmin, v.x); xmax = std::max(xmax, v.x); } assert(near(xmin, -xmax, 1e-3f));
        }
        { const Mesh m = makeShirt(); float zmin = 1e9f, zmax = -1e9f, xmax = -1e9f; for (const auto& v : m.v) { zmin = std::min(zmin, v.z); zmax = std::max(zmax, v.z); xmax = std::max(xmax, v.x); }
          assert(zmin > h.hipZ - 0.1f && zmin < h.waistZ && zmax > h.shoulderZ - 0.05f && zmax < h.height - 0.15f && xmax > h.r.x); }          // hem at the hips, top at the shoulders, sleeves reach out sideways
        { const Mesh m = makeShorts(); float zmin = 1e9f, zmax = -1e9f; for (const auto& v : m.v) { zmin = std::min(zmin, v.z); zmax = std::max(zmax, v.z); }
          assert(zmin > 0.35f * h.height * 0.5f && zmin < h.hipZ && zmax > h.hipZ && zmax < h.waistZ + 0.1f); }
        { const Mesh m = makeBoots(); float zmin = 1e9f, zmax = -1e9f, ymin = 1e9f; for (const auto& v : m.v) { zmin = std::min(zmin, v.z); zmax = std::max(zmax, v.z); ymin = std::min(ymin, v.y); }
          assert(near(zmin, 0.f, 1e-4f) && zmax > 0.25f && zmax < 0.45f * h.height && ymin < -0.1f); }                                           // sole on the floor, shaft below the knee, toes towards -Y
        { const Mesh sk = makeSkirt(), sh = makeShorts(); float skMin = 1e9f, shMin = 1e9f; for (const auto& v : sk.v) skMin = std::min(skMin, v.z); for (const auto& v : sh.v) shMin = std::min(shMin, v.z); assert(shMin < skMin + 0.4f); }
        Scene sc; assert(addPreset(sc, 9) != 0 && addPreset(sc, 10) != 0 && addPreset(sc, 11) != 0 && addPreset(sc, 12) == 0 && sc.undo() && sc.redo());
        assert(std::string(bodyName(9)) == "Shirt" && std::string(bodyName(10)) == "Shorts" && std::string(bodyName(11)) == "Boots");
    }
    // ---- 0.30.0: Spin and Select Similar (Perimeter) ----
    {
        const float PI = 3.14159265f;
        // semicircle profile with both ends on the Z axis, spun 360 -> UV sphere-like closed surface
        Mesh pr; for (int k = 0; k <= 8; ++k) { const float a = PI * k / 8; pr.v.push_back({std::sin(a), 0.f, -std::cos(a)}); }
        for (int k = 0; k < 8; ++k) pr.f.push_back({k, k + 1, k});           // (degenerate faces only to carry the edges; removed below)
        pr.f.clear();
        std::set<Edge> pe; for (int k = 0; k < 8; ++k) pe.insert(mkEdge(k, k + 1));
        { Mesh m = pr; std::vector<Edge> mk; const int n = spinEdges(m, pe, 2, 360.f, 16, &mk);
          assert(n == 2 * 16 + 6 * 16 && m.v.size() == 9 + 7 * 15 && validMesh(m) && closedManifold(m) && mk.size() == 8);   // poles shared, seam not duplicated
          assert(signedVolume(m) > 3.3 && signedVolume(m) < 4.19);
          Mesh t = m; t.v.resize(m.v.size()); int E = 0; closedManifold(m, &E); assert((int)m.v.size() - E + (int)m.f.size() == 2); }
        // open vertical segment, 90 degrees, 4 steps: ring 4 lands on the Y axis, faces point away from the axis
        Mesh sg; sg.v = {{1, 0, 0}, {1, 0, 1}};
        { Mesh m = sg; std::vector<Edge> mk; assert(spinEdges(m, {mkEdge(0, 1)}, 2, 90.f, 4, &mk) == 4 && m.v.size() == 10 && mk.size() == 1 && validMesh(m));
          assert(near(m.v[8].x, 0.f, 1e-5f) && near(m.v[8].y, 1.f, 1e-5f) && near(m.v[9].z, 1.f, 1e-5f) && mk[0] == mkEdge(8, 9));
          assert(boundaryEdges(m).size() == 10);
          for (const auto& fc : m.f) { Vec3 c{}; for (int vi : fc) c = c + m.v[vi]; c = c * 0.25f; c.z = 0; assert(dot(faceNormal(m, fc), c) > 0.f); } }
        { Mesh m = sg; assert(spinEdges(m, {mkEdge(0, 1)}, 2, -90.f, 4) == 4 && near(m.v[8].x, 0.f, 1e-5f) && near(m.v[8].y, -1.f, 1e-5f));     // negative angle spins the other way, still pointing outwards
          for (const auto& fc : m.f) { Vec3 c{}; for (int vi : fc) c = c + m.v[vi]; c = c * 0.25f; c.z = 0; assert(dot(faceNormal(m, fc), c) > 0.f); } }
        { Mesh m = sg; assert(spinEdges(m, {mkEdge(0, 1)}, 2, 360.f, 12) == 12 && m.v.size() == 24 && boundaryEdges(m).size() == 24 && validMesh(m)); }   // open tube, no seam ring
        // axis X and Y keep the coordinate along the axis and the radius
        for (int ax = 0; ax < 2; ++ax) { Mesh m; m.v = {{0, 0, 0}, {0, 0, 0}}; const int u = (ax + 1) % 3, w = (ax + 2) % 3; auto set = [&](Vec3& p, int i, float v) { (i == 0 ? p.x : i == 1 ? p.y : p.z) = v; };
          set(m.v[0], u, 2.f); set(m.v[1], u, 2.f); set(m.v[1], ax, 1.f); const Mesh orig = m;
          assert(spinEdges(m, {mkEdge(0, 1)}, ax, 180.f, 6) == 6);
          for (size_t i = 2; i < m.v.size(); ++i) { const Vec3 p = m.v[i]; auto g = [&](int c) { return c == 0 ? p.x : c == 1 ? p.y : p.z; };
            assert(near(std::sqrt(g(u) * g(u) + g(w) * g(w)), 2.f, 1e-4f) && (near(g(ax), 0.f, 1e-5f) || near(g(ax), 1.f, 1e-5f))); }
          const Vec3 last = m.v.back(); auto gl = [&](int c) { return c == 0 ? last.x : c == 1 ? last.y : last.z; }; assert(near(gl(u), -2.f, 1e-4f) && near(gl(w), 0.f, 1e-4f)); }
        // a point off both axes: (1,1,0) -> (-1,1,0) after 90 degrees about Z (counter-clockwise seen from +Z), and 180 -> (-1,-1,0)
        { Mesh m; m.v = {{1, 1, 0}, {1, 1, 1}}; assert(spinEdges(m, {mkEdge(0, 1)}, 2, 90.f, 1) == 1 && near(m.v[2].x, -1.f, 1e-5f) && near(m.v[2].y, 1.f, 1e-5f)
              && near(m.v[3].x, -1.f, 1e-5f) && near(m.v[3].y, 1.f, 1e-5f) && near(m.v[3].z, 1.f, 1e-5f));
          Mesh m2; m2.v = {{1, 1, 0}, {1, 1, 1}}; assert(spinEdges(m2, {mkEdge(0, 1)}, 2, 180.f, 2) == 2 && near(m2.v[4].x, -1.f, 1e-5f) && near(m2.v[4].y, -1.f, 1e-5f) && near(m2.v[2].x, -1.f, 1e-5f) && near(m2.v[2].y, 1.f, 1e-5f)); }
        // rejections change nothing
        { Mesh m = sg; const Mesh b = m; std::vector<Edge> mk{{1, 2}};
          assert(spinEdges(m, {mkEdge(0, 1)}, 3, 90.f, 4) == 0 && spinEdges(m, {mkEdge(0, 1)}, -1, 90.f, 4) == 0 && spinEdges(m, {mkEdge(0, 1)}, 2, 90.f, 0) == 0 && spinEdges(m, {mkEdge(0, 1)}, 2, 90.f, 129) == 0
                 && spinEdges(m, {mkEdge(0, 1)}, 2, 0.f, 4) == 0 && spinEdges(m, {mkEdge(0, 1)}, 2, NAN, 4) == 0 && spinEdges(m, {mkEdge(0, 1)}, 2, 361.f, 4) == 0 && spinEdges(m, {}, 2, 90.f, 4, &mk) == 0 && mk.empty()
                 && spinEdges(m, {mkEdge(0, 5)}, 2, 90.f, 4) == 0 && sameMesh(m, b)); }
        { Mesh m; m.v = {{0, 0, 0}, {0, 0, 1}}; assert(spinEdges(m, {mkEdge(0, 1)}, 2, 90.f, 4) == 0 && m.v.size() == 2); }                        // both ends on the axis
        { Mesh m; m.v = {{0, 0, 0}, {1, 0, 0}}; assert(spinEdges(m, {mkEdge(0, 1)}, 2, 90.f, 3) == 3 && m.v.size() == 5);                             // one end on the axis -> triangle fan
          for (const auto& fc : m.f) assert(fc.size() == 3 && faceArea(m, fc) > 0.f); }
        // scene: one undo step, selection becomes the last ring
        { Scene s; addPrimitive(s, 1); setEditMode(s, true); setSelectMode(s, 1); s.sel.clearSets(); s.sel.e.insert(mkEdge(0, 1));
          const size_t nv = s.find(s.selected)->mesh.v.size(), nf = s.find(s.selected)->mesh.f.size(); const size_t d = s.undoDepth();
          assert(spinSelectedEdges(s, 2, 90.f, 3) && s.undoDepth() == d + 1 && s.find(s.selected)->mesh.f.size() == nf + 3 && s.find(s.selected)->mesh.v.size() > nv && s.sel.mode == 1 && s.sel.e.size() == 1);
          assert(s.undo() && s.find(s.selected)->mesh.f.size() == nf && s.redo() && s.find(s.selected)->mesh.f.size() == nf + 3);
          s.sel.clearSets(); assert(!spinSelectedEdges(s, 2, 90.f, 3)); Scene o; addPrimitive(o, 0); assert(!spinSelectedEdges(o, 2, 90.f, 3)); }
        // similar perimeter: 1x1 (4), 2x2 (8), 1x1.05 (4.1), 1x3 (8)
        { Mesh ar; ar.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}, {3, 0, 0}, {5, 0, 0}, {5, 2, 0}, {3, 2, 0}, {6, 0, 0}, {7.05f, 0, 0}, {7.05f, 1, 0}, {6, 1, 0}, {9, 0, 0}, {12, 0, 0}, {12, 1, 0}, {9, 1, 0}};
          ar.f = {{0, 1, 2, 3}, {4, 5, 6, 7}, {8, 9, 10, 11}, {12, 13, 14, 15}};
          assert(similarPerimeterFaces(ar, {0}, 0.f).size() == 1 && similarPerimeterFaces(ar, {0}, 4.f).size() == 2 && similarPerimeterFaces(ar, {0}, 101.f).size() == 4
                 && similarPerimeterFaces(ar, {0}, -1.f).empty() && similarPerimeterFaces(ar, {}, 10.f).empty() && similarPerimeterFaces(ar, {1}, 0.f).size() == 2);      // 2x2 and 1x3 share perimeter 8
          assert(similarPerimeterFaces(ar, {0}, 2.f).size() == 1 && similarPerimeterFaces(ar, {0}, 3.f).size() == 2);          // 1x1.05 has +2.5 % perimeter
          assert(near(facePerimeter(ar, ar.f[3]), 8.f, 1e-5f));
          Scene s; addPrimitive(s, 0); setEditMode(s, true); setSelectMode(s, 2); s.sel.clearSets(); s.sel.f.insert(0);
          assert(selectSimilarPerimeterActive(s, 1.f) && s.sel.f.size() == 6 && s.sel.mode == 2); s.sel.clearSets(); assert(!selectSimilarPerimeterActive(s, 1.f)); Scene o; addPrimitive(o, 0); assert(!selectSimilarPerimeterActive(o, 1.f)); }
    }

    puts("all tests passed"); return 0;
}
