// Scene-level rig tests (0.31.0 / 0.32.0). g++ -std=c++17 -Wall -Wextra -O1 tests/test_rig_scene.cpp -o t_rs && ./t_rs
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include "../app/src/main/cpp/core/project_io.hpp"
using namespace atlas;
static bool nr(float a, float b, float e = 1e-4f) { return std::fabs(a - b) < e; }
static bool nv(Vec3 a, Vec3 b, float e = 1e-4f) { return nr(a.x, b.x, e) && nr(a.y, b.y, e) && nr(a.z, b.z, e); }
static void undoTo(Scene& s, size_t depth) { while (s.undoDepth() > depth && s.undo()) {} refreshSkinned(s); }

// A 3-bone chain armature (Root/Mid/Tip, z 0..3) and a tall box mesh around it, bound with automatic weights.
static uint32_t makeChain(Scene& s) {
    uint32_t id = addArmature(s); assert(id && s.selected == id && s.find(id)->isArmature && s.find(id)->arm.bones.size() == 1);
    assert(armRename(s, 0, "Root") && armSetRest(s, 0, {0, 0, 0}, {0, 0, 1}, 0.f));
    assert(armExtrudeActive(s, {0, 0, 1}) == 1 && armExtrudeActive(s, {0, 0, 1}) == 2);
    Object* a = s.find(id); a->arm.bones[1].name = "Mid"; a->arm.bones[2].name = "Tip"; assert(validArmature(a->arm));
    return id;
}
static uint32_t makeBox(Scene& s) {
    uint32_t id = addPrimitive(s, 0); Object* m = s.find(id); for (auto& v : m->mesh.v) { v.x *= 0.3f; v.y *= 0.3f; v.z = (v.z + 1.f) * 1.5f; }
    m->meshRev = nextRev(); return id;   // z in [0,3]
}

int main() {
    // ---- armature object lifecycle, undo
    { Scene s; uint32_t a = addArmature(s); assert(a && s.undoDepth() == 1 && s.find(a)->name == "Armature" && s.find(a)->arm.bones[0].name == "Bone" && s.find(a)->activeBone == 0);
      uint32_t b = addArmature(s); assert(s.find(b)->name == "Armature.001"); assert(s.undo() && !s.find(b) && s.redo() && s.find(b));
      s.editMode = false; Scene e; addPrimitive(e, 0); setEditMode(e, true); assert(addArmature(e) == 0);   // not in Edit Mode
      assert(displayMesh(*s.find(a)).v.empty());
      s.selected = a; assert(!setEditMode(s, true) && !s.editMode); }          // armatures have no mesh Edit Mode
    // ---- bone editing is undoable, one step each, and refuses bad input without side effects
    { Scene s; makeChain(s); const size_t d = s.undoDepth(); Object* a = s.find(s.selected);
      assert(armAddBone(s, {1, 0, 0}, {1, 0, 1}, -1, false) == 3 && s.undoDepth() == d + 1 && a->arm.bones.size() == 4 && a->activeBone == 3);
      assert(armAddBone(s, {1, 0, 0}, {1, 0, 0}, -1, false) == -1 && armAddBone(s, {0, 0, 0}, {0, 0, 1}, 9, false) == -1 && s.undoDepth() == d + 1);
      assert(armSetParent(s, 3, 1, false) && a->arm.bones[3].parent == 1 && !armSetParent(s, 1, 3, false) && !armSetParent(s, 0, 2, true) && s.undoDepth() == d + 2);
      assert(armRename(s, 3, "Side.L") && !armRename(s, 3, "Mid") && !armRename(s, 3, "") && a->arm.bones[3].name == "Side.L");
      assert(armSetDeform(s, 3, false) && !armSetDeform(s, 3, false) && !a->arm.bones[3].deform);
      assert(armSelectBone(s, 1) && a->activeBone == 1 && !armSelectBone(s, 9) && armSelectBone(s, -1) && a->activeBone == -1 && s.undoDepth() == d + 4);   // selection is not an undo step
      assert(armExtrudeActive(s, {0, 0, 1}) == -1 && !armDeleteActive(s));                       // no active bone
      undoTo(s, d); assert(a->arm.bones.size() == 3 && validArmature(a->arm)); while (s.redo()) {} refreshSkinned(s); assert(a->arm.bones.size() == 4 && a->arm.bones[3].name == "Side.L"); }
    // ---- pose and reset, mirror
    { Scene s; makeChain(s); Object* a = s.find(s.selected);
      assert(!armResetPose(s, true));                                   // already at rest
      assert(armSetPose(s, 1, {}, {45, 0, 0}, {1, 1, 1}) && !poseIsRest(a->arm) && !armSetPose(s, 1, {}, {NAN, 0, 0}, {1, 1, 1}) && !armSetPose(s, 1, {}, {}, {0, 1, 1}));
      armSelectBone(s, 1); assert(armResetPose(s, false) && poseIsRest(a->arm) && s.undo() && !poseIsRest(a->arm) && s.redo() && poseIsRest(a->arm));
      Scene t; uint32_t id = addArmature(t); Object* b = t.find(id); armRename(t, 0, "Arm.L"); armSetRest(t, 0, {0, 0, 1}, {1, 0, 1}, 0.f); const size_t dt = t.undoDepth();
      assert(armMirror(t, true) && b->arm.bones.size() == 2 && b->arm.bones[1].name == "Arm.R" && nv(b->arm.bones[1].tail, {-1, 0, 1}) && b->activeBone == 1);
      assert(armMirror(t, false) && b->arm.bones.size() == 3 && b->arm.bones[2].name == "Arm.L.1" && nv(b->arm.bones[2].tail, {1, 0, 1}));   // Arm.R mirrors back; the name Arm.L is taken, so it gets a suffix
      undoTo(t, dt); assert(b->arm.bones.size() == 1); }
    // ---- delete bone remaps skin weights of bound meshes; undo restores both
    { Scene s; uint32_t aid = makeChain(s); uint32_t mid = makeBox(s); s.selected = mid; assert(bindMeshToArmature(s, aid));
      Object* m = s.find(mid); Object* a = s.find(aid); assert(m->armatureId == aid && m->skin.v.size() == m->mesh.v.size() && validSkin(m->skin, 3));
      const Skin before = m->skin; s.selected = aid; armSelectBone(s, 1); assert(armDeleteActive(s) && a->arm.bones.size() == 2 && validSkin(m->skin, 2));
      for (const auto& in : m->skin.v) assert(nr(weightSum(in), 1.f, 1e-3f));
      for (size_t i = 0; i < m->skin.v.size(); ++i) assert(vertexWeight(m->skin, (int)i, 0) + vertexWeight(m->skin, (int)i, 1) > 0.99f);
      assert(s.undo() && a->arm.bones.size() == 3 && m->skin.v.size() == before.v.size() && vertexWeight(m->skin, 0, 1) == vertexWeight(before, 0, 1) && vertexWeight(m->skin, 7, 1) == vertexWeight(before, 7, 1));
      assert(s.redo() && a->arm.bones.size() == 2 && validSkin(m->skin, 2)); }
    // ---- binding, posing the mesh, caches, modifiers
    { Scene s; uint32_t aid = makeChain(s); uint32_t mid = makeBox(s); Object* m = s.find(mid);
      const Mesh rest = m->mesh; const size_t d0 = s.undoDepth();
      s.selected = mid; assert(bindMeshToArmature(s, aid) && s.undoDepth() == d0 + 1 && m->skinned && m->armatureId == aid);
      assert(!bindMeshToArmature(s, mid) && !bindMeshToArmature(s, 99) && s.undoDepth() == d0 + 1);
      for (size_t i = 0; i < rest.v.size(); ++i) assert(nv(displayMesh(*m).v[i], rest.v[i], 1e-4f));          // neutral pose -> same shape
      const uint64_t rev0 = m->modsRev; assert(!refreshSkinned(s) && m->modsRev == rev0);                       // nothing changed -> no cache churn
      s.selected = aid; assert(armSetPose(s, 2, {}, {90, 0, 0}, {1, 1, 1}) && m->modsRev != rev0);
      const Mesh& bent = displayMesh(*m); bool moved = false, still = true;
      for (size_t i = 0; i < rest.v.size(); ++i) { if (rest.v[i].z > 2.5f && !nv(bent.v[i], rest.v[i], 0.1f)) moved = true; if (rest.v[i].z < 0.5f && !nv(bent.v[i], rest.v[i], 0.05f)) still = false; }
      assert(moved && still && bent.f == rest.f && sameMesh(m->mesh, rest));                                      // base mesh is never modified by posing
      // modifiers evaluate on the deformed mesh
      s.selected = mid; assert(addModifier(s, 0)); assert(displayMesh(*s.find(mid)).v.size() > rest.v.size());
      // moving the armature object moves the deformation with it consistently: neutral pose still reproduces the rest shape
      s.selected = aid; armResetPose(s, true); Object* ao = s.find(aid); ao->pos[0] = 4.f; ao->rot[2] = 30.f; refreshSkinned(s); s.selected = mid; s.find(mid)->mods.clear(); s.find(mid)->modsRev = nextRev();
      for (size_t i = 0; i < rest.v.size(); ++i) assert(nv(displayMesh(*s.find(mid)).v[i], rest.v[i], 1e-3f));
      // unbind
      assert(unbindMesh(s) && !s.find(mid)->skinned && s.find(mid)->armatureId == 0 && s.find(mid)->skin.v.empty() && !unbindMesh(s));
      assert(s.undo() && s.find(mid)->armatureId == aid && s.find(mid)->skin.v.size() == rest.v.size()); refreshSkinned(s); assert(s.find(mid)->skinned); }
    // ---- stale skin (mesh topology edited after binding) is ignored, never crashes
    { Scene s; uint32_t aid = makeChain(s); uint32_t mid = makeBox(s); s.selected = mid; bindMeshToArmature(s, aid);
      setEditMode(s, true); refreshSkinned(s); assert(!s.find(mid)->skinned);                                    // edit mode shows the rest mesh
      setSelectMode(s, 2); s.sel.clearSets(); s.sel.f.insert(0); assert(subdivideSelected(s)); setEditMode(s, false); refreshSkinned(s);
      Object* m = s.find(mid); assert(m->skin.v.size() != m->mesh.v.size() && !m->skinned && displayMesh(*m).v.size() == m->mesh.v.size());
      armSelectBone(s, 0); s.selected = mid; assert(bindMeshToArmature(s, aid) && m->skin.v.size() == m->mesh.v.size()); refreshSkinned(s); assert(m->skinned);
      // deleting the armature object: the mesh falls back to its base shape
      s.selected = aid; assert(deleteSelectedObject(s)); refreshSkinned(s); assert(!s.find(mid)->skinned); assert(s.undo()); refreshSkinned(s); assert(s.find(mid)->skinned); }
    // ---- weight assignment in Edit Mode
    { Scene s; uint32_t aid = makeChain(s); uint32_t mid = makeBox(s); s.selected = mid;
      assert(!assignWeightSelected(s, 0, 1.f));                                                                 // object mode / not bound
      bindMeshToArmature(s, aid); assert(!assignWeightSelected(s, 0, 1.f));                                     // object mode
      s.selected = aid; assert(armSetPose(s, 2, {}, {90, 0, 0}, {1, 1, 1})); s.selected = mid;
      setEditMode(s, true); setSelectMode(s, 0); s.sel.clearSets(); assert(!assignWeightSelected(s, 0, 1.f));   // nothing selected
      s.sel.v.insert(0); s.sel.v.insert(1); const size_t d = s.undoDepth(); Object* m = s.find(mid);
      assert(!assignWeightSelected(s, 7, 1.f) && !assignWeightSelected(s, 0, 2.f) && !assignWeightSelected(s, -1, 1.f) && s.undoDepth() == d);
      assert(assignWeightSelected(s, 2, 1.f) && s.undoDepth() == d + 1 && nr(vertexWeight(m->skin, 0, 2), 1.f) && nr(vertexWeight(m->skin, 1, 2), 1.f) && vertexWeight(m->skin, 0, 0) == 0.f);
      assert(nr(weightSum(m->skin.v[2]), 1.f, 1e-3f) && vertexWeight(m->skin, 2, 2) < 1.f);                     // others untouched
      assert(meshInfluenceCount(*m, 2) >= 2); assert(s.undo() && vertexWeight(m->skin, 0, 2) < 1.f && s.redo() && nr(vertexWeight(m->skin, 0, 2), 1.f));
      // the displayed mesh follows weight changes through undo/redo (the bent tip drags vertex 0 only while it carries tip weight)
      setEditMode(s, false); refreshSkinned(s); const Vec3 withW = displayMesh(*m).v[0];
      assert(s.undo()); refreshSkinned(s); const Vec3 without = displayMesh(*m).v[0]; assert(!nv(withW, without, 0.05f));
      assert(s.redo()); refreshSkinned(s); assert(nv(displayMesh(*m).v[0], withW, 1e-5f)); }
    // ---- project round trip (v6), including pose, weights, binding, names with spaces
    { Scene s; uint32_t aid = makeChain(s); Object* a = s.find(aid); a->name = "My Rig"; a->arm.bones[2].deform = false; armSetPose(s, 1, {0.1f, 0.2f, 0.3f}, {10, 20, 30}, {1, 1.5f, 1});
      uint32_t mid = makeBox(s); s.selected = mid; bindMeshToArmature(s, aid);
      const std::string p = "/tmp/atlas_rig_test.atlas"; assert(saveProject(s, p));
      Scene l; std::string err; assert(loadProject(l, p, &err) && l.objects.size() == 2 && err.empty());
      const Object* la = l.find(aid); const Object* lm = l.find(mid);
      assert(la && la->isArmature && la->arm.bones.size() == 3 && la->arm.bones[2].parent == 1 && la->arm.bones[2].connected && !la->arm.bones[2].deform && la->arm.bones[1].name == "Mid");
      assert(nv(la->arm.bones[1].loc, {0.1f, 0.2f, 0.3f}) && nv(la->arm.bones[1].rot, {10, 20, 30}) && nr(la->arm.bones[1].scl.y, 1.5f) && validArmature(la->arm));
      assert(lm && lm->armatureId == aid && lm->skin.v.size() == lm->mesh.v.size() && lm->skinned);
      for (size_t i = 0; i < lm->skin.v.size(); ++i) for (int k = 0; k < 4; ++k) { assert(lm->skin.v[i].bone[k] == s.find(mid)->skin.v[i].bone[k] && nr(lm->skin.v[i].w[k], s.find(mid)->skin.v[i].w[k], 1e-6f)); }
      for (size_t i = 0; i < lm->mesh.v.size(); ++i) assert(nv(displayMesh(*lm).v[i], displayMesh(*s.find(mid)).v[i], 1e-5f));
      // a v5 project (no rig records) still loads
      FILE* f = fopen("/tmp/atlas_v5.atlas", "w"); fputs("ATLAS 5\nnext 2\nobject 1 Cube 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nmods 0\nend\n", f); fclose(f);
      Scene o; assert(loadProject(o, "/tmp/atlas_v5.atlas") && o.objects.size() == 1 && !o.objects[0].isArmature && o.objects[0].armatureId == 0);
      // corruptions are rejected and leave the scene untouched
      auto mutate = [&](const char* from, const char* to) { FILE* r = fopen(p.c_str(), "r"); std::string c; char buf[4096]; size_t n; while ((n = fread(buf, 1, sizeof buf, r)) > 0) c.append(buf, n); fclose(r);
          size_t at = c.find(from); assert(at != std::string::npos); c.replace(at, strlen(from), to); FILE* w = fopen("/tmp/atlas_bad.atlas", "w"); fputs(c.c_str(), w); fclose(w); };
      Scene g; addPrimitive(g, 0); const size_t cnt = g.objects.size();
      mutate("bone Root -1 0 1", "bone Root 7 0 1"); assert(!loadProject(g, "/tmp/atlas_bad.atlas", &err) && g.objects.size() == cnt);                 // parent out of range
      mutate("bone Mid 0 1 1", "bone Root 0 1 1"); assert(!loadProject(g, "/tmp/atlas_bad.atlas", &err));                                              // duplicate bone name
      mutate("rig 0 1 0 8", "rig 0 2 0 8"); assert(!loadProject(g, "/tmp/atlas_bad.atlas", &err));                                                          // binding to a non-armature
      mutate("rig 0 1 0 8", "rig 0 9 0 8"); assert(!loadProject(g, "/tmp/atlas_bad.atlas", &err));                                                          // binding to a missing object
      mutate("sk 0 0.97", "sk 5 0.97"); assert(!loadProject(g, "/tmp/atlas_bad.atlas", &err) && g.objects.size() == cnt); }          // weight on a bone that does not exist
    puts("rig scene tests passed"); return 0;
}
