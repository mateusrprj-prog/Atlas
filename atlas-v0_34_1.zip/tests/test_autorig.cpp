// Auto-rig tests (0.34.0). g++ -std=c++17 -Wall -Wextra -O1 tests/test_autorig.cpp -o t_ar && ./t_ar
#include <cassert>
#include <cstdio>
#include "../app/src/main/cpp/core/import_scene.hpp"
using namespace atlas;
static bool nr(float a, float b, float e = 1e-4f) { return std::fabs(a - b) < e; }
static bool closeMesh(const Mesh& a, const Mesh& b, float e = 1e-4f) { if (a.v.size() != b.v.size() || a.f != b.f) return false; for (size_t i = 0; i < a.v.size(); ++i) if (length(a.v[i] - b.v[i]) > e) return false; return true; }
static int find(const Armature& a, const char* n) { for (size_t i = 0; i < a.bones.size(); ++i) if (a.bones[i].name == n) return (int)i; return -1; }

static void checkRig(const Armature& A, const std::vector<Vec3>& P, float H, bool strictNames = true) {
    assert(validArmature(A) && A.bones.size() == 21);
    Vec3 lo = P[0], hi = P[0]; for (const Vec3& p : P) { lo.x = std::min(lo.x, p.x); lo.y = std::min(lo.y, p.y); lo.z = std::min(lo.z, p.z); hi.x = std::max(hi.x, p.x); hi.y = std::max(hi.y, p.y); hi.z = std::max(hi.z, p.z); }
    const float m = 0.02f * H;
    for (const Bone& b : A.bones) for (Vec3 q : {b.head, b.tail}) assert(q.x >= lo.x - m && q.x <= hi.x + m && q.y >= lo.y - m && q.y <= hi.y + m && q.z >= lo.z - m && q.z <= hi.z + m);   // inside the mesh bounds
    if (strictNames) for (const char* n : {"Hips", "Spine", "Chest", "Neck", "Head", "Clavicle.L", "UpperArm.L", "LowerArm.L", "Hand.L", "UpperLeg.L", "LowerLeg.L", "Foot.L", "Toes.L", "Clavicle.R", "UpperArm.R", "LowerArm.R", "Hand.R", "UpperLeg.R", "LowerLeg.R", "Foot.R", "Toes.R"}) assert(find(A, n) >= 0);
    // vertical order along the body
    const auto& B = A.bones; auto at = [&](const char* n) -> const Bone& { return B[find(A, n)]; };
    assert(at("Hips").parent == -1 && at("Head").tail.z > at("Neck").head.z && at("Neck").head.z > at("Chest").head.z && at("Chest").head.z > at("Spine").head.z && at("Spine").head.z > at("Hips").head.z);
    assert(at("Head").tail.z > lo.z + 0.97f * H);
    for (const char* sd : {".L", ".R"}) {
        const std::string s = sd; const Bone& ul = at(("UpperLeg" + s).c_str()); const Bone& ll = at(("LowerLeg" + s).c_str()); const Bone& ft = at(("Foot" + s).c_str());
        assert(ul.head.z > ul.tail.z && ll.head.z > ll.tail.z && ft.head.z > ft.tail.z && ft.tail.z < lo.z + 0.05f * H + 0.03f * H);   // hip > knee > ankle > toes
        { const float f = (ul.head.z - ul.tail.z) / (ul.head.z - ll.tail.z); assert(f > 0.4f && f < 0.56f); }                              // knee about halfway down the leg
        assert(ll.tail.z > lo.z && ll.tail.z < lo.z + 0.08f * H);                                                                          // ankle near the floor
        assert(ul.head.z > lo.z + 0.4f * H && ul.head.z < lo.z + 0.62f * H);                                                               // hip joint at plausible height
        assert(at(("Clavicle" + s).c_str()).head.z > lo.z + 0.7f * H);
        assert((at(("Hand" + s).c_str()).tail.x - at("Hips").head.x) * (s == ".L" ? 1 : -1) > 0.2f * H * 0.5f);                                                  // hands out to the sides
    }
    for (const char* n : {"Clavicle", "UpperArm", "LowerArm", "Hand", "UpperLeg", "LowerLeg", "Foot", "Toes"}) {   // left/right symmetry
        const Bone& l = at((std::string(n) + ".L").c_str()); const Bone& r = at((std::string(n) + ".R").c_str());
        assert((l.head.x > at("Hips").head.x && r.head.x < at("Hips").head.x) || std::string(n) == "Clavicle");
        assert(nr(l.tail.x - at("Hips").head.x, at("Hips").head.x - r.tail.x, 0.03f * H) && nr(l.tail.z, r.tail.z, 0.03f * H) && nr(l.parent >= 0 ? 0.f : 0.f, 0.f));
    }
}

int main() {
    // ---- presets: anime female (A-pose), realistic female, male
    for (int k = 0; k < 3; ++k) {
        Mesh m = makePreset(k); AutoRigReport r = autoRigHumanoid(m.v);
        assert(r.ok && r.error.empty() && nr(r.height, k == 0 ? 1.62f : k == 1 ? 1.68f : 1.78f, 0.01f) && r.facing < 0);
        checkRig(r.arm, m.v, r.height);
        for (const Bone& b : r.arm.bones) { assert(b.deform); assert(boneLength(b) > 0.02f * r.height * 0.5f); }
        // toes point to the front of the character (-Y)
        const Bone& t = r.arm.bones[find(r.arm, "Toes.L")]; assert(t.tail.y < t.head.y);
    }
    // facing +Y: same body turned around (rotate 180° about Z) -> toes must point to +Y, rig still valid
    { Mesh m = makePreset(1); for (Vec3& p : m.v) { p.x = -p.x; p.y = -p.y; } AutoRigReport r = autoRigHumanoid(m.v); assert(r.ok && r.facing > 0); checkRig(r.arm, m.v, r.height);
      const Bone& t = r.arm.bones[find(r.arm, "Toes.L")]; assert(t.tail.y > t.head.y); }
    // shifted and scaled mesh (centimetres, off-centre): measurements are relative
    { Mesh m = makePreset(0); for (Vec3& p : m.v) { p.x = p.x * 100 + 40; p.y = p.y * 100 - 20; p.z = p.z * 100 + 7; } AutoRigReport r = autoRigHumanoid(m.v); assert(r.ok && nr(r.height, 162.f, 0.5f)); checkRig(r.arm, m.v, r.height); }

    // ---- rejections
    { Mesh c = makeCube(); AutoRigReport r = autoRigHumanoid(c.v); assert(!r.ok && !r.error.empty() && r.arm.bones.empty()); }
    { Mesh sph = makeUVSphere(24, 16); AutoRigReport r = autoRigHumanoid(sph.v); assert(!r.ok); }
    { Mesh cy = makeCylinder(16); AutoRigReport r = autoRigHumanoid(cy.v); assert(!r.ok); }
    { Mesh m = makePreset(1); for (Vec3& p : m.v) { float y = p.y; p.y = p.z; p.z = y; } AutoRigReport r = autoRigHumanoid(m.v); assert(!r.ok); }          // lying down
    { Mesh m = makePreset(1); for (Vec3& p : m.v) p.x *= 0.15f; AutoRigReport r = autoRigHumanoid(m.v); assert(!r.ok); }                                   // arms glued to the body
    { std::vector<Vec3> few(10); AutoRigReport r = autoRigHumanoid(few); assert(!r.ok); }
    { std::vector<Vec3> nan = makePreset(0).v; nan[5].x = NAN; AutoRigReport r = autoRigHumanoid(nan); assert(!r.ok); }
    { Mesh h = makePreset(5); AutoRigReport r = autoRigHumanoid(h.v); assert(!r.ok); }                                                                     // a hand is not a body

    // ---- scene: rig + bind + pose + undo
    {
        Scene s; uint32_t mesh = addPreset(s, 1); assert(mesh && s.selected == mesh); Object* mo = s.find(mesh); const Mesh orig = mo->mesh;
        std::string msg; const size_t d0 = s.undoDepth(); uint32_t arm = autoRigSelected(s, &msg);
        assert(arm && s.selected == arm && s.undoDepth() == d0 + 2 && msg.find("21 ossos") != std::string::npos);
        Object* ao = s.find(arm); assert(ao->isArmature && ao->arm.bones.size() == 21 && ao->name == s.find(mesh)->name + "_Rig" && validArmature(ao->arm));
        mo = s.find(mesh); assert(mo->armatureId == arm && mo->skin.v.size() == mo->mesh.v.size() && sameMesh(mo->mesh, orig));
        refreshSkinned(s); assert(closeMesh(displayMesh(*mo), orig));        // neutral pose = original mesh
        // rotate the left upper arm: left hand moves a lot, right foot and head stay put
        s.selected = arm; const int ua = find(ao->arm, "UpperArm.L"); assert(armSetPose(s, ua, {}, {60, 0, 0}, {1, 1, 1}));
        refreshSkinned(s); mo = s.find(mesh); const Mesh& posed = displayMesh(*mo);
        float moveHand = 0, moveFoot = 0, moveHead = 0;
        for (size_t i = 0; i < orig.v.size(); ++i) { const Vec3& p = orig.v[i]; const float d = length(posed.v[i] - p);
            if (p.x > 0.30f && p.z > 0.95f && p.z < 1.1f) moveHand = std::max(moveHand, d);
            if (p.x < -0.05f && p.z < 0.1f) moveFoot = std::max(moveFoot, d);
            if (p.z > 1.6f) moveHead = std::max(moveHead, d); }
        assert(moveHand > 0.1f && moveFoot < 1e-4f && moveHead < 0.02f);
        // undo: pose, bind, armature (3 steps) -> back to a lone untouched mesh
        assert(s.undo() && s.undo() && s.undo()); refreshSkinned(s); assert(!s.find(arm) && s.find(mesh)->armatureId == 0 && closeMesh(displayMesh(*s.find(mesh)), orig) && s.undoDepth() == d0);
        assert(s.redo() && s.redo()); refreshSkinned(s); assert(s.find(arm) && s.find(mesh)->armatureId == arm);
    }
    // transformed mesh object (scale 2, moved): the rig is built in world space and the bound mesh stays where it was
    {
        Scene s; uint32_t mesh = addPreset(s, 0); Object* mo = s.find(mesh); mo->scale[0] = mo->scale[1] = mo->scale[2] = 2.f; mo->pos[0] = 3.f; mo->pos[1] = 1.f;
        const Mesh orig = mo->mesh; uint32_t arm = autoRigSelected(s); assert(arm);
        const Object* ao = s.find(arm); assert(nr(ao->pos[0], 0.f) && nr(ao->scale[0], 1.f));
        const Bone& head = ao->arm.bones[find(ao->arm, "Head")]; assert(nr(head.tail.z, 3.24f, 0.02f) && nr(head.tail.x, 3.f, 0.1f));
        refreshSkinned(s); mo = s.find(mesh); assert(closeMesh(displayMesh(*mo), orig, 1e-3f));
    }
    // refusals leave the scene untouched
    { Scene s; uint32_t c = addPrimitive(s, 0); std::string msg; const size_t d = s.undoDepth(); assert(autoRigSelected(s, &msg) == 0 && !msg.empty() && s.undoDepth() == d && s.objects.size() == 1 && s.selected == c);
      uint32_t a = addArmature(s); assert(a && autoRigSelected(s, &msg) == 0);                                   // armature selected
      Scene e; addPreset(e, 1); setEditMode(e, true); assert(autoRigSelected(e, &msg) == 0); }                    // Edit Mode
    // ---- import -> auto-rig, end to end: export a preset as GLB-less path (merge) is covered in test_import; here: import into scene
    { Scene s; std::string msg; assert(importModelToScene(s, (const uint8_t*)"abc", 3, "glb", "x", &msg) == 0 && !msg.empty() && s.objects.empty());
      Scene e; addPreset(e, 1); setEditMode(e, true); assert(importModelToScene(e, (const uint8_t*)"abcdefghij", 10, "glb", "x", &msg) == 0); }
    std::puts("test_autorig OK"); return 0;
}
