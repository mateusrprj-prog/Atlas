#!/bin/sh
# Builds and runs every core test with sanitizers. Usage: sh tests/run_all.sh   (CI can call this instead of listing files)
set -e
for t in test_rig test_rig_scene test_import test_autorig; do
  g++ -std=c++17 -Wall -Wextra -O1 -g -fsanitize=address,undefined tests/$t.cpp -o /tmp/$t && /tmp/$t
done
# test_scene is large: plain build (add -fsanitize=address,undefined for a deeper, slower run)
g++ -std=c++17 -Wall -Wextra -O1 tests/test_scene.cpp -o /tmp/test_scene && /tmp/test_scene
