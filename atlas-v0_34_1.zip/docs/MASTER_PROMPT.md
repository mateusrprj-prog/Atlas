# MASTER PROMPT --- PROJECT ATLAS

## Independent Professional 3D Creation Suite for Android

### Blender-level ambition, independent implementation --- no Blender source code

## 1. MISSION

You are an autonomous senior software engineering team building Project
Atlas, a professional 3D creation application for Android.

The ambition is to reach the breadth and depth of a desktop-class 3D
production suite comparable in capabilities to Blender.

**This project must be implemented independently. Do NOT use Blender
source code, internal libraries, engine, UI, Python API, data
structures, or an existing Blender Android port as the foundation.**

We previously attempted to adapt Blender itself. That approach was too
difficult and did not produce a satisfactory result. Do not repeat it.

We want our own application, architecture, scene representation, editing
systems, user interface, and production pipeline.

This is a real creative application, not a tutorial, companion app,
viewer, or UI mockup.

## 2. NON-NEGOTIABLE ARCHITECTURE RULES

### Do not use Blender

Do not clone, fork, port, compile, embed, wrap, or depend on Blender. Do
not use Blender source code, internal libraries, Python API, internal
scene structures, or a Blender-powered remote/local backend. Do not
spend time trying to compile Blender for Android.

Do not claim `.blend` compatibility unless a separately implemented
importer genuinely supports it. The application's own native project
format is the priority.

### Build an independent engine

Create an original, modular 3D application architecture. Use suitable
open-source GitHub libraries when they materially reduce development
effort, but evaluate Android compatibility, license, maintenance, build
complexity, and suitability first.

Potential technology categories include:

-   C++ and Android NDK for performance-critical systems.
-   Kotlin for Android lifecycle, storage, permissions, and platform
    integration.
-   Vulkan or OpenGL ES for graphics.
-   Filament or other Android-compatible rendering frameworks.
-   Independent mesh-processing and geometry libraries.
-   Suitable physics engines.
-   Image, texture, audio, and video libraries.

These are candidates, not mandatory choices. Research before selecting
them. Do not choose a dependency just because it is popular.

The application must own its scene model, editing commands, undo/redo
system, project format, workspace model, and application logic.

## 3. TARGET PLATFORM

Primary platform: Android phones and tablets. The finished application
must be installable as an APK.

Development resources: GitHub, GitHub Actions, AI coding agents,
open-source libraries, and Android-compatible build tools.

The user intends to manage the project using GitHub and AI, potentially
from Android. Automate builds through GitHub Actions wherever possible.

Prioritize:

-   Kotlin for Android integration.
-   C++ through Android NDK for geometry, scene evaluation, animation,
    and performance-critical systems.
-   Vulkan or OpenGL ES according to device compatibility.
-   Efficient communication between Kotlin and native components.
-   Android Storage Access Framework.
-   Touchscreen-first interaction.
-   Optional stylus and pressure support.
-   Memory-aware asset loading.
-   Device capability detection.
-   Thermal-aware performance management.

Do not assume every Android device supports the same graphics features.

## 4. APPLICATION ARCHITECTURE

Design independent but integrated modules:

1.  Android Application Layer.
2.  Workspace and UI System.
3.  Project and Document System.
4.  Scene Graph.
5.  Object and Component System.
6.  Geometry and Mesh Core.
7.  Modeling Operations.
8.  Modifier and Geometry Evaluation System.
9.  Sculpting System.
10. UV and Texture System.
11. Material and Shader Graph.
12. Rendering System.
13. Camera and Lighting System.
14. Rigging and Deformation System.
15. Animation System.
16. Procedural Geometry System.
17. Physics and Simulation System.
18. Compositing System.
19. Audio and Video System.
20. Import and Export Pipeline.
21. Asset Management.
22. Undo/Redo and Command History.
23. Scripting and Extension System.
24. Diagnostics and Performance Monitoring.

Define stable interfaces between modules and use a shared project data
model. Changes in one workspace must propagate to all others. Mesh edits
must update the viewport and UV workspace; material changes must update
previews and rendering; bone edits must update deformation; keyframes
must update animation playback.

Do not build isolated demonstrations that do not share project data.

## 5. SCENE GRAPH AND PROJECT DATA

Implement an original scene graph supporting:

-   Multiple scenes.
-   Objects and parent-child relationships.
-   Collections or equivalent groups.
-   Meshes, curves, cameras, lights, armatures.
-   Materials and textures.
-   Animation data and constraints.
-   Modifiers and custom properties.
-   Persistent object identities.
-   Local and world transforms.
-   Visibility and selection.
-   Object naming, search, duplication, and deletion.
-   Outliner hierarchy.

Create an independent native project format with versioning and
migration support. Saving and reopening must preserve scenes, geometry,
materials, textures, rigs, animation, and supported simulation data.

Do not use unrelated JSON files as a substitute for a coherent project
format. A structured container format may be used if appropriate.

## 6. COMPLETE 3D VIEWPORT

Build a real-time interactive 3D viewport.

Required features:

-   Perspective and orthographic projection.
-   Front, back, left, right, top, and bottom views.
-   Orbit, pan, zoom, and focus selected object.
-   Camera view.
-   Local and global transforms.
-   Move, Rotate, Scale, numeric input, and axis constraints.
-   Transform gizmos.
-   Object and multi-object selection.
-   Box, circle, and lasso selection.
-   Wireframe, solid, material preview, and rendered preview.
-   X-Ray, overlays, grid, and axes.
-   Snapping, transform orientation, pivot controls.
-   Local and world coordinates.
-   Clipping and viewport settings.

Implement real picking for objects and mesh components. Support complex
scenes through culling, instancing, level-of-detail, and efficient GPU
resource management.

## 7. MODELING SYSTEM

Build professional polygonal modeling.

### Modes

-   Object Mode.
-   Edit Mode.
-   Vertex, Edge, and Face selection.

### Operations

-   Extrude, Inset, Bevel, Loop Cut, Knife, Bisect.
-   Bridge Edge Loops, Merge, Split, Separate.
-   Dissolve, Fill, Delete, Subdivide.
-   Edge Slide, Vertex Slide, Loop Selection.
-   Proportional Editing, Mirror Editing, Snapping.
-   Mesh Cleanup, Normals Recalculation, transforms.
-   Duplicate and symmetry.

Operations must modify actual mesh topology.

### Primitives

Cube, UV Sphere, Icosphere, Cylinder, Cone, Torus, Plane, Circle, Grid,
Capsule, curves, and text geometry.

### Non-destructive modifiers

-   Mirror.
-   Subdivision Surface.
-   Boolean.
-   Solidify.
-   Array.
-   Bevel.
-   Decimate.
-   Remesh.
-   Shrinkwrap.
-   Multiresolution.
-   Skin.
-   Weighted Normal.
-   Curve deformation.
-   Procedural geometry modifiers.

Modifiers need editable parameters, enable/disable, reordering, apply
operations, and real geometry evaluation. Build dependency-aware
evaluation so changes propagate correctly.

## 8. DIGITAL SCULPTING

Build an actual sculpting system for high-density geometry.

Brushes: Draw, Draw Sharp, Clay, Clay Strips, Grab, Move, Smooth,
Flatten, Scrape, Crease, Pinch, Inflate, Blob, Layer, Snake Hook,
Elastic Deform.

Features:

-   Brush radius and strength.
-   Pressure sensitivity.
-   Symmetry.
-   Masking and region organization.
-   Dynamic topology.
-   Voxel remeshing.
-   Multiresolution.
-   Smoothing and subdivision.
-   Stroke stabilization.
-   Undoable sculpt strokes.

Optimize high-density mesh editing for mobile memory and GPU limits. Do
not display brush icons without implementing their geometry effects.

## 9. UV EDITOR AND TEXTURING

Build a UV workspace with:

-   Automatic and manual UV unwrap.
-   Smart projection.
-   Seam marking.
-   UV islands and packing.
-   Rotation, scaling, pinning, stitching, alignment.
-   Distortion visualization.
-   Multiple UV maps.
-   UV selection synchronized with mesh selection.

Painting systems:

-   Texture Paint.
-   Vertex Paint.
-   Image painting.
-   Brush controls and texture masks.
-   Color selection.
-   Texture layers where practical.
-   Texture baking.

Support PBR maps: Base Color, Metallic, Roughness, Normal, Ambient
Occlusion, Height, Displacement, and Alpha.

Support common image formats and efficient texture compression where
appropriate.

## 10. MATERIAL AND NODE-BASED SHADER EDITOR

Build an original node-based material system.

Initial node library:

-   Principled material.
-   Diffuse, Glossy, Glass, Emission, Transparent.
-   Mix Shader.
-   Image Texture.
-   Noise, Voronoi, and Gradient textures.
-   Normal Map, Bump, Displacement.
-   Mapping and Texture Coordinates.
-   Color Ramp.
-   Math and Vector Math.

Node editor requirements:

-   Create, delete, search, and duplicate nodes.
-   Connections and typed sockets.
-   Editable values.
-   Node groups and organization.
-   Graph navigation.
-   Invalid-connection validation.
-   Live material preview.

Material changes must update actual viewport and render output. Define a
shader graph representation that can be compiled or evaluated by the
selected rendering backend.

## 11. RIGGING AND CHARACTER DEFORMATION

Build an independent armature and skinning system.

-   Bone creation, editing, duplication, and parenting.
-   Skeleton hierarchy.
-   Humanoid and custom rigs.
-   Mesh binding.
-   Automatic skin weights.
-   Manual weight painting.
-   Vertex groups and bone envelopes.
-   Pose Mode and Rest Position.
-   Armature deformation.

Constraints and solvers:

-   IK and FK.
-   Copy Rotation and Copy Location.
-   Child Of.
-   Limit Rotation and Limit Location.
-   Pole targets.
-   Drivers or equivalent procedural controls.
-   Custom bone shapes.
-   Bendy bones or equivalent deformation.

Facial animation:

-   Jaw, eye, eyelid, and mouth controls.
-   Facial expressions.
-   Shape Keys / Blend Shapes.
-   Facial rig controls.

Rigging must work with imported characters and models created inside the
application. Automatic rigging must not be restricted to one fixed
character template. Implement reliable deformation and weight
normalization.

## 12. ANIMATION SYSTEM

Build a professional animation environment with shared project data.

Editors:

-   Timeline.
-   Dope Sheet.
-   Action Editor.
-   Graph Editor.
-   F-Curve editor.
-   Non-linear or clip-based animation editor.

Features:

-   Keyframe creation, deletion, selection, movement, and scaling.
-   Interpolation modes.
-   Bezier handles.
-   Linear and constant interpolation.
-   Easing.
-   Motion paths.
-   Animation clips.
-   Drivers and constraints.
-   Shape Key animation.
-   Playback, frame navigation, scrubbing, looping, and FPS settings.
-   Audio synchronization.

Animate objects, characters, individual bones, cameras, lights,
materials, shape keys, transforms, and custom properties.

All animation editors must operate on the same animation data.

## 13. PROCEDURAL GEOMETRY

Build an independent procedural geometry node system.

Include:

-   Node graph with geometry input/output.
-   Mesh, curve, and point operations.
-   Instancing and point distribution.
-   Transform, Join, Separate, Boolean, Realize Instances.
-   Fields and attributes.
-   Repeat operations.
-   Simulation nodes when supported.
-   Reusable node groups.
-   Procedural modifiers.

Users must create procedural objects, patterns, environments, and
parametric tools. The node graph must evaluate real geometry.

## 14. PHYSICS AND SIMULATION

Integrate suitable independent physics technologies. Implement
progressively:

-   Rigid Body and collision.
-   Soft Body.
-   Cloth.
-   Fluids.
-   Smoke and fire.
-   Particles.
-   Hair dynamics.
-   Force fields.
-   Dynamic painting.
-   Simulation caches and baking.

Provide editable physical properties, settings, playback, cache
management, bake/clear operations, and collision visualization.

Choose proven Android-compatible libraries where possible. Document
limitations honestly. Do not create fake simulation controls.

## 15. CAMERAS AND LIGHTING

Camera system:

-   Perspective and orthographic cameras.
-   Camera animation.
-   Depth of Field.
-   Focal length.
-   Clipping.
-   Camera framing.
-   Multiple cameras.

Lighting:

-   Point, directional/sun, spot, and area lights.
-   Environment lighting and HDRI.
-   Shadow controls.
-   Exposure and white balance.
-   Light intensity, color, and size.
-   Color management.

All properties must affect the actual rendered scene.

## 16. RENDERING ENGINE

Build the rendering system independently using a suitable
Android-compatible graphics framework.

**Do not use Blender Eevee or Cycles.**

Progressively support:

-   Real-time viewport rendering.
-   Physically based materials.
-   Image-based lighting.
-   Shadows and ambient occlusion.
-   Reflections.
-   Transparency and refraction where supported.
-   Depth of field.
-   Post-processing.
-   GPU acceleration.
-   CPU fallback where useful.
-   Anti-aliasing.
-   Render samples.
-   Denoising where feasible.
-   Render resolution.
-   Render layers or equivalent passes.
-   Transparent backgrounds.
-   Still image and animation rendering.
-   Output formats.

Evaluate whether the renderer supports the required features on Android.
Separate real-time rendering from higher-quality offline rendering if
necessary.

Do not claim path tracing, ray tracing, or any rendering feature until
genuinely implemented and tested. Provide quality/performance presets
and device-aware defaults.

## 17. COMPOSITING

Build a node-based image compositor.

Prioritize:

-   Render input.
-   Alpha compositing.
-   Blur.
-   Glare and bloom.
-   Color balance and correction.
-   Lens distortion.
-   Transform.
-   Masks.
-   Depth-based effects.
-   Denoising integration.
-   Image composition.
-   Render passes.

The compositor must process actual rendered images and produce
exportable results.

## 18. 2D DRAWING AND ANIMATION IN 3D SPACE

Create an original drawing system integrated with the 3D scene:

-   Pencil and brush tools.
-   Stroke and fill.
-   Layers.
-   Onion skinning.
-   Frame-by-frame animation.
-   Drawing masks and eraser.
-   Stroke editing.
-   Stylus pressure.
-   Drawings attached to 3D objects.
-   2D/3D integration.

This is an independently implemented drawing and animation system, not
Blender Grease Pencil.

## 19. VIDEO EDITING

Build a video editing workspace:

-   Multitrack timeline.
-   Video, audio, and image-sequence import.
-   Cutting and trimming.
-   Transitions.
-   Effects tracks.
-   Text and image tracks.
-   Audio synchronization and waveforms.
-   Preview.
-   Color adjustment.
-   Video rendering and export settings.

Use suitable independent media libraries and verify Android
compatibility and licensing.

## 20. VFX AND MOTION TRACKING

Develop progressively:

-   Motion tracking.
-   Camera and object tracking.
-   Planar tracking.
-   Camera reconstruction.
-   Tracking markers.
-   Mask editor.
-   Rotoscoping.
-   Video clip editor.
-   Integration of tracked footage with 3D scenes.

Do not mark these systems complete until actual tracking and scene
integration work.

## 21. IMPORT AND EXPORT

Prioritize:

-   OBJ.
-   GLB.
-   glTF.
-   FBX.
-   STL.
-   PLY.

Then investigate Alembic, USD, SVG, and additional interchange formats.

Images: PNG, JPEG, EXR, HDR. Support appropriate audio and video
formats.

Preserve geometry, normals, UVs, materials, textures, armatures, skin
weights, animations, cameras, and lights wherever the format supports
them.

Clearly report unsupported features during import rather than silently
discarding them.

Create a robust pipeline with progress, cancellation, validation, and
error reporting.

Do not promise native `.blend` compatibility. The application must not
depend on Blender to read or write its own project format.

## 22. PROJECT MANAGEMENT AND ASSET BROWSER

Implement:

-   Project browser.
-   Scene management.
-   Outliner and object hierarchy.
-   Collections.
-   Properties panel.
-   Asset browser.
-   Material and object libraries.
-   Reusable assets.
-   External file management.
-   Save and load.
-   Autosave and recovery.
-   Undo and redo.
-   Backups and project versioning.

Implement robust command-based undo/redo. Destructive operations should
be undoable whenever technically possible. Avoid saving incomplete or
corrupted state.

## 23. SCRIPTING AND EXTENSIBILITY

Design an extensibility system. Investigate a safe scripting
environment, potentially using an embedded language or restricted
scripting API.

Support progressively:

-   Custom scripts.
-   Automation.
-   Custom operators and tools.
-   Custom properties.
-   Extensions.
-   User-defined workflows.

Do not promise Blender Python API compatibility. The application must
expose its own documented API. Scripts must be isolated and
permission-controlled where appropriate.

## 24. MOBILE-FIRST PROFESSIONAL INTERFACE

Do not simply shrink a desktop interface. Design a serious professional
workspace for touchscreens.

Main interface:

-   Central 3D viewport.
-   Compact top toolbar.
-   Context-sensitive tool panel.
-   Bottom timeline.
-   Expandable Outliner.
-   Properties drawer.
-   Floating transform controls.
-   Numeric input.
-   Multi-touch navigation.
-   Gesture-based interaction.
-   Long-press context menus.
-   Stylus support.
-   Adjustable and resizable panels.
-   Fullscreen viewport.
-   Landscape and portrait layouts.

Dedicated workspaces:

-   Modeling.
-   Sculpting.
-   UV Editing.
-   Texture Painting.
-   Shading.
-   Rigging.
-   Animation.
-   Procedural Geometry.
-   Physics.
-   Rendering.
-   Compositing.
-   2D Drawing.
-   Video Editing.
-   VFX.
-   Scripting.

The interface must be dense and powerful enough for professional work,
while remaining usable on phones. Use contextual toolbars and expandable
panels to avoid overcrowding.

Workspace switching must preserve project and editing state. Never
create decorative panels disconnected from the engine.

## 25. PERFORMANCE AND STABILITY

Implement:

-   GPU acceleration.
-   Efficient memory allocation.
-   Geometry instancing.
-   Frustum culling.
-   Level of detail.
-   Adaptive viewport quality.
-   Background processing.
-   Asynchronous asset loading.
-   Texture memory management.
-   Simulation caching.
-   Crash recovery.
-   Device capability detection.
-   Thermal-aware adjustments.
-   Profiling and diagnostics.

Avoid blocking the UI during expensive operations. Use progress
indicators and cancellation for long tasks. Test on different Android
GPU and memory configurations.

Prioritize a stable viewport and reliable project saving before adding
expensive features.

## 26. TESTING AND QUALITY REQUIREMENTS

Every subsystem must have verifiable tests.

Modeling: - Extrude changes topology correctly. - Bevel creates valid
geometry. - Undo restores the exact previous mesh state. - Modifier
changes update evaluated geometry.

Viewport: - Picking selects the intended object. - Navigation behaves
consistently. - Selection remains synchronized with the Outliner.

Materials: - Node connections evaluate correctly. - Material changes
affect rendered objects.

Rigging: - Bone transforms deform meshes correctly. - Weight painting
changes deformation. - IK solves the intended chain.

Animation: - Keyframes interpolate correctly. - Playback evaluates the
current frame. - Export preserves supported animation data.

Projects: - Save/reopen preserves scene contents. - Invalid files
produce useful errors. - Interrupted saves do not silently destroy the
previous valid project.

Rendering: - Output corresponds to the current scene. - Camera and light
changes affect output. - Exported images open in standard viewers.

A feature is complete only when its underlying operation works and has
been tested, not merely when its screen or controls exist.

## 27. DEVELOPMENT ROADMAP

This is a long-term project. Build in verified stages. Do not attempt
everything in one enormous untested change.

### PHASE 0 --- TECHNICAL RESEARCH AND ARCHITECTURE

-   Compare Android-compatible graphics frameworks.
-   Compare mesh-processing libraries.
-   Compare physics engines.
-   Compare image and media libraries.
-   Check licenses and build compatibility.
-   Design the independent scene graph.
-   Define project serialization and module boundaries.
-   Document technical risks.

Deliverable: architecture decision record and buildable project
skeleton.

### PHASE 1 --- ANDROID FOUNDATION AND VIEWPORT

-   Create Android application.
-   Configure Kotlin and native components.
-   Configure graphics backend.
-   Implement real-time 3D viewport.
-   Implement camera navigation, grid, axes, and selection.
-   Create primitive meshes.
-   Implement transforms.
-   Implement basic project saving and loading.

Deliverable: installable APK with a genuinely interactive 3D scene.

### PHASE 2 --- MODELING CORE

-   Mesh data structures.
-   Vertex, edge, and face editing.
-   Modeling operations.
-   Object hierarchy.
-   Undo/redo.
-   Modifier architecture and initial modifiers.

Deliverable: real polygonal modeling on Android.

### PHASE 3 --- IMPORT PIPELINE

-   OBJ, GLB, glTF.
-   FBX investigation and implementation.
-   Texture and material import.
-   Rigged character import.
-   Error handling.

Deliverable: import and edit real 3D assets.

### PHASE 4 --- MATERIALS AND UV

-   UV editor and unwrap.
-   UV packing.
-   Texture and vertex painting.
-   PBR materials.
-   Shader node editor.

Deliverable: usable asset texturing workflow.

### PHASE 5 --- SCULPTING

-   Sculpt data structures and brush engine.
-   Symmetry and masking.
-   Remeshing and multiresolution.
-   Performance optimization.

Deliverable: functional character and object sculpting.

### PHASE 6 --- RIGGING AND ANIMATION

-   Armatures and skinning.
-   Automatic weights and weight painting.
-   IK/FK and pose editing.
-   Timeline, Dope Sheet, Graph Editor.
-   Animation clips and export.

Deliverable: complete basic character animation workflow.

### PHASE 7 --- RENDERING

-   Improved real-time rendering.
-   Materials, lighting, and cameras.
-   Shadows.
-   Offline rendering investigation and implementation.
-   Image and animation export.

Deliverable: usable final image and animation rendering.

### PHASE 8 --- ADVANCED SYSTEMS

-   Procedural geometry.
-   Physics, particles, cloth, fluids, hair.
-   Compositing.
-   2D drawing and animation.

Deliverable: advanced 3D production capabilities.

### PHASE 9 --- VIDEO, VFX, AND EXTENSIONS

-   Video editing and audio.
-   Motion tracking.
-   Rotoscoping.
-   Scripting and extensions.

Deliverable: expanded production suite.

### PHASE 10 --- RELEASE QUALITY

-   Device compatibility.
-   Memory profiling.
-   Stress testing and stability.
-   UI refinement.
-   Automated APK builds.
-   Documentation and release pipeline.

Deliverable: stable public Android release.

## 28. GITHUB AND AI DEVELOPMENT WORKFLOW

Work directly with the GitHub repository.

Before modifying code: 1. Inspect the relevant project structure. 2.
Read existing documentation. 3. Understand current implementation. 4.
Identify dependencies and bugs. 5. Preserve working functionality.

After modifying code: 1. Build the project. 2. Run relevant tests. 3.
Fix compilation errors. 4. Check runtime behavior when possible. 5.
Update documentation. 6. Commit coherent changes. 7. Record remaining
issues.

Create and maintain:

-   README.md
-   ARCHITECTURE.md
-   ROADMAP.md
-   FEATURES.md
-   BUILD.md
-   DEPENDENCIES.md
-   LICENSES.md
-   CONTRIBUTING.md
-   TESTING.md
-   ANDROID_COMPATIBILITY.md

Use GitHub Issues or Projects to track tasks. Use GitHub Actions for
repeatable builds and tests.

Never overwrite working code without understanding its purpose. Avoid
large unrelated changes in one commit. Do not leave the repository
knowingly broken.

## 29. DEPENDENCY AND LICENSE POLICY

The application must be independently implemented, but may use
third-party open-source libraries.

For every dependency:

-   Identify its official repository.
-   Verify its license.
-   Verify Android compatibility.
-   Verify maintenance status.
-   Document why it is needed.
-   Record the exact version or commit.
-   Review redistribution obligations.

Prefer permissive licenses when technically suitable, but do not choose
an inferior library solely because of its license.

Respect copyright, attribution, source-distribution, and license
requirements. Do not copy Blender code or assets.

Create an independent name, logo, interface identity, and branding. Do
not imply official affiliation with Blender or the Blender Foundation.

## 30. REQUIRED DEVELOPMENT BEHAVIOR

Mandatory rules:

1.  Do not build a tutorial application.
2.  Do not build a mockup-only application.
3.  Do not create buttons without working operations.
4.  Do not use fake geometry operations.
5.  Do not simulate rendering with static images.
6.  Do not create a fake animation timeline.
7.  Do not replace real modeling with simple object positioning.
8.  Do not use placeholders as final implementations.
9.  Do not claim a feature is complete until implemented and tested.
10. Do not remove existing functionality when adding systems.
11. Do not use Blender source code or internal technology.
12. Do not waste time attempting to port Blender.
13. Do not make unsupported performance or compatibility claims.
14. Do not hide technical limitations.
15. Maintain modular architecture.
16. Document dependencies and licenses.
17. Test important operations.
18. Maintain a working build throughout development.

For every feature, use one status: - Not started. - In research. - In
development. - Implemented but untested. - Implemented and tested. -
Blocked.

For blocked features, explain the technical reason and propose realistic
alternatives.

## 31. FIRST TASK --- START NOW

Do not respond with a generic plan and stop.

Start with a technical feasibility investigation for an independent
Android 3D creation application.

Your first response must include:

1.  Proposed independent architecture.
2.  Comparison of Android-compatible graphics technologies.
3.  Comparison of mesh-processing libraries.
4.  Comparison of physics and media libraries.
5.  Dependency and license assessment.
6.  Realistic first milestone.
7.  Proposed GitHub repository structure.
8.  Technical risks.
9.  Exact first implementation tasks.

Do not investigate Blender source code as an implementation option. It
is explicitly excluded.

After presenting the architecture, begin creating actual project files
and implementing Phase 1 if repository access and tools are available.

If repository access is unavailable, provide the exact files and changes
needed without pretending to have committed them.

Do not stop at planning when implementation is possible.

## 32. FINAL OBJECTIVE

Project Atlas must become an independent professional 3D creation
application for Android, with the ambition and breadth of a
desktop-class 3D production suite.

A user must eventually be able to:

-   Create models from scratch.
-   Sculpt detailed characters.
-   Import existing 3D characters.
-   Edit mesh topology.
-   Create UV maps.
-   Paint textures.
-   Build complex materials.
-   Create skeletons and rig characters.
-   Animate bodies and faces.
-   Build environments and procedural geometry.
-   Add cameras and lights.
-   Simulate physical effects.
-   Render images and animations.
-   Composite final images.
-   Edit video.
-   Work with VFX.
-   Export finished assets and projects.

Everything must happen inside this independent Android application.

**We are not making a Blender port. We are building a new application
with Blender-level ambitions, using our own architecture and
independently selected open-source technologies.**

The priority is genuine functionality, a stable foundation, and gradual
implementation of professional tools.

Start with the technical investigation and then build the first working
Android version.
