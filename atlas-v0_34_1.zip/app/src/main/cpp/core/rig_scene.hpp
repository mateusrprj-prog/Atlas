// Scene-level rig operations (0.31.0 armature objects + bone editing + pose, 0.32.0 binding + weights).
// Every operation is ONE undo step. Rig state (armature, skin, binding) is snapshotted for the armature and all meshes bound to it.
#pragma once
#include "scene.hpp"

namespace atlas {

inline Mat4 objectMatrix(const Object& o) { return trsMatrix({o.pos[0], o.pos[1], o.pos[2]}, {o.rot[0], o.rot[1], o.rot[2]}, {o.scale[0], o.scale[1], o.scale[2]}); }
inline Mat4 meshToArmature(const Object& arm, const Object& mesh) { return mmul(affineInverse(objectMatrix(arm)), objectMatrix(mesh)); }

inline void dropSkinCache(Object& o) { o.skinned = false; o.skinSrcRev = ~0ull; o.skinSig.clear(); o.skinMesh = Mesh{}; o.modsRev = nextRev(); }

// Recomputes the posed copy of every bound mesh whose pose / weights / geometry changed. Returns true if anything visible changed.
// The mesh being edited (Edit Mode) is shown undeformed so the user edits what they see.
inline bool refreshSkinned(Scene& s) {
    bool changed = false;
    for (auto& o : s.objects) {
        if (o.isArmature) continue;
        const Object* a = o.armatureId ? s.find(o.armatureId) : nullptr;
        const bool ok = a && a->isArmature && !o.mesh.v.empty() && o.skin.v.size() == o.mesh.v.size() && validSkin(o.skin, (int)a->arm.bones.size())
                        && !(s.editMode && o.id == s.selected);
        if (!ok) { if (o.skinned) { dropSkinCache(o); changed = true; } continue; }
        const Mat4 toArm = meshToArmature(*a, o); const std::vector<Mat4> sk = skinMatrices(a->arm);
        std::vector<float> sig; sig.push_back((float)sk.size());
        for (const auto& m : sk) for (float x : m.m) sig.push_back(x);
        for (float x : toArm.m) sig.push_back(x);
        if (o.skinned && o.skinSrcRev == o.meshRev && o.skinSig == sig) continue;
        o.skinMesh = skinMesh(o.mesh, o.skin, a->arm, toArm); o.skinned = true; o.skinSrcRev = o.meshRev; o.skinSig = std::move(sig); o.modsRev = nextRev();
        changed = true;
    }
    return changed;
}

struct RigSnap { uint32_t id = 0; Armature arm; Skin skin; uint32_t armatureId = 0; int activeBone = -1; };
inline RigSnap rigSnap(const Object& o) { RigSnap r; r.id = o.id; r.arm = o.arm; r.skin = o.skin; r.armatureId = o.armatureId; r.activeBone = o.activeBone; return r; }
inline std::vector<RigSnap> snapGroup(const Scene& s, uint32_t armId) {
    std::vector<RigSnap> v;
    if (const Object* a = s.find(armId)) v.push_back(rigSnap(*a));
    for (const auto& o : s.objects) if (!o.isArmature && o.armatureId == armId) v.push_back(rigSnap(o));
    return v;
}
struct RigCmd : Command {
    std::vector<RigSnap> before, after;
    static void restore(Scene& s, const std::vector<RigSnap>& st) {
        for (const auto& r : st) if (Object* o = s.find(r.id)) {
            o->arm = r.arm; o->skin = r.skin; o->armatureId = r.armatureId; o->activeBone = r.activeBone; o->skinSrcRev = ~0ull;
        }
        refreshSkinned(s);
    }
    void apply(Scene& s) override { restore(s, after); }
    void revert(Scene& s) override { restore(s, before); }
};
inline bool commitRig(Scene& s, std::vector<RigSnap> before, uint32_t armId) {
    auto c = std::make_unique<RigCmd>(); c->before = std::move(before); c->after = snapGroup(s, armId);
    refreshSkinned(s); s.record(std::move(c)); return true;
}

// ---------------------------------------------------------------- armature objects and bone editing (0.31.0)
inline uint32_t addArmature(Scene& s) {
    if (s.editMode) return 0;
    Object o; o.id = s.nextId++; o.name = uniqueName(s, "Armature"); o.isArmature = true; o.meshRev = nextRev();
    addBone(o.arm, "Bone", {0, 0, 0}, {0, 0, 0.5f}); o.activeBone = 0;
    const uint32_t id = o.id; s.execute(std::make_unique<AddObjectCmd>(std::move(o))); return id;
}
inline Object* activeArmature(Scene& s) { Object* o = s.find(s.selected); return (o && o->isArmature && !s.editMode) ? o : nullptr; }

// Runs `fn(workCopy, activeBone)` on a copy of the active armature; commits (one undo step) only if fn succeeds and the result is valid.
template <class Fn> inline bool editArmature(Scene& s, Fn fn) {
    Object* o = activeArmature(s); if (!o) return false;
    Armature work = o->arm; int active = o->activeBone;
    if (!fn(work, active) || !validArmature(work)) return false;
    const uint32_t id = o->id; auto before = snapGroup(s, id);
    o->arm = std::move(work); o->activeBone = (active >= 0 && active < (int)o->arm.bones.size()) ? active : -1;
    return commitRig(s, std::move(before), id);
}
inline int armAddBone(Scene& s, Vec3 head, Vec3 tail, int parent, bool connected) {
    int made = -1;
    editArmature(s, [&](Armature& a, int& act) { made = addBone(a, "Bone", head, tail, parent, connected); act = made; return made >= 0; });
    return made;
}
inline int armExtrudeActive(Scene& s, Vec3 delta) {   // new connected child at the tip of the active bone, its tail = old tail + delta
    int made = -1;
    editArmature(s, [&](Armature& a, int& act) {
        if (act < 0 || act >= (int)a.bones.size() || !finite3(delta)) return false;
        made = extrudeBone(a, act, a.bones[act].tail + delta); act = made; return made >= 0;
    });
    return made;
}
inline bool armSelectBone(Scene& s, int idx) {   // selection only: no undo step
    Object* o = activeArmature(s); if (!o || idx < -1 || idx >= (int)o->arm.bones.size()) return false;
    o->activeBone = idx; return true;
}
inline bool armSetParent(Scene& s, int child, int parent, bool connected) { return editArmature(s, [&](Armature& a, int&) { return setBoneParent(a, child, parent, connected); }); }
inline bool armRename(Scene& s, int idx, const std::string& n) { return editArmature(s, [&](Armature& a, int&) { return renameBone(a, idx, n); }); }
inline bool armSetRest(Scene& s, int idx, Vec3 head, Vec3 tail, float roll) { return editArmature(s, [&](Armature& a, int&) { return setBoneRest(a, idx, head, tail, roll); }); }
inline bool armSetDeform(Scene& s, int idx, bool on) {
    return editArmature(s, [&](Armature& a, int&) { if (idx < 0 || idx >= (int)a.bones.size() || a.bones[idx].deform == on) return false; a.bones[idx].deform = on; return true; });
}
inline bool armSetPose(Scene& s, int idx, Vec3 loc, Vec3 rot, Vec3 scl) { return editArmature(s, [&](Armature& a, int&) { return setBonePose(a, idx, loc, rot, scl); }); }
inline bool armResetPose(Scene& s, bool all) {
    return editArmature(s, [&](Armature& a, int& act) {
        if (poseIsRest(a)) return false;
        if (all) { resetPose(a); return true; }
        if (act < 0 || act >= (int)a.bones.size()) return false;
        Bone& b = a.bones[act]; b.loc = {}; b.rot = {}; b.scl = {1, 1, 1}; return true;
    });
}
inline bool armMirror(Scene& s, bool all) {   // mirrors the active bone (and its children) or the whole armature across X = 0
    return editArmature(s, [&](Armature& a, int& act) {
        std::vector<int> src;
        if (all) for (int i = 0; i < (int)a.bones.size(); ++i) src.push_back(i);
        else {
            if (act < 0 || act >= (int)a.bones.size()) return false;
            for (int i = 0; i < (int)a.bones.size(); ++i) if (isAncestorOrSelf(a, act, i)) src.push_back(i);
        }
        auto made = mirrorBonesX(a, src); if (made.empty()) return false; act = made.front(); return true;
    });
}
inline bool armDeleteActive(Scene& s) {
    Object* o = activeArmature(s); if (!o || o->activeBone < 0 || o->activeBone >= (int)o->arm.bones.size()) return false;
    const uint32_t id = o->id; auto before = snapGroup(s, id);
    std::vector<int> map; if (!deleteBone(o->arm, o->activeBone, &map)) return false;
    for (auto& m : s.objects) if (!m.isArmature && m.armatureId == id) remapSkin(m.skin, map);
    o->activeBone = -1; return commitRig(s, std::move(before), id);
}

// ---------------------------------------------------------------- binding and weights (0.32.0)
// Binds the active mesh object to `armId` with automatic weights from bone proximity (replaces any previous binding).
inline bool bindMeshToArmature(Scene& s, uint32_t armId) {
    Object* m = s.find(s.selected); const Object* a = s.find(armId);
    if (!m || m->isArmature || !a || !a->isArmature || s.editMode || m->mesh.v.empty()) return false;
    Skin sk; if (!autoWeights(m->mesh, a->arm, meshToArmature(*a, *m), sk)) return false;
    const uint32_t prev = m->armatureId; auto bPrev = prev && prev != armId ? snapGroup(s, prev) : std::vector<RigSnap>{};
    auto before = snapGroup(s, armId); { RigSnap r = rigSnap(*m); bool have = false; for (auto& x : before) if (x.id == r.id) have = true; if (!have) before.push_back(r); }
    m->skin = std::move(sk); m->armatureId = armId; m->skinSrcRev = ~0ull;
    auto c = std::make_unique<RigCmd>(); c->before = std::move(before);
    for (auto& r : bPrev) { bool have = false; for (auto& x : c->before) if (x.id == r.id) have = true; if (!have) c->before.push_back(r); }
    c->after = snapGroup(s, armId); { RigSnap r = rigSnap(*m); bool have = false; for (auto& x : c->after) if (x.id == r.id) have = true; if (!have) c->after.push_back(r); }
    refreshSkinned(s); s.record(std::move(c)); return true;
}
inline bool unbindMesh(Scene& s) {
    Object* m = s.find(s.selected); if (!m || m->isArmature || m->armatureId == 0 || s.editMode) return false;
    auto c = std::make_unique<RigCmd>(); c->before.push_back(rigSnap(*m));
    m->armatureId = 0; m->skin = Skin{}; m->skinSrcRev = ~0ull; c->after.push_back(rigSnap(*m));
    refreshSkinned(s); s.record(std::move(c)); return true;
}
// Edit Mode, selected vertices of the active bound mesh: give `bone` weight w (0..1); the other influences share the rest.
inline bool assignWeightSelected(Scene& s, int bone, float w) {
    Object* m = s.find(s.selected); if (!m || m->isArmature || !s.editMode || m->armatureId == 0) return false;
    const Object* a = s.find(m->armatureId); if (!a || bone < 0 || bone >= (int)a->arm.bones.size() || m->skin.v.size() != m->mesh.v.size()) return false;
    const std::vector<char> mask = selectedVertexMask(s.sel, m->mesh); Skin work = m->skin; bool any = false;
    for (size_t i = 0; i < mask.size(); ++i) if (mask[i]) { if (!setVertexWeight(work, (int)i, bone, w)) return false; any = true; }
    if (!any) return false;
    auto c = std::make_unique<RigCmd>(); c->before.push_back(rigSnap(*m)); m->skin = std::move(work); m->skinSrcRev = ~0ull; c->after.push_back(rigSnap(*m));
    refreshSkinned(s); s.record(std::move(c)); return true;
}
inline int meshInfluenceCount(const Object& m, int bone) {   // vertices that carry weight on `bone` (for the UI)
    int n = 0; for (const auto& in : m.skin.v) for (int k = 0; k < kMaxInfluences; ++k) if (in.bone[k] == bone && in.w[k] > 0) { ++n; break; }
    return n;
}

}  // namespace atlas
