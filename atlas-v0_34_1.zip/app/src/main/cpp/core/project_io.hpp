// Versioned text project format with atomic save. v1 (cubes only, Y-up) is migrated on load; v2 has meshes; v3 adds modifier stacks; v4 adds subsurf/solidify parameters; v5 adds smooth/deform/decimate parameters; v6 adds armatures (bones + pose) and per-vertex skin weights.
#pragma once
#include <cstdio>
#include <fstream>
#include <iomanip>
#include <set>
#include <string>
#include "rig_scene.hpp"

namespace atlas {

constexpr int kProjectVersion = 6;

inline bool saveProject(const Scene& s, const std::string& path) {
    const std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp, std::ios::trunc);
        if (!f) return false;
        f << std::setprecision(9);
        f << "ATLAS " << kProjectVersion << "\nnext " << s.nextId << "\n";
        for (const auto& o : s.objects) {
            std::string nm = o.name.empty() ? "Object" : o.name;
            for (auto& c : nm) if (c == ' ' || c == '\t' || c == '\n') c = '_';
            f << "object " << o.id << " " << nm;
            for (int i = 0; i < 3; ++i) f << " " << o.pos[i];
            for (int i = 0; i < 3; ++i) f << " " << o.rot[i];
            for (int i = 0; i < 3; ++i) f << " " << o.scale[i];
            f << " " << o.mesh.v.size() << " " << o.mesh.f.size() << "\n";
            for (const auto& v : o.mesh.v) f << "v " << v.x << " " << v.y << " " << v.z << "\n";
            for (const auto& fc : o.mesh.f) { f << "f " << fc.size(); for (int i : fc) f << " " << i; f << "\n"; }
            f << "mods " << o.mods.size() << "\n";
            for (const auto& m : o.mods)
                f << "mod " << m.type << " " << (m.enabled ? 1 : 0) << " " << m.axis << " " << m.merge << " " << m.count << " "
                  << m.offset[0] << " " << m.offset[1] << " " << m.offset[2] << " " << m.levels << " " << m.thickness << " " << m.shift << " "
                  << m.factor << " " << m.iterations << " " << m.mode << " " << m.angle << "\n";
            f << "rig " << (o.isArmature ? 1 : 0) << " " << o.armatureId << " " << o.arm.bones.size() << " " << o.skin.v.size() << "\n";
            for (const auto& b : o.arm.bones) {
                std::string bn = b.name.empty() ? "Bone" : b.name; for (auto& c : bn) if (c == ' ' || c == '\t' || c == '\n') c = '_';
                f << "bone " << bn << " " << b.parent << " " << (b.connected ? 1 : 0) << " " << (b.deform ? 1 : 0) << " " << b.head.x << " " << b.head.y << " " << b.head.z << " "
                  << b.tail.x << " " << b.tail.y << " " << b.tail.z << " " << b.roll << " " << b.loc.x << " " << b.loc.y << " " << b.loc.z << " "
                  << b.rot.x << " " << b.rot.y << " " << b.rot.z << " " << b.scl.x << " " << b.scl.y << " " << b.scl.z << "\n";
            }
            for (const auto& in : o.skin.v) {
                f << "sk"; for (int k = 0; k < kMaxInfluences; ++k) f << " " << in.bone[k] << " " << in.w[k]; f << "\n";
            }
        }
        f << "end\n"; f.flush();
        if (!f) { std::remove(tmp.c_str()); return false; }
    }
    return std::rename(tmp.c_str(), path.c_str()) == 0;
}

// Loads into `out` only if the whole file is valid; otherwise `out` is untouched.
inline bool loadProject(Scene& out, const std::string& path, std::string* err = nullptr) {
    auto fail = [&](const char* m) { if (err) *err = m; return false; };
    std::ifstream f(path);
    if (!f) return fail("cannot open file");
    std::string tag; int ver = 0;
    if (!(f >> tag >> ver) || tag != "ATLAS") return fail("not an Atlas project");
    if (ver < 1 || ver > kProjectVersion) return fail("unsupported project version");
    std::vector<Object> objs; uint32_t next = 1; bool ended = false; std::string w;
    std::set<uint32_t> ids;
    while (f >> w) {
        if (w == "next") { if (!(f >> next)) return fail("bad header"); }
        else if (w == "cube" && ver == 1) {  // v1: Y-up unit cube with half-extent 0.5*scale
            Object o; float p[3], sc[3];
            if (!(f >> o.id >> p[0] >> p[1] >> p[2] >> sc[0] >> sc[1] >> sc[2])) return fail("corrupt cube record");
            o.name = "Cube." + std::to_string(o.id); o.mesh = makeCube();
            o.pos[0] = p[0]; o.pos[1] = -p[2]; o.pos[2] = p[1];
            o.scale[0] = sc[0] * 0.5f; o.scale[1] = sc[2] * 0.5f; o.scale[2] = sc[1] * 0.5f;
            if (o.id == 0 || !ids.insert(o.id).second) return fail("bad object id");
            objs.push_back(std::move(o));
        } else if (w == "object" && ver >= 2) {
            Object o; size_t nv = 0, nf = 0;
            if (!(f >> o.id >> o.name)) return fail("corrupt object record");
            for (int i = 0; i < 3; ++i) f >> o.pos[i];
            for (int i = 0; i < 3; ++i) f >> o.rot[i];
            for (int i = 0; i < 3; ++i) f >> o.scale[i];
            if (!(f >> nv >> nf)) return fail("corrupt object record");
            if (o.id == 0 || !ids.insert(o.id).second) return fail("bad object id");
            if (nv > 10000000 || nf > 10000000) return fail("mesh too large");
            for (size_t i = 0; i < nv; ++i) {
                std::string t; Vec3 v;
                if (!(f >> t >> v.x >> v.y >> v.z) || t != "v") return fail("corrupt vertex");
                if (!std::isfinite(v.x) || !std::isfinite(v.y) || !std::isfinite(v.z)) return fail("bad vertex");
                o.mesh.v.push_back(v);
            }
            for (size_t i = 0; i < nf; ++i) {
                std::string t; size_t k = 0;
                if (!(f >> t >> k) || t != "f" || k < 3 || k > 4096) return fail("corrupt face");
                std::vector<int> fc(k);
                for (size_t j = 0; j < k; ++j) if (!(f >> fc[j])) return fail("corrupt face");
                o.mesh.f.push_back(std::move(fc));
            }
            if (!f || !validMesh(o.mesh)) return fail("invalid mesh");
            if (ver >= 3) {
                std::string t; size_t nm = 0;
                if (!(f >> t >> nm) || t != "mods" || nm > 16) return fail("corrupt modifier list");
                for (size_t i = 0; i < nm; ++i) {
                    Modifier m; int en = 1;
                    if (!(f >> t >> m.type >> en >> m.axis >> m.merge >> m.count >> m.offset[0] >> m.offset[1] >> m.offset[2]) || t != "mod")
                        return fail("corrupt modifier");
                    if (ver >= 4 && !(f >> m.levels >> m.thickness >> m.shift)) return fail("corrupt modifier");
                    if (ver >= 5 && !(f >> m.factor >> m.iterations >> m.mode >> m.angle)) return fail("corrupt modifier");
                    m.enabled = en != 0;
                    if (!validModifier(m)) return fail("invalid modifier");
                    o.mods.push_back(m);
                }
                o.modsRev = nextRev();
            }
            if (ver >= 6) {
                std::string t; int isArm = 0; size_t nb = 0, ns = 0;
                if (!(f >> t >> isArm >> o.armatureId >> nb >> ns) || t != "rig" || (isArm != 0 && isArm != 1)) return fail("corrupt rig record");
                if (nb > 4096 || (ns != 0 && ns != nv)) return fail("bad rig sizes");
                o.isArmature = isArm == 1;
                for (size_t i = 0; i < nb; ++i) {
                    Bone b; int cn = 0, df = 0;
                    if (!(f >> t >> b.name >> b.parent >> cn >> df >> b.head.x >> b.head.y >> b.head.z >> b.tail.x >> b.tail.y >> b.tail.z >> b.roll >> b.loc.x >> b.loc.y >> b.loc.z
                            >> b.rot.x >> b.rot.y >> b.rot.z >> b.scl.x >> b.scl.y >> b.scl.z) || t != "bone") return fail("corrupt bone");
                    b.connected = cn != 0; b.deform = df != 0; o.arm.bones.push_back(std::move(b));
                }
                if (!validArmature(o.arm)) return fail("invalid armature");
                for (size_t i = 0; i < ns; ++i) {
                    Influence in; std::string st;
                    if (!(f >> st) || st != "sk") return fail("corrupt skin");
                    for (int k = 0; k < kMaxInfluences; ++k) if (!(f >> in.bone[k] >> in.w[k])) return fail("corrupt skin");
                    o.skin.v.push_back(in);
                }
                if (!validSkin(o.skin, 4096) || (ns != 0 && o.armatureId == 0)) return fail("invalid skin");   // exact bone range is checked against the armature below
                if (o.isArmature && (o.armatureId != 0 || ns != 0)) return fail("invalid armature object");
            }
            objs.push_back(std::move(o));
        } else if (w == "end") { ended = true; break; }
        else return fail("unknown record");
    }
    if (!ended) return fail("truncated file");
    for (const auto& o : objs) if (o.armatureId != 0) {   // a binding must point at an armature object whose bone count fits the weights
        const Object* a = nullptr; for (const auto& c : objs) if (c.id == o.armatureId) a = &c;
        if (!a || !a->isArmature) return fail("bad armature reference");
        if (!validSkin(o.skin, (int)a->arm.bones.size())) return fail("skin does not match armature");
    }
    uint32_t maxId = 0; for (auto& o : objs) { maxId = std::max(maxId, o.id); o.meshRev = nextRev(); }
    out.reset(); out.objects = std::move(objs); out.nextId = std::max(next, maxId + 1); refreshSkinned(out);
    return true;
}

}  // namespace atlas
