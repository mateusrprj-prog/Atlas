// Model import (0.33.0): glTF 2.0 / GLB and binary FBX, own parsers (no third-party code).
// Output is ONE merged Mesh in Atlas conventions (Z-up, right-handed, front = -Y, meters). Node transforms are baked in.
// Supported: GLB, .gltf with embedded base64 buffers, triangle/strip/fan primitives, node hierarchy (matrix or TRS), instancing.
//            FBX binary 7.x (32 and 64-bit offsets, zlib arrays), Geometry/Model hierarchy, n-gons kept, Lcl TRS + PreRotation.
// NOT supported (reported, never silently wrong): sparse accessors, Draco/meshopt, external .bin/.fbm files, ASCII FBX.
// Materials, UVs, normals, skins and animations are ignored for now (geometry only).
#pragma once
#include <algorithm>
#include <array>
#include <cctype>
#include <cstdint>
#include <cstdlib>
#include <cstring>
#include <set>
#include <map>
#include <string>
#include <vector>
#include "mesh.hpp"
#include "modifiers.hpp"
#include "rig.hpp"

namespace atlas {

struct ImportResult {
    bool ok = false; std::string error;
    Mesh mesh; int parts = 0;        // primitives / geometries merged
    int skipped = 0;                 // primitives ignored (points, lines, ...)
    std::string format;              // "glb", "gltf", "fbx"
};

namespace imp {

constexpr size_t kMaxVerts = 3000000;

// ---------------------------------------------------------------- tiny JSON (read-only)
struct J {
    enum T { Null, Bool, Num, Str, Arr, Obj } t = Null;
    double n = 0; bool b = false; std::string s; std::vector<J> a; std::vector<std::pair<std::string, J>> o;
    const J* get(const char* k) const { if (t != Obj) return nullptr; for (auto& p : o) if (p.first == k) return &p.second; return nullptr; }
    const J* at(size_t i) const { return (t == Arr && i < a.size()) ? &a[i] : nullptr; }
    double num(double d) const { return t == Num ? n : d; }
};
struct JParser {
    const char* p; const char* e; bool err = false;
    void ws() { while (p < e && (*p == ' ' || *p == '\n' || *p == '\r' || *p == '\t')) ++p; }
    static void utf8(std::string& s, unsigned c) {
        if (c < 0x80) s += (char)c;
        else if (c < 0x800) { s += (char)(0xC0 | (c >> 6)); s += (char)(0x80 | (c & 63)); }
        else { s += (char)(0xE0 | (c >> 12)); s += (char)(0x80 | ((c >> 6) & 63)); s += (char)(0x80 | (c & 63)); }
    }
    bool str(std::string& out) {
        if (p >= e || *p != '"') return false; ++p;
        while (p < e && *p != '"') {
            if (*p == '\\') {
                if (++p >= e) return false;
                switch (*p) {
                    case 'n': out += '\n'; break; case 't': out += '\t'; break; case 'r': out += '\r'; break;
                    case 'b': out += '\b'; break; case 'f': out += '\f'; break;
                    case 'u': { if (e - p < 5) return false; unsigned c = 0; for (int i = 1; i <= 4; ++i) { char h = p[i]; c <<= 4;
                                if (h >= '0' && h <= '9') c |= h - '0'; else if (h >= 'a' && h <= 'f') c |= h - 'a' + 10; else if (h >= 'A' && h <= 'F') c |= h - 'A' + 10; else return false; }
                                utf8(out, c); p += 4; break; }
                    default: out += *p;
                }
                ++p;
            } else out += *p++;
        }
        if (p >= e) return false; ++p; return true;
    }
    bool val(J& j, int depth) {
        if (depth > 64) return false; ws(); if (p >= e) return false;
        if (*p == '{') {
            j.t = J::Obj; ++p; ws(); if (p < e && *p == '}') { ++p; return true; }
            for (;;) {
                ws(); std::string k; if (!str(k)) return false; ws(); if (p >= e || *p != ':') return false; ++p;
                J v; if (!val(v, depth + 1)) return false; j.o.emplace_back(std::move(k), std::move(v)); ws();
                if (p < e && *p == ',') { ++p; continue; } if (p < e && *p == '}') { ++p; return true; } return false;
            }
        }
        if (*p == '[') {
            j.t = J::Arr; ++p; ws(); if (p < e && *p == ']') { ++p; return true; }
            for (;;) {
                J v; if (!val(v, depth + 1)) return false; j.a.push_back(std::move(v)); ws();
                if (p < e && *p == ',') { ++p; continue; } if (p < e && *p == ']') { ++p; return true; } return false;
            }
        }
        if (*p == '"') { j.t = J::Str; return str(j.s); }
        if (e - p >= 4 && !strncmp(p, "true", 4)) { j.t = J::Bool; j.b = true; p += 4; return true; }
        if (e - p >= 5 && !strncmp(p, "false", 5)) { j.t = J::Bool; p += 5; return true; }
        if (e - p >= 4 && !strncmp(p, "null", 4)) { p += 4; return true; }
        char* end = nullptr; std::string tmp(p, std::min<size_t>(64, (size_t)(e - p)));
        double d = strtod(tmp.c_str(), &end); if (end == tmp.c_str()) return false;
        j.t = J::Num; j.n = d; p += (end - tmp.c_str()); return true;
    }
};

inline bool base64(const std::string& in, std::vector<uint8_t>& out) {
    uint32_t val = 0; int bits = -8;
    for (char c : in) {
        int d;
        if (c >= 'A' && c <= 'Z') d = c - 'A'; else if (c >= 'a' && c <= 'z') d = c - 'a' + 26; else if (c >= '0' && c <= '9') d = c - '0' + 52;
        else if (c == '+') d = 62; else if (c == '/') d = 63; else if (c == '=' || c == '\n' || c == '\r' || c == ' ') continue; else return false;
        val = ((val << 6) | (uint32_t)d) & 0xFFFFFF; bits += 6; if (bits >= 0) { out.push_back((uint8_t)((val >> bits) & 0xFF)); bits -= 8; }
    }
    return true;
}

// ---------------------------------------------------------------- zlib inflate (RFC 1950/1951)
struct Huff { uint16_t count[16]; uint16_t symbol[288]; };
struct Bits {
    const uint8_t* p; size_t n; size_t pos = 0; uint32_t buf = 0; int cnt = 0; bool err = false;
    int get(int need) {
        long val = buf;
        while (cnt < need) { if (pos >= n) { err = true; return 0; } val |= (long)p[pos++] << cnt; cnt += 8; }
        buf = (uint32_t)(val >> need); cnt -= need; return (int)(val & ((1L << need) - 1));
    }
};
inline int hconstruct(Huff& h, const uint16_t* len, int n) {
    for (int i = 0; i < 16; ++i) h.count[i] = 0;
    for (int i = 0; i < n; ++i) ++h.count[len[i]];
    if (h.count[0] == n) return 0;
    int left = 1; for (int l = 1; l < 16; ++l) { left <<= 1; left -= h.count[l]; if (left < 0) return left; }
    uint16_t offs[16]; offs[1] = 0; for (int l = 1; l < 15; ++l) offs[l + 1] = offs[l] + h.count[l];
    for (int s = 0; s < n; ++s) if (len[s]) h.symbol[offs[len[s]]++] = (uint16_t)s;
    return left;
}
inline int hdecode(Bits& b, const Huff& h) {
    int code = 0, first = 0, index = 0;
    for (int l = 1; l < 16; ++l) {
        code |= b.get(1); if (b.err) return -1;
        int count = h.count[l];
        if (code - count < first) return h.symbol[index + (code - first)];
        index += count; first += count; first <<= 1; code <<= 1;
    }
    return -1;
}
inline bool inflateBlockCodes(Bits& b, std::vector<uint8_t>& out, const Huff& lc, const Huff& dc, size_t cap) {
    static const uint16_t lbase[29] = {3,4,5,6,7,8,9,10,11,13,15,17,19,23,27,31,35,43,51,59,67,83,99,115,131,163,195,227,258};
    static const uint16_t lext[29] = {0,0,0,0,0,0,0,0,1,1,1,1,2,2,2,2,3,3,3,3,4,4,4,4,5,5,5,5,0};
    static const uint16_t dbase[30] = {1,2,3,4,5,7,9,13,17,25,33,49,65,97,129,193,257,385,513,769,1025,1537,2049,3073,4097,6145,8193,12289,16385,24577};
    static const uint16_t dext[30] = {0,0,0,0,1,1,2,2,3,3,4,4,5,5,6,6,7,7,8,8,9,9,10,10,11,11,12,12,13,13};
    for (;;) {
        int sym = hdecode(b, lc); if (sym < 0) return false;
        if (sym < 256) { if (out.size() >= cap) return false; out.push_back((uint8_t)sym); }
        else if (sym == 256) return true;
        else {
            sym -= 257; if (sym >= 29) return false;
            int len = lbase[sym] + b.get(lext[sym]); int ds = hdecode(b, dc); if (ds < 0 || ds >= 30) return false;
            size_t dist = dbase[ds] + b.get(dext[ds]); if (b.err || dist > out.size() || out.size() + len > cap) return false;
            for (int i = 0; i < len; ++i) out.push_back(out[out.size() - dist]);
        }
    }
}
inline bool inflateZlib(const uint8_t* src, size_t n, std::vector<uint8_t>& out, size_t cap) {
    if (n < 6 || (src[0] & 0x0F) != 8 || ((src[0] << 8) | src[1]) % 31 != 0 || (src[1] & 0x20)) return false;
    Bits b{src + 2, n - 2};
    int last;
    do {
        last = b.get(1); int type = b.get(2); if (b.err) return false;
        if (type == 0) {
            b.buf = 0; b.cnt = 0; if (b.pos + 4 > b.n) return false;
            unsigned len = b.p[b.pos] | (b.p[b.pos + 1] << 8), nlen = b.p[b.pos + 2] | (b.p[b.pos + 3] << 8); b.pos += 4;
            if (len != (~nlen & 0xFFFF) || b.pos + len > b.n || out.size() + len > cap) return false;
            out.insert(out.end(), b.p + b.pos, b.p + b.pos + len); b.pos += len;
        } else if (type == 1) {
            static Huff lc, dc; static bool init = false;
            if (!init) { uint16_t l[288]; int i = 0; for (; i < 144; ++i) l[i] = 8; for (; i < 256; ++i) l[i] = 9; for (; i < 280; ++i) l[i] = 7; for (; i < 288; ++i) l[i] = 8;
                         hconstruct(lc, l, 288); for (i = 0; i < 30; ++i) l[i] = 5; hconstruct(dc, l, 30); init = true; }
            if (!inflateBlockCodes(b, out, lc, dc, cap)) return false;
        } else if (type == 2) {
            static const uint8_t order[19] = {16,17,18,0,8,7,9,6,10,5,11,4,12,3,13,2,14,1,15};
            int nlen = b.get(5) + 257, ndist = b.get(5) + 1, ncode = b.get(4) + 4; if (b.err || nlen > 286 || ndist > 30) return false;
            uint16_t lens[320]; int i = 0; for (; i < ncode; ++i) lens[order[i]] = (uint16_t)b.get(3); for (; i < 19; ++i) lens[order[i]] = 0;
            Huff ch; if (hconstruct(ch, lens, 19) != 0) return false;
            i = 0;
            while (i < nlen + ndist) {
                int sym = hdecode(b, ch); if (sym < 0) return false;
                if (sym < 16) lens[i++] = (uint16_t)sym;
                else {
                    int rep, v = 0;
                    if (sym == 16) { if (i == 0) return false; v = lens[i - 1]; rep = 3 + b.get(2); }
                    else if (sym == 17) rep = 3 + b.get(3); else rep = 11 + b.get(7);
                    if (b.err || i + rep > nlen + ndist) return false; while (rep--) lens[i++] = (uint16_t)v;
                }
            }
            if (lens[256] == 0) return false;
            Huff lc, dc; int e1 = hconstruct(lc, lens, nlen); if (e1 < 0 || (e1 > 0 && nlen - lc.count[0] != 1)) return false;
            int e2 = hconstruct(dc, lens + nlen, ndist); if (e2 < 0 || (e2 > 0 && ndist - dc.count[0] != 1)) return false;
            if (!inflateBlockCodes(b, out, lc, dc, cap)) return false;
        } else return false;
    } while (!last);
    return true;
}

// ---------------------------------------------------------------- shared helpers
inline Mat4 yUpToZUp() { Mat4 r; r.m[0] = 1; r.m[5] = 0; r.m[6] = -1; r.m[9] = 1; r.m[10] = 0; return r; }   // (x, y, z) -> (x, -z, y)
inline float det3(const Mat4& a) {
    const float* m = a.m;
    return m[0] * (m[5] * m[10] - m[6] * m[9]) - m[1] * (m[4] * m[10] - m[6] * m[8]) + m[2] * (m[4] * m[9] - m[5] * m[8]);
}
// Appends `src` transformed by `w`; flips winding when `w` mirrors.
inline void appendMesh(Mesh& dst, const Mesh& src, const Mat4& w) {
    const int base = (int)dst.v.size(); const bool flip = det3(w) < 0;
    for (const Vec3& p : src.v) dst.v.push_back(xfPoint(w, p));
    for (auto f : src.f) { for (int& i : f) i += base; if (flip) std::reverse(f.begin(), f.end()); dst.f.push_back(std::move(f)); }
}
// Merges coincident vertices (importers emit one vertex per normal/UV split) so the mesh is usable for editing.
inline void finishMesh(Mesh& m) {
    if (m.v.empty()) return;
    Vec3 lo = m.v[0], hi = m.v[0];
    for (const Vec3& p : m.v) { lo.x = std::min(lo.x, p.x); lo.y = std::min(lo.y, p.y); lo.z = std::min(lo.z, p.z); hi.x = std::max(hi.x, p.x); hi.y = std::max(hi.y, p.y); hi.z = std::max(hi.z, p.z); }
    const float diag = length(hi - lo); weldVertices(m, std::max(diag * 1e-6f, 1e-7f));
}
inline bool finiteMesh(const Mesh& m) { for (const Vec3& p : m.v) if (!finite3(p)) return false; return true; }

// ---------------------------------------------------------------- glTF / GLB
struct Gltf {
    J doc; std::vector<std::vector<uint8_t>> buffers; std::string err; Mesh out; int parts = 0, skipped = 0; int visits = 0;

    bool readAccessor(int ai, int wantComp, std::vector<double>& v, int& comps) {
        const J* acc = doc.get("accessors") ? doc.get("accessors")->at((size_t)ai) : nullptr; if (!acc) { err = "accessor inválido"; return false; }
        if (acc->get("sparse")) { err = "accessor esparso (sparse) não suportado"; return false; }
        const J* bvI = acc->get("bufferView"); if (!bvI) { err = "accessor sem bufferView"; return false; }
        const J* bv = doc.get("bufferViews") ? doc.get("bufferViews")->at((size_t)bvI->num(-1)) : nullptr; if (!bv) { err = "bufferView inválido"; return false; }
        const int bi = bv->get("buffer") ? (int)bv->get("buffer")->num(-1) : -1; if (bi < 0 || bi >= (int)buffers.size()) { err = "buffer inválido"; return false; }
        const std::vector<uint8_t>& buf = buffers[bi];
        const std::string type = acc->get("type") ? acc->get("type")->s : "";
        comps = type == "SCALAR" ? 1 : type == "VEC2" ? 2 : type == "VEC3" ? 3 : type == "VEC4" ? 4 : 0;
        if (!comps || (wantComp && comps != wantComp)) { err = "tipo de accessor inesperado: " + type; return false; }
        const int ct = (int)(acc->get("componentType") ? acc->get("componentType")->num(0) : 0);
        const int csz = (ct == 5120 || ct == 5121) ? 1 : (ct == 5122 || ct == 5123) ? 2 : (ct == 5125 || ct == 5126) ? 4 : 0; if (!csz) { err = "componentType inválido"; return false; }
        const double cntD = acc->get("count") ? acc->get("count")->num(-1) : -1; if (cntD < 0 || cntD > (double)kMaxVerts * 4) { err = "accessor count inválido"; return false; }
        const size_t count = (size_t)cntD;
        const size_t off = (size_t)(bv->get("byteOffset") ? bv->get("byteOffset")->num(0) : 0) + (size_t)(acc->get("byteOffset") ? acc->get("byteOffset")->num(0) : 0);
        size_t stride = (size_t)(bv->get("byteStride") ? bv->get("byteStride")->num(0) : 0); const size_t esz = (size_t)csz * comps; if (stride == 0) stride = esz;
        if (count && (off + (count - 1) * stride + esz > buf.size())) { err = "accessor fora do buffer (arquivo truncado?)"; return false; }
        const bool norm = acc->get("normalized") && acc->get("normalized")->b;
        v.resize(count * comps);
        for (size_t i = 0; i < count; ++i) for (int c = 0; c < comps; ++c) {
            const uint8_t* q = buf.data() + off + i * stride + (size_t)c * csz; double x = 0;
            switch (ct) {
                case 5120: x = (int8_t)q[0]; if (norm) x = std::max(x / 127.0, -1.0); break;
                case 5121: x = q[0]; if (norm) x /= 255.0; break;
                case 5122: { int16_t s; memcpy(&s, q, 2); x = s; if (norm) x = std::max(x / 32767.0, -1.0); break; }
                case 5123: { uint16_t s; memcpy(&s, q, 2); x = s; if (norm) x /= 65535.0; break; }
                case 5125: { uint32_t s; memcpy(&s, q, 4); x = s; break; }
                default: { float s; memcpy(&s, q, 4); x = s; }
            }
            v[i * comps + c] = x;
        }
        return true;
    }
    static Mat4 nodeMatrix(const J& n) {
        if (const J* m = n.get("matrix")) {
            Mat4 r; if (m->a.size() == 16) for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) r.m[i * 4 + j] = (float)m->a[j * 4 + i].num(i == j);
            return r;
        }
        Vec3 t, s{1, 1, 1}; float q[4] = {0, 0, 0, 1};
        if (const J* a = n.get("translation")) if (a->a.size() == 3) t = {(float)a->a[0].num(0), (float)a->a[1].num(0), (float)a->a[2].num(0)};
        if (const J* a = n.get("scale")) if (a->a.size() == 3) s = {(float)a->a[0].num(1), (float)a->a[1].num(1), (float)a->a[2].num(1)};
        if (const J* a = n.get("rotation")) if (a->a.size() == 4) for (int i = 0; i < 4; ++i) q[i] = (float)a->a[i].num(i == 3);
        float l = std::sqrt(q[0] * q[0] + q[1] * q[1] + q[2] * q[2] + q[3] * q[3]); if (l < 1e-8f) { q[0] = q[1] = q[2] = 0; q[3] = 1; l = 1; }
        const float x = q[0] / l, y = q[1] / l, z = q[2] / l, w = q[3] / l; Mat4 r;
        r.m[0] = (1 - 2 * (y * y + z * z)) * s.x; r.m[1] = (2 * (x * y - z * w)) * s.y;     r.m[2] = (2 * (x * z + y * w)) * s.z;     r.m[3] = t.x;
        r.m[4] = (2 * (x * y + z * w)) * s.x;     r.m[5] = (1 - 2 * (x * x + z * z)) * s.y; r.m[6] = (2 * (y * z - x * w)) * s.z;     r.m[7] = t.y;
        r.m[8] = (2 * (x * z - y * w)) * s.x;     r.m[9] = (2 * (y * z + x * w)) * s.y;     r.m[10] = (1 - 2 * (x * x + y * y)) * s.z; r.m[11] = t.z;
        return r;
    }
    bool addPrimitive(const J& prim, const Mat4& w) {
        const int mode = (int)(prim.get("mode") ? prim.get("mode")->num(4) : 4);
        if (mode < 4 || mode > 6) { ++skipped; return true; }
        const J* at = prim.get("attributes"); const J* pos = at ? at->get("POSITION") : nullptr; if (!pos) { ++skipped; return true; }
        if (prim.get("extensions") && prim.get("extensions")->get("KHR_draco_mesh_compression")) { err = "malha comprimida com Draco não é suportada (reexporte sem compressão)"; return false; }
        std::vector<double> P, I; int pc = 0, ic = 0;
        if (!readAccessor((int)pos->num(-1), 3, P, pc)) return false;
        const size_t nv = P.size() / 3; if (out.v.size() + nv > kMaxVerts) { err = "malha grande demais (limite 3 milhões de vértices)"; return false; }
        std::vector<uint32_t> idx;
        if (const J* ii = prim.get("indices")) { if (!readAccessor((int)ii->num(-1), 1, I, ic)) return false; idx.reserve(I.size()); for (double d : I) idx.push_back((uint32_t)d); }
        else { idx.resize(nv); for (size_t i = 0; i < nv; ++i) idx[i] = (uint32_t)i; }
        for (uint32_t i : idx) if (i >= nv) { err = "índice fora do range"; return false; }
        Mesh m; m.v.reserve(nv); for (size_t i = 0; i < nv; ++i) m.v.push_back({(float)P[i * 3], (float)P[i * 3 + 1], (float)P[i * 3 + 2]});
        if (mode == 4) for (size_t i = 0; i + 2 < idx.size(); i += 3) m.f.push_back({(int)idx[i], (int)idx[i + 1], (int)idx[i + 2]});
        else if (mode == 5) for (size_t i = 0; i + 2 < idx.size(); ++i) { if (i & 1) m.f.push_back({(int)idx[i + 1], (int)idx[i], (int)idx[i + 2]}); else m.f.push_back({(int)idx[i], (int)idx[i + 1], (int)idx[i + 2]}); }
        else for (size_t i = 1; i + 1 < idx.size(); ++i) m.f.push_back({(int)idx[0], (int)idx[i], (int)idx[i + 1]});
        std::vector<std::vector<int>> keep; for (auto& f : m.f) if (f[0] != f[1] && f[1] != f[2] && f[0] != f[2]) keep.push_back(f); m.f = std::move(keep);
        appendMesh(out, m, w); ++parts; return true;
    }
    bool walk(int ni, const Mat4& parent, int depth) {
        if (depth > 64 || ++visits > 200000) { err = "hierarquia de nós inválida (ciclo?)"; return false; }
        const J* nodes = doc.get("nodes"); const J* n = nodes ? nodes->at((size_t)ni) : nullptr; if (!n) { err = "nó inválido"; return false; }
        const Mat4 w = mmul(parent, nodeMatrix(*n));
        if (const J* mi = n->get("mesh")) {
            const J* meshes = doc.get("meshes"); const J* me = meshes ? meshes->at((size_t)mi->num(-1)) : nullptr; if (!me) { err = "mesh inválida"; return false; }
            if (const J* prims = me->get("primitives")) for (const J& p : prims->a) if (!addPrimitive(p, w)) return false;
        }
        if (const J* ch = n->get("children")) for (const J& c : ch->a) if (!walk((int)c.num(-1), w, depth + 1)) return false;
        return true;
    }
    bool run(const uint8_t* d, size_t n) {
        const uint8_t* bin = nullptr; size_t binLen = 0; const char* js = nullptr; size_t jsLen = 0;
        if (n >= 12 && !memcmp(d, "glTF", 4)) {
            uint32_t ver, total; memcpy(&ver, d + 4, 4); memcpy(&total, d + 8, 4);
            if (ver != 2) { err = "GLB versão " + std::to_string(ver) + " não suportada (só 2)"; return false; }
            size_t pos = 12; const size_t end = std::min<size_t>(total, n);
            while (pos + 8 <= end) {
                uint32_t cl, ct; memcpy(&cl, d + pos, 4); memcpy(&ct, d + pos + 4, 4); pos += 8;
                if (cl > end - pos) { err = "GLB truncado"; return false; }
                if (ct == 0x4E4F534A && !js) { js = (const char*)d + pos; jsLen = cl; } else if (ct == 0x004E4942 && !bin) { bin = d + pos; binLen = cl; }
                pos += (cl + 3) & ~3u;
            }
            if (!js) { err = "GLB sem chunk JSON"; return false; }
        } else { js = (const char*)d; jsLen = n; }
        JParser jp{js, js + jsLen}; if (!jp.val(doc, 0) || doc.t != J::Obj) { err = "JSON do glTF inválido"; return false; }
        if (const J* req = doc.get("extensionsRequired")) for (const J& e : req->a) if (e.s == "KHR_draco_mesh_compression" || e.s == "EXT_meshopt_compression" || e.s == "KHR_mesh_quantization_unsupported")
            { err = "extensão obrigatória não suportada: " + e.s; return false; }
        if (const J* bs = doc.get("buffers")) for (size_t i = 0; i < bs->a.size(); ++i) {
            const J& b = bs->a[i]; std::vector<uint8_t> data; const J* uri = b.get("uri");
            if (!uri) { if (i == 0 && bin) data.assign(bin, bin + binLen); else { err = "buffer sem dados"; return false; } }
            else if (!uri->s.compare(0, 5, "data:")) { size_t c = uri->s.find("base64,"); if (c == std::string::npos || !base64(uri->s.substr(c + 7), data)) { err = "data URI inválida"; return false; } }
            else { err = "buffer externo (" + uri->s + ") não dá para ler pelo seletor de arquivos; exporte como .glb"; return false; }
            buffers.push_back(std::move(data));
        }
        const Mat4 root = yUpToZUp(); const J* nodes = doc.get("nodes");
        if (!nodes || nodes->a.empty()) { err = "glTF sem nós"; return false; }
        std::vector<int> roots;
        const J* scenes = doc.get("scenes");
        if (scenes && !scenes->a.empty()) {
            const J* sc = scenes->at((size_t)(doc.get("scene") ? doc.get("scene")->num(0) : 0)); if (!sc) sc = scenes->at(0);
            if (const J* ns = sc->get("nodes")) for (const J& x : ns->a) roots.push_back((int)x.num(-1));
        }
        if (roots.empty()) {   // no scene: every node that is nobody's child
            std::vector<char> child(nodes->a.size(), 0);
            for (const J& nd : nodes->a) if (const J* c = nd.get("children")) for (const J& x : c->a) { int k = (int)x.num(-1); if (k >= 0 && k < (int)child.size()) child[k] = 1; }
            for (size_t i = 0; i < child.size(); ++i) if (!child[i]) roots.push_back((int)i);
        }
        for (int r : roots) if (!walk(r, root, 0)) return false;
        return true;
    }
};

// ---------------------------------------------------------------- FBX (binary)
struct FProp { char t = 0; double d = 0; int64_t i = 0; std::string s; std::vector<double> ad; std::vector<int64_t> ai; };
struct FNode { std::string name; std::vector<FProp> props; std::vector<FNode> kids;
    const FNode* kid(const char* n) const { for (auto& k : kids) if (k.name == n) return &k; return nullptr; } };

struct FbxReader {
    const uint8_t* d = nullptr; size_t n = 0; bool wide = false; std::string err;
    template <class T> bool rd(size_t& pos, T& v) { if (pos + sizeof(T) > n) return false; memcpy(&v, d + pos, sizeof(T)); pos += sizeof(T); return true; }
    bool rdOff(size_t& pos, uint64_t& v) { if (wide) return rd(pos, v); uint32_t x; if (!rd(pos, x)) return false; v = x; return true; }
    bool readProp(size_t& pos, FProp& p, bool keepArrays) {
        uint8_t t; if (!rd(pos, t)) return false; p.t = (char)t;
        switch (t) {
            case 'Y': { int16_t v; if (!rd(pos, v)) return false; p.i = v; p.d = v; return true; }
            case 'C': { uint8_t v; if (!rd(pos, v)) return false; p.i = v; p.d = v; return true; }
            case 'I': { int32_t v; if (!rd(pos, v)) return false; p.i = v; p.d = v; return true; }
            case 'F': { float v; if (!rd(pos, v)) return false; p.d = v; p.i = (int64_t)v; return true; }
            case 'D': { double v; if (!rd(pos, v)) return false; p.d = v; p.i = (int64_t)v; return true; }
            case 'L': { int64_t v; if (!rd(pos, v)) return false; p.i = v; p.d = (double)v; return true; }
            case 'S': case 'R': { uint32_t l; if (!rd(pos, l) || l > n - pos) return false; if (t == 'S') p.s.assign((const char*)d + pos, l); pos += l; return true; }
            case 'f': case 'd': case 'l': case 'i': case 'b': {
                uint32_t len, enc, clen; if (!rd(pos, len) || !rd(pos, enc) || !rd(pos, clen) || clen > n - pos) return false;
                const size_t es = (t == 'd' || t == 'l') ? 8 : (t == 'b' ? 1 : 4);
                if ((uint64_t)len * es > (1ull << 29)) { err = "array FBX grande demais"; return false; }
                if (keepArrays) {
                    std::vector<uint8_t> tmp; const uint8_t* src = d + pos;
                    if (enc == 1) { if (!inflateZlib(d + pos, clen, tmp, (size_t)len * es) || tmp.size() != (size_t)len * es) { err = "array FBX corrompido (zlib)"; return false; } src = tmp.data(); }
                    else if (enc == 0) { if ((uint64_t)len * es != clen) return false; } else return false;
                    for (uint32_t k = 0; k < len; ++k) {
                        if (t == 'd') { double v; memcpy(&v, src + k * 8, 8); p.ad.push_back(v); }
                        else if (t == 'f') { float v; memcpy(&v, src + k * 4, 4); p.ad.push_back(v); }
                        else if (t == 'i') { int32_t v; memcpy(&v, src + k * 4, 4); p.ai.push_back(v); }
                        else if (t == 'l') { int64_t v; memcpy(&v, src + k * 8, 8); p.ai.push_back(v); }
                    }
                }
                pos += clen; return true;
            }
        }
        err = "tipo de propriedade FBX desconhecido"; return false;
    }
    bool readNode(size_t& pos, FNode& out, bool& isNull, int depth) {
        if (depth > 40) { err = "FBX aninhado demais"; return false; }
        uint64_t end, np, pl; uint8_t nl;
        if (!rdOff(pos, end) || !rdOff(pos, np) || !rdOff(pos, pl) || !rd(pos, nl)) return false;
        if (end == 0 && np == 0 && pl == 0 && nl == 0) { isNull = true; return true; }
        isNull = false; if (end > n || pos + nl > n) return false;
        out.name.assign((const char*)d + pos, nl); pos += nl;
        const size_t propEnd = pos + pl; if (propEnd > end || propEnd > n) return false;
        const bool keep = out.name == "Vertices" || out.name == "PolygonVertexIndex";
        if (np > 100000) return false;
        for (uint64_t i = 0; i < np; ++i) { FProp p; if (!readProp(pos, p, keep)) { if (err.empty()) err = "propriedade FBX inválida"; return false; } out.props.push_back(std::move(p)); }
        pos = propEnd;
        while (pos < end) {
            FNode k; bool nul; if (!readNode(pos, k, nul, depth + 1)) { if (err.empty()) err = "nó FBX inválido"; return false; }
            if (nul) break; out.kids.push_back(std::move(k));
        }
        pos = (size_t)end; return true;
    }
};

inline std::string fbxName(const std::string& s) { size_t z = s.find('\0'); return z == std::string::npos ? s : s.substr(0, z); }
inline double fbxProp(const FNode* props70, const char* name, int idx, double def) {
    if (!props70) return def;
    for (auto& p : props70->kids) if (p.name == "P" && p.props.size() >= 5 + (size_t)idx && p.props[0].s == name) return p.props[4 + idx].d;
    return def;
}
inline bool loadFbx(const uint8_t* d, size_t n, ImportResult& r) {
    if (n >= 5 && !memcmp(d, "; FBX", 5)) { r.error = "FBX em texto (ASCII) não é suportado; exporte como FBX binário"; return false; }
    if (n < 27 || memcmp(d, "Kaydara FBX Binary", 18)) { r.error = "não parece um arquivo FBX binário"; return false; }
    uint32_t ver; memcpy(&ver, d + 23, 4);
    FbxReader rd; rd.d = d; rd.n = n; rd.wide = ver >= 7500;
    FNode top; size_t pos = 27;
    while (pos + (rd.wide ? 25 : 13) <= n) {
        FNode nd; bool nul; if (!rd.readNode(pos, nd, nul, 0)) { r.error = rd.err.empty() ? "FBX corrompido" : rd.err; return false; }
        if (nul) break; top.kids.push_back(std::move(nd));
    }
    const FNode* objs = top.kid("Objects"); if (!objs) { r.error = "FBX sem nó Objects"; return false; }
    // global settings: up axis and unit scale
    int up = 1; double unit = 1.0;
    if (const FNode* gs = top.kid("GlobalSettings")) if (const FNode* p70 = gs->kid("Properties70")) { up = (int)fbxProp(p70, "UpAxis", 0, 1); unit = fbxProp(p70, "UnitScaleFactor", 0, 1.0); }
    if (!(unit > 0) || !std::isfinite(unit)) unit = 1.0;
    struct Model { int64_t id; int64_t parent = 0; Mat4 local; };
    std::map<int64_t, size_t> modelIdx; std::vector<Model> models; std::map<int64_t, const FNode*> geoms;
    for (auto& o : objs->kids) {
        if (o.props.empty()) continue;
        if (o.name == "Geometry" && o.props.size() >= 3 && o.props[2].s == "Mesh") geoms[o.props[0].i] = &o;
        else if (o.name == "Model") {
            Model m; m.id = o.props[0].i; const FNode* p70 = o.kid("Properties70");
            const Vec3 T{(float)fbxProp(p70, "Lcl Translation", 0, 0), (float)fbxProp(p70, "Lcl Translation", 1, 0), (float)fbxProp(p70, "Lcl Translation", 2, 0)};
            const Vec3 R{(float)fbxProp(p70, "Lcl Rotation", 0, 0), (float)fbxProp(p70, "Lcl Rotation", 1, 0), (float)fbxProp(p70, "Lcl Rotation", 2, 0)};
            const Vec3 S{(float)fbxProp(p70, "Lcl Scaling", 0, 1), (float)fbxProp(p70, "Lcl Scaling", 1, 1), (float)fbxProp(p70, "Lcl Scaling", 2, 1)};
            const Vec3 Pre{(float)fbxProp(p70, "PreRotation", 0, 0), (float)fbxProp(p70, "PreRotation", 1, 0), (float)fbxProp(p70, "PreRotation", 2, 0)};
            m.local = mmul(trsMatrix(T, {0, 0, 0}, {1, 1, 1}), mmul(rotFromEuler(Pre), trsMatrix({0, 0, 0}, R, S)));
            modelIdx[m.id] = models.size(); models.push_back(m);
        }
    }
    std::vector<std::pair<int64_t, int64_t>> geomOf;   // (geometry id, model id)
    if (const FNode* cs = top.kid("Connections")) for (auto& c : cs->kids)
        if (c.name == "C" && c.props.size() >= 3 && c.props[0].s == "OO") {
            const int64_t ch = c.props[1].i, pa = c.props[2].i;
            if (geoms.count(ch) && modelIdx.count(pa)) geomOf.push_back({ch, pa});
            else if (modelIdx.count(ch) && (pa == 0 || modelIdx.count(pa))) models[modelIdx[ch]].parent = pa;
        }
    const double sc = unit / 100.0;                       // FBX stores centimetres by default -> metres
    Mat4 root = up == 2 ? Mat4{} : yUpToZUp(); for (int i : {0, 1, 2}) for (int j : {0, 1, 2}) root.m[i * 4 + j] *= (float)sc;
    auto world = [&](int64_t mid) {
        Mat4 w; int guard = 0; int64_t cur = mid; std::vector<const Model*> chain;
        while (cur != 0 && modelIdx.count(cur) && guard++ < 64) { const Model& m = models[modelIdx[cur]]; chain.push_back(&m); cur = m.parent; }
        for (int i = (int)chain.size() - 1; i >= 0; --i) w = mmul(w, chain[i]->local);
        return mmul(root, w);
    };
    auto addGeom = [&](const FNode& g, const Mat4& w) -> bool {
        const FNode* vn = g.kid("Vertices"); const FNode* in = g.kid("PolygonVertexIndex");
        if (!vn || !in || vn->props.empty() || in->props.empty()) return true;
        const auto& V = vn->props[0].ad; const auto& I = in->props[0].ai; const size_t nv = V.size() / 3;
        if (r.mesh.v.size() + nv > kMaxVerts) { r.error = "malha grande demais (limite 3 milhões de vértices)"; return false; }
        Mesh m; m.v.reserve(nv); for (size_t i = 0; i < nv; ++i) m.v.push_back({(float)V[i * 3], (float)V[i * 3 + 1], (float)V[i * 3 + 2]});
        std::vector<int> poly;
        for (int64_t raw : I) {
            const bool endp = raw < 0; const int64_t idx = endp ? ~raw : raw;
            if (idx < 0 || idx >= (int64_t)nv) { r.error = "índice FBX fora do range"; return false; }
            poly.push_back((int)idx);
            if (endp) { if (poly.size() >= 3) m.f.push_back(poly); poly.clear(); }
        }
        appendMesh(r.mesh, m, w); ++r.parts; return true;
    };
    std::set<int64_t> used;
    for (auto& go : geomOf) { used.insert(go.first); if (!addGeom(*geoms[go.first], world(go.second))) return false; }
    for (auto& g : geoms) if (!used.count(g.first)) if (!addGeom(*g.second, root)) return false;
    return true;
}

}  // namespace imp

// Optional stage logger (the Android bridge points it at a file so a native crash leaves a trail). Never required.
inline void (*gImportLog)(const std::string&) = nullptr;
inline void importLog(const std::string& m) { if (gImportLog) gImportLog(m); }
constexpr size_t kMaxFacesImport = 1200000;   // beyond this a phone runs out of memory (faces are heap vectors)

// Entry point. `ext` = lower-case extension without dot ("glb", "gltf", "fbx"); content is sniffed when the extension is unknown.
inline ImportResult importModel(const uint8_t* d, size_t n, std::string ext) {
    ImportResult r;
    if (!d || n < 8) { r.error = "arquivo vazio ou pequeno demais"; return r; }
    for (auto& c : ext) c = (char)std::tolower((unsigned char)c);
    if (ext != "glb" && ext != "gltf" && ext != "fbx") ext = !memcmp(d, "glTF", 4) ? "glb" : (!memcmp(d, "Kaydara", 7) || !memcmp(d, "; FBX", 5)) ? "fbx" : "gltf";
    r.format = ext;
    if (ext == "fbx") { if (!imp::loadFbx(d, n, r)) { if (r.error.empty()) r.error = "falha ao ler o FBX"; return r; } }
    else {
        imp::Gltf g; if (!g.run(d, n)) { r.error = g.err.empty() ? "falha ao ler o glTF" : g.err; return r; }
        r.mesh = std::move(g.out); r.parts = g.parts; r.skipped = g.skipped;
    }
    importLog("parsed: " + std::to_string(r.mesh.v.size()) + " vertices, " + std::to_string(r.mesh.f.size()) + " faces");
    if (r.mesh.v.empty() || r.mesh.f.empty()) { r.error = "o arquivo não contém malhas de triângulos"; return r; }
    if (r.mesh.f.size() > kMaxFacesImport) { r.error = "modelo pesado demais: " + std::to_string(r.mesh.f.size()) + " faces (limite " + std::to_string(kMaxFacesImport) + "). Reduza o modelo (decimate) e tente de novo"; return r; }
    if (!imp::finiteMesh(r.mesh)) { r.error = "o arquivo tem vértices inválidos (NaN/infinito)"; return r; }
    importLog("weld start");
    imp::finishMesh(r.mesh);
    importLog("weld done: " + std::to_string(r.mesh.v.size()) + " vertices, " + std::to_string(r.mesh.f.size()) + " faces");
    if (r.mesh.f.empty() || !validMesh(r.mesh)) { r.error = "malha vazia depois da limpeza"; return r; }
    r.ok = true; return r;
}

}  // namespace atlas
