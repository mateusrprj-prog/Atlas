// Rig core (0.31.0 armature/bones/pose, 0.32.0 skinning). Header-only, no GL/JNI/Scene dependency.
// Conventions: Z-up, right-handed. A bone points along its local +Y (head -> tail); rest data lives in ARMATURE space.
// Pose channels (loc / Euler XYZ degrees, R = Rz*Ry*Rx / scale) are relative to the bone's own rest frame.
// Matrices are row-major 4x4 for column vectors: p' = M * p.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstring>
#include <set>
#include <string>
#include <vector>
#include "mesh.hpp"

namespace atlas {

struct Mat4 { float m[16] = {1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1, 0, 0, 0, 0, 1}; };

inline Mat4 mmul(const Mat4& a, const Mat4& b) {
    Mat4 r;
    for (int i = 0; i < 4; ++i) for (int j = 0; j < 4; ++j) {
        float s = 0; for (int k = 0; k < 4; ++k) s += a.m[i * 4 + k] * b.m[k * 4 + j];
        r.m[i * 4 + j] = s;
    }
    return r;
}
inline Vec3 xfPoint(const Mat4& a, Vec3 p) {
    return {a.m[0] * p.x + a.m[1] * p.y + a.m[2] * p.z + a.m[3], a.m[4] * p.x + a.m[5] * p.y + a.m[6] * p.z + a.m[7],
            a.m[8] * p.x + a.m[9] * p.y + a.m[10] * p.z + a.m[11]};
}
inline Vec3 xfDir(const Mat4& a, Vec3 p) {
    return {a.m[0] * p.x + a.m[1] * p.y + a.m[2] * p.z, a.m[4] * p.x + a.m[5] * p.y + a.m[6] * p.z, a.m[8] * p.x + a.m[9] * p.y + a.m[10] * p.z};
}
// Inverse of an affine matrix (general 3x3 block, so non-uniform scale works). Singular -> identity.
inline Mat4 affineInverse(const Mat4& a) {
    const float *m = a.m;
    const float c00 = m[5] * m[10] - m[6] * m[9], c01 = m[6] * m[8] - m[4] * m[10], c02 = m[4] * m[9] - m[5] * m[8];
    const float det = m[0] * c00 + m[1] * c01 + m[2] * c02;
    if (!std::isfinite(det) || std::fabs(det) < 1e-12f) return Mat4{};
    const float id = 1.f / det; Mat4 r;
    r.m[0] = c00 * id;                           r.m[1] = (m[2] * m[9] - m[1] * m[10]) * id; r.m[2] = (m[1] * m[6] - m[2] * m[5]) * id;
    r.m[4] = c01 * id;                           r.m[5] = (m[0] * m[10] - m[2] * m[8]) * id; r.m[6] = (m[2] * m[4] - m[0] * m[6]) * id;
    r.m[8] = c02 * id;                           r.m[9] = (m[1] * m[8] - m[0] * m[9]) * id;  r.m[10] = (m[0] * m[5] - m[1] * m[4]) * id;
    r.m[3] = -(r.m[0] * m[3] + r.m[1] * m[7] + r.m[2] * m[11]);
    r.m[7] = -(r.m[4] * m[3] + r.m[5] * m[7] + r.m[6] * m[11]);
    r.m[11] = -(r.m[8] * m[3] + r.m[9] * m[7] + r.m[10] * m[11]);
    return r;
}
// Rotation block from Euler XYZ degrees (R = Rz*Ry*Rx), same convention as the scene objects.
inline Mat4 rotFromEuler(Vec3 deg) {
    const float k = 0.01745329252f;
    const float cx = std::cos(deg.x * k), sx = std::sin(deg.x * k), cy = std::cos(deg.y * k), sy = std::sin(deg.y * k), cz = std::cos(deg.z * k), sz = std::sin(deg.z * k);
    Mat4 r;
    r.m[0] = cz * cy; r.m[1] = cz * sy * sx - sz * cx; r.m[2] = cz * sy * cx + sz * sx;
    r.m[4] = sz * cy; r.m[5] = sz * sy * sx + cz * cx; r.m[6] = sz * sy * cx - cz * sx;
    r.m[8] = -sy;     r.m[9] = cy * sx;                r.m[10] = cy * cx;
    return r;
}
inline Mat4 trsMatrix(Vec3 loc, Vec3 eulerDeg, Vec3 scl) {   // T * R * S
    Mat4 r = rotFromEuler(eulerDeg);
    const float s[3] = {scl.x, scl.y, scl.z};
    for (int i = 0; i < 3; ++i) for (int j = 0; j < 3; ++j) r.m[i * 4 + j] *= s[j];
    r.m[3] = loc.x; r.m[7] = loc.y; r.m[11] = loc.z; return r;
}
inline Mat4 fromBasis(Vec3 x, Vec3 y, Vec3 z, Vec3 t) {
    Mat4 r;
    r.m[0] = x.x; r.m[1] = y.x; r.m[2] = z.x; r.m[3] = t.x;
    r.m[4] = x.y; r.m[5] = y.y; r.m[6] = z.y; r.m[7] = t.y;
    r.m[8] = x.z; r.m[9] = y.z; r.m[10] = z.z; r.m[11] = t.z; return r;
}
inline Mat4 axisAngleMatrix(Vec3 axis, float rad) {   // Rodrigues; zero axis -> identity
    Vec3 a = normalized(axis); if (length(a) < 0.5f) return Mat4{};
    const float c = std::cos(rad), s = std::sin(rad), t = 1.f - c; Mat4 r;
    r.m[0] = t * a.x * a.x + c;       r.m[1] = t * a.x * a.y - s * a.z; r.m[2] = t * a.x * a.z + s * a.y;
    r.m[4] = t * a.x * a.y + s * a.z; r.m[5] = t * a.y * a.y + c;       r.m[6] = t * a.y * a.z - s * a.x;
    r.m[8] = t * a.x * a.z - s * a.y; r.m[9] = t * a.y * a.z + s * a.x; r.m[10] = t * a.z * a.z + c;
    return r;
}

// ---------------------------------------------------------------- bones
struct Bone {
    std::string name;
    int parent = -1;              // index into Armature::bones, -1 = root
    bool connected = false;       // head sits on the parent's tail (kept by addBone / extrudeBone / setBoneParent)
    bool deform = true;           // takes part in skinning
    Vec3 head, tail;              // rest pose, armature space
    float roll = 0.f;             // degrees about the bone's Y axis
    Vec3 loc, rot, scl{1, 1, 1};  // pose channels (local to the bone's rest frame)
};
struct Armature { std::vector<Bone> bones; };

inline float boneLength(const Bone& b) { return length(b.tail - b.head); }

// Rest frame (armature space): origin at head, Y along head->tail, X/Z from the Z-up reference and the roll.
inline Mat4 boneRestMatrix(const Bone& b) {
    Vec3 y = normalized(b.tail - b.head); if (length(y) < 0.5f) y = {0, 1, 0};
    const Vec3 ref = std::fabs(y.z) > 0.9999f ? Vec3{0, 1, 0} : Vec3{0, 0, 1};
    Vec3 x = normalized(cross(y, ref)); Vec3 z = cross(x, y);
    const float r = b.roll * 0.01745329252f, c = std::cos(r), s = std::sin(r);
    const Vec3 x2 = x * c + z * s, z2 = z * c - x * s;
    return fromBasis(x2, y, z2, b.head);
}

inline bool finite3(Vec3 v) { return std::isfinite(v.x) && std::isfinite(v.y) && std::isfinite(v.z); }

// Is `anc` an ancestor of (or equal to) `b`?  Cycle-safe.
inline bool isAncestorOrSelf(const Armature& a, int anc, int b) {
    for (int n = 0, i = b; i >= 0 && i < (int)a.bones.size() && n <= (int)a.bones.size(); ++n, i = a.bones[i].parent) if (i == anc) return true;
    return false;
}
inline bool validArmature(const Armature& a) {
    const int n = (int)a.bones.size(); std::set<std::string> names;
    for (int i = 0; i < n; ++i) {
        const Bone& b = a.bones[i];
        if (b.name.empty() || !names.insert(b.name).second) return false;
        if (b.parent < -1 || b.parent >= n || b.parent == i) return false;
        if (!finite3(b.head) || !finite3(b.tail) || !finite3(b.loc) || !finite3(b.rot) || !finite3(b.scl) || !std::isfinite(b.roll)) return false;
        if (boneLength(b) < 1e-6f) return false;
        int steps = 0, p = b.parent; while (p >= 0 && steps <= n) { p = a.bones[p].parent; ++steps; }
        if (steps > n) return false;   // cycle
    }
    return true;
}
// Parents-first ordering (works for any index layout).
inline std::vector<int> boneOrder(const Armature& a) {
    const int n = (int)a.bones.size(); std::vector<int> out; std::vector<char> done(n, 0);
    for (int i = 0; i < n; ++i) {
        std::vector<int> chain; int j = i;
        while (j >= 0 && !done[j] && (int)chain.size() <= n) { chain.push_back(j); j = a.bones[j].parent; }
        for (int k = (int)chain.size() - 1; k >= 0; --k) if (!done[chain[k]]) { done[chain[k]] = 1; out.push_back(chain[k]); }
    }
    return out;
}
inline std::vector<Mat4> restMatrices(const Armature& a) {
    std::vector<Mat4> r(a.bones.size()); for (size_t i = 0; i < r.size(); ++i) r[i] = boneRestMatrix(a.bones[i]); return r;
}
// Pose matrices in armature space: world = parentWorld * (parentRest^-1 * rest) * poseLocal.
inline std::vector<Mat4> poseMatrices(const Armature& a) {
    const std::vector<Mat4> rest = restMatrices(a); std::vector<Mat4> w(a.bones.size());
    for (int i : boneOrder(a)) {
        const Bone& b = a.bones[i];
        const Mat4 local = trsMatrix(b.loc, b.rot, b.scl);
        if (b.parent < 0) w[i] = mmul(rest[i], local);
        else w[i] = mmul(w[b.parent], mmul(mmul(affineInverse(rest[b.parent]), rest[i]), local));
    }
    return w;
}
// Skinning matrices (pose * rest^-1): identity when every pose channel is neutral.
inline std::vector<Mat4> skinMatrices(const Armature& a) {
    const std::vector<Mat4> rest = restMatrices(a), w = poseMatrices(a); std::vector<Mat4> s(a.bones.size());
    for (size_t i = 0; i < s.size(); ++i) s[i] = mmul(w[i], affineInverse(rest[i]));
    return s;
}
inline bool poseIsRest(const Armature& a) {
    for (const auto& b : a.bones) if (b.loc.x != 0 || b.loc.y != 0 || b.loc.z != 0 || b.rot.x != 0 || b.rot.y != 0 || b.rot.z != 0 || b.scl.x != 1 || b.scl.y != 1 || b.scl.z != 1) return false;
    return true;
}
inline void resetPose(Armature& a) { for (auto& b : a.bones) { b.loc = {}; b.rot = {}; b.scl = {1, 1, 1}; } }

// ---------------------------------------------------------------- bone editing
inline std::string uniqueBoneName(const Armature& a, std::string base) {
    if (base.empty()) base = "Bone";
    auto taken = [&](const std::string& n) { for (const auto& b : a.bones) if (b.name == n) return true; return false; };
    if (!taken(base)) return base;
    for (int i = 1;; ++i) { std::string c = base + "." + std::to_string(i); if (!taken(c)) return c; }
}
inline std::string cleanBoneName(std::string n) {
    for (auto& c : n) if (c == ' ' || c == '\t' || c == '\n' || c == '\r') c = '_';
    if (n.size() > 48) n.resize(48);
    return n;
}
// New bone. parent -1 = root. connected: head snaps onto the parent's tail. Returns the index or -1 (nothing changed).
inline int addBone(Armature& a, const std::string& name, Vec3 head, Vec3 tail, int parent = -1, bool connected = false) {
    if (!finite3(head) || !finite3(tail) || length(tail - head) < 1e-6f) return -1;
    if (parent < -1 || parent >= (int)a.bones.size()) return -1;
    Bone b; b.name = uniqueBoneName(a, cleanBoneName(name)); b.head = head; b.tail = tail; b.parent = parent;
    if (parent >= 0 && connected) { b.head = a.bones[parent].tail; b.connected = true; if (length(b.tail - b.head) < 1e-6f) return -1; }
    a.bones.push_back(b); return (int)a.bones.size() - 1;
}
inline int extrudeBone(Armature& a, int idx, Vec3 tail, const std::string& name = "Bone") {
    if (idx < 0 || idx >= (int)a.bones.size()) return -1;
    return addBone(a, name, a.bones[idx].tail, tail, idx, true);
}
inline bool setBoneParent(Armature& a, int child, int parent, bool connected) {
    const int n = (int)a.bones.size();
    if (child < 0 || child >= n || parent < -1 || parent >= n || child == parent) return false;
    if (parent >= 0 && isAncestorOrSelf(a, child, parent)) return false;   // would create a cycle
    Bone& b = a.bones[child];
    if (parent >= 0 && connected) {
        const Vec3 h = a.bones[parent].tail; if (length(b.tail - h) < 1e-6f) return false;
        b.head = h; b.connected = true;
    } else b.connected = false;
    b.parent = parent; return true;
}
inline bool setBoneRest(Armature& a, int idx, Vec3 head, Vec3 tail, float roll) {
    if (idx < 0 || idx >= (int)a.bones.size() || !finite3(head) || !finite3(tail) || !std::isfinite(roll) || length(tail - head) < 1e-6f) return false;
    Bone& b = a.bones[idx]; b.head = head; b.tail = tail; b.roll = roll;
    for (auto& c : a.bones) if (c.parent == idx && c.connected) c.head = tail;   // connected children follow
    if (b.parent >= 0 && b.connected) b.head = a.bones[b.parent].tail;
    for (auto& c : a.bones) if (c.parent == idx && c.connected && length(c.tail - c.head) < 1e-6f) return false;
    return true;
}
inline bool renameBone(Armature& a, int idx, const std::string& raw) {
    if (idx < 0 || idx >= (int)a.bones.size()) return false;
    const std::string n = cleanBoneName(raw); if (n.empty()) return false;
    for (int i = 0; i < (int)a.bones.size(); ++i) if (i != idx && a.bones[i].name == n) return false;
    a.bones[idx].name = n; return true;
}
inline bool setBonePose(Armature& a, int idx, Vec3 loc, Vec3 rot, Vec3 scl) {
    if (idx < 0 || idx >= (int)a.bones.size() || !finite3(loc) || !finite3(rot) || !finite3(scl)) return false;
    if (std::fabs(scl.x) < 1e-4f || std::fabs(scl.y) < 1e-4f || std::fabs(scl.z) < 1e-4f) return false;
    Bone& b = a.bones[idx]; b.loc = loc; b.rot = rot; b.scl = scl; return true;
}
// Removes one bone; its children are re-parented to its parent (connection is dropped). `map` gets old index -> new index (-1 = removed).
inline bool deleteBone(Armature& a, int idx, std::vector<int>* map = nullptr) {
    const int n = (int)a.bones.size(); if (idx < 0 || idx >= n) return false;
    const int par = a.bones[idx].parent;
    for (auto& b : a.bones) if (b.parent == idx) { b.parent = par; b.connected = false; }
    std::vector<int> m(n); int k = 0;
    for (int i = 0; i < n; ++i) m[i] = i == idx ? -1 : k++;
    a.bones.erase(a.bones.begin() + idx);
    for (auto& b : a.bones) if (b.parent >= 0) b.parent = m[b.parent];
    if (map) *map = m;
    return true;
}
// "Arm.L" <-> "Arm.R", "Arm_l" <-> "Arm_r", "Left.Hand" style. Returns "" if the name has no side marker.
inline std::string flipSideName(const std::string& n) {
    auto endsWith = [&](const char* s) { const size_t l = std::strlen(s); return n.size() >= l && n.compare(n.size() - l, l, s) == 0; };
    static const char* pairs[][2] = {{".L", ".R"}, {".R", ".L"}, {"_L", "_R"}, {"_R", "_L"}, {".l", ".r"}, {".r", ".l"}, {"_l", "_r"}, {"_r", "_l"}, {"-L", "-R"}, {"-R", "-L"}};
    for (const auto& p : pairs) if (endsWith(p[0])) return n.substr(0, n.size() - std::strlen(p[0])) + p[1];
    if (n.rfind("Left", 0) == 0) return "Right" + n.substr(4);
    if (n.rfind("Right", 0) == 0) return "Left" + n.substr(5);
    return "";
}
// Mirrors the given bones across the armature's X = 0 plane into new bones (names flipped, or ".mirror" if there is no side marker).
// Parents map to the mirrored copy when that bone was mirrored too, otherwise to the same parent. Returns the new indices.
inline std::vector<int> mirrorBonesX(Armature& a, const std::vector<int>& src) {
    std::vector<int> out; std::vector<int> map(a.bones.size(), -1);
    std::vector<int> ord; { std::set<int> want; for (int i : src) if (i >= 0 && i < (int)a.bones.size()) want.insert(i);
        for (int i : boneOrder(a)) if (want.count(i)) ord.push_back(i); }
    auto flip = [](Vec3 v) { return Vec3{-v.x, v.y, v.z}; };
    for (int i : ord) {
        Bone b = a.bones[i]; const std::string f = flipSideName(b.name);
        b.name = uniqueBoneName(a, f.empty() ? b.name + ".mirror" : f);
        b.head = flip(b.head); b.tail = flip(b.tail); b.roll = -b.roll; b.loc.x = -b.loc.x; b.rot.y = -b.rot.y; b.rot.z = -b.rot.z;
        const int p = a.bones[i].parent;
        b.parent = p >= 0 && map[p] >= 0 ? map[p] : p;
        b.connected = a.bones[i].connected && b.parent >= 0 && length(b.head - a.bones[b.parent].tail) < 1e-5f;   // stays connected only if it still touches its parent
        a.bones.push_back(b); map[i] = (int)a.bones.size() - 1; out.push_back(map[i]);
    }
    return out;
}

// ---------------------------------------------------------------- skinning (0.32.0)
constexpr int kMaxInfluences = 4;
struct Influence { int bone[kMaxInfluences] = {-1, -1, -1, -1}; float w[kMaxInfluences] = {0, 0, 0, 0}; };
struct Skin { std::vector<Influence> v; };

inline float weightSum(const Influence& in) { float s = 0; for (int k = 0; k < kMaxInfluences; ++k) if (in.bone[k] >= 0) s += in.w[k]; return s; }
inline void normalizeInfluence(Influence& in) {   // drops non-positive weights, sorts strongest first, scales the sum to 1
    std::vector<std::pair<float, int>> t;
    for (int k = 0; k < kMaxInfluences; ++k) if (in.bone[k] >= 0 && in.w[k] > 1e-6f && std::isfinite(in.w[k])) t.push_back({in.w[k], in.bone[k]});
    std::sort(t.begin(), t.end(), [](auto& x, auto& y) { return x.first != y.first ? x.first > y.first : x.second < y.second; });
    Influence o; float s = 0; for (auto& p : t) s += p.first;
    for (size_t k = 0; k < t.size() && k < (size_t)kMaxInfluences; ++k) { o.bone[k] = t[k].second; o.w[k] = s > 0 ? t[k].first / s : 0; }
    in = o;
}
inline float vertexWeight(const Skin& s, int vi, int bone) {
    if (vi < 0 || vi >= (int)s.v.size()) return 0;
    for (int k = 0; k < kMaxInfluences; ++k) if (s.v[vi].bone[k] == bone) return s.v[vi].w[k];
    return 0;
}
// Paint-style assignment: bone gets `w` (0..1); the other influences share the rest in proportion; w = 0 removes the bone.
inline bool setVertexWeight(Skin& s, int vi, int bone, float w) {
    if (vi < 0 || vi >= (int)s.v.size() || bone < 0 || !std::isfinite(w) || w < 0.f || w > 1.f) return false;
    Influence& in = s.v[vi];
    int slot = -1; for (int k = 0; k < kMaxInfluences; ++k) if (in.bone[k] == bone) slot = k;
    if (slot < 0) for (int k = 0; k < kMaxInfluences; ++k) if (in.bone[k] < 0) { slot = k; break; }
    if (slot < 0) { slot = 0; for (int k = 1; k < kMaxInfluences; ++k) if (in.w[k] < in.w[slot]) slot = k; in.bone[slot] = -1; in.w[slot] = 0; }   // full: drop the weakest
    float others = 0;
    for (int k = 0; k < kMaxInfluences; ++k) if (in.bone[k] >= 0 && k != slot) others += in.w[k];
    const float rest = 1.f - w;
    for (int k = 0; k < kMaxInfluences; ++k) if (in.bone[k] >= 0 && k != slot) in.w[k] = others > 1e-9f ? in.w[k] / others * rest : 0.f;
    in.bone[slot] = bone; in.w[slot] = w; normalizeInfluence(in); return true;
}
inline float distPointSegment(Vec3 p, Vec3 a, Vec3 b) {
    const Vec3 ab = b - a; const float l2 = dot(ab, ab);
    float t = l2 > 1e-12f ? dot(p - a, ab) / l2 : 0.f; t = std::min(1.f, std::max(0.f, t));
    return length(p - (a + ab * t));
}
// Automatic weights from bone proximity (armature space): w ~ 1 / (d^2 + eps)^2 over deforming bones, strongest 4 kept.
// `toArm` maps mesh-local points to armature space. Returns false (skin untouched) when there is nothing to bind to.
inline bool autoWeights(const Mesh& m, const Armature& a, const Mat4& toArm, Skin& out) {
    std::vector<int> db; float maxLen = 0;
    for (int i = 0; i < (int)a.bones.size(); ++i) if (a.bones[i].deform) { db.push_back(i); maxLen = std::max(maxLen, boneLength(a.bones[i])); }
    if (db.empty() || m.v.empty() || !validArmature(a)) return false;
    const float eps = std::max(1e-6f, 0.02f * maxLen * maxLen);
    Skin s; s.v.resize(m.v.size());
    for (size_t vi = 0; vi < m.v.size(); ++vi) {
        const Vec3 p = xfPoint(toArm, m.v[vi]); Influence in;
        std::vector<std::pair<float, int>> cand;
        for (int b : db) { const float d = distPointSegment(p, a.bones[b].head, a.bones[b].tail); const float q = d * d + eps; cand.push_back({1.f / (q * q), b}); }
        std::sort(cand.begin(), cand.end(), [](auto& x, auto& y) { return x.first != y.first ? x.first > y.first : x.second < y.second; });
        for (size_t k = 0; k < cand.size() && k < (size_t)kMaxInfluences; ++k) { in.bone[k] = cand[k].second; in.w[k] = cand[k].first; }
        normalizeInfluence(in); s.v[vi] = in;
    }
    out = std::move(s); return true;
}
// Re-indexes a skin after deleteBone (map: old -> new, -1 = removed); vertices left with no weight are renormalized from what remains.
inline void remapSkin(Skin& s, const std::vector<int>& map) {
    for (auto& in : s.v) {
        for (int k = 0; k < kMaxInfluences; ++k) if (in.bone[k] >= 0) { in.bone[k] = in.bone[k] < (int)map.size() ? map[in.bone[k]] : -1; if (in.bone[k] < 0) in.w[k] = 0; }
        normalizeInfluence(in);
    }
}
inline bool validSkin(const Skin& s, int boneCount) {
    for (const auto& in : s.v) for (int k = 0; k < kMaxInfluences; ++k) {
        if (in.bone[k] >= boneCount || in.bone[k] < -1) return false;
        if (!std::isfinite(in.w[k]) || in.w[k] < 0.f) return false;
    }
    return true;
}
// Linear blend skinning. `toArm` = mesh-local -> armature space. Vertices without weights stay put.
inline Mesh skinMesh(const Mesh& rest, const Skin& s, const Armature& a, const Mat4& toArm) {
    Mesh out = rest; if (s.v.size() != rest.v.size() || a.bones.empty()) return out;
    const std::vector<Mat4> sk = skinMatrices(a); const Mat4 fromArm = affineInverse(toArm);
    std::vector<Mat4> C(sk.size()); for (size_t i = 0; i < sk.size(); ++i) C[i] = mmul(fromArm, mmul(sk[i], toArm));
    for (size_t vi = 0; vi < rest.v.size(); ++vi) {
        const Influence& in = s.v[vi]; Vec3 acc; float tot = 0;
        for (int k = 0; k < kMaxInfluences; ++k) if (in.bone[k] >= 0 && in.bone[k] < (int)C.size() && in.w[k] > 0) { acc = acc + xfPoint(C[in.bone[k]], rest.v[vi]) * in.w[k]; tot += in.w[k]; }
        if (tot > 1e-6f) out.v[vi] = acc * (1.f / tot);
    }
    return out;
}

}  // namespace atlas
