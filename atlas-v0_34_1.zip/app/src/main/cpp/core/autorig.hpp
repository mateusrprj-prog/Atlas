// Auto-rig (0.34.0): reads a humanoid mesh and builds a 21-bone armature that fits it. Header-only, no Scene/GL/JNI.
// Method (own code, geometric heuristics, no learning): the mesh is measured in slices.
//   - height and arm span from the bounding box; hand tips = extremes in +X / -X
//   - feet = lowest vertices per side (toe direction decides which way the character faces along Y)
//   - crotch = highest slice (going down from the torso) where the middle gap opens between the legs
//   - neck = narrowest central slice between 78 % and 95 % of the height
// Everything else (spine, shoulders, elbows, knees) is placed from those measurements with human proportions.
// Expects: Z-up, character standing, centred on X (left/right), arms out (T-pose, A-pose or hanging at the sides).
// Fails with a message (never a wrong rig) when the mesh does not look like that.
#pragma once
#include <algorithm>
#include <cmath>
#include <string>
#include <vector>
#include "rig.hpp"

namespace atlas {

struct AutoRigReport {
    bool ok = false; std::string error; std::string notes;   // notes: measurements that fell back to proportions
    Armature arm; float height = 0.f, facing = -1.f;        // facing: sign of Y the toes point to
};

namespace ar {
struct Slice { float lo, hi; };
inline float median(std::vector<float> v) { if (v.empty()) return 0.f; std::nth_element(v.begin(), v.begin() + v.size() / 2, v.end()); return v[v.size() / 2]; }
inline float mean(const std::vector<float>& v) { if (v.empty()) return 0.f; double s = 0; for (float x : v) s += x; return (float)(s / v.size()); }
}  // namespace ar

inline AutoRigReport autoRigHumanoid(const std::vector<Vec3>& P) {
    AutoRigReport R;
    if (P.size() < 30) { R.error = "malha pequena demais para reconhecer um corpo"; return R; }
    Vec3 lo = P[0], hi = P[0];
    for (const Vec3& p : P) {
        if (!finite3(p)) { R.error = "malha com vértices inválidos"; return R; }
        lo.x = std::min(lo.x, p.x); lo.y = std::min(lo.y, p.y); lo.z = std::min(lo.z, p.z); hi.x = std::max(hi.x, p.x); hi.y = std::max(hi.y, p.y); hi.z = std::max(hi.z, p.z);
    }
    const float H = hi.z - lo.z, W = hi.x - lo.x, zmin = lo.z, cx = (lo.x + hi.x) * 0.5f;
    if (H < 1e-5f) { R.error = "malha sem altura"; return R; }
    if (W < 0.18f * H) { R.error = "não achei os braços: o personagem precisa estar de pé com os braços para os lados (T-pose ou A-pose), e em pé no eixo Z"; return R; }
    if (W > 1.6f * H) { R.error = "largura maior que a altura: o modelo parece deitado ou não é um humanoide em pé"; return R; }
    R.height = H;
    // helpers: vertices in a z band (absolute z), optionally one side only (side = +1 / -1 / 0 both) and within |x - cx| <= maxDx
    auto band = [&](float z0, float z1, int side, float maxDx = 1e30f) {
        std::vector<const Vec3*> o;
        for (const Vec3& p : P) { const float dx = p.x - cx; if (p.z < z0 || p.z > z1) continue; if (side && dx * side <= 0) continue; if (std::fabs(dx) > maxDx) continue; o.push_back(&p); }
        return o;
    };
    auto yAt = [&](float z) {   // torso depth centre at height z
        std::vector<float> ys; float t = 0.012f * H;
        for (int k = 0; k < 4 && ys.size() < 6; ++k, t *= 2) { ys.clear(); for (auto* p : band(z - t, z + t, 0, 0.12f * H)) ys.push_back(p->y); }
        if (ys.empty()) { for (const Vec3& p : P) ys.push_back(p.y); }
        return ar::median(ys);
    };

    // ---- plausibility: legs and head must be narrow compared with the height (rejects boxes, spheres and props)
    { float a = 1e30f, c = -1e30f, ha = 1e30f, hc = -1e30f; int nl = 0, nh = 0;
      for (const Vec3& p : P) {
          if (p.z >= zmin + 0.10f * H && p.z <= zmin + 0.25f * H) { a = std::min(a, p.x); c = std::max(c, p.x); ++nl; }
          if (p.z >= zmin + 0.92f * H) { ha = std::min(ha, p.x); hc = std::max(hc, p.x); ++nh; }
      }
      if (nl < 4 || nh < 3 || c - a > 0.5f * H || hc - ha > 0.4f * H) { R.error = "o modelo não parece um humanoide de pé (pernas ou cabeça com proporção estranha)"; return R; } }

    // ---- feet: lowest 6 % of the height per side
    float toeSign = 0; Vec3 footC[2]; float toeFar[2] = {0, 0}; float legY[2] = {0, 0};
    float votes = 0;
    for (int s = 0; s < 2; ++s) {
        const int sd = s == 0 ? 1 : -1; auto fb = band(zmin, zmin + 0.06f * H, sd);
        if (fb.size() < 3) { R.error = "não achei os dois pés: o personagem precisa ficar em pé, com os pés no chão (z mínimo) e simétrico em X"; return R; }
        std::vector<float> xs, ys; for (auto* p : fb) { xs.push_back(p->x); ys.push_back(p->y); }
        footC[s] = {ar::mean(xs), ar::mean(ys), zmin};
        std::vector<float> sy; for (auto* p : band(zmin + 0.10f * H, zmin + 0.25f * H, sd, 0.3f * H)) sy.push_back(p->y);   // shin centre in Y
        legY[s] = sy.empty() ? footC[s].y : ar::mean(sy);
        float ymn = 1e30f, ymx = -1e30f; for (auto* p : fb) { ymn = std::min(ymn, p->y); ymx = std::max(ymx, p->y); }
        votes += ((ymx - legY[s]) > (legY[s] - ymn)) ? 1.f : -1.f;
    }
    toeSign = votes >= 0 ? 1.f : -1.f; R.facing = toeSign;
    for (int s = 0; s < 2; ++s) {
        const int sd = s == 0 ? 1 : -1; float far = 0;
        for (auto* p : band(zmin, zmin + 0.06f * H, sd)) far = std::max(far, (p->y - legY[s]) * toeSign);
        toeFar[s] = std::max(far, 0.04f * H);
    }

    // ---- crotch: walk down from 0.56 H; the first slice whose middle (|x| < 1.2 % H) is empty marks where the legs split
    float crotchZ = 0.47f * H + zmin; bool crotchOk = false;
    for (float z = zmin + 0.56f * H; z > zmin + 0.30f * H; z -= 0.005f * H) {
        if (band(z - 0.006f * H, z + 0.006f * H, 0, 0.012f * H).empty()) { crotchZ = z + 0.006f * H; crotchOk = true; break; }
    }
    if (crotchOk && (crotchZ < zmin + 0.34f * H || crotchZ > zmin + 0.56f * H)) { crotchOk = false; crotchZ = 0.47f * H + zmin; }
    if (!crotchOk) R.notes += "entrepernas não detectado (usei proporção); ";

    // ---- neck: narrowest central slice in 78..95 % of the height
    float neckZ = zmin + 0.84f * H, bestExt = 1e30f; bool neckOk = false;
    for (float z = zmin + 0.78f * H; z <= zmin + 0.95f * H; z += 0.01f * H) {
        auto b = band(z - 0.006f * H, z + 0.006f * H, 0, 0.2f * H); if (b.size() < 3) continue;
        float a = 1e30f, c = -1e30f; for (auto* p : b) { a = std::min(a, p->x); c = std::max(c, p->x); }
        if (c - a < bestExt - 1e-6f) { bestExt = c - a; neckZ = z; neckOk = true; }
    }
    if (!neckOk) R.notes += "pescoço não detectado (usei proporção); ";

    // ---- measurements for the arms: tips at the X extremes
    Vec3 tip[2]; float reach[2];
    for (int s = 0; s < 2; ++s) {
        const int sd = s == 0 ? 1 : -1; float mx = 0; for (const Vec3& p : P) mx = std::max(mx, (p.x - cx) * sd);
        if (mx < 0.14f * H) { R.error = "braços colados no corpo: use uma pose com os braços um pouco afastados (A-pose ou T-pose)"; return R; }
        std::vector<float> xs, ys, zs; for (const Vec3& p : P) if ((p.x - cx) * sd >= mx - 0.03f * H) { xs.push_back(p.x); ys.push_back(p.y); zs.push_back(p.z); }
        tip[s] = {ar::mean(xs), ar::mean(ys), ar::mean(zs)}; reach[s] = mx;
    }

    // ---- build the skeleton
    const float hipJointZ = crotchZ + 0.05f * H, shoulderZ = neckZ - 0.05f * H, headBaseZ = neckZ + 0.035f * H;
    const float span = shoulderZ - hipJointZ;
    if (span < 0.10f * H) { R.error = "proporções do corpo estranhas (tronco curto demais): confira se o modelo é um humanoide de pé"; return R; }
    if (zmin + H - headBaseZ < 0.03f * H) { R.error = "não achei a cabeça acima do pescoço"; return R; }
    const float ty = yAt(hipJointZ);
    Armature& A = R.arm;
    auto V = [&](float x, float y, float z) { return Vec3{x, y, z}; };
    const int hips = addBone(A, "Hips", V(cx, yAt(hipJointZ), hipJointZ), V(cx, yAt(hipJointZ + 0.25f * span), hipJointZ + 0.25f * span));
    const int spine = addBone(A, "Spine", {}, V(cx, yAt(hipJointZ + 0.58f * span), hipJointZ + 0.58f * span), hips, true);
    const int chest = addBone(A, "Chest", {}, V(cx, yAt(shoulderZ), shoulderZ), spine, true);
    const int neck = addBone(A, "Neck", {}, V(cx, yAt(headBaseZ), headBaseZ), chest, true);
    addBone(A, "Head", {}, V(cx, yAt(headBaseZ + 0.5f * (zmin + H - headBaseZ)), zmin + H), neck, true);
    (void)ty;
    for (int s = 0; s < 2; ++s) {
        const int sd = s == 0 ? 1 : -1; const char* suf = s == 0 ? ".L" : ".R";
        // arm
        const float sh = std::min(0.13f * H, 0.55f * reach[s]); const float sy = yAt(shoulderZ);
        const int clav = addBone(A, std::string("Clavicle") + suf, V(cx + sd * 0.01f * H, sy, shoulderZ), V(cx + sd * sh, sy, shoulderZ), chest, false);
        const Vec3 sj = V(cx + sd * sh, sy, shoulderZ); Vec3 d = tip[s] - sj; const float L = length(d);
        if (L < 0.15f * H) { R.error = "braço curto demais para a pose detectada: afaste os braços do corpo"; R.arm = Armature{}; return R; }
        d = d * (1.f / L); const Vec3 wrist = tip[s] - d * std::min(0.10f * H, 0.2f * L); const Vec3 elbow = sj + (wrist - sj) * 0.5f;
        const int up = addBone(A, std::string("UpperArm") + suf, {}, elbow, clav, true);
        const int lo2 = addBone(A, std::string("LowerArm") + suf, {}, wrist, up, true);
        addBone(A, std::string("Hand") + suf, {}, tip[s] + d * (0.01f * H), lo2, true);
        // leg
        std::vector<float> hx, hy; for (auto* p : band(crotchZ - 0.12f * H, crotchZ - 0.02f * H, sd)) { hx.push_back(p->x); hy.push_back(p->y); }
        const float legx = hx.empty() ? cx + sd * 0.06f * H : ar::mean(hx), legy = hy.empty() ? yAt(hipJointZ) : ar::mean(hy);
        std::vector<float> ax; for (auto* p : band(zmin + 0.08f * H, zmin + 0.20f * H, sd, 0.3f * H)) ax.push_back(p->x);
        const float ankx = ax.empty() ? legx : ar::mean(ax); const float ankleZ = zmin + 0.045f * H;
        const Vec3 hipJ = V(legx, legy, hipJointZ), ankle = V(ankx, legY[s], ankleZ);
        const Vec3 knee = hipJ + (ankle - hipJ) * 0.48f;
        const int ul = addBone(A, std::string("UpperLeg") + suf, hipJ, knee, hips, false);
        const int ll = addBone(A, std::string("LowerLeg") + suf, {}, ankle, ul, true);
        const int ft = addBone(A, std::string("Foot") + suf, {}, V(ankx, legY[s] + toeSign * 0.55f * toeFar[s], zmin + 0.02f * H), ll, true);
        addBone(A, std::string("Toes") + suf, {}, V(ankx, legY[s] + toeSign * toeFar[s], zmin + 0.015f * H), ft, true);
        (void)footC;
    }
    if (!validArmature(A)) { R.error = "o esqueleto gerado ficou inválido (medidas degeneradas)"; R.arm = Armature{}; return R; }
    R.ok = true; return R;
}

}  // namespace atlas
