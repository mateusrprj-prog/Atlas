// Polygon mesh (indexed faces, any vertex count >= 3) and modeling operations. Z-up, CCW = outward.
#pragma once
#include <random>
#include <algorithm>
#include <cmath>
#include <map>
#include <set>
#include <utility>
#include <vector>
#include "math3.hpp"

namespace atlas {

struct Mesh {
    std::vector<Vec3> v;
    std::vector<std::vector<int>> f;
};

using Edge = std::pair<int, int>;  // always (min, max)
inline Edge mkEdge(int a, int b) { return {std::min(a, b), std::max(a, b)}; }

inline bool sameMesh(const Mesh& a, const Mesh& b) {
    if (a.v.size() != b.v.size() || a.f != b.f) return false;
    for (size_t i = 0; i < a.v.size(); ++i)
        if (a.v[i].x != b.v[i].x || a.v[i].y != b.v[i].y || a.v[i].z != b.v[i].z) return false;
    return true;
}

inline bool validMesh(const Mesh& m) {
    for (const auto& fc : m.f) {
        if (fc.size() < 3) return false;
        for (int i : fc) if (i < 0 || i >= (int)m.v.size()) return false;
    }
    return true;
}

// Newell's method: robust normal for any planar-ish polygon.
inline Vec3 faceNormal(const Mesh& m, const std::vector<int>& face) {
    Vec3 n; size_t k = face.size();
    for (size_t i = 0; i < k; ++i) {
        const Vec3& a = m.v[face[i]]; const Vec3& b = m.v[face[(i + 1) % k]];
        n.x += (a.y - b.y) * (a.z + b.z);
        n.y += (a.z - b.z) * (a.x + b.x);
        n.z += (a.x - b.x) * (a.y + b.y);
    }
    return normalized(n);
}

// ---------- primitives (default size like a 2 m cube) ----------
inline Mesh makeCube() {
    Mesh m;
    for (int z = 0; z < 2; ++z) {
        const float zz = z ? 1.f : -1.f;
        m.v.push_back({-1, -1, zz}); m.v.push_back({1, -1, zz});
        m.v.push_back({1, 1, zz}); m.v.push_back({-1, 1, zz});
    }
    m.f = {{0, 3, 2, 1}, {4, 5, 6, 7}, {0, 1, 5, 4}, {3, 7, 6, 2}, {0, 4, 7, 3}, {1, 2, 6, 5}};
    return m;
}
inline Mesh makePlane() {
    Mesh m; m.v = {{-1, -1, 0}, {1, -1, 0}, {1, 1, 0}, {-1, 1, 0}}; m.f = {{0, 1, 2, 3}}; return m;
}
inline Mesh makeCylinder(int n = 16) {
    Mesh m;
    for (int i = 0; i < n; ++i) { float a = 6.2831853f * i / n; m.v.push_back({std::cos(a), std::sin(a), -1}); }
    for (int i = 0; i < n; ++i) { float a = 6.2831853f * i / n; m.v.push_back({std::cos(a), std::sin(a), 1}); }
    for (int i = 0; i < n; ++i) { int j = (i + 1) % n; m.f.push_back({i, j, n + j, n + i}); }
    std::vector<int> top, bot;
    for (int i = 0; i < n; ++i) top.push_back(n + i);
    for (int i = n - 1; i >= 0; --i) bot.push_back(i);
    m.f.push_back(top); m.f.push_back(bot);
    return m;
}
inline Mesh makeUVSphere(int seg = 16, int rings = 8) {
    Mesh m;
    m.v.push_back({0, 0, 1});
    for (int k = 1; k < rings; ++k) {
        float th = 3.14159265f * k / rings, z = std::cos(th), r = std::sin(th);
        for (int j = 0; j < seg; ++j) { float ph = 6.2831853f * j / seg; m.v.push_back({r * std::cos(ph), r * std::sin(ph), z}); }
    }
    const int bottom = (int)m.v.size(); m.v.push_back({0, 0, -1});
    auto ring = [&](int k, int j) { return 1 + (k - 1) * seg + (j % seg); };
    for (int j = 0; j < seg; ++j) m.f.push_back({0, ring(1, j), ring(1, j + 1)});
    for (int k = 1; k < rings - 1; ++k)
        for (int j = 0; j < seg; ++j) m.f.push_back({ring(k, j), ring(k + 1, j), ring(k + 1, j + 1), ring(k, j + 1)});
    for (int j = 0; j < seg; ++j) m.f.push_back({bottom, ring(rings - 1, j + 1), ring(rings - 1, j)});
    return m;
}
inline Mesh makePrimitive(int kind) {
    switch (kind) { case 1: return makePlane(); case 2: return makeCylinder(); case 3: return makeUVSphere(); default: return makeCube(); }
}
inline const char* primitiveName(int kind) {
    switch (kind) { case 1: return "Plane"; case 2: return "Cylinder"; case 3: return "Sphere"; default: return "Cube"; }
}

// ---------- queries ----------
inline bool rayTriangle(Vec3 o, Vec3 d, Vec3 a, Vec3 b, Vec3 c, float& t) {
    Vec3 e1 = b - a, e2 = c - a, p = cross(d, e2);
    float det = dot(e1, p);
    if (std::fabs(det) < 1e-12f) return false;
    float inv = 1.f / det; Vec3 s = o - a;
    float u = dot(s, p) * inv; if (u < 0 || u > 1) return false;
    Vec3 q = cross(s, e1);
    float v = dot(d, q) * inv; if (v < 0 || u + v > 1) return false;
    t = dot(e2, q) * inv; return t >= 0;
}
// Nearest face hit (fan triangulation). Returns face index or -1.
inline int pickFace(const Mesh& m, Vec3 o, Vec3 d, float* tOut = nullptr) {
    int best = -1; float bt = 1e30f;
    for (size_t fi = 0; fi < m.f.size(); ++fi) {
        const auto& fc = m.f[fi];
        for (size_t i = 1; i + 1 < fc.size(); ++i) {
            float t;
            if (rayTriangle(o, d, m.v[fc[0]], m.v[fc[i]], m.v[fc[i + 1]], t) && t < bt) { bt = t; best = (int)fi; }
        }
    }
    if (tOut) *tOut = bt;
    return best;
}
inline std::vector<std::pair<int, int>> uniqueEdges(const Mesh& m) {
    std::vector<std::pair<int, int>> e;
    for (const auto& fc : m.f)
        for (size_t i = 0; i < fc.size(); ++i) {
            int a = fc[i], b = fc[(i + 1) % fc.size()];
            e.push_back({std::min(a, b), std::max(a, b)});
        }
    std::sort(e.begin(), e.end());
    e.erase(std::unique(e.begin(), e.end()), e.end());
    return e;
}

// ---------- modeling operations ----------
// Extrude the selected faces as one region along their (averaged) normals. Selected faces are moved
// to duplicated vertices; side quads are created on the region boundary. Face indices stay valid.
inline bool extrudeFaces(Mesh& m, const std::vector<int>& sel, float dist) {
    if (sel.empty() || std::fabs(dist) < 1e-6f) return false;
    for (int i : sel) if (i < 0 || i >= (int)m.f.size()) return false;
    std::map<std::pair<int, int>, int> cnt;
    std::map<int, Vec3> vn;
    for (int fi : sel) {
        const auto& fc = m.f[fi]; Vec3 n = faceNormal(m, fc);
        for (size_t i = 0; i < fc.size(); ++i) {
            int a = fc[i], b = fc[(i + 1) % fc.size()];
            cnt[{std::min(a, b), std::max(a, b)}]++;
            vn[a] = vn[a] + n;
        }
    }
    std::map<int, int> dup;
    for (auto& kv : vn) {
        Vec3 n = normalized(kv.second);
        dup[kv.first] = (int)m.v.size();
        m.v.push_back(m.v[kv.first] + n * dist);
    }
    std::vector<std::vector<int>> sides;
    for (int fi : sel) {
        const auto& fc = m.f[fi];
        for (size_t i = 0; i < fc.size(); ++i) {
            int a = fc[i], b = fc[(i + 1) % fc.size()];
            if (cnt[{std::min(a, b), std::max(a, b)}] != 1) continue;
            if (dist > 0) sides.push_back({a, b, dup[b], dup[a]});
            else sides.push_back({a, dup[a], dup[b], b});
        }
    }
    for (int fi : sel) for (int& vi : m.f[fi]) vi = dup[vi];
    for (auto& s : sides) m.f.push_back(s);
    return true;
}

// Remove faces and compact unused vertices.
inline bool deleteFaces(Mesh& m, const std::vector<int>& sel) {
    if (sel.empty()) return false;
    std::vector<char> del(m.f.size(), 0);
    for (int i : sel) { if (i < 0 || i >= (int)m.f.size()) return false; del[i] = 1; }
    std::vector<std::vector<int>> nf;
    for (size_t i = 0; i < m.f.size(); ++i) if (!del[i]) nf.push_back(m.f[i]);
    std::vector<int> remap(m.v.size(), -1); std::vector<Vec3> nv;
    for (auto& fc : nf) for (int& vi : fc) {
        if (remap[vi] < 0) { remap[vi] = (int)nv.size(); nv.push_back(m.v[vi]); }
        vi = remap[vi];
    }
    m.v = nv; m.f = nf; return true;
}

// Surface area of a (planar-ish) polygon.
inline float faceArea(const Mesh& m, const std::vector<int>& face) {
    Vec3 n; size_t k = face.size();
    for (size_t i = 0; i < k; ++i) {
        const Vec3& a = m.v[face[i]]; const Vec3& b = m.v[face[(i + 1) % k]];
        n.x += (a.y - b.y) * (a.z + b.z); n.y += (a.z - b.z) * (a.x + b.x); n.z += (a.x - b.x) * (a.y + b.y);
    }
    return 0.5f * length(n);
}

namespace detail {
inline bool uniqueValidFaces(const Mesh& m, const std::vector<int>& in, std::vector<int>& out) {
    out = in; std::sort(out.begin(), out.end()); out.erase(std::unique(out.begin(), out.end()), out.end());
    for (int i : out) if (i < 0 || i >= (int)m.f.size()) return false;
    return !out.empty();
}
}  // namespace detail

// Extrude selected edges into a strip of quads. New vertices move along the averaged normals of the faces
// that touch each selected edge. `newEdges` receives the edges of the extruded copy. Every selected edge
// must belong to at least one face.
inline bool extrudeEdges(Mesh& m, const std::set<Edge>& sel, float dist, std::set<Edge>* newEdges = nullptr) {
    if (sel.empty() || std::fabs(dist) < 1e-6f) return false;
    for (const auto& e : sel) if (e.first < 0 || e.second >= (int)m.v.size() || e.first >= e.second) return false;
    std::map<int, Vec3> vn; std::map<Edge, std::pair<int, int>> dirOf;
    for (const auto& fc : m.f) {
        Vec3 n = faceNormal(m, fc);
        for (size_t i = 0; i < fc.size(); ++i) {
            int a = fc[i], b = fc[(i + 1) % fc.size()]; Edge e = mkEdge(a, b);
            if (!sel.count(e)) continue;
            vn[a] = vn[a] + n; vn[b] = vn[b] + n;
            if (!dirOf.count(e)) dirOf[e] = {a, b};
        }
    }
    if (dirOf.size() != sel.size()) return false;
    std::map<int, int> dup;
    for (auto& kv : vn) {
        Vec3 d = normalized(kv.second); if (length(d) < 0.5f) d = Vec3{0, 0, 1};
        dup[kv.first] = (int)m.v.size(); m.v.push_back(m.v[kv.first] + d * dist);
    }
    std::set<Edge> made;
    for (const auto& kv : dirOf) {
        int a = kv.second.first, b = kv.second.second;
        m.f.push_back({b, a, dup[a], dup[b]});   // shared edge runs opposite to the original face
        made.insert(mkEdge(dup[a], dup[b]));
    }
    if (newEdges) *newEdges = made;
    return true;
}

inline bool deleteVertices(Mesh& m, const std::set<int>& sel) {
    std::vector<int> faces;
    for (size_t fi = 0; fi < m.f.size(); ++fi) for (int vi : m.f[fi]) if (sel.count(vi)) { faces.push_back((int)fi); break; }
    return deleteFaces(m, faces);
}
inline bool deleteEdges(Mesh& m, const std::set<Edge>& sel) {
    std::vector<int> faces;
    for (size_t fi = 0; fi < m.f.size(); ++fi) {
        const auto& fc = m.f[fi];
        for (size_t i = 0; i < fc.size(); ++i) if (sel.count(mkEdge(fc[i], fc[(i + 1) % fc.size()]))) { faces.push_back((int)fi); break; }
    }
    return deleteFaces(m, faces);
}

// Inset each selected face individually: the face shrinks towards its centroid by `amount` (0..1, exclusive)
// and a ring of quads fills the gap. Face indices stay valid (each face becomes its inner face).
inline bool insetFaces(Mesh& m, const std::vector<int>& selIn, float amount) {
    std::vector<int> sel;
    if (!detail::uniqueValidFaces(m, selIn, sel) || !(amount > 1e-6f) || !(amount < 1.f)) return false;
    for (int fi : sel) {
        const std::vector<int> fc = m.f[fi]; const size_t n = fc.size();
        Vec3 c; for (int vi : fc) c = c + m.v[vi]; c = c * (1.f / n);
        std::vector<int> in(n);
        for (size_t i = 0; i < n; ++i) { in[i] = (int)m.v.size(); m.v.push_back(m.v[fc[i]] + (c - m.v[fc[i]]) * amount); }
        for (size_t i = 0; i < n; ++i) { size_t j = (i + 1) % n; m.f.push_back({fc[i], fc[j], in[j], in[i]}); }
        m.f[fi] = in;
    }
    return true;
}

// Split each selected face into quads (edge midpoints + face centre). Neighbouring unselected faces receive
// the new midpoints so the mesh stays watertight (they become n-gons). `created` = all faces that came from
// the selection.
inline bool subdivideFaces(Mesh& m, const std::vector<int>& selIn, std::vector<int>* created = nullptr) {
    std::vector<int> sel;
    if (!detail::uniqueValidFaces(m, selIn, sel)) return false;
    const int origN = (int)m.f.size();
    std::map<Edge, int> mid;
    auto midOf = [&](int a, int b) {
        Edge e = mkEdge(a, b); auto it = mid.find(e); if (it != mid.end()) return it->second;
        int i = (int)m.v.size(); m.v.push_back((m.v[a] + m.v[b]) * 0.5f); mid[e] = i; return i;
    };
    std::vector<char> isSel(origN, 0);
    for (int fi : sel) { isSel[fi] = 1; const auto& fc = m.f[fi]; for (size_t i = 0; i < fc.size(); ++i) midOf(fc[i], fc[(i + 1) % fc.size()]); }
    for (int fi = 0; fi < origN; ++fi) {
        if (isSel[fi]) continue;
        const auto& fc = m.f[fi]; std::vector<int> out;
        for (size_t i = 0; i < fc.size(); ++i) {
            out.push_back(fc[i]);
            auto it = mid.find(mkEdge(fc[i], fc[(i + 1) % fc.size()])); if (it != mid.end()) out.push_back(it->second);
        }
        if (out.size() != fc.size()) m.f[fi] = out;
    }
    std::vector<int> made;
    for (int fi : sel) {
        const std::vector<int> fc = m.f[fi]; const size_t n = fc.size();
        Vec3 c; for (int vi : fc) c = c + m.v[vi]; c = c * (1.f / n);
        int ci = (int)m.v.size(); m.v.push_back(c);
        std::vector<int> mids(n); for (size_t i = 0; i < n; ++i) mids[i] = midOf(fc[i], fc[(i + 1) % n]);
        for (size_t i = 0; i < n; ++i) {
            std::vector<int> q = {fc[i], mids[i], ci, mids[(i + n - 1) % n]};
            if (i == 0) { m.f[fi] = q; made.push_back(fi); } else { m.f.push_back(q); made.push_back((int)m.f.size() - 1); }
        }
    }
    if (created) *created = made;
    return true;
}

// Collapse the selected vertices into one vertex at their centroid. Degenerate faces are removed.
// `merged` receives the index of the resulting vertex (after compaction).
inline bool mergeVerticesAtCenter(Mesh& m, const std::set<int>& sel, int* merged = nullptr) {
    if (sel.size() < 2) return false;
    for (int i : sel) if (i < 0 || i >= (int)m.v.size()) return false;
    Vec3 c; for (int i : sel) c = c + m.v[i]; c = c * (1.f / sel.size());
    const int keep = *sel.begin(); m.v[keep] = c;
    std::vector<int> remap(m.v.size()); for (size_t i = 0; i < remap.size(); ++i) remap[i] = (int)i;
    for (int i : sel) remap[i] = keep;
    std::vector<std::vector<int>> nf;
    for (const auto& fc : m.f) {
        std::vector<int> out;
        for (int vi : fc) { int r = remap[vi]; if (out.empty() || out.back() != r) out.push_back(r); }
        while (out.size() > 1 && out.front() == out.back()) out.pop_back();
        if (out.size() >= 3) nf.push_back(out);
    }
    std::vector<int> compact(m.v.size(), -1); std::vector<Vec3> nv;
    for (auto& fc : nf) for (int& vi : fc) { if (compact[vi] < 0) { compact[vi] = (int)nv.size(); nv.push_back(m.v[vi]); } vi = compact[vi]; }
    if (merged) *merged = compact[keep];
    m.v = nv; m.f = nf; return true;
}

inline bool flipFaces(Mesh& m, const std::vector<int>& selIn) {
    std::vector<int> sel; if (!detail::uniqueValidFaces(m, selIn, sel)) return false;
    for (int fi : sel) std::reverse(m.f[fi].begin(), m.f[fi].end());
    return true;
}

// ---------- edit-mode transforms on a vertex mask (pivot = median point of the masked vertices) ----------
inline bool maskCentroid(const Mesh& m, const std::vector<char>& mask, Vec3* c) {
    Vec3 sum; int n = 0;
    for (size_t i = 0; i < mask.size() && i < m.v.size(); ++i) if (mask[i]) { sum = sum + m.v[i]; ++n; }
    if (!n) return false;
    *c = sum * (1.f / n); return true;
}
inline bool moveVertices(Mesh& m, const std::vector<char>& mask, Vec3 d) {
    bool any = false;
    for (size_t i = 0; i < mask.size() && i < m.v.size(); ++i) if (mask[i]) { m.v[i] = m.v[i] + d; any = true; }
    return any;
}
// Rotate about the local axis (0=X, 1=Y, 2=Z) through the pivot.
inline bool rotateVertices(Mesh& m, const std::vector<char>& mask, int axis, float deg) {
    Vec3 c; if (!maskCentroid(m, mask, &c)) return false;
    float a = deg * 0.01745329252f, cs = std::cos(a), sn = std::sin(a);
    for (size_t i = 0; i < mask.size() && i < m.v.size(); ++i) if (mask[i]) {
        Vec3 p = m.v[i] - c, q = p;
        if (axis == 0) { q.y = p.y * cs - p.z * sn; q.z = p.y * sn + p.z * cs; }
        else if (axis == 1) { q.x = p.x * cs + p.z * sn; q.z = -p.x * sn + p.z * cs; }
        else { q.x = p.x * cs - p.y * sn; q.y = p.x * sn + p.y * cs; }
        m.v[i] = c + q;
    }
    return true;
}
inline bool scaleVertices(Mesh& m, const std::vector<char>& mask, Vec3 k) {
    Vec3 c; if (!maskCentroid(m, mask, &c)) return false;
    for (size_t i = 0; i < mask.size() && i < m.v.size(); ++i) if (mask[i]) {
        Vec3 p = m.v[i] - c; m.v[i] = c + Vec3{p.x * k.x, p.y * k.y, p.z * k.z};
    }
    return true;
}

// ---------- edge rings / loops ----------
namespace detail {
inline std::map<Edge, std::vector<int>> edgeFaces(const Mesh& m) {
    std::map<Edge, std::vector<int>> r;
    for (size_t fi = 0; fi < m.f.size(); ++fi) { const auto& fc = m.f[fi]; for (size_t i = 0; i < fc.size(); ++i) r[mkEdge(fc[i], fc[(i + 1) % fc.size()])].push_back((int)fi); }
    return r;
}
}  // namespace detail

// Loop cut: walks the ring of quads that contains `start` (edges "parallel" across quads) and splits every quad
// of the ring with a new edge loop. `t` (0..1, exclusive) is measured from start.first towards start.second and
// stays consistent along the whole ring. Triangles/n-gons at the end of an open ring receive the midpoints so the
// mesh stays watertight. `newEdges` receives the cut edges.
inline bool loopCut(Mesh& m, Edge start, float t, std::set<Edge>* newEdges = nullptr) {
    if (!(t > 1e-4f) || !(t < 1.f - 1e-4f)) return false;
    auto ef = detail::edgeFaces(m);
    if (!ef.count(start)) return false;
    std::map<Edge, std::pair<int, int>> dir;           // ring edge -> directed (p,q), parallel to start
    std::vector<std::pair<int, int>> todo = {{start.first, start.second}};
    while (!todo.empty()) {
        auto pq = todo.back(); todo.pop_back();
        Edge e = mkEdge(pq.first, pq.second); if (dir.count(e)) continue;
        dir[e] = pq;
        for (int fi : ef[e]) {
            const auto& fc = m.f[fi]; if (fc.size() != 4) continue;
            for (int i = 0; i < 4; ++i) {
                if (mkEdge(fc[i], fc[(i + 1) % 4]) != e) continue;
                int c = fc[(i + 2) % 4], d = fc[(i + 3) % 4];
                todo.push_back(fc[i] == pq.first ? std::make_pair(d, c) : std::make_pair(c, d));
                break;
            }
        }
    }
    std::map<Edge, int> mid;
    for (const auto& kv : dir) {
        const Vec3 &P = m.v[kv.second.first], &Q = m.v[kv.second.second];
        mid[kv.first] = (int)m.v.size(); m.v.push_back(P + (Q - P) * t);
    }
    std::set<Edge> made; const int n0 = (int)m.f.size();
    for (int fi = 0; fi < n0; ++fi) {
        const std::vector<int> fc = m.f[fi]; const size_t n = fc.size();
        std::vector<int> hit; for (size_t i = 0; i < n; ++i) if (mid.count(mkEdge(fc[i], fc[(i + 1) % n]))) hit.push_back((int)i);
        if (hit.empty()) continue;
        if (n == 4 && hit.size() == 2 && hit[1] - hit[0] == 2) {          // split the quad
            int i = hit[0]; int a = fc[i], b = fc[(i + 1) % 4], c = fc[(i + 2) % 4], d = fc[(i + 3) % 4];
            int m1 = mid[mkEdge(a, b)], m2 = mid[mkEdge(c, d)];
            m.f[fi] = {a, m1, m2, d}; m.f.push_back({m1, b, c, m2}); made.insert(mkEdge(m1, m2));
        } else {                                                           // just insert midpoints
            std::vector<int> out;
            for (size_t i = 0; i < n; ++i) { out.push_back(fc[i]); auto it = mid.find(mkEdge(fc[i], fc[(i + 1) % n])); if (it != mid.end()) out.push_back(it->second); }
            m.f[fi] = out;
        }
    }
    if (newEdges) *newEdges = made;
    return !made.empty();
}

// Edge loop through `start`: continues straight through vertices of valence 4 in both directions.
inline std::set<Edge> edgeLoop(const Mesh& m, Edge start) {
    auto ef = detail::edgeFaces(m); std::set<Edge> loop;
    if (!ef.count(start)) return loop;
    std::map<int, std::vector<Edge>> inc;
    for (const auto& kv : ef) { inc[kv.first.first].push_back(kv.first); inc[kv.first.second].push_back(kv.first); }
    auto shareFace = [&](const Edge& x, const Edge& y) { for (int f : ef[x]) for (int g : ef[y]) if (f == g) return true; return false; };
    loop.insert(start);
    for (int dirn = 0; dirn < 2; ++dirn) {
        Edge cur = start; int v = dirn ? start.first : start.second;
        for (;;) {
            auto& list = inc[v]; if (list.size() != 4) break;
            const Edge* next = nullptr;
            for (const auto& e : list) if (e != cur && !shareFace(cur, e)) { next = &e; break; }
            if (!next || loop.count(*next)) break;
            loop.insert(*next); cur = *next; v = cur.first == v ? cur.second : cur.first;
        }
    }
    return loop;
}


// ---------- 0.10.0: dissolve ----------
// Removes vertices no face uses, keeping the order of the rest. Returns how many were removed.
inline int compactUnusedVertices(Mesh& m) {
    std::vector<char> used(m.v.size(), 0);
    for (const auto& fc : m.f) for (int i : fc) used[i] = 1;
    std::vector<int> remap(m.v.size(), -1); std::vector<Vec3> nv;
    for (size_t i = 0; i < m.v.size(); ++i) if (used[i]) { remap[i] = (int)nv.size(); nv.push_back(m.v[i]); }
    const int removed = (int)m.v.size() - (int)nv.size();
    if (removed == 0) return 0;
    for (auto& fc : m.f) for (int& i : fc) i = remap[i];
    m.v = std::move(nv); return removed;
}

namespace detail {
// Direction (a->b) in which `fc` walks the edge {a,b}: +1 if a then b, -1 if b then a, 0 if the face does not have the edge.
inline int edgeDirInFace(const std::vector<int>& fc, int a, int b) {
    const size_t n = fc.size();
    for (size_t i = 0; i < n; ++i) {
        const int p = fc[i], q = fc[(i + 1) % n];
        if (p == a && q == b) return 1;
        if (p == b && q == a) return -1;
    }
    return 0;
}

// Merges the two faces on each given manifold edge (winding must be consistent). Faces chained through several edges
// become ONE polygon. A group whose outline is not a single simple loop is left untouched. Vertex indices never change
// (leftover vertices stay in the mesh). `made` gets the indices (in the final face list) of the merged faces.
// Returns the number of polygons created.
inline int dissolveEdgesCore(Mesh& m, const std::set<Edge>& edges, std::vector<int>* made) {
    auto ef = edgeFaces(m);
    const int nf = (int)m.f.size();
    std::vector<int> par(nf); for (int i = 0; i < nf; ++i) par[i] = i;
    auto root = [&](int x) { while (par[x] != x) { par[x] = par[par[x]]; x = par[x]; } return x; };
    std::vector<char> inGroup(nf, 0);
    for (const Edge& e : edges) {
        auto it = ef.find(e); if (it == ef.end() || it->second.size() != 2) continue;
        const int f1 = it->second[0], f2 = it->second[1]; if (f1 == f2) continue;
        if (edgeDirInFace(m.f[f1], e.first, e.second) * edgeDirInFace(m.f[f2], e.first, e.second) != -1) continue;
        const int a = root(f1), b = root(f2); if (a != b) par[std::max(a, b)] = std::min(a, b);
        inGroup[f1] = inGroup[f2] = 1;
    }
    std::map<int, std::vector<int>> groups;
    for (int i = 0; i < nf; ++i) if (inGroup[i]) groups[root(i)].push_back(i);
    std::vector<char> removed(nf, 0); std::map<int, std::vector<int>> merged;   // representative face -> new polygon
    for (auto& g : groups) {
        const std::vector<int>& fs = g.second; if (fs.size() < 2) continue;
        std::set<std::pair<int, int>> dir;
        for (int fi : fs) { const auto& fc = m.f[fi]; for (size_t i = 0; i < fc.size(); ++i) dir.insert({fc[i], fc[(i + 1) % fc.size()]}); }
        std::map<int, int> next; bool ok = true; size_t bnd = 0;
        for (const auto& d : dir) {
            if (dir.count({d.second, d.first})) continue;       // shared by two faces of the group: interior
            if (next.count(d.first)) { ok = false; break; }     // vertex touched twice by the outline: pinched
            next[d.first] = d.second; ++bnd;
        }
        if (!ok || bnd < 3) continue;
        std::vector<int> poly; const int start = next.begin()->first; int cur = start;
        for (size_t guard = 0; guard <= bnd; ++guard) {
            poly.push_back(cur); auto it = next.find(cur); if (it == next.end()) { ok = false; break; }
            cur = it->second; if (cur == start) break;
        }
        if (!ok || cur != start || poly.size() != bnd) continue;   // more than one loop (hole) or open outline
        merged[fs[0]] = poly;
        for (size_t k = 1; k < fs.size(); ++k) removed[fs[k]] = 1;
    }
    if (merged.empty()) return 0;
    std::vector<std::vector<int>> nfaces;
    for (int i = 0; i < nf; ++i) {
        if (removed[i]) continue;
        auto it = merged.find(i);
        if (it != merged.end()) { if (made) made->push_back((int)nfaces.size()); nfaces.push_back(it->second); }
        else nfaces.push_back(m.f[i]);
    }
    m.f = std::move(nfaces); return (int)merged.size();
}

// Removes vertices flagged in `mask` that have exactly two neighbours and are straight within `cosLimit`
// (cos of the largest allowed bend; -1 = any bend). Faces must keep >= 3 corners; the shortcut edge must be new.
// Vertex indices are not changed. Returns how many vertices were dissolved.
inline int dissolveStraightVerts(Mesh& m, const std::vector<char>& mask, float cosLimit) {
    const int nv = (int)m.v.size();
    std::vector<std::set<int>> nb(nv); std::vector<std::vector<int>> vf(nv); std::set<Edge> es;
    for (size_t fi = 0; fi < m.f.size(); ++fi) {
        const auto& fc = m.f[fi]; const size_t n = fc.size();
        for (size_t i = 0; i < n; ++i) {
            const int a = fc[i], b = fc[(i + 1) % n];
            nb[a].insert(b); nb[b].insert(a); es.insert(mkEdge(a, b)); vf[a].push_back((int)fi);
        }
    }
    int count = 0;
    for (int v = 0; v < nv && v < (int)mask.size(); ++v) {
        if (!mask[v] || nb[v].size() != 2 || vf[v].empty() || vf[v].size() > 2) continue;
        const int a = *nb[v].begin(), b = *nb[v].rbegin();
        if (a == b || es.count(mkEdge(a, b))) continue;
        bool big = true; for (int fi : vf[v]) if (m.f[fi].size() < 4) big = false;
        if (!big) continue;
        const Vec3 d1 = normalized(m.v[v] - m.v[a]), d2 = normalized(m.v[b] - m.v[v]);
        if (dot(d1, d2) < cosLimit) continue;
        for (int fi : vf[v]) { auto& fc = m.f[fi]; fc.erase(std::find(fc.begin(), fc.end(), v)); }
        es.erase(mkEdge(a, v)); es.erase(mkEdge(v, b)); es.insert(mkEdge(a, b));
        nb[a].erase(v); nb[a].insert(b); nb[b].erase(v); nb[b].insert(a); nb[v].clear();
        ++count;
    }
    return count;
}
}  // namespace detail

// Dissolve Edges: merges the faces on each selected edge into one polygon (chains merge into a single face). Edges on a
// boundary, on non-manifold seams or with inconsistent winding are ignored. Vertices left straight (< 1 degree) by the
// merge are removed too. Returns the polygons created (0 = mesh untouched). `made` = merged faces in the new face list.
inline int dissolveEdges(Mesh& m, const std::set<Edge>& edges, std::vector<int>* made = nullptr) {
    Mesh work = m; std::vector<int> mf;
    const int n = detail::dissolveEdgesCore(work, edges, &mf);
    if (n == 0) return 0;
    std::vector<char> mask(work.v.size(), 0);
    for (const Edge& e : edges) { if (e.first >= 0 && e.first < (int)mask.size()) mask[e.first] = 1; if (e.second >= 0 && e.second < (int)mask.size()) mask[e.second] = 1; }
    detail::dissolveStraightVerts(work, mask, std::cos(1.f * 0.01745329252f));
    compactUnusedVertices(work);
    if (!validMesh(work)) return 0;
    m = std::move(work); if (made) *made = mf; return n;
}

// Limited Dissolve: merges neighbouring faces whose normals differ by at most `angleDeg` (only faces flagged in
// `faceMask`, if given) and removes the vertices that end up straight within the same angle. Returns polygons created.
inline int limitedDissolve(Mesh& m, float angleDeg, const std::vector<char>* faceMask = nullptr, std::vector<int>* made = nullptr) {
    if (!std::isfinite(angleDeg) || angleDeg < 0.f || angleDeg > 180.f) return 0;
    const float cosL = std::cos(angleDeg * 0.01745329252f) - 1e-6f;
    auto ef = detail::edgeFaces(m);
    std::vector<Vec3> nrm(m.f.size()); for (size_t i = 0; i < m.f.size(); ++i) nrm[i] = faceNormal(m, m.f[i]);
    std::set<Edge> flat;
    for (const auto& kv : ef) {
        if (kv.second.size() != 2) continue;
        const int a = kv.second[0], b = kv.second[1];
        if (faceMask && (a >= (int)faceMask->size() || b >= (int)faceMask->size() || !(*faceMask)[a] || !(*faceMask)[b])) continue;
        if (length(nrm[a]) < 0.5f || length(nrm[b]) < 0.5f) continue;
        if (dot(nrm[a], nrm[b]) >= cosL) flat.insert(kv.first);
    }
    Mesh work = m; std::vector<int> mf;
    const int n = detail::dissolveEdgesCore(work, flat, &mf);
    if (n == 0) return 0;
    std::vector<char> mask(work.v.size(), 0);
    for (const Edge& e : flat) { mask[e.first] = 1; mask[e.second] = 1; }
    detail::dissolveStraightVerts(work, mask, cosL);
    compactUnusedVertices(work);
    if (!validMesh(work)) return 0;
    // faces keep their order, so `made` (computed before vertex cleanup) is still valid
    m = std::move(work); if (made) *made = mf; return n;
}

// Splits the mesh into the faces in `sel` and the rest. Both parts get their own compact vertex list.
inline bool separateFaces(const Mesh& m, const std::vector<int>& selIn, Mesh& picked, Mesh& rest) {
    std::vector<int> sel; if (!detail::uniqueValidFaces(m, selIn, sel)) return false;
    if (sel.size() >= m.f.size()) return false;                         // nothing would stay behind
    std::vector<char> take(m.f.size(), 0); for (int i : sel) take[i] = 1;
    picked = Mesh(); rest = Mesh();
    auto copyFace = [&](Mesh& out, std::vector<int>& remap, const std::vector<int>& fc) {
        std::vector<int> g; g.reserve(fc.size());
        for (int vi : fc) { if (remap[vi] < 0) { remap[vi] = (int)out.v.size(); out.v.push_back(m.v[vi]); } g.push_back(remap[vi]); }
        out.f.push_back(std::move(g));
    };
    std::vector<int> ra(m.v.size(), -1), rb(m.v.size(), -1);
    for (size_t i = 0; i < m.f.size(); ++i) { if (take[i]) copyFace(picked, ra, m.f[i]); else copyFace(rest, rb, m.f[i]); }
    return true;
}

// ---------- 0.12.0: dissolve vertices, loose parts ----------
// Dissolve Vertices: removes each selected vertex and merges the faces around it into one polygon. Vertices on an open
// border that end up with two neighbours are removed from their faces (faces keep >= 3 corners). Returns the number of
// vertices removed (0 = mesh untouched). `made` = merged faces in the new face list.
inline int dissolveVertices(Mesh& m, const std::set<int>& verts, std::vector<int>* made = nullptr) {
    std::vector<char> mask(m.v.size(), 0); bool any = false;
    for (int v : verts) if (v >= 0 && v < (int)m.v.size()) { mask[v] = 1; any = true; }
    if (!any) return 0;
    std::set<Edge> es;
    for (const auto& fc : m.f) for (size_t i = 0; i < fc.size(); ++i) {
        const int a = fc[i], b = fc[(i + 1) % fc.size()];
        if (mask[a] || mask[b]) es.insert(mkEdge(a, b));
    }
    Mesh work = m; std::vector<int> mf;
    detail::dissolveEdgesCore(work, es, &mf);
    detail::dissolveStraightVerts(work, mask, -2.f);     // any bend: the selected vertex goes away
    compactUnusedVertices(work);
    const int removed = (int)m.v.size() - (int)work.v.size();
    if (removed <= 0 || !validMesh(work)) return 0;
    m = std::move(work); if (made) *made = mf; return removed;
}

// Splits a mesh into its connected parts (vertices connected through faces). Parts keep face order; unused vertices are dropped.
inline std::vector<Mesh> splitLooseParts(const Mesh& m) {
    const int nv = (int)m.v.size();
    std::vector<int> par(nv); for (int i = 0; i < nv; ++i) par[i] = i;
    auto root = [&](int x) { while (par[x] != x) { par[x] = par[par[x]]; x = par[x]; } return x; };
    for (const auto& fc : m.f) for (size_t i = 1; i < fc.size(); ++i) { const int a = root(fc[0]), b = root(fc[i]); if (a != b) par[std::max(a, b)] = std::min(a, b); }
    std::map<int, int> partOf; std::vector<Mesh> parts; std::vector<std::vector<int>> remap;
    for (const auto& fc : m.f) {
        const int r = root(fc[0]); auto it = partOf.find(r);
        if (it == partOf.end()) { it = partOf.insert({r, (int)parts.size()}).first; parts.emplace_back(); remap.emplace_back(nv, -1); }
        Mesh& out = parts[it->second]; std::vector<int>& rm = remap[it->second]; std::vector<int> g;
        for (int vi : fc) { if (rm[vi] < 0) { rm[vi] = (int)out.v.size(); out.v.push_back(m.v[vi]); } g.push_back(rm[vi]); }
        out.f.push_back(std::move(g));
    }
    return parts;
}

// ---------- 0.13.0: fill, bridge, bevel vertices ----------
namespace detail {
// Orders a set of edges into closed loops. Fails (false) if any vertex does not have exactly two selected edges.
inline bool edgeLoops(const std::set<Edge>& es, std::vector<std::vector<int>>& loops) {
    loops.clear(); std::map<int, std::vector<int>> adj;
    for (const Edge& e : es) { adj[e.first].push_back(e.second); adj[e.second].push_back(e.first); }
    for (const auto& kv : adj) if (kv.second.size() != 2) return false;
    std::set<int> seen;
    for (const auto& kv : adj) {
        if (seen.count(kv.first)) continue;
        std::vector<int> loop; int prev = -1, cur = kv.first;
        for (;;) {
            loop.push_back(cur); seen.insert(cur);
            const auto& nb = adj[cur]; int nxt = (nb[0] != prev) ? nb[0] : nb[1];
            if (prev == -1) nxt = nb[0];
            prev = cur; cur = nxt;
            if (cur == kv.first) break;
            if (seen.count(cur)) return false;
        }
        if (loop.size() < 3) return false;
        loops.push_back(loop);
    }
    return true;
}
// +1 if some face walks loop[0]->loop[1], -1 if some face walks the other way, 0 = no face (or conflicting faces on the loop).
inline int loopFaceDir(const Mesh& m, const std::map<Edge, std::vector<int>>& ef, const std::vector<int>& loop) {
    int dir = 0; const size_t n = loop.size();
    for (size_t i = 0; i < n; ++i) {
        const int a = loop[i], b = loop[(i + 1) % n];
        auto it = ef.find(mkEdge(a, b)); if (it == ef.end()) continue;
        if (it->second.size() != 1) return 2;            // already two faces (or more): not an open border
        const int d = edgeDirInFace(m.f[it->second[0]], a, b);
        if (dir != 0 && d != dir) return 2;              // inconsistent winding along the loop
        dir = d;
    }
    return dir;
}
}  // namespace detail

// Fill: makes ONE polygon from selected edges that form a single closed loop. The winding is chosen to match the faces
// already next to the loop (so a hole closes with outward normals). Returns the new face index or -1 (mesh untouched).
inline int fillLoop(Mesh& m, const std::set<Edge>& edges) {
    std::vector<std::vector<int>> loops;
    if (!detail::edgeLoops(edges, loops) || loops.size() != 1) return -1;
    std::vector<int> loop = loops[0];
    auto ef = detail::edgeFaces(m);
    const int d = detail::loopFaceDir(m, ef, loop);
    if (d == 2) return -1;
    if (d == 1) std::reverse(loop.begin(), loop.end());          // existing faces walk it forward: ours must walk backward
    std::vector<int> key = loop; std::sort(key.begin(), key.end());
    for (const auto& fc : m.f) { if (fc.size() != loop.size()) continue; std::vector<int> k = fc; std::sort(k.begin(), k.end()); if (k == key) return -1; }
    m.f.push_back(loop); return (int)m.f.size() - 1;
}

// Bridge Edge Loops: joins exactly two closed loops of the same length with a ring of quads. The second loop is aligned
// (start and direction) to minimise the distance between paired vertices. Returns the number of quads (0 = untouched).
inline int bridgeLoops(Mesh& m, const std::set<Edge>& edges, std::vector<int>* made = nullptr, int twist = 0) {
    std::vector<std::vector<int>> loops;
    if (!detail::edgeLoops(edges, loops) || loops.size() != 2 || loops[0].size() != loops[1].size()) return 0;
    const std::vector<int>& A = loops[0]; const std::vector<int> B0 = loops[1]; const size_t n = A.size();
    for (int a : A) for (int b : B0) if (a == b) return 0;
    auto ef = detail::edgeFaces(m);
    std::vector<int> B; float best = 1e30f;
    for (int rev = 0; rev < 2; ++rev) for (size_t s = 0; s < n; ++s) {
        std::vector<int> c(n); for (size_t i = 0; i < n; ++i) c[i] = B0[rev ? (s + n - i) % n : (s + i) % n];
        float sum = 0; for (size_t i = 0; i < n; ++i) { const Vec3 d = m.v[A[i]] - m.v[c[i]]; sum += length(d); }
        if (sum < best - 1e-6f) { best = sum; B = c; }
    }
    if (twist != 0) { const int k = (int)(((long long)twist % (long long)n + (long long)n) % (long long)n); std::rotate(B.begin(), B.begin() + k, B.end()); }   // manual alignment on top of the automatic one
    const int da = detail::loopFaceDir(m, ef, A), db = detail::loopFaceDir(m, ef, B);
    if (da == 2 || db == 2) return 0;
    // quad walks a_i -> a_{i+1} unless an existing face already does (then it must go backward). B is aligned with A, so
    // an existing face on B walking forward means the quad must walk B backward, i.e. A forward.
    int fwd = 1;                         // 1: quad = a_i,a_{i+1},b_{i+1},b_i
    if (da == 1) fwd = 0; else if (da == -1) fwd = 1;
    if (db != 0) { const int fb = (db == 1) ? 1 : 0; if (da != 0 && fb != fwd) return 0; if (da == 0) fwd = fb; }
    Mesh work = m; std::vector<int> mf;
    for (size_t i = 0; i < n; ++i) {
        const size_t j = (i + 1) % n;
        std::vector<int> q = fwd ? std::vector<int>{A[i], A[j], B[j], B[i]} : std::vector<int>{A[j], A[i], B[i], B[j]};
        mf.push_back((int)work.f.size()); work.f.push_back(q);
    }
    if (!validMesh(work)) return 0;
    m = std::move(work); if (made) *made = mf; return (int)n;
}

// (0.18.0) `twist` shifts the second loop by that many vertices after the automatic alignment (any integer, wraps around).

// Bevel Vertices (chamfer): every selected vertex whose faces form a closed fan is replaced by one point per incident edge,
// a distance min(width, 0.49 * edge length) down that edge, plus a new cap polygon. Vertices on an open border or on
// non-manifold seams are skipped. Returns the number of vertices beveled (0 = untouched). `caps` = new cap face indices.
inline int bevelVertices(Mesh& m, const std::set<int>& verts, float width, std::vector<int>* caps = nullptr) {
    if (!std::isfinite(width) || width <= 0.f) return 0;
    const int nv = (int)m.v.size();
    std::vector<std::vector<int>> vf(nv);
    for (size_t fi = 0; fi < m.f.size(); ++fi) { std::set<int> seen; for (int v : m.f[fi]) if (!seen.insert(v).second) return 0; for (int v : m.f[fi]) vf[v].push_back((int)fi); }
    auto ef = detail::edgeFaces(m);
    for (const auto& kv : ef) if (kv.second.size() > 2) return 0;
    struct Fan { int v; std::vector<int> faces; };           // faces in chain order
    std::vector<Fan> fans;
    for (int v : verts) {
        if (v < 0 || v >= nv || vf[v].size() < 3) continue;
        std::map<int, int> byNext; bool ok = true;           // next-vertex -> face
        std::map<int, std::pair<int, int>> pn;               // face -> (prev, next)
        for (int fi : vf[v]) {
            const auto& fc = m.f[fi]; const size_t k = fc.size(); size_t pos = 0;
            while (fc[pos] != v) ++pos;
            const int p = fc[(pos + k - 1) % k], n = fc[(pos + 1) % k];
            if (byNext.count(n)) { ok = false; break; }
            byNext[n] = fi; pn[fi] = {p, n};
        }
        if (!ok) continue;
        std::vector<int> chain; int cur = vf[v][0];
        for (size_t g = 0; g <= vf[v].size(); ++g) {
            chain.push_back(cur); auto it = byNext.find(pn[cur].first);   // face whose "next" is my "prev"
            if (it == byNext.end()) { ok = false; break; }
            cur = it->second; if (cur == chain[0]) break;
        }
        if (!ok || cur != chain[0] || chain.size() != vf[v].size()) continue;
        for (int fi : chain) { auto e1 = ef.find(mkEdge(v, pn[fi].first)); auto e2 = ef.find(mkEdge(v, pn[fi].second)); if (e1 == ef.end() || e2 == ef.end() || e1->second.size() != 2 || e2->second.size() != 2) ok = false; }
        if (!ok) continue;
        fans.push_back({v, chain});
    }
    if (fans.empty()) return 0;
    Mesh out = m; std::map<std::pair<int, int>, int> pt; std::set<int> done;
    for (const Fan& fan : fans) {
        done.insert(fan.v);
        for (int fi : fan.faces) {
            const auto& fc = m.f[fi]; const size_t k = fc.size(); size_t pos = 0; while (fc[pos] != fan.v) ++pos;
            for (int u : {fc[(pos + k - 1) % k], fc[(pos + 1) % k]}) {
                if (pt.count({fan.v, u})) continue;
                const Vec3 d = m.v[u] - m.v[fan.v]; const float len = length(d);
                if (len < 1e-9f) return 0;
                pt[{fan.v, u}] = (int)out.v.size(); out.v.push_back(m.v[fan.v] + d * (std::min(width, 0.49f * len) / len));
            }
        }
    }
    for (auto& fc : out.f) fc.clear();
    for (size_t fi = 0; fi < m.f.size(); ++fi) {
        const auto& fc = m.f[fi]; const size_t k = fc.size();
        for (size_t i = 0; i < k; ++i) {
            const int c = fc[i];
            if (!done.count(c)) { out.f[fi].push_back(c); continue; }
            out.f[fi].push_back(pt[{c, fc[(i + k - 1) % k]}]); out.f[fi].push_back(pt[{c, fc[(i + 1) % k]}]);
        }
    }
    for (const Fan& fan : fans) {
        std::vector<int> cap;
        for (int fi : fan.faces) {
            const auto& fc = m.f[fi]; const size_t k = fc.size(); size_t pos = 0; while (fc[pos] != fan.v) ++pos;
            cap.push_back(pt[{fan.v, fc[(pos + 1) % k]}]);
        }
        if (caps) caps->push_back((int)out.f.size());
        out.f.push_back(cap);
    }
    compactUnusedVertices(out);
    if (!validMesh(out)) return 0;
    const int n = (int)fans.size(); m = std::move(out); return n;
}

// ---- 0.16.0: Bevel Edges (one segment, flat chamfer) ----
// Every selected edge becomes a strip of one quad between two parallel edges. Closed manifold meshes only: every vertex touched by a
// selected edge needs a full fan of faces (each of its edges shared by exactly 2 faces); otherwise the whole operation is refused.
// A touched vertex is removed. Around it, each face F that met it gets a corner replacement built from c(F,E) for its two edges at the
// vertex: an unselected edge E gives the point P_E on E at distance d_E; a selected edge E gives, inside F, the point P_E' of the OTHER
// edge E' of F when E' is unselected, or the parallelogram corner Q_F = v + d*e1 + d*e2 when both are selected. d = min(width, 0.49*len).
// The width is measured ALONG the edges, which equals the perpendicular chamfer width for 90 degree corners (approximate otherwise).
// Where the ring of new points around a removed vertex has 3+ distinct points a cap polygon closes it (e.g. a cube corner with 3 edges).
// `strips` receives the new strip faces.
inline int bevelEdges(Mesh& m, const std::set<Edge>& sel, float width, std::vector<int>* strips = nullptr) {
    if (sel.empty() || !std::isfinite(width) || width <= 0.f) return 0;
    const int nv = (int)m.v.size();
    std::vector<std::vector<int>> vf(nv);
    for (size_t fi = 0; fi < m.f.size(); ++fi) { std::set<int> seen; for (int v : m.f[fi]) if (!seen.insert(v).second) return 0; for (int v : m.f[fi]) vf[v].push_back((int)fi); }
    const auto ef = detail::edgeFaces(m);
    for (const auto& kv : ef) if (kv.second.size() > 2) return 0;
    std::set<int> touched;
    for (const Edge& e : sel) { auto it = ef.find(e); if (it == ef.end() || it->second.size() != 2) return 0; touched.insert(e.first); touched.insert(e.second); }
    auto cornerOf = [&](int fi, int v, int& p, int& n) { const auto& fc = m.f[fi]; const size_t k = fc.size(); size_t pos = 0; while (fc[pos] != v) ++pos; p = fc[(pos + k - 1) % k]; n = fc[(pos + 1) % k]; };
    auto dist = [&](int v, int u) { const float len = length(m.v[u] - m.v[v]); return std::min(width, 0.49f * len); };
    auto dirTo = [&](int v, int u) { return normalized(m.v[u] - m.v[v]); };
    Mesh out = m;
    std::map<std::pair<int, int>, int> P;                    // (vertex, neighbour) -> point on that edge
    std::map<std::pair<int, int>, int> Q;                    // (vertex, face) -> corner point inside the face
    std::map<std::pair<int, int>, std::vector<int>> seq;     // (vertex, face) -> replacement of the corner, in face order
    std::vector<std::vector<int>> caps;
    auto pointP = [&](int v, int u) -> int {
        auto it = P.find({v, u}); if (it != P.end()) return it->second;
        const int id = (int)out.v.size(); out.v.push_back(m.v[v] + dirTo(v, u) * dist(v, u)); P[{v, u}] = id; return id; };
    for (int v : touched) {
        if (vf[v].size() < 3) return 0;
        std::map<int, int> byNext; std::map<int, std::pair<int, int>> pn;
        for (int fi : vf[v]) { int p, n; cornerOf(fi, v, p, n); if (byNext.count(n)) return 0; byNext[n] = fi; pn[fi] = {p, n}; }
        std::vector<int> chain; int cur = vf[v][0];
        for (size_t g = 0; g <= vf[v].size(); ++g) {
            chain.push_back(cur); auto it = byNext.find(pn[cur].first); if (it == byNext.end()) return 0;
            cur = it->second; if (cur == chain[0]) break;
        }
        if (cur != chain[0] || chain.size() != vf[v].size()) return 0;
        for (int fi : chain) for (int u : {pn[fi].first, pn[fi].second}) { auto it = ef.find(mkEdge(v, u)); if (it == ef.end() || it->second.size() != 2) return 0; }
        auto isSel = [&](int u) { return sel.count(mkEdge(v, u)) > 0; };
        auto c = [&](int fi, int u, int other) -> int {      // point for edge (v,u) as seen from face fi whose other edge here is (v,other)
            if (!isSel(u)) return pointP(v, u);
            if (!isSel(other)) return pointP(v, other);
            auto it = Q.find({v, fi}); if (it != Q.end()) return it->second;
            const int id = (int)out.v.size(); out.v.push_back(m.v[v] + dirTo(v, u) * dist(v, u) + dirTo(v, other) * dist(v, other)); Q[{v, fi}] = id; return id; };
        std::vector<int> ring;
        for (int fi : chain) {
            const int p = pn[fi].first, n = pn[fi].second;
            std::vector<int> s{c(fi, p, n), c(fi, n, p)}; if (s[0] == s[1]) s.pop_back();
            seq[{v, fi}] = s;
            std::vector<int> r(s.rbegin(), s.rend());        // the cap walks the fan the other way round
            for (int id : r) if (ring.empty() || ring.back() != id) ring.push_back(id);
        }
        while (ring.size() > 1 && ring.front() == ring.back()) ring.pop_back();
        if (ring.size() >= 3) caps.push_back(ring);
    }
    for (size_t fi = 0; fi < m.f.size(); ++fi) {
        const auto& fc = m.f[fi]; std::vector<int> nf;
        for (int v : fc) { if (!touched.count(v)) nf.push_back(v); else { const auto& s = seq[{v, (int)fi}]; nf.insert(nf.end(), s.begin(), s.end()); } }
        out.f[fi] = nf;
    }
    std::vector<int> made;
    for (const Edge& e : sel) {
        const auto& fs = ef.at(e); int f1 = -1, f2 = -1;
        for (int fi : fs) { const auto& fc = m.f[fi]; const size_t k = fc.size(); for (size_t i = 0; i < k; ++i) { if (fc[i] == e.first && fc[(i + 1) % k] == e.second) f1 = fi; if (fc[i] == e.second && fc[(i + 1) % k] == e.first) f2 = fi; } }
        if (f1 < 0 || f2 < 0) return 0;                       // inconsistent winding
        const int a = e.first, b = e.second;
        // f1 runs a->b, f2 runs b->a. f1's corner at a ends with c(f1,E); at b it starts with c(f1,E). Same for f2 with a/b swapped.
        const int f1a = seq.at({a, f1}).back(), f1b = seq.at({b, f1}).front(), f2b = seq.at({b, f2}).back(), f2a = seq.at({a, f2}).front();
        std::vector<int> st{f1b, f1a, f2a, f2b}, q;
        for (int id : st) if (q.empty() || q.back() != id) q.push_back(id);
        while (q.size() > 1 && q.front() == q.back()) q.pop_back();
        if (q.size() < 3) continue;
        made.push_back((int)out.f.size()); out.f.push_back(q);
    }
    for (const auto& r : caps) out.f.push_back(r);
    compactUnusedVertices(out);
    if (!validMesh(out)) return 0;
    if (strips) *strips = made;
    const int n = (int)sel.size(); m = std::move(out); return n;
}

// ---- 0.17.0: Edge Slide ----
// Slides the vertices of the selected edge chains sideways along the edges that leave the chain, without changing the topology.
// `t` in (-1, 1): t > 0 moves every vertex a fraction t of the way along its LEFT edge, t < 0 along its RIGHT edge. Left/right are
// measured walking the chain, seen from outside (faces are CCW so the face containing the directed edge p->v lies on the left),
// which keeps the whole chain on one side. Selected edges must form chains/cycles (no vertex with 3+ selected edges). Refuses when the
// needed side has no face (open border), when the side edge would be the chain itself, or when the winding is inconsistent.
// Returns the number of vertices moved.
inline int edgeSlide(Mesh& m, const std::set<Edge>& sel, float t, std::set<int>* moved = nullptr) {
    if (sel.empty() || !std::isfinite(t) || t <= -1.f || t >= 1.f || t == 0.f) return 0;
    const int nv = (int)m.v.size();
    std::map<int, std::vector<int>> adj;
    for (const Edge& e : sel) { if (e.first < 0 || e.second >= nv || e.first == e.second) return 0; adj[e.first].push_back(e.second); adj[e.second].push_back(e.first); }
    for (const auto& kv : adj) if (kv.second.size() > 2) return 0;
    std::map<std::pair<int, int>, int> faceOf;                    // directed edge -> face
    for (size_t fi = 0; fi < m.f.size(); ++fi) { const auto& fc = m.f[fi]; const size_t k = fc.size(); for (size_t i = 0; i < k; ++i) { if (faceOf.count({fc[i], fc[(i + 1) % k]})) return 0; faceOf[{fc[i], fc[(i + 1) % k]}] = (int)fi; } }
    for (const Edge& e : sel) if (!faceOf.count({e.first, e.second}) && !faceOf.count({e.second, e.first})) return 0;
    auto nextIn = [&](int fi, int v) { const auto& fc = m.f[fi]; const size_t k = fc.size(); for (size_t i = 0; i < k; ++i) if (fc[i] == v) return fc[(i + 1) % k]; return -1; };
    auto prevIn = [&](int fi, int v) { const auto& fc = m.f[fi]; const size_t k = fc.size(); for (size_t i = 0; i < k; ++i) if (fc[i] == v) return fc[(i + k - 1) % k]; return -1; };
    // orient every chain: start at a degree-1 vertex when there is one, otherwise anywhere (cycle)
    std::map<int, std::pair<int, int>> pn;                        // vertex -> (prev, next) along its chain, -1 when absent
    std::set<int> seen;
    auto walk = [&](int start) {
        int prev = -1, cur = start; pn[start] = {-1, -1};
        for (;;) {
            seen.insert(cur); int nxt = -1;
            for (int u : adj[cur]) if (u != prev) { nxt = u; break; }
            if (nxt == -1) { pn[cur].second = -1; pn[cur].first = prev; break; }
            if (nxt == start && cur != start) { pn[cur] = {prev, start}; pn[start].first = cur; break; }   // closed cycle
            pn[cur] = {prev, nxt}; prev = cur; cur = nxt;
        }
    };
    for (const auto& kv : adj) if (kv.second.size() == 1 && !seen.count(kv.first)) walk(kv.first);
    for (const auto& kv : adj) if (!seen.count(kv.first)) walk(kv.first);
    std::vector<std::pair<int, Vec3>> moves;
    for (const auto& kv : pn) {
        const int v = kv.first, p = kv.second.first, n = kv.second.second; int target = -1;
        if (t > 0.f) {                                            // left
            if (p != -1) { auto it = faceOf.find({p, v}); if (it == faceOf.end()) return 0; target = nextIn(it->second, v); }
            else { auto it = faceOf.find({v, n}); if (it == faceOf.end()) return 0; target = prevIn(it->second, v); }
        } else {                                                  // right
            if (p != -1) { auto it = faceOf.find({v, p}); if (it == faceOf.end()) return 0; target = prevIn(it->second, v); }
            else { auto it = faceOf.find({n, v}); if (it == faceOf.end()) return 0; target = nextIn(it->second, v); }
        }
        if (target < 0 || target == p || target == n || target == v) return 0;
        moves.push_back({v, m.v[v] + (m.v[target] - m.v[v]) * std::fabs(t)});
    }
    if (moves.empty()) return 0;
    Mesh out = m; for (const auto& mv : moves) out.v[mv.first] = mv.second;
    if (!validMesh(out)) return 0;
    m = std::move(out); if (moved) for (const auto& mv : moves) moved->insert(mv.first);
    return (int)moves.size();
}

// ---- 0.18.0: sharp edges ----
// Edges shared by exactly two faces whose normals differ by MORE than `angleDeg` (open-border and non-manifold edges are never sharp).
inline std::set<Edge> sharpEdges(const Mesh& m, float angleDeg) {
    std::set<Edge> out;
    if (!std::isfinite(angleDeg) || angleDeg < 0.f || angleDeg >= 180.f) return out;
    const float lim = std::cos(angleDeg * 3.14159265358979f / 180.f) - 1e-6f;
    for (const auto& kv : detail::edgeFaces(m)) {
        if (kv.second.size() != 2) continue;
        const Vec3 a = normalized(faceNormal(m, m.f[kv.second[0]])), b = normalized(faceNormal(m, m.f[kv.second[1]]));
        if (length(a) < 0.5f || length(b) < 0.5f) continue;
        if (dot(a, b) < lim) out.insert(kv.first);
    }
    return out;
}

// ---- 0.20.0: proportional editing ----
// Weight 1 on the selected vertices, falling off to 0 at `radius` (local units) from the selection. Distance is either straight-line to
// the nearest selected vertex or, with `connected`, the shortest path along mesh edges (multi-source Dijkstra), so separate islands and
// far-around-the-corner parts do not follow. Falloff: 0 smooth (3t^2 - 2t^3), 1 linear, 2 sharp (t^2), 3 constant (1 inside the radius),
// with t = 1 - d/radius. radius <= 0 or not finite: only the selection moves (weight 1), everything else 0.
inline float falloffWeight(int type, float d, float radius) {
    if (!(radius > 0.f) || !std::isfinite(radius) || d >= radius) return 0.f;
    const float t = 1.f - std::max(d, 0.f) / radius;
    switch (type) { case 1: return t; case 2: return t * t; case 3: return 1.f; default: return t * t * (3.f - 2.f * t); }
}
inline std::vector<float> proportionalWeights(const Mesh& m, const std::vector<char>& mask, float radius, int falloff, bool connected) {
    const size_t n = m.v.size(); std::vector<float> w(n, 0.f), dist(n, 1e30f);
    std::vector<int> sel; for (size_t i = 0; i < n && i < mask.size(); ++i) if (mask[i]) { sel.push_back((int)i); w[i] = 1.f; dist[i] = 0.f; }
    if (sel.empty() || !(radius > 0.f) || !std::isfinite(radius)) return w;
    if (!connected) {
        for (size_t i = 0; i < n; ++i) { if (i < mask.size() && mask[i]) continue; float best = 1e30f; for (int s : sel) best = std::min(best, length(m.v[i] - m.v[s])); dist[i] = best; }
    } else {
        std::vector<std::vector<std::pair<int, float>>> adj(n);
        for (const auto& e : uniqueEdges(m)) { const float l = length(m.v[e.first] - m.v[e.second]); adj[e.first].push_back({e.second, l}); adj[e.second].push_back({e.first, l}); }
        std::set<std::pair<float, int>> q; for (int s : sel) q.insert({0.f, s});
        while (!q.empty()) {
            auto top = *q.begin(); q.erase(q.begin()); const int u = top.second; if (top.first > dist[u]) continue;
            if (top.first >= radius) break;
            for (const auto& nb : adj[u]) { const float nd = dist[u] + nb.second; if (nd < dist[nb.first]) { dist[nb.first] = nd; q.insert({nd, nb.first}); } }
        }
    }
    for (size_t i = 0; i < n; ++i) if (!(i < mask.size() && mask[i])) w[i] = falloffWeight(falloff, dist[i], radius);
    return w;
}
// Weighted versions of move/rotate/scale: vertex i gets weight[i] of the effect (pivot = centroid of the SELECTED mask, as before).
inline bool moveVerticesW(Mesh& m, const std::vector<float>& w, Vec3 d) {
    bool any = false;
    for (size_t i = 0; i < w.size() && i < m.v.size(); ++i) if (w[i] > 0.f) { m.v[i] = m.v[i] + d * w[i]; any = true; }
    return any;
}
inline bool rotateVerticesW(Mesh& m, const std::vector<char>& mask, const std::vector<float>& w, int axis, float deg) {
    Vec3 c; if (!maskCentroid(m, mask, &c)) return false;
    for (size_t i = 0; i < w.size() && i < m.v.size(); ++i) if (w[i] > 0.f) {
        const float a = deg * w[i] * 0.01745329252f, cs = std::cos(a), sn = std::sin(a); Vec3 p = m.v[i] - c, q = p;
        if (axis == 0) { q.y = p.y * cs - p.z * sn; q.z = p.y * sn + p.z * cs; }
        else if (axis == 1) { q.x = p.x * cs + p.z * sn; q.z = -p.x * sn + p.z * cs; }
        else { q.x = p.x * cs - p.y * sn; q.y = p.x * sn + p.y * cs; }
        m.v[i] = c + q;
    }
    return true;
}
inline bool scaleVerticesW(Mesh& m, const std::vector<char>& mask, const std::vector<float>& w, Vec3 k) {
    Vec3 c; if (!maskCentroid(m, mask, &c)) return false;
    for (size_t i = 0; i < w.size() && i < m.v.size(); ++i) if (w[i] > 0.f) {
        const Vec3 p = m.v[i] - c; m.v[i] = c + Vec3{p.x * (1.f + (k.x - 1.f) * w[i]), p.y * (1.f + (k.y - 1.f) * w[i]), p.z * (1.f + (k.z - 1.f) * w[i])};
    }
    return true;
}

// ---- 0.22.0 / 0.23.0: topology queries ----
// Edges with exactly one face (open borders) / edges that are not shared by exactly two faces (borders and 3+ face seams).
inline std::set<Edge> boundaryEdges(const Mesh& m) { std::set<Edge> o; for (const auto& kv : detail::edgeFaces(m)) if (kv.second.size() == 1) o.insert(kv.first); return o; }
inline std::set<Edge> nonManifoldEdges(const Mesh& m) { std::set<Edge> o; for (const auto& kv : detail::edgeFaces(m)) if (kv.second.size() != 2) o.insert(kv.first); return o; }
// Deterministic random subset (same result on every platform): mt19937 raw output + Fisher-Yates, round(ratio * n) indices out of [0, n).
inline std::vector<int> randomSubset(int n, float ratio, uint32_t seed) {
    std::vector<int> idx; if (n <= 0 || !std::isfinite(ratio) || ratio < 0.f || ratio > 1.f) return idx;
    const int count = (int)std::lround((double)ratio * n); std::vector<int> all(n); for (int i = 0; i < n; ++i) all[i] = i;
    std::mt19937 g(seed); for (int i = n - 1; i > 0; --i) std::swap(all[i], all[(int)(g() % (uint32_t)(i + 1))]);
    idx.assign(all.begin(), all.begin() + count); std::sort(idx.begin(), idx.end()); return idx;
}

}  // namespace atlas
