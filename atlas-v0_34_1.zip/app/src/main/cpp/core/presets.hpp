// Atlas core: ready-made character base meshes (0.24.0). Pure geometry, no GL/JNI.
// Z-up, feet on z = 0, character faces -Y (front view looks along +Y), A-pose, X-symmetric.
// Every body is a set of CLOSED, outward-facing parts (torso, head, legs, feet, arms, hands, bust) that
// overlap but are not welded: use Object > Separate Loose Parts to split them, or keep them as one object.
#pragma once
#include "mesh.hpp"

namespace atlas {

struct BodyRing { float z, rx, ry, cy; };   // cross-section: height, half-width (X), half-depth (Y), forward/back shift of the centre

namespace detail {
inline void appendMesh(Mesh& dst, const Mesh& src) {
    const int base = (int)dst.v.size();
    for (const auto& p : src.v) dst.v.push_back(p);
    for (const auto& fc : src.f) { std::vector<int> g; for (int i : fc) g.push_back(i + base); dst.f.push_back(std::move(g)); }
}
// Closed tube through elliptical rings given bottom -> top. Bottom cap faces down, top cap faces up.
inline Mesh loft(const std::vector<BodyRing>& rings, int n) {
    Mesh m; const int R = (int)rings.size();
    for (const auto& r : rings)
        for (int i = 0; i < n; ++i) { const float a = 6.2831853f * i / n; m.v.push_back({r.rx * std::cos(a), r.cy + r.ry * std::sin(a), r.z}); }
    for (int k = 0; k + 1 < R; ++k)
        for (int i = 0; i < n; ++i) { const int j = (i + 1) % n; m.f.push_back({k * n + i, k * n + j, (k + 1) * n + j, (k + 1) * n + i}); }
    std::vector<int> top, bot;
    for (int i = 0; i < n; ++i) top.push_back((R - 1) * n + i);
    for (int i = n - 1; i >= 0; --i) bot.push_back(i);
    m.f.push_back(top); m.f.push_back(bot);
    return m;
}
inline Mesh ellipsoid(Vec3 c, Vec3 r, int seg = 12, int rings = 8) {
    Mesh m = makeUVSphere(seg, rings);
    for (auto& p : m.v) p = {c.x + p.x * r.x, c.y + p.y * r.y, c.z + p.z * r.z};
    return m;
}
inline Mesh box(Vec3 c, Vec3 h) {
    Mesh m = makeCube();
    for (auto& p : m.v) p = {c.x + p.x * h.x, c.y + p.y * h.y, c.z + p.z * h.z};
    return m;
}
// Proper rotation about Y (keeps winding) followed by a translation.
inline void rotYMove(Mesh& m, float deg, Vec3 t) {
    const float a = deg * 3.14159265f / 180.f, c = std::cos(a), s = std::sin(a);
    for (auto& p : m.v) p = {p.x * c + p.z * s + t.x, p.y + t.y, -p.x * s + p.z * c + t.z};
}
}  // namespace detail

struct BodyStyle {
    float height;                       // total height in metres
    float headRx, headRy, headRz;       // head ellipsoid half sizes (before scaling to height)
    float legX;                         // leg centre offset from the mid plane
    float shoulderX;                    // shoulder joint offset
    float armDeg;                       // A-pose angle away from vertical
    float armLen;                       // shoulder -> wrist
    float bust;                         // bust ellipsoid radius, 0 = none
    std::vector<BodyRing> torso, leg, arm;   // normalised to height 1; arm rings are (t along the arm, ...) with z in [0, 1]
};

inline BodyStyle bodyStyle(int kind) {
    BodyStyle s;
    if (kind == 1) {            // realistic female, ~7.5 heads
        s.height = 1.68f; s.headRx = .072f; s.headRy = .08f; s.headRz = .098f; s.legX = .085f; s.shoulderX = .17f; s.armDeg = 20.f; s.armLen = .43f; s.bust = .052f;
        s.torso = {{.50f, .115f, .085f, .00f}, {.53f, .165f, .095f, .01f}, {.56f, .175f, .10f, .012f}, {.62f, .125f, .08f, .005f}, {.66f, .105f, .072f, .0f},
                   {.72f, .125f, .082f, .0f}, {.76f, .135f, .092f, -.005f}, {.80f, .14f, .085f, .0f}, {.835f, .17f, .075f, .0f}, {.86f, .06f, .058f, .0f}, {.90f, .045f, .045f, .0f}};
        s.leg = {{.03f, .032f, .035f, .0f}, {.10f, .038f, .04f, .0f}, {.18f, .048f, .05f, .0f}, {.27f, .045f, .047f, .0f}, {.35f, .062f, .065f, .0f}, {.44f, .078f, .08f, .0f}, {.54f, .088f, .088f, .0f}};
    } else if (kind == 2) {     // male base, ~7.5 heads, broad shoulders
        s.height = 1.78f; s.headRx = .08f; s.headRy = .09f; s.headRz = .105f; s.legX = .09f; s.shoulderX = .205f; s.armDeg = 20.f; s.armLen = .43f; s.bust = 0.f;
        s.torso = {{.50f, .12f, .09f, .0f}, {.53f, .15f, .10f, .008f}, {.57f, .155f, .10f, .008f}, {.63f, .145f, .095f, .0f}, {.68f, .145f, .09f, .0f},
                   {.74f, .16f, .095f, -.004f}, {.79f, .18f, .10f, -.004f}, {.835f, .205f, .085f, .0f}, {.86f, .07f, .065f, .0f}, {.90f, .05f, .05f, .0f}};
        s.leg = {{.03f, .036f, .04f, .0f}, {.10f, .042f, .045f, .0f}, {.18f, .052f, .055f, .0f}, {.27f, .05f, .052f, .0f}, {.35f, .065f, .068f, .0f}, {.44f, .08f, .082f, .0f}, {.54f, .09f, .09f, .0f}};
    } else if (kind == 3) {     // chibi: ~3 heads, huge head, short limbs
        s.height = 1.0f; s.headRx = .16f; s.headRy = .165f; s.headRz = .17f; s.legX = .045f; s.shoulderX = .11f; s.armDeg = 25.f; s.armLen = .22f; s.bust = 0.f;
        s.torso = {{.30f, .08f, .06f, .0f}, {.33f, .11f, .08f, .0f}, {.40f, .12f, .09f, .0f}, {.47f, .11f, .08f, .0f}, {.52f, .09f, .07f, .0f}, {.55f, .04f, .04f, .0f}};
        s.leg = {{.02f, .03f, .035f, .0f}, {.10f, .035f, .04f, .0f}, {.20f, .04f, .045f, .0f}, {.33f, .05f, .055f, .0f}};
    } else {                    // anime female, ~6.5 heads: big head, long legs, tiny waist
        s.height = 1.62f; s.headRx = .088f; s.headRy = .092f; s.headRz = .108f; s.legX = .07f; s.shoulderX = .14f; s.armDeg = 22.f; s.armLen = .40f; s.bust = .046f;
        s.torso = {{.52f, .10f, .075f, .0f}, {.55f, .14f, .085f, .008f}, {.58f, .15f, .09f, .01f}, {.64f, .105f, .068f, .004f}, {.68f, .088f, .06f, .0f},
                   {.73f, .105f, .068f, .0f}, {.77f, .115f, .078f, -.004f}, {.805f, .12f, .072f, .0f}, {.83f, .14f, .066f, .0f}, {.85f, .045f, .042f, .0f}, {.885f, .036f, .036f, .0f}};
        s.leg = {{.025f, .026f, .03f, .0f}, {.10f, .032f, .034f, .0f}, {.20f, .042f, .044f, .0f}, {.28f, .038f, .04f, .0f}, {.37f, .056f, .058f, .0f}, {.46f, .07f, .07f, .0f}, {.56f, .08f, .08f, .0f}};
    }
    s.arm = {{.0f, .022f, .022f, 0.f}, {.2f, .027f, .027f, 0.f}, {.5f, .032f, .032f, 0.f}, {.55f, .031f, .031f, 0.f}, {.8f, .04f, .04f, 0.f}, {1.f, .046f, .046f, 0.f}};   // wrist -> shoulder
    return s;
}

// kind: 0 = anime female, 1 = realistic female, 2 = male. Returns the combined mesh (several closed parts).
inline Mesh makeBody(int kind) {
    const BodyStyle s = bodyStyle(kind); const float H = s.height; const float hs = std::min(1.f, H / 1.7f); Mesh out;
    auto scaleRings = [&](const std::vector<BodyRing>& in) { std::vector<BodyRing> r; for (auto b : in) r.push_back({b.z * H, b.rx, b.ry, b.cy}); return r; };
    detail::appendMesh(out, detail::loft(scaleRings(s.torso), 16));
    const float topTorso = s.torso.back().z * H;
    detail::appendMesh(out, detail::ellipsoid({0, 0.005f, topTorso + s.headRz * 0.85f}, {s.headRx, s.headRy, s.headRz}, 16, 10));
    for (int side = -1; side <= 1; side += 2) {
        Mesh leg = detail::loft(scaleRings(s.leg), 12); for (auto& p : leg.v) p.x += side * s.legX; detail::appendMesh(out, leg);
        detail::appendMesh(out, detail::box({side * s.legX, -0.05f * H / 1.7f, 0.022f * H / 1.7f}, {0.038f * H / 1.7f, 0.1f * H / 1.7f, 0.022f * H / 1.7f}));      // foot, toes towards -Y
        std::vector<BodyRing> ar; for (auto b : s.arm) ar.push_back({-s.armLen + b.z * s.armLen, b.rx, b.ry, 0.f});                                               // z from -armLen (wrist) to 0 (shoulder)
        Mesh arm = detail::loft(ar, 10), hand = detail::ellipsoid({0, 0, -s.armLen - 0.06f * hs}, {0.026f * hs, 0.014f * hs, 0.06f * hs}, 10, 6);
        const float shoulderZ = (s.torso.back().z - (s.torso.size() > 3 ? 0.04f : 0.f)) * H;
        detail::rotYMove(arm, -side * s.armDeg, {side * s.shoulderX, 0, shoulderZ});
        detail::rotYMove(hand, -side * s.armDeg, {side * s.shoulderX, 0, shoulderZ});
        detail::appendMesh(out, arm); detail::appendMesh(out, hand);
        if (s.bust > 0.f) detail::appendMesh(out, detail::ellipsoid({side * s.bust * 1.15f, -0.075f, 0.765f * H}, {s.bust, s.bust * 0.9f, s.bust}, 10, 7));
    }
    float top = 0.f; for (const auto& p : out.v) top = std::max(top, p.z);       // normalise so the character is exactly `height` tall
    if (top > 1e-6f) { const float k = H / top; for (auto& p : out.v) p = p * k; }
    return out;
}

// Anime-style head on a short neck: neck base at z = 0, face towards -Y. Parts: neck, head, 2 ears, 2 eyes, nose, back hair, fringe.
inline Mesh makeAnimeHead() {
    Mesh m;
    detail::appendMesh(m, detail::loft({{0.f, .045f, .045f, 0.f}, {.06f, .042f, .042f, 0.f}, {.12f, .04f, .04f, 0.f}}, 12));
    detail::appendMesh(m, detail::ellipsoid({0, 0, .21f}, {.09f, .095f, .11f}, 16, 10));
    for (int side = -1; side <= 1; side += 2) {
        detail::appendMesh(m, detail::ellipsoid({side * .092f, .005f, .205f}, {.012f, .02f, .03f}, 8, 6));       // ear
        detail::appendMesh(m, detail::ellipsoid({side * .036f, -.088f, .20f}, {.022f, .008f, .03f}, 10, 6));     // eye (large, anime)
    }
    detail::appendMesh(m, detail::ellipsoid({0, -.098f, .178f}, {.008f, .008f, .008f}, 8, 6));                  // nose
    detail::appendMesh(m, detail::ellipsoid({0, .03f, .215f}, {.1f, .095f, .125f}, 16, 10));                     // back hair volume
    detail::appendMesh(m, detail::ellipsoid({0, -.065f, .29f}, {.095f, .045f, .035f}, 12, 6));                  // fringe
    return m;
}
// Hand, fingers up (+Z), thumb on the +X side, palm facing -Y: palm, 4 fingers, thumb (6 closed parts).
inline Mesh makeHand() {
    Mesh m;
    detail::appendMesh(m, detail::box({0, 0, 0}, {.04f, .012f, .045f}));
    const float fx[4] = {-.027f, -.009f, .009f, .027f}, fl[4] = {.06f, .072f, .066f, .05f};
    for (int i = 0; i < 4; ++i) {
        Mesh f = detail::loft({{.04f, .009f, .009f, 0.f}, {.04f + fl[i] * .5f, .0085f, .0085f, 0.f}, {.04f + fl[i], .007f, .007f, 0.f}}, 8);
        for (auto& p : f.v) p.x += fx[i];
        detail::appendMesh(m, f);
    }
    Mesh th = detail::loft({{0.f, .011f, .011f, 0.f}, {.03f, .0105f, .0105f, 0.f}, {.06f, .009f, .009f, 0.f}}, 8);
    detail::rotYMove(th, 40.f, {.04f, 0.f, -.02f}); detail::appendMesh(m, th);
    return m;
}

// ---- 0.27.0: clothes and hair sized for the Anime Female (preset 0) so they can be added on top of her ----
struct HeadInfo { Vec3 c; Vec3 r; float shoulderZ; float waistZ; float hipZ; float scale; float height; };
inline HeadInfo animeFemaleInfo() {                  // same numbers makeBody(0) uses, after its height normalisation
    const BodyStyle s = bodyStyle(0); const float H = s.height;
    const float topTorso = s.torso.back().z * H, preTop = topTorso + s.headRz * 1.85f;
    const float k = H / preTop; HeadInfo h;
    h.c = {0, 0.005f * k, (topTorso + s.headRz * 0.85f) * k}; h.r = {s.headRx * k, s.headRy * k, s.headRz * k};
    h.shoulderZ = s.torso[s.torso.size() - 3].z * H * k; h.waistZ = s.torso[4].z * H * k; h.hipZ = s.torso[2].z * H * k; h.scale = k; h.height = H; return h;
}
// Long anime hair: skull cap, fringe and 9 tapering strands around the back half down to the waist (11 closed parts).
inline Mesh makeLongHair() {
    const HeadInfo h = animeFemaleInfo(); Mesh m;
    detail::appendMesh(m, detail::ellipsoid({h.c.x, h.c.y + h.r.y * 0.12f, h.c.z + h.r.z * 0.08f}, {h.r.x * 1.1f, h.r.y * 1.12f, h.r.z * 1.1f}, 16, 10));
    detail::appendMesh(m, detail::ellipsoid({0, h.c.y - h.r.y * 0.75f, h.c.z + h.r.z * 0.78f}, {h.r.x * 1.05f, h.r.y * 0.4f, h.r.z * 0.3f}, 12, 6));
    const float zTop = h.c.z + h.r.z * 0.1f, zEnd = h.waistZ + 0.08f;
    for (int i = 0; i < 9; ++i) {
        const float a = (10.f + 20.f * i) * 3.14159265f / 180.f;
        Mesh st = detail::loft({{zEnd, .008f, .008f, 0.f}, {zEnd + (zTop - zEnd) * .35f, .02f, .018f, 0.f}, {zEnd + (zTop - zEnd) * .7f, .03f, .024f, 0.f}, {zTop, .034f, .028f, 0.f}}, 8);
        for (auto& p : st.v) { p.x += h.r.x * 1.12f * std::cos(a); p.y += h.c.y + h.r.y * 1.12f * std::sin(a); }
        detail::appendMesh(m, st);
    }
    return m;
}
// Twin tails: cap, fringe, two hanging tails with a tie ball each (6 closed parts).
inline Mesh makeTwinTails() {
    const HeadInfo h = animeFemaleInfo(); Mesh m;
    detail::appendMesh(m, detail::ellipsoid({h.c.x, h.c.y + h.r.y * 0.12f, h.c.z + h.r.z * 0.08f}, {h.r.x * 1.1f, h.r.y * 1.12f, h.r.z * 1.1f}, 16, 10));
    detail::appendMesh(m, detail::ellipsoid({0, h.c.y - h.r.y * 0.75f, h.c.z + h.r.z * 0.78f}, {h.r.x * 1.05f, h.r.y * 0.4f, h.r.z * 0.3f}, 12, 6));
    const float zTop = h.c.z + h.r.z * 0.25f, zEnd = h.hipZ;
    for (int side = -1; side <= 1; side += 2) {
        Mesh tail = detail::loft({{zEnd, .006f, .006f, 0.f}, {zEnd + (zTop - zEnd) * .3f, .03f, .03f, 0.f}, {zEnd + (zTop - zEnd) * .75f, .04f, .04f, 0.f}, {zTop, .03f, .03f, 0.f}}, 10);
        for (auto& p : tail.v) { p.x += side * h.r.x * 1.45f; p.y += h.c.y; }
        detail::appendMesh(m, tail);
        detail::appendMesh(m, detail::ellipsoid({side * h.r.x * 1.45f, h.c.y, zTop}, {.03f, .03f, .02f}, 8, 6));
    }
    return m;
}
// Flared skirt from the waist to above the knee (1 closed part).
inline Mesh makeSkirt() {
    const HeadInfo h = animeFemaleInfo(); const BodyStyle s = bodyStyle(0);
    const float rxW = s.torso[4].rx * h.scale + .012f, ryW = s.torso[4].ry * h.scale + .012f;
    const float hem = h.height * 0.34f;
    return detail::loft({{hem, .27f, .25f, 0.f}, {hem + (h.waistZ - hem) * .45f, .2f, .18f, 0.f}, {h.hipZ, s.torso[2].rx * h.scale + .02f, s.torso[2].ry * h.scale + .02f, 0.f}, {h.waistZ, rxW, ryW, 0.f}}, 20);
}
// ---- 0.29.0: shirt, shorts and boots sized for the Anime Female (preset 0) ----
// Shirt: torso tube from the hips to the shoulders, a cover over each breast and 2 short sleeves (5 closed parts).
inline Mesh makeShirt() {
    const HeadInfo h = animeFemaleInfo(); const BodyStyle s = bodyStyle(0); const float H = s.height, k = h.scale, o = .012f;
    std::vector<BodyRing> r; for (int i = 2; i <= 8; ++i) r.push_back({s.torso[i].z * H * k, s.torso[i].rx * k + o, s.torso[i].ry * k + o, s.torso[i].cy * k});
    Mesh m = detail::loft(r, 16);
    const float shoulderZ = (s.torso.back().z - 0.04f) * H;
    for (int side = -1; side <= 1; side += 2) {
        if (s.bust > 0.f) detail::appendMesh(m, detail::ellipsoid({side * s.bust * 1.15f * k, -0.075f * k, 0.765f * H * k}, {(s.bust + o) * k, (s.bust * .9f + o) * k, (s.bust + o) * k}, 10, 7));
        const float a0 = -s.armLen * .5f, a1 = .01f;     // pre-scale, along the arm: sleeve covers the upper half
        Mesh sl = detail::loft({{a0, .043f, .043f, 0.f}, {-s.armLen * .22f, .049f, .049f, 0.f}, {a1, .056f, .056f, 0.f}}, 10);
        detail::rotYMove(sl, -side * s.armDeg, {side * s.shoulderX, 0, shoulderZ});
        for (auto& p : sl.v) { p = p * k; }
        detail::appendMesh(m, sl);
    }
    return m;
}
// Shorts: pelvis tube + one short leg each (3 closed parts), from the hips down to the middle of the thigh.
inline Mesh makeShorts() {
    const HeadInfo h = animeFemaleInfo(); const BodyStyle s = bodyStyle(0); const float H = s.height, k = h.scale, o = .014f;
    std::vector<BodyRing> r; for (int i = 0; i <= 3; ++i) r.push_back({s.torso[i].z * H * k, s.torso[i].rx * k + o, s.torso[i].ry * k + o, s.torso[i].cy * k});
    Mesh m = detail::loft(r, 16);
    for (int side = -1; side <= 1; side += 2) {
        std::vector<BodyRing> lr; for (int i = 4; i <= 6; ++i) lr.push_back({s.leg[i].z * H * k, s.leg[i].rx * k + o, s.leg[i].ry * k + o, 0.f});
        lr.push_back({lr.back().z + .02f, lr.back().rx, lr.back().ry, 0.f});
        Mesh leg = detail::loft(lr, 12); for (auto& p : leg.v) { p.x += side * s.legX * k; }
        detail::appendMesh(m, leg);
    }
    return m;
}
// Boots: shaft up to the calf + a bigger foot, per side (4 closed parts).
inline Mesh makeBoots() {
    const HeadInfo h = animeFemaleInfo(); const BodyStyle s = bodyStyle(0); const float H = s.height, k = h.scale, fs = H / 1.7f;
    Mesh m;
    for (int side = -1; side <= 1; side += 2) {
        Mesh sh = detail::loft({{.0f, .046f * k, .05f * k, 0.f}, {s.leg[0].z * H * k, .043f * k, .047f * k, 0.f}, {s.leg[1].z * H * k, .047f * k, .049f * k, 0.f}, {s.leg[2].z * H * k, .058f * k, .059f * k, 0.f}}, 12);
        for (auto& p : sh.v) { p.x += side * s.legX * k; }
        detail::appendMesh(m, sh);
        detail::appendMesh(m, detail::box({side * s.legX * k, -.05f * fs * k, .03f * fs * k}, {.046f * fs * k, .108f * fs * k, .03f * fs * k}));
    }
    return m;
}
// Presets: 0 anime female, 1 realistic female, 2 male, 3 chibi, 4 anime head, 5 hand, 6 long hair, 7 twin tails, 8 skirt, 9 shirt, 10 shorts, 11 boots (6-11 fit the anime female).
constexpr int kPresetCount = 12;
inline Mesh makePreset(int kind) {
    switch (kind) { case 4: return makeAnimeHead(); case 5: return makeHand(); case 6: return makeLongHair(); case 7: return makeTwinTails(); case 8: return makeSkirt();
                    case 9: return makeShirt(); case 10: return makeShorts(); case 11: return makeBoots(); default: return makeBody(kind); }
}
inline const char* bodyName(int kind) {
    switch (kind) { case 1: return "Female_Body"; case 2: return "Male_Body"; case 3: return "Chibi"; case 4: return "Anime_Head"; case 5: return "Hand"; case 6: return "Long_Hair"; case 7: return "Twin_Tails"; case 8: return "Skirt";
                    case 9: return "Shirt"; case 10: return "Shorts"; case 11: return "Boots"; default: return "Anime_Female"; }
}

}  // namespace atlas
