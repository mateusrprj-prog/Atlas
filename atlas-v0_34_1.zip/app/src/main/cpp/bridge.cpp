#include <jni.h>
#include <cmath>
#include <string>
#include <mutex>
#include <cstdio>
#include <exception>
#include "core/import_scene.hpp"
#include "core/project_io.hpp"
#include "renderer.hpp"

using namespace atlas;

static Scene gScene;
static Renderer gRenderer;
static bool gStarted = false;

// Import runs in two steps so the heavy parse never blocks the GL thread: importPrepare (any thread, no Scene access) parks the mesh here,
// importCommit (GL thread) moves it into the scene.
static std::mutex gPendMtx;
static Mesh gPendMesh;
static std::string gLogPath;
static void writeLog(const std::string& line) {
    if (gLogPath.empty()) return;
    if (FILE* f = fopen(gLogPath.c_str(), "a")) { fputs(line.c_str(), f); fputc('\n', f); fflush(f); fclose(f); }
}

namespace {

// ---- interactive transform (move / rotate / scale) with one undo entry per gesture ----
struct Prop { bool on = false, connected = false; float radius = 1.f; int falloff = 0; } gProp;   // 0.20.0 proportional editing (local units)
struct Drag {
    std::vector<float> weights;                     // empty = no proportional editing for this gesture
    bool active = false, editMesh = false, moved = false;
    int tool = 0, axis = 0; uint32_t id = 0;
    Xf before; Mesh meshBefore; SelState selBefore;
} gDrag;

Vec3 axisVec(int a) { return a == 1 ? Vec3{1, 0, 0} : a == 2 ? Vec3{0, 1, 0} : Vec3{0, 0, 1}; }

bool beginDrag(int tool, int axis) {
    gDrag.active = false;
    if (tool <= 0) return false;
    Object* o = gScene.find(gScene.selected);
    if (!o) return false;
    if (gScene.editMode) {
        std::vector<char> mask = selectedVertexMask(gScene.sel, o->mesh);
        if (std::find(mask.begin(), mask.end(), (char)1) == mask.end()) return false;
        gDrag.editMesh = true; gDrag.meshBefore = o->mesh; gDrag.selBefore = gScene.sel;
        gDrag.weights = gProp.on ? proportionalWeights(o->mesh, mask, gProp.radius, gProp.falloff, gProp.connected) : std::vector<float>();
    } else { gDrag.editMesh = false; gDrag.weights.clear(); }
    gDrag.before = getXf(*o); gDrag.id = o->id; gDrag.tool = tool; gDrag.axis = axis;
    gDrag.moved = false; gDrag.active = true; return true;
}

void restoreDrag(Object& o) {
    setXf(o, gDrag.before);
    if (gDrag.editMesh) { o.mesh = gDrag.meshBefore; o.meshRev = nextRev(); }
}

void updateDrag(float dx, float dy) {
    Object* o = gScene.find(gDrag.id);
    if (!gDrag.active || !o) return;
    restoreDrag(*o);
    if (dx == 0 && dy == 0) return;
    gDrag.moved = true;
    Camera& c = gRenderer.cam; Vec3 f, r, u; c.basis(f, r, u);
    Vec3 p{o->pos[0], o->pos[1], o->pos[2]};
    float depth = dot(p - c.eye(), f); if (depth < 0.1f) depth = 0.1f;
    float wpp = 2.f * depth * std::tan(c.fovY * 0.5f) / (float)gRenderer.height;  // world units per pixel
    if (gDrag.tool == 1) {
        Vec3 delta;
        if (gDrag.axis == 0) delta = r * (dx * wpp) - u * (dy * wpp);
        else {
            Vec3 a = axisVec(gDrag.axis); float sx = dot(a, r), sy = dot(a, u), s2 = sx * sx + sy * sy;
            delta = s2 < 1e-4f ? Vec3{} : a * (((dx * sx - dy * sy) * wpp) / s2);
        }
        if (gDrag.editMesh && !gDrag.weights.empty()) moveVerticesW(o->mesh, gDrag.weights, worldToLocalDir(*o, delta));
        else if (gDrag.editMesh) moveVertices(o->mesh, selectedVertexMask(gScene.sel, o->mesh), worldToLocalDir(*o, delta));
        else { o->pos[0] += delta.x; o->pos[1] += delta.y; o->pos[2] += delta.z; }
    } else if (gDrag.tool == 2) {
        int a = gDrag.axis ? gDrag.axis - 1 : 2;
        if (gDrag.editMesh && !gDrag.weights.empty()) rotateVerticesW(o->mesh, selectedVertexMask(gScene.sel, o->mesh), gDrag.weights, a, dx * 0.4f);
        else if (gDrag.editMesh) rotateVertices(o->mesh, selectedVertexMask(gScene.sel, o->mesh), a, dx * 0.4f);   // local axis
        else o->rot[a] += dx * 0.4f;
    } else if (gDrag.tool == 3) {
        float k = std::exp(dx * 0.005f);
        if (gDrag.editMesh) {
            Vec3 kk{gDrag.axis == 0 || gDrag.axis == 1 ? k : 1.f, gDrag.axis == 0 || gDrag.axis == 2 ? k : 1.f, gDrag.axis == 0 || gDrag.axis == 3 ? k : 1.f};
            if (!gDrag.weights.empty()) scaleVerticesW(o->mesh, selectedVertexMask(gScene.sel, o->mesh), gDrag.weights, kk);
            else scaleVertices(o->mesh, selectedVertexMask(gScene.sel, o->mesh), kk);
        } else for (int i = 0; i < 3; ++i) if (gDrag.axis == 0 || gDrag.axis - 1 == i) o->scale[i] *= k;
    }
    if (gDrag.editMesh) o->meshRev = nextRev();
}

void endDrag() {
    if (!gDrag.active) return;
    gDrag.active = false;
    Object* o = gScene.find(gDrag.id);
    if (!o || !gDrag.moved) return;
    if (gDrag.editMesh) gScene.record(std::make_unique<MeshEditCmd>(o->id, gDrag.meshBefore, o->mesh, gDrag.selBefore, gScene.sel));
    else { Xf after = getXf(*o); if (!sameXf(after, gDrag.before)) gScene.record(std::make_unique<TransformCmd>(o->id, gDrag.before, after)); }
}

void cancelDrag() {
    if (!gDrag.active) return;
    gDrag.active = false;
    if (Object* o = gScene.find(gDrag.id)) restoreDrag(*o);
}

void startupScene() {
    if (gStarted) return;
    gStarted = true;
    gScene.reset();
    Object o; o.id = gScene.nextId++; o.name = "Cube"; o.mesh = makeCube(); o.meshRev = nextRev();
    gScene.selected = o.id; gScene.objects.push_back(o);
}

}  // namespace

extern "C" {
#define FN(name) JNIEXPORT auto JNICALL Java_dev_atlas_NativeBridge_##name

FN(init)(JNIEnv*, jobject) -> void { gRenderer.init(); }
FN(resize)(JNIEnv*, jobject, jint w, jint h) -> void { gRenderer.resize(w, h); }
FN(draw)(JNIEnv*, jobject) -> void { refreshSkinned(gScene); gRenderer.draw(gScene); }
FN(ensureScene)(JNIEnv*, jobject) -> void { startupScene(); }
FN(newScene)(JNIEnv*, jobject) -> void {
    cancelDrag(); gScene.reset();
    Object o; o.id = gScene.nextId++; o.name = "Cube"; o.mesh = makeCube(); o.meshRev = nextRev();
    gScene.selected = o.id; gScene.objects.push_back(o);
}

// ---- camera ----
FN(orbit)(JNIEnv*, jobject, jfloat dx, jfloat dy) -> void {
    Camera& c = gRenderer.cam; c.yaw -= dx * 0.01f; c.pitch += dy * 0.01f;
    if (c.pitch > 1.55f) c.pitch = 1.55f;
    if (c.pitch < -1.55f) c.pitch = -1.55f;
}
FN(pan)(JNIEnv*, jobject, jfloat dx, jfloat dy) -> void {
    Camera& c = gRenderer.cam; Vec3 f, r, u; c.basis(f, r, u);
    float wpp = 2.f * c.dist * std::tan(c.fovY * 0.5f) / (float)gRenderer.height;
    c.target = c.target - r * (dx * wpp) + u * (dy * wpp);
}
FN(zoom)(JNIEnv*, jobject, jfloat k) -> void {
    Camera& c = gRenderer.cam; c.dist /= k;
    if (c.dist < 0.5f) c.dist = 0.5f;
    if (c.dist > 100.f) c.dist = 100.f;
}
FN(viewPreset)(JNIEnv*, jobject, jint p) -> void {
    Camera& c = gRenderer.cam; const float h = 1.5707963f;
    switch (p) {
        case 0: c.yaw = -h; c.pitch = 0; break;       // front
        case 1: c.yaw = h; c.pitch = 0; break;        // back
        case 2: c.yaw = 0; c.pitch = 0; break;        // right
        case 3: c.yaw = 2 * h; c.pitch = 0; break;    // left
        case 4: c.yaw = -h; c.pitch = 1.55f; break;   // top
        default: c.yaw = -h; c.pitch = -1.55f; break; // bottom
    }
}
FN(resetView)(JNIEnv*, jobject) -> void { float asp = gRenderer.cam.aspect; gRenderer.cam = Camera(); gRenderer.cam.aspect = asp; }
FN(frameSelected)(JNIEnv*, jobject) -> jboolean {
    const Object* o = gScene.find(gScene.selected);
    if (!o) return false;
    float rad = 0; for (const auto& v : displayMesh(*o).v) rad = std::max(rad, length(v));
    float sc = std::max(o->scale[0], std::max(o->scale[1], o->scale[2]));
    gRenderer.cam.target = Vec3{o->pos[0], o->pos[1], o->pos[2]};
    gRenderer.cam.dist = std::max(3.f, rad * sc * 3.f); return true;
}
FN(setShading)(JNIEnv*, jobject, jint m) -> void { gRenderer.shading = m; }

// ---- scene operations ----
FN(addPrimitive)(JNIEnv*, jobject, jint kind) -> jboolean { if (gScene.editMode) return false; cancelDrag(); addPrimitive(gScene, kind); return true; }
FN(addPreset)(JNIEnv*, jobject, jint kind) -> jboolean { if (gScene.editMode) return false; cancelDrag(); return addPreset(gScene, kind) != 0; }
FN(duplicateSelected)(JNIEnv*, jobject) -> jboolean { return duplicateSelected(gScene) != 0; }
FN(deleteSelected)(JNIEnv*, jobject) -> jboolean { return deleteSelectedObject(gScene); }
FN(selectObject)(JNIEnv*, jobject, jint id) -> jboolean {
    if (gScene.editMode || !gScene.find((uint32_t)id)) return false;
    gScene.selected = (uint32_t)id; return true;
}
FN(selectAll)(JNIEnv*, jobject) -> void { selectAllActive(gScene); }
FN(selectInvert)(JNIEnv*, jobject) -> void { invertActive(gScene); }
FN(selectNone)(JNIEnv*, jobject) -> void { if (gScene.editMode) gScene.sel.clearSets(); else gScene.selected = 0; }
FN(tap)(JNIEnv*, jobject, jfloat x, jfloat y) -> jint {
    Vec3 o, d; gRenderer.screenRay(x, y, o, d);
    if (gScene.editMode) {
        const float tol = 22.f * 2.f * std::tan(gRenderer.cam.fovY * 0.5f) / (float)gRenderer.height;   // ~22 px pick radius
        int hit = -1;
        if (gScene.sel.mode == 0) { hit = pickActiveVertex(gScene, o, d, tol); if (hit >= 0) gScene.toggleVertex(hit); }
        else if (gScene.sel.mode == 1) { Edge e; if (pickActiveEdge(gScene, o, d, tol, &e)) { gScene.toggleEdge(e); hit = 1; } }
        else { hit = pickActiveFace(gScene, o, d); if (hit >= 0) gScene.toggleFace(hit); }
        if (hit < 0) gScene.sel.clearSets();
        return hit;
    }
    gScene.selected = pickObject(gScene, o, d); return (jint)gScene.selected;
}
FN(setProportional)(JNIEnv*, jobject, jboolean on, jfloat radius, jint falloff, jboolean connected) -> void {
    cancelDrag(); gProp.on = on; gProp.radius = radius; gProp.falloff = falloff < 0 || falloff > 3 ? 0 : falloff; gProp.connected = connected;
}
FN(boxSelect)(JNIEnv*, jobject, jfloat x0, jfloat y0, jfloat x1, jfloat y1, jint op, jboolean xray) -> jboolean {
    cancelDrag();
    const ViewInfo vw = makeView(gRenderer.cam.eye(), gRenderer.cam.target, gRenderer.cam.fovY, gRenderer.width, gRenderer.height);
    return boxSelectActive(gScene, vw, x0, y0, x1, y1, op, xray);
}
FN(setMode)(JNIEnv*, jobject, jint m) -> jboolean { cancelDrag(); return setEditMode(gScene, m == 1); }
FN(mode)(JNIEnv*, jobject) -> jint { return gScene.editMode ? 1 : 0; }
FN(setSelectMode)(JNIEnv*, jobject, jint m) -> jboolean { cancelDrag(); return setSelectMode(gScene, m); }
FN(selectMode)(JNIEnv*, jobject) -> jint { return gScene.sel.mode; }
FN(extrude)(JNIEnv*, jobject, jfloat dist) -> jboolean { cancelDrag(); return extrudeSelected(gScene, dist); }
FN(deleteSelection)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return deleteSelection(gScene); }
FN(insetFaces)(JNIEnv*, jobject, jfloat amount) -> jboolean { cancelDrag(); return insetSelected(gScene, amount); }
FN(subdivide)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return subdivideSelected(gScene); }
FN(mergeCenter)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return mergeSelectedAtCenter(gScene); }
FN(addModifier)(JNIEnv*, jobject, jint type) -> jboolean { cancelDrag(); return addModifier(gScene, type); }
FN(removeModifier)(JNIEnv*, jobject, jint i) -> jboolean { cancelDrag(); return removeModifier(gScene, i); }
FN(toggleModifier)(JNIEnv*, jobject, jint i) -> jboolean { cancelDrag(); return toggleModifier(gScene, i); }
FN(moveModifier)(JNIEnv*, jobject, jint i, jint d) -> jboolean { cancelDrag(); return moveModifier(gScene, i, d); }
FN(applyModifier)(JNIEnv*, jobject, jint i) -> jboolean { cancelDrag(); return applyModifierAt(gScene, i); }
FN(setModifier)(JNIEnv* env, jobject, jint i, jint axis, jint count, jfloatArray off) -> jboolean {
    const Object* o = gScene.find(gScene.selected);
    if (!o || i < 0 || i >= (jint)o->mods.size() || env->GetArrayLength(off) != 3) return false;
    Modifier m = o->mods[i]; m.axis = axis; m.count = count;
    env->GetFloatArrayRegion(off, 0, 3, m.offset);
    return setModifier(gScene, i, m);
}
FN(setModifierParams)(JNIEnv*, jobject, jint i, jint levels, jfloat thickness, jfloat shift) -> jboolean {
    const Object* o = gScene.find(gScene.selected);
    if (!o || i < 0 || i >= (jint)o->mods.size()) return false;
    Modifier m = o->mods[i]; m.levels = levels; m.thickness = thickness; m.shift = shift;
    return setModifier(gScene, i, m);
}
FN(setModifierExtra)(JNIEnv*, jobject, jint i, jint axis, jfloat factor, jint iterations, jint mode, jfloat angle) -> jboolean {
    const Object* o = gScene.find(gScene.selected);
    if (!o || i < 0 || i >= (jint)o->mods.size()) return false;
    Modifier m = o->mods[i]; m.axis = axis; m.factor = factor; m.iterations = iterations; m.mode = mode; m.angle = angle;
    return setModifier(gScene, i, m);
}
FN(setModifierMerge)(JNIEnv*, jobject, jint i, jfloat merge) -> jboolean {
    const Object* o = gScene.find(gScene.selected);
    if (!o || i < 0 || i >= (jint)o->mods.size()) return false;
    Modifier m = o->mods[i]; m.merge = merge;
    return setModifier(gScene, i, m);
}
FN(renameSelected)(JNIEnv* env, jobject, jstring name) -> jboolean {
    cancelDrag();
    const char* p = env->GetStringUTFChars(name, nullptr);
    bool ok = renameSelected(gScene, p ? p : ""); if (p) env->ReleaseStringUTFChars(name, p); return ok;
}
FN(applyTransform)(JNIEnv*, jobject, jint mode) -> jboolean { cancelDrag(); return applyTransformSelected(gScene, mode); }
FN(originToGeometry)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return originToGeometry(gScene); }
FN(selectMore)(JNIEnv*, jobject) -> jboolean { return selectMoreLess(gScene, true); }
FN(selectLess)(JNIEnv*, jobject) -> jboolean { return selectMoreLess(gScene, false); }
FN(joinAll)(JNIEnv*, jobject) -> jint { cancelDrag(); return joinAllObjects(gScene); }
FN(selectLinked)(JNIEnv*, jobject) -> jboolean { return selectLinkedActive(gScene); }
FN(weldSelected)(JNIEnv*, jobject, jfloat dist) -> jboolean { cancelDrag(); return weldSelected(gScene, dist); }
FN(dissolveEdges)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return dissolveSelectedEdges(gScene); }
FN(limitedDissolve)(JNIEnv*, jobject, jfloat angle) -> jboolean { cancelDrag(); return limitedDissolveSelected(gScene, angle); }
FN(separateSelected)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return separateSelected(gScene) != 0; }
FN(dissolveVertices)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return dissolveSelectedVertices(gScene); }
FN(dissolveFaces)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return dissolveSelectedFaces(gScene); }
FN(separateLoose)(JNIEnv*, jobject) -> jint { cancelDrag(); return separateLooseParts(gScene); }
FN(fillSelected)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return fillSelected(gScene); }
FN(bridgeLoops)(JNIEnv*, jobject, jint twist) -> jboolean { cancelDrag(); return bridgeSelectedTwist(gScene, twist); }
FN(trisToQuads)(JNIEnv*, jobject, jfloat angle) -> jboolean { cancelDrag(); return trisToQuadsSelected(gScene, angle); }
FN(selectSimilarNormal)(JNIEnv*, jobject, jfloat angle) -> jboolean { cancelDrag(); return selectSimilarNormalActive(gScene, angle); }
FN(rotateEdges)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return rotateSelectedEdges(gScene); }
FN(duplicateFaces)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return duplicateSelectedFaces(gScene); }
FN(spinEdges)(JNIEnv*, jobject, jint axis, jfloat angle, jint steps) -> jboolean { cancelDrag(); return spinSelectedEdges(gScene, axis, angle, steps); }
FN(selectSimilarPerimeter)(JNIEnv*, jobject, jfloat tol) -> jboolean { cancelDrag(); return selectSimilarPerimeterActive(gScene, tol); }
FN(selectSimilarArea)(JNIEnv*, jobject, jfloat tol) -> jboolean { cancelDrag(); return selectSimilarAreaActive(gScene, tol); }
FN(selectSharp)(JNIEnv*, jobject, jfloat angle) -> jboolean { cancelDrag(); return selectSharpEdgesActive(gScene, angle); }
FN(bevelVertices)(JNIEnv*, jobject, jfloat width) -> jboolean { cancelDrag(); return bevelSelectedVertices(gScene, width); }
FN(triangulateFaces)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return triangulateSelectedFaces(gScene); }
FN(pokeFaces)(JNIEnv*, jobject, jfloat offset) -> jboolean { cancelDrag(); return pokeSelectedFaces(gScene, offset); }
FN(recalcNormals)(JNIEnv*, jobject, jboolean inside) -> jboolean { cancelDrag(); return recalcNormalsActive(gScene, inside); }
FN(selectBoundary)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return selectBoundaryActive(gScene); }
FN(selectNonManifold)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return selectNonManifoldActive(gScene); }
FN(selectRandom)(JNIEnv*, jobject, jfloat ratio, jint seed) -> jboolean { cancelDrag(); return selectRandomActive(gScene, ratio, (uint32_t)seed); }
FN(bevelEdges)(JNIEnv*, jobject, jfloat width) -> jboolean { cancelDrag(); return bevelSelectedEdges(gScene, width); }
FN(edgeSlide)(JNIEnv*, jobject, jfloat t) -> jboolean { cancelDrag(); return edgeSlideSelected(gScene, t); }
FN(loopCut)(JNIEnv*, jobject, jfloat t) -> jboolean { cancelDrag(); return loopCutSelected(gScene, t); }
FN(selectLoop)(JNIEnv*, jobject) -> jboolean { return selectLoopActive(gScene); }
FN(flipNormals)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return flipSelectedFaces(gScene); }

// ---- interactive transform ----
FN(beginTransform)(JNIEnv*, jobject, jint tool, jint axis) -> jboolean { return beginDrag(tool, axis); }
FN(dragStep)(JNIEnv*, jobject, jfloat tdx, jfloat tdy, jfloat sdx, jfloat sdy) -> void {
    if (gDrag.active) updateDrag(tdx, tdy);
    else {
        Camera& c = gRenderer.cam; c.yaw -= sdx * 0.01f; c.pitch += sdy * 0.01f;
        if (c.pitch > 1.55f) c.pitch = 1.55f;
        if (c.pitch < -1.55f) c.pitch = -1.55f;
    }
}
FN(endTransform)(JNIEnv*, jobject) -> void { endDrag(); }
FN(cancelTransform)(JNIEnv*, jobject) -> void { cancelDrag(); }

// ---- history & files ----
FN(undo)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return gScene.undo(); }
FN(redo)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return gScene.redo(); }
FN(save)(JNIEnv* env, jobject, jstring path) -> jboolean {
    const char* p = env->GetStringUTFChars(path, nullptr);
    bool ok = saveProject(gScene, p); env->ReleaseStringUTFChars(path, p); return ok;
}
FN(load)(JNIEnv* env, jobject, jstring path) -> jboolean {
    cancelDrag();
    const char* p = env->GetStringUTFChars(path, nullptr);
    bool ok = loadProject(gScene, p); env->ReleaseStringUTFChars(path, p); return ok;
}

// ---- state for the UI ----
FN(outliner)(JNIEnv* env, jobject) -> jstring {
    std::string s;
    for (const auto& o : gScene.objects) {
        if (!s.empty()) s += "\n";
        s += std::to_string(o.id) + "\t" + o.name + "\t" + (o.id == gScene.selected ? "1" : "0");
    }
    return env->NewStringUTF(s.c_str());
}
FN(modifiers)(JNIEnv* env, jobject) -> jstring {   // one line per modifier: type, enabled, axis, count, ox, oy, oz, levels, thickness, shift, merge, factor, iterations, mode, angle
    std::string s; const Object* o = gScene.find(gScene.selected);
    if (o) for (const auto& m : o->mods) {
        if (!s.empty()) s += "\n";
        s += std::to_string(m.type) + "\t" + (m.enabled ? "1" : "0") + "\t" + std::to_string(m.axis) + "\t" + std::to_string(m.count) + "\t" +
             std::to_string(m.offset[0]) + "\t" + std::to_string(m.offset[1]) + "\t" + std::to_string(m.offset[2]) + "\t" +
             std::to_string(m.levels) + "\t" + std::to_string(m.thickness) + "\t" + std::to_string(m.shift) + "\t" + std::to_string(m.merge) + "\t" +
             std::to_string(m.factor) + "\t" + std::to_string(m.iterations) + "\t" + std::to_string(m.mode) + "\t" + std::to_string(m.angle);
    }
    return env->NewStringUTF(s.c_str());
}
FN(stats)(JNIEnv* env, jobject) -> jstring {
    size_t v = 0, f = 0;
    for (const auto& o : gScene.objects) { v += o.mesh.v.size(); f += o.mesh.f.size(); }
    std::string s = "Objetos " + std::to_string(gScene.objects.size()) + "  Verts " + std::to_string(v) + "  Faces " + std::to_string(f);
    if (gScene.editMode) {
        const Object* a = gScene.find(gScene.selected);
        size_t tot = 0;
        if (a) tot = gScene.sel.mode == 0 ? a->mesh.v.size() : gScene.sel.mode == 1 ? uniqueEdges(a->mesh).size() : a->mesh.f.size();
        s += "  Sel " + std::to_string(selectionCount(gScene.sel)) + "/" + std::to_string(tot);
    }
    return env->NewStringUTF(s.c_str());
}
FN(activeTransform)(JNIEnv* env, jobject) -> jfloatArray {
    const Object* o = gScene.find(gScene.selected);
    if (!o) return env->NewFloatArray(0);
    float v[9]; for (int i = 0; i < 3; ++i) { v[i] = o->pos[i]; v[3 + i] = o->rot[i]; v[6 + i] = o->scale[i]; }
    jfloatArray a = env->NewFloatArray(9); env->SetFloatArrayRegion(a, 0, 9, v); return a;
}
FN(setActiveTransform)(JNIEnv* env, jobject, jfloatArray arr) -> jboolean {
    if (env->GetArrayLength(arr) != 9) return false;
    float v[9]; env->GetFloatArrayRegion(arr, 0, 9, v);
    for (float x : v) if (!std::isfinite(x)) return false;
    Xf a; for (int i = 0; i < 3; ++i) { a.pos[i] = v[i]; a.rot[i] = v[3 + i]; a.scale[i] = v[6 + i]; }
    return setObjectTransform(gScene, a);
}

// ---- import (0.33.0) and auto-rig (0.34.0). Both return "OK\t<message>" or "ERR\t<reason>". ----
FN(importModel)(JNIEnv* env, jobject, jbyteArray data, jstring ext, jstring name) -> jstring {   // kept for compatibility: runs on the caller's thread
    cancelDrag();
    const jsize n = data ? env->GetArrayLength(data) : 0;
    jbyte* b = n > 0 ? env->GetByteArrayElements(data, nullptr) : nullptr;
    const char* e = env->GetStringUTFChars(ext, nullptr); const char* nm = env->GetStringUTFChars(name, nullptr);
    std::string msg; uint32_t id = 0;
    try { id = b ? importModelToScene(gScene, (const uint8_t*)b, (size_t)n, e, nm, &msg) : 0; } catch (const std::exception& ex) { msg = std::string("erro interno: ") + ex.what(); id = 0; }
    if (!b) msg = "arquivo vazio";
    env->ReleaseStringUTFChars(ext, e); env->ReleaseStringUTFChars(name, nm); if (b) env->ReleaseByteArrayElements(data, b, JNI_ABORT);
    return env->NewStringUTF(((id ? "OK\t" : "ERR\t") + msg).c_str());
}
FN(setLogPath)(JNIEnv* env, jobject, jstring path) -> void {
    const char* p = env->GetStringUTFChars(path, nullptr); gLogPath = p ? p : ""; if (p) env->ReleaseStringUTFChars(path, p);
    atlas::gImportLog = gLogPath.empty() ? nullptr : &writeLog;
}
FN(importPrepare)(JNIEnv* env, jobject, jbyteArray data, jstring ext) -> jstring {   // NOT on the GL thread: never touches gScene
    const jsize n = data ? env->GetArrayLength(data) : 0;
    jbyte* b = n > 0 ? env->GetByteArrayElements(data, nullptr) : nullptr;
    const char* e = env->GetStringUTFChars(ext, nullptr);
    std::string msg; bool ok = false; Mesh m;
    writeLog("prepare start: " + std::to_string((long long)n) + " bytes, ext=" + (e ? e : ""));
    try { ok = b ? prepareImport(m, (const uint8_t*)b, (size_t)n, e ? e : "", &msg) : false; }
    catch (const std::exception& ex) { msg = std::string("erro interno: ") + ex.what(); ok = false; }
    catch (...) { msg = "erro interno desconhecido"; ok = false; }
    if (!b) msg = "arquivo vazio";
    if (e) env->ReleaseStringUTFChars(ext, e); if (b) env->ReleaseByteArrayElements(data, b, JNI_ABORT);
    if (ok) { std::lock_guard<std::mutex> g(gPendMtx); gPendMesh = std::move(m); }
    writeLog(std::string("prepare ") + (ok ? "ok: " : "FAILED: ") + msg);
    return env->NewStringUTF(((ok ? "OK\t" : "ERR\t") + msg).c_str());
}
FN(importCommit)(JNIEnv* env, jobject, jstring name) -> jstring {   // GL thread only
    cancelDrag();
    const char* nm = env->GetStringUTFChars(name, nullptr); const std::string base = nm ? nm : ""; if (nm) env->ReleaseStringUTFChars(name, nm);
    Mesh m; { std::lock_guard<std::mutex> g(gPendMtx); m = std::move(gPendMesh); gPendMesh = Mesh(); }
    if (gScene.editMode) return env->NewStringUTF("ERR\tImport só no Object Mode");
    const uint32_t id = commitImport(gScene, std::move(m), base);
    writeLog(id ? "commit ok" : "commit FAILED");
    return env->NewStringUTF(id ? "OK\t" : "ERR\tnada para importar");
}
FN(autoRig)(JNIEnv* env, jobject) -> jstring {
    cancelDrag(); std::string msg; const uint32_t id = autoRigSelected(gScene, &msg);
    return env->NewStringUTF(((id ? "OK\t" : "ERR\t") + msg).c_str());
}

// ---- rig (0.31.0 armatures / bones / pose, 0.32.0 binding / weights) ----
FN(addArmature)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return addArmature(gScene) != 0; }
// First line: "A <bones> <active>" for an armature, "M <armature name or -> <skin valid 0/1> <weighted verts of active bone or -1>" for a mesh, empty otherwise.
// Then one line per bone: idx, name, parent, connected, deform, head xyz, tail xyz, roll, loc xyz, rot xyz, scl xyz.
FN(armInfo)(JNIEnv* env, jobject) -> jstring {
    std::string s; const Object* o = gScene.find(gScene.selected);
    if (o && o->isArmature) {
        s = "A\t" + std::to_string(o->arm.bones.size()) + "\t" + std::to_string(o->activeBone);
        for (size_t i = 0; i < o->arm.bones.size(); ++i) {
            const Bone& b = o->arm.bones[i];
            s += "\n" + std::to_string(i) + "\t" + b.name + "\t" + std::to_string(b.parent) + "\t" + (b.connected ? "1" : "0") + "\t" + (b.deform ? "1" : "0");
            const float v[16] = {b.head.x, b.head.y, b.head.z, b.tail.x, b.tail.y, b.tail.z, b.roll, b.loc.x, b.loc.y, b.loc.z, b.rot.x, b.rot.y, b.rot.z, b.scl.x, b.scl.y, b.scl.z};
            for (float x : v) s += "\t" + std::to_string(x);
        }
    } else if (o) {
        const Object* a = o->armatureId ? gScene.find(o->armatureId) : nullptr;
        const bool valid = a && o->skin.v.size() == o->mesh.v.size();
        s = "M\t" + std::string(a ? a->name : "-") + "\t" + (valid ? "1" : "0") + "\t0";
        if (a) for (size_t i = 0; i < a->arm.bones.size(); ++i) s += "\n" + std::to_string(i) + "\t" + a->arm.bones[i].name;   // bone list for weight assignment
    }
    return env->NewStringUTF(s.c_str());
}
FN(armatures)(JNIEnv* env, jobject) -> jstring {   // "id\tname" per armature object
    std::string s;
    for (const auto& o : gScene.objects) if (o.isArmature) { if (!s.empty()) s += "\n"; s += std::to_string(o.id) + "\t" + o.name; }
    return env->NewStringUTF(s.c_str());
}
FN(armSelectBone)(JNIEnv*, jobject, jint i) -> jboolean { return armSelectBone(gScene, i); }
FN(armAddBone)(JNIEnv*, jobject, jfloat hx, jfloat hy, jfloat hz, jfloat tx, jfloat ty, jfloat tz, jint parent, jboolean connected) -> jint {
    cancelDrag(); return armAddBone(gScene, {hx, hy, hz}, {tx, ty, tz}, parent, connected);
}
FN(armExtrude)(JNIEnv*, jobject, jfloat dx, jfloat dy, jfloat dz) -> jint { cancelDrag(); return armExtrudeActive(gScene, {dx, dy, dz}); }
FN(armDelete)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return armDeleteActive(gScene); }
FN(armSetParent)(JNIEnv*, jobject, jint child, jint parent, jboolean connected) -> jboolean { cancelDrag(); return armSetParent(gScene, child, parent, connected); }
FN(armRename)(JNIEnv* env, jobject, jint i, jstring name) -> jboolean {
    cancelDrag(); const char* p = env->GetStringUTFChars(name, nullptr);
    bool ok = armRename(gScene, i, p ? p : ""); if (p) env->ReleaseStringUTFChars(name, p); return ok;
}
FN(armSetRest)(JNIEnv* env, jobject, jint i, jfloatArray arr) -> jboolean {   // head xyz, tail xyz, roll
    cancelDrag(); if (env->GetArrayLength(arr) != 7) return false;
    float v[7]; env->GetFloatArrayRegion(arr, 0, 7, v); for (float x : v) if (!std::isfinite(x)) return false;
    return armSetRest(gScene, i, {v[0], v[1], v[2]}, {v[3], v[4], v[5]}, v[6]);
}
FN(armSetPose)(JNIEnv* env, jobject, jint i, jfloatArray arr) -> jboolean {   // loc xyz, rot xyz (deg), scale xyz
    cancelDrag(); if (env->GetArrayLength(arr) != 9) return false;
    float v[9]; env->GetFloatArrayRegion(arr, 0, 9, v); for (float x : v) if (!std::isfinite(x)) return false;
    return armSetPose(gScene, i, {v[0], v[1], v[2]}, {v[3], v[4], v[5]}, {v[6], v[7], v[8]});
}
FN(armSetDeform)(JNIEnv*, jobject, jint i, jboolean on) -> jboolean { cancelDrag(); return armSetDeform(gScene, i, on); }
FN(armResetPose)(JNIEnv*, jobject, jboolean all) -> jboolean { cancelDrag(); return armResetPose(gScene, all); }
FN(armMirror)(JNIEnv*, jobject, jboolean all) -> jboolean { cancelDrag(); return armMirror(gScene, all); }
FN(bindToArmature)(JNIEnv*, jobject, jint id) -> jboolean { cancelDrag(); return bindMeshToArmature(gScene, (uint32_t)id); }
FN(unbindArmature)(JNIEnv*, jobject) -> jboolean { cancelDrag(); return unbindMesh(gScene); }
FN(assignWeight)(JNIEnv*, jobject, jint bone, jfloat w) -> jboolean { cancelDrag(); return assignWeightSelected(gScene, bone, w); }
}
