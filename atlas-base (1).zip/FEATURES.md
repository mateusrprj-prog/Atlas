# Features (status per feature)
| Feature | Status |
|---|---|
| Scene graph (flat, single collection), persistent ids, unique names | Implemented and tested (host) |
| Polygon mesh core (n-gon faces), primitives: cube, plane, cylinder, UV sphere | Implemented and tested (host) |
| Edit Mode: face selection by picking | Implemented but untested on device |
| Extrude faces (region), delete faces | Implemented and tested (host) |
| Move / Rotate / Scale by drag, X/Y/Z constraint, one undo step per gesture | Implemented but untested on device |
| Numeric Location/Rotation/Scale fields (Properties) | Implemented but untested on device |
| Command undo/redo (add, delete, transform, mesh edit) | Implemented and tested (host) |
| Project format v2 (meshes), atomic save, v1 migration | Implemented and tested (host) |
| Viewport: orbit/pan/zoom, view presets, frame selected, wireframe/solid, axis gizmo | Implemented but untested on device |
| Blender-style shell: menus, workspace tabs, Outliner, Properties, header, status bar | Implemented but untested on device |
| Vertex/edge selection, bevel, inset, loop cut, knife | Not started |
| Parenting, collections, multi-select, local orientation, ortho view | Not started |
| Timeline / animation | Not started (Phase 6) |
| Workspaces other than Layout/Modeling | Not started (tabs are disabled) |
| Materials, UV, sculpt, rig, render, import/export | Not started |

Known limits: edit snapshots copy the whole mesh per undo step (fine for small meshes); n-gon fan
triangulation assumes convex faces; Z-up like Blender (import converters will handle Y-up formats).
