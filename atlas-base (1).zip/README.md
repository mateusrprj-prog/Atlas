# Atlas
Independent 3D creation app for Android (no Blender code). See FEATURES.md for per-feature status.

## Build
CI builds the APK (`.github/workflows/build.yml`). Locally: `gradle :app:assembleDebug`.
Core tests (host, no Android needed): `g++ -std=c++17 tests/test_scene.cpp -o t && ./t`.

## Controls (landscape)
- Select tool: 1 finger orbit, 2 fingers pan, pinch zoom, tap selects (object or face in Edit Mode).
- Move/Rotate/Scale: 1 finger drag transforms the selection (X/Y/Z buttons constrain), 2 fingers orbit.
- Modeling tab / Object Mode menu enters Edit Mode; tap faces, then Mesh > Extrude Faces and drag with Move.
