// Atlas core: scene model, transforms, selection state, command-based undo/redo. No GL, no JNI.
#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <cstdio>
#include <memory>
#include <string>
#include <vector>
#include "mesh.hpp"

namespace atlas {

// Monotonic revision stamp: renderers cache GPU data per (object id, meshRev).
inline uint64_t nextRev() { static uint64_t r = 0; return ++r; }

struct Xf { float pos[3] = {0, 0, 0}; float rot[3] = {0, 0, 0}; float scale[3] = {1, 1, 1}; };

struct Object {
    uint32_t id = 0;
    std::string name;
    float pos[3] = {0, 0, 0};
    float rot[3] = {0, 0, 0};   // Euler XYZ in degrees, R = Rz*Ry*Rx
    float scale[3] = {1, 1, 1};
    Mesh mesh;
    uint64_t meshRev = 0;
};

inline Xf getXf(const Object& o) {
    Xf x; for (int i = 0; i < 3; ++i) { x.pos[i] = o.pos[i]; x.rot[i] = o.rot[i]; x.scale[i] = o.scale[i]; } return x;
}
inline void setXf(Object& o, const Xf& x) {
    for (int i = 0; i < 3; ++i) { o.pos[i] = x.pos[i]; o.rot[i] = x.rot[i]; o.scale[i] = x.scale[i]; }
}
inline bool sameXf(const Xf& a, const Xf& b) {
    for (int i = 0; i < 3; ++i) if (a.pos[i] != b.pos[i] || a.rot[i] != b.rot[i] || a.scale[i] != b.scale[i]) return false;
    return true;
}

// Row-major 3x3 rotation matrix from Euler degrees.
inline void eulerToMat(const float* d, float* R) {
    const float k = 0.01745329252f;
    float cx = std::cos(d[0] * k), sx = std::sin(d[0] * k), cy = std::cos(d[1] * k), sy = std::sin(d[1] * k),
          cz = std::cos(d[2] * k), sz = std::sin(d[2] * k);
    R[0] = cz * cy; R[1] = cz * sy * sx - sz * cx; R[2] = cz * sy * cx + sz * sx;
    R[3] = sz * cy; R[4] = sz * sy * sx + cz * cx; R[5] = sz * sy * cx - cz * sx;
    R[6] = -sy;     R[7] = cy * sx;                R[8] = cy * cx;
}
// Column-major 4x4 (T * R * S).
inline void modelMatrix(const Object& o, float* M) {
    float R[9]; eulerToMat(o.rot, R);
    for (int c = 0; c < 3; ++c) for (int r = 0; r < 3; ++r) M[c * 4 + r] = R[r * 3 + c] * o.scale[c];
    M[3] = M[7] = M[11] = 0; M[12] = o.pos[0]; M[13] = o.pos[1]; M[14] = o.pos[2]; M[15] = 1;
}
inline float safeScale(float s) { return std::fabs(s) < 1e-6f ? 1e-6f : s; }
inline Vec3 worldToLocalDir(const Object& o, Vec3 d) {
    float R[9]; eulerToMat(o.rot, R);
    return {(R[0] * d.x + R[3] * d.y + R[6] * d.z) / safeScale(o.scale[0]),
            (R[1] * d.x + R[4] * d.y + R[7] * d.z) / safeScale(o.scale[1]),
            (R[2] * d.x + R[5] * d.y + R[8] * d.z) / safeScale(o.scale[2])};
}
inline Vec3 worldToLocalPoint(const Object& o, Vec3 p) {
    return worldToLocalDir(o, p - Vec3{o.pos[0], o.pos[1], o.pos[2]});
}

class Scene;
struct Command {
    virtual ~Command() = default;
    virtual void apply(Scene&) = 0;
    virtual void revert(Scene&) = 0;
};

class Scene {
public:
    std::vector<Object> objects;
    uint32_t nextId = 1;
    uint32_t selected = 0;          // active object, 0 = none
    bool editMode = false;
    std::vector<int> selFaces;      // face selection of the active object (edit mode)

    Object* find(uint32_t id) { for (auto& o : objects) if (o.id == id) return &o; return nullptr; }
    const Object* find(uint32_t id) const { for (auto& o : objects) if (o.id == id) return &o; return nullptr; }

    void execute(std::unique_ptr<Command> c) { c->apply(*this); record(std::move(c)); }
    // Push an already-applied command (used by interactive drags).
    void record(std::unique_ptr<Command> c) { undoStack.push_back(std::move(c)); redoStack.clear(); }
    bool undo() {
        if (undoStack.empty()) return false;
        undoStack.back()->revert(*this);
        redoStack.push_back(std::move(undoStack.back())); undoStack.pop_back();
        sanitize(); return true;
    }
    bool redo() {
        if (redoStack.empty()) return false;
        redoStack.back()->apply(*this);
        undoStack.push_back(std::move(redoStack.back())); redoStack.pop_back();
        sanitize(); return true;
    }
    void clearHistory() { undoStack.clear(); redoStack.clear(); }
    size_t undoDepth() const { return undoStack.size(); }

    // Keep selection state valid after history jumps.
    void sanitize() {
        Object* o = find(selected);
        if (!o) { selected = 0; editMode = false; selFaces.clear(); return; }
        if (editMode) {
            const int n = (int)o->mesh.f.size();
            selFaces.erase(std::remove_if(selFaces.begin(), selFaces.end(), [n](int i) { return i < 0 || i >= n; }), selFaces.end());
        }
    }
    void toggleFace(int fi) {
        auto it = std::find(selFaces.begin(), selFaces.end(), fi);
        if (it == selFaces.end()) selFaces.push_back(fi); else selFaces.erase(it);
    }
    void reset() { objects.clear(); nextId = 1; selected = 0; editMode = false; selFaces.clear(); clearHistory(); }

private:
    std::vector<std::unique_ptr<Command>> undoStack, redoStack;
};

struct AddObjectCmd : Command {
    Object obj;
    explicit AddObjectCmd(Object o) : obj(std::move(o)) {}
    void apply(Scene& s) override { s.objects.push_back(obj); s.selected = obj.id; s.editMode = false; s.selFaces.clear(); }
    void revert(Scene& s) override {
        for (size_t i = 0; i < s.objects.size(); ++i) if (s.objects[i].id == obj.id) { s.objects.erase(s.objects.begin() + i); break; }
    }
};
struct DeleteObjectCmd : Command {
    Object obj; size_t index;
    DeleteObjectCmd(Object o, size_t i) : obj(std::move(o)), index(i) {}
    void apply(Scene& s) override {
        for (size_t i = 0; i < s.objects.size(); ++i) if (s.objects[i].id == obj.id) { s.objects.erase(s.objects.begin() + i); break; }
        s.selected = 0; s.editMode = false; s.selFaces.clear();
    }
    void revert(Scene& s) override {
        s.objects.insert(s.objects.begin() + std::min(index, s.objects.size()), obj); s.selected = obj.id;
    }
};
struct TransformCmd : Command {
    uint32_t id; Xf before, after;
    TransformCmd(uint32_t i, const Xf& b, const Xf& a) : id(i), before(b), after(a) {}
    void apply(Scene& s) override { if (Object* o = s.find(id)) setXf(*o, after); }
    void revert(Scene& s) override { if (Object* o = s.find(id)) setXf(*o, before); }
};
struct MeshEditCmd : Command {
    uint32_t id; Mesh before, after;
    MeshEditCmd(uint32_t i, Mesh b, Mesh a) : id(i), before(std::move(b)), after(std::move(a)) {}
    void apply(Scene& s) override { if (Object* o = s.find(id)) { o->mesh = after; o->meshRev = nextRev(); } }
    void revert(Scene& s) override { if (Object* o = s.find(id)) { o->mesh = before; o->meshRev = nextRev(); } }
};

// ---------- high-level operations (shared by UI and tests) ----------
inline std::string uniqueName(const Scene& s, std::string base) {
    if (base.size() > 4 && base[base.size() - 4] == '.' && std::isdigit((unsigned char)base[base.size() - 3]) &&
        std::isdigit((unsigned char)base[base.size() - 2]) && std::isdigit((unsigned char)base[base.size() - 1]))
        base.resize(base.size() - 4);
    auto exists = [&](const std::string& n) { for (auto& o : s.objects) if (o.name == n) return true; return false; };
    if (!exists(base)) return base;
    for (int i = 1; i < 100000; ++i) {
        char buf[16]; std::snprintf(buf, sizeof buf, ".%03d", i);
        if (!exists(base + buf)) return base + buf;
    }
    return base;
}
inline uint32_t addPrimitive(Scene& s, int kind) {
    Object o; o.id = s.nextId++; o.name = uniqueName(s, primitiveName(kind));
    o.mesh = makePrimitive(kind); o.meshRev = nextRev();
    uint32_t id = o.id; s.execute(std::make_unique<AddObjectCmd>(std::move(o))); return id;
}
inline uint32_t duplicateSelected(Scene& s) {
    const Object* src = s.find(s.selected);
    if (!src || s.editMode) return 0;
    Object o = *src; o.id = s.nextId++; o.name = uniqueName(s, src->name); o.meshRev = nextRev();
    uint32_t id = o.id; s.execute(std::make_unique<AddObjectCmd>(std::move(o))); return id;
}
inline bool deleteSelectedObject(Scene& s) {
    if (s.editMode) return false;
    for (size_t i = 0; i < s.objects.size(); ++i)
        if (s.objects[i].id == s.selected) { s.execute(std::make_unique<DeleteObjectCmd>(s.objects[i], i)); return true; }
    return false;
}
inline bool extrudeSelected(Scene& s, float dist) {
    Object* o = s.find(s.selected);
    if (!s.editMode || !o || s.selFaces.empty()) return false;
    Mesh before = o->mesh, after = before;
    if (!extrudeFaces(after, s.selFaces, dist)) return false;
    s.execute(std::make_unique<MeshEditCmd>(o->id, std::move(before), std::move(after))); return true;
}
inline bool deleteSelectedFaces(Scene& s) {
    Object* o = s.find(s.selected);
    if (!s.editMode || !o || s.selFaces.empty()) return false;
    Mesh before = o->mesh, after = before;
    if (!deleteFaces(after, s.selFaces)) return false;
    s.execute(std::make_unique<MeshEditCmd>(o->id, std::move(before), std::move(after)));
    s.selFaces.clear(); return true;
}
inline bool setObjectTransform(Scene& s, const Xf& after) {
    Object* o = s.find(s.selected);
    if (!o || s.editMode) return false;
    Xf a = after; for (int i = 0; i < 3; ++i) if (std::fabs(a.scale[i]) < 1e-4f) a.scale[i] = 1e-4f;
    Xf b = getXf(*o); if (sameXf(a, b)) return false;
    s.execute(std::make_unique<TransformCmd>(o->id, b, a)); return true;
}
inline bool setEditMode(Scene& s, bool on) {
    if (on) { if (!s.find(s.selected)) return false; s.editMode = true; s.selFaces.clear(); return true; }
    s.editMode = false; s.selFaces.clear(); return true;
}
inline uint32_t pickObject(const Scene& s, Vec3 org, Vec3 dir) {
    uint32_t best = 0; float bt = 1e30f;
    for (const auto& o : s.objects) {
        float t; Vec3 lo = worldToLocalPoint(o, org), ld = worldToLocalDir(o, dir);
        if (pickFace(o.mesh, lo, ld, &t) >= 0 && t < bt) { bt = t; best = o.id; }
    }
    return best;
}
inline int pickActiveFace(const Scene& s, Vec3 org, Vec3 dir) {
    const Object* o = s.find(s.selected);
    if (!o) return -1;
    return pickFace(o->mesh, worldToLocalPoint(*o, org), worldToLocalDir(*o, dir));
}

}  // namespace atlas
