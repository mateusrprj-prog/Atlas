// Polygon mesh (indexed faces, any vertex count >= 3) and modeling operations. Z-up, CCW = outward.
#pragma once
#include <algorithm>
#include <cmath>
#include <map>
#include <utility>
#include <vector>
#include "math3.hpp"

namespace atlas {

struct Mesh {
    std::vector<Vec3> v;
    std::vector<std::vector<int>> f;
};

inline bool sameMesh(const Mesh& a, const Mesh& b) {
    if (a.v.size() != b.v.size() || a.f != b.f) return false;
    for (size_t i = 0; i < a.v.size(); ++i)
        if (a.v[i].x != b.v[i].x || a.v[i].y != b.v[i].y || a.v[i].z != b.v[i].z) return false;
    return true;
}

inline bool validMesh(const Mesh& m) {
    for (const auto& fc : m.f) {
        if (fc.size() < 3) return false;
        for (int i : fc) if (i < 0 || i >= (int)m.v.size()) return false;
    }
    return true;
}

// Newell's method: robust normal for any planar-ish polygon.
inline Vec3 faceNormal(const Mesh& m, const std::vector<int>& face) {
    Vec3 n; size_t k = face.size();
    for (size_t i = 0; i < k; ++i) {
        const Vec3& a = m.v[face[i]]; const Vec3& b = m.v[face[(i + 1) % k]];
        n.x += (a.y - b.y) * (a.z + b.z);
        n.y += (a.z - b.z) * (a.x + b.x);
        n.z += (a.x - b.x) * (a.y + b.y);
    }
    return normalized(n);
}

// ---------- primitives (default size like a 2 m cube) ----------
inline Mesh makeCube() {
    Mesh m;
    for (int z = 0; z < 2; ++z) {
        const float zz = z ? 1.f : -1.f;
        m.v.push_back({-1, -1, zz}); m.v.push_back({1, -1, zz});
        m.v.push_back({1, 1, zz}); m.v.push_back({-1, 1, zz});
    }
    m.f = {{0, 3, 2, 1}, {4, 5, 6, 7}, {0, 1, 5, 4}, {3, 7, 6, 2}, {0, 4, 7, 3}, {1, 2, 6, 5}};
    return m;
}
inline Mesh makePlane() {
    Mesh m; m.v = {{-1, -1, 0}, {1, -1, 0}, {1, 1, 0}, {-1, 1, 0}}; m.f = {{0, 1, 2, 3}}; return m;
}
inline Mesh makeCylinder(int n = 16) {
    Mesh m;
    for (int i = 0; i < n; ++i) { float a = 6.2831853f * i / n; m.v.push_back({std::cos(a), std::sin(a), -1}); }
    for (int i = 0; i < n; ++i) { float a = 6.2831853f * i / n; m.v.push_back({std::cos(a), std::sin(a), 1}); }
    for (int i = 0; i < n; ++i) { int j = (i + 1) % n; m.f.push_back({i, j, n + j, n + i}); }
    std::vector<int> top, bot;
    for (int i = 0; i < n; ++i) top.push_back(n + i);
    for (int i = n - 1; i >= 0; --i) bot.push_back(i);
    m.f.push_back(top); m.f.push_back(bot);
    return m;
}
inline Mesh makeUVSphere(int seg = 16, int rings = 8) {
    Mesh m;
    m.v.push_back({0, 0, 1});
    for (int k = 1; k < rings; ++k) {
        float th = 3.14159265f * k / rings, z = std::cos(th), r = std::sin(th);
        for (int j = 0; j < seg; ++j) { float ph = 6.2831853f * j / seg; m.v.push_back({r * std::cos(ph), r * std::sin(ph), z}); }
    }
    const int bottom = (int)m.v.size(); m.v.push_back({0, 0, -1});
    auto ring = [&](int k, int j) { return 1 + (k - 1) * seg + (j % seg); };
    for (int j = 0; j < seg; ++j) m.f.push_back({0, ring(1, j), ring(1, j + 1)});
    for (int k = 1; k < rings - 1; ++k)
        for (int j = 0; j < seg; ++j) m.f.push_back({ring(k, j), ring(k + 1, j), ring(k + 1, j + 1), ring(k, j + 1)});
    for (int j = 0; j < seg; ++j) m.f.push_back({bottom, ring(rings - 1, j + 1), ring(rings - 1, j)});
    return m;
}
inline Mesh makePrimitive(int kind) {
    switch (kind) { case 1: return makePlane(); case 2: return makeCylinder(); case 3: return makeUVSphere(); default: return makeCube(); }
}
inline const char* primitiveName(int kind) {
    switch (kind) { case 1: return "Plane"; case 2: return "Cylinder"; case 3: return "Sphere"; default: return "Cube"; }
}

// ---------- queries ----------
inline bool rayTriangle(Vec3 o, Vec3 d, Vec3 a, Vec3 b, Vec3 c, float& t) {
    Vec3 e1 = b - a, e2 = c - a, p = cross(d, e2);
    float det = dot(e1, p);
    if (std::fabs(det) < 1e-12f) return false;
    float inv = 1.f / det; Vec3 s = o - a;
    float u = dot(s, p) * inv; if (u < 0 || u > 1) return false;
    Vec3 q = cross(s, e1);
    float v = dot(d, q) * inv; if (v < 0 || u + v > 1) return false;
    t = dot(e2, q) * inv; return t >= 0;
}
// Nearest face hit (fan triangulation). Returns face index or -1.
inline int pickFace(const Mesh& m, Vec3 o, Vec3 d, float* tOut = nullptr) {
    int best = -1; float bt = 1e30f;
    for (size_t fi = 0; fi < m.f.size(); ++fi) {
        const auto& fc = m.f[fi];
        for (size_t i = 1; i + 1 < fc.size(); ++i) {
            float t;
            if (rayTriangle(o, d, m.v[fc[0]], m.v[fc[i]], m.v[fc[i + 1]], t) && t < bt) { bt = t; best = (int)fi; }
        }
    }
    if (tOut) *tOut = bt;
    return best;
}
inline std::vector<std::pair<int, int>> uniqueEdges(const Mesh& m) {
    std::vector<std::pair<int, int>> e;
    for (const auto& fc : m.f)
        for (size_t i = 0; i < fc.size(); ++i) {
            int a = fc[i], b = fc[(i + 1) % fc.size()];
            e.push_back({std::min(a, b), std::max(a, b)});
        }
    std::sort(e.begin(), e.end());
    e.erase(std::unique(e.begin(), e.end()), e.end());
    return e;
}

// ---------- modeling operations ----------
// Extrude the selected faces as one region along their (averaged) normals. Selected faces are moved
// to duplicated vertices; side quads are created on the region boundary. Face indices stay valid.
inline bool extrudeFaces(Mesh& m, const std::vector<int>& sel, float dist) {
    if (sel.empty() || std::fabs(dist) < 1e-6f) return false;
    for (int i : sel) if (i < 0 || i >= (int)m.f.size()) return false;
    std::map<std::pair<int, int>, int> cnt;
    std::map<int, Vec3> vn;
    for (int fi : sel) {
        const auto& fc = m.f[fi]; Vec3 n = faceNormal(m, fc);
        for (size_t i = 0; i < fc.size(); ++i) {
            int a = fc[i], b = fc[(i + 1) % fc.size()];
            cnt[{std::min(a, b), std::max(a, b)}]++;
            vn[a] = vn[a] + n;
        }
    }
    std::map<int, int> dup;
    for (auto& kv : vn) {
        Vec3 n = normalized(kv.second);
        dup[kv.first] = (int)m.v.size();
        m.v.push_back(m.v[kv.first] + n * dist);
    }
    std::vector<std::vector<int>> sides;
    for (int fi : sel) {
        const auto& fc = m.f[fi];
        for (size_t i = 0; i < fc.size(); ++i) {
            int a = fc[i], b = fc[(i + 1) % fc.size()];
            if (cnt[{std::min(a, b), std::max(a, b)}] != 1) continue;
            if (dist > 0) sides.push_back({a, b, dup[b], dup[a]});
            else sides.push_back({a, dup[a], dup[b], b});
        }
    }
    for (int fi : sel) for (int& vi : m.f[fi]) vi = dup[vi];
    for (auto& s : sides) m.f.push_back(s);
    return true;
}

// Remove faces and compact unused vertices.
inline bool deleteFaces(Mesh& m, const std::vector<int>& sel) {
    if (sel.empty()) return false;
    std::vector<char> del(m.f.size(), 0);
    for (int i : sel) { if (i < 0 || i >= (int)m.f.size()) return false; del[i] = 1; }
    std::vector<std::vector<int>> nf;
    for (size_t i = 0; i < m.f.size(); ++i) if (!del[i]) nf.push_back(m.f[i]);
    std::vector<int> remap(m.v.size(), -1); std::vector<Vec3> nv;
    for (auto& fc : nf) for (int& vi : fc) {
        if (remap[vi] < 0) { remap[vi] = (int)nv.size(); nv.push_back(m.v[vi]); }
        vi = remap[vi];
    }
    m.v = nv; m.f = nf; return true;
}

}  // namespace atlas
