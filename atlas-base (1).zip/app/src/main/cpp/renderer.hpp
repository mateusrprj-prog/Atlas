#pragma once
#include <unordered_map>
#include "core/scene.hpp"
namespace atlas {
struct Camera {
    float yaw = -0.8f, pitch = 0.5f, dist = 9.f, fovY = 0.9f, aspect = 1.f;
    Vec3 target;
    Vec3 eye() const;
    void basis(Vec3& f, Vec3& r, Vec3& u) const;
};
class Renderer {
public:
    void init();                       // call on every GL context (re)creation
    void resize(int w, int h);
    void draw(const Scene& s);
    void screenRay(float px, float py, Vec3& org, Vec3& dir) const;
    Camera cam;
    int width = 1, height = 1;
    int shading = 0;                   // 0 solid, 1 wireframe
private:
    struct Gpu { unsigned tri = 0, line = 0; int triN = 0, lineN = 0; uint64_t rev = 0; };
    Gpu& ensure(const Object& o);
    unsigned prog = 0, cubeVbo = 0, gridVbo = 0, gizmoVbo = 0, overlayVbo = 0;
    int gridN = 0;
    int uVP = -1, uModel = -1, uColor = -1, uLit = -1;
    std::unordered_map<uint32_t, Gpu> gpu;
};
}
