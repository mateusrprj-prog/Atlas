# Architecture (v0.2)
- `core/` (header-only C++17, no GL/JNI): `math3`, `mesh` (polygon mesh, primitives, extrude/delete, picking),
  `scene` (objects, transforms, selection, command history, high-level ops), `project_io` (v2 format).
- `renderer.*`: GLES3. Per-object GPU buffers keyed by (object id, meshRev); edit overlay; axis gizmo.
- `bridge.cpp`: thin JNI layer + interactive drag state (one undo entry per gesture).
- `kotlin/dev/atlas`: Android shell. All scene access goes through `act {}` which runs on the GL thread,
  then refreshes Outliner/Properties/status from native state.
Conventions: Z-up, right-handed, CCW faces are outward, Euler XYZ degrees (R = Rz*Ry*Rx).
