#include <cassert>
#include <cstdio>
#include "../app/src/main/cpp/core/project_io.hpp"
using namespace atlas;

static void checkOutward(const Mesh& m) {
    assert(validMesh(m));
    for (const auto& fc : m.f) {
        Vec3 c; for (int i : fc) c = c + m.v[i]; c = c * (1.f / fc.size());
        assert(dot(faceNormal(m, fc), c) > 0);  // normals point away from the origin
    }
}

int main() {
    // primitives
    checkOutward(makeCube()); checkOutward(makeCylinder()); checkOutward(makeUVSphere());
    assert(makeCube().v.size() == 8 && makeCube().f.size() == 6);

    // object add / transform / undo / redo
    Scene s; uint32_t a = addPrimitive(s, 0);
    assert(s.objects.size() == 1 && s.selected == a && s.objects[0].name == "Cube");
    uint32_t b = addPrimitive(s, 0); assert(s.find(b)->name == "Cube.001");
    Xf x = getXf(*s.find(a)); x.pos[0] = 3; x.rot[2] = 90; assert(s.selected == b);
    s.selected = a; assert(setObjectTransform(s, x));
    assert(s.find(a)->pos[0] == 3); assert(s.undo()); assert(s.find(a)->pos[0] == 0); assert(s.redo()); assert(s.find(a)->rot[2] == 90);

    // picking respects rotation/scale/translation
    Scene p; uint32_t c1 = addPrimitive(p, 0); uint32_t c2 = addPrimitive(p, 0);
    p.find(c2)->pos[1] = -6;   // behind c1 along the ray from +y? ray goes -y from y=+10
    Vec3 org{0, 10, 0}, dir{0, -1, 0};
    assert(pickObject(p, org, dir) == c1);
    Vec3 miss{5, 10, 0}; assert(pickObject(p, miss, dir) == 0);
    p.find(c1)->scale[0] = 6; assert(pickObject(p, miss, dir) == c1);  // scaled object now hit

    // edit mode: extrude a face, undo restores exact mesh
    Scene e; uint32_t id = addPrimitive(e, 0); assert(setEditMode(e, true));
    Mesh original = e.find(id)->mesh;
    int topFace = pickActiveFace(e, Vec3{0, 0, 10}, Vec3{0, 0, -1}); assert(topFace == 1);
    e.toggleFace(topFace);
    assert(extrudeSelected(e, 0.5f));
    const Mesh& m = e.find(id)->mesh;
    assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m));
    for (const auto& fc : m.f) { Vec3 n = faceNormal(m, fc); assert(length(n) > 0.99f); }
    float maxz = -9; for (auto& v : m.v) maxz = std::max(maxz, v.z); assert(std::fabs(maxz - 1.5f) < 1e-5f);
    assert(e.undo()); assert(sameMesh(e.find(id)->mesh, original));
    assert(e.redo()); assert(e.find(id)->mesh.f.size() == 10);
    assert(deleteSelectedFaces(e)); assert(e.find(id)->mesh.f.size() == 9 && validMesh(e.find(id)->mesh));
    assert(e.undo()); assert(e.find(id)->mesh.f.size() == 10);

    // undoing the creation while in edit mode leaves a consistent state
    Scene g; addPrimitive(g, 3); setEditMode(g, true); g.undo();
    assert(g.objects.empty() && !g.editMode && g.selected == 0);

    // delete / duplicate
    Scene d; addPrimitive(d, 2); assert(duplicateSelected(d) != 0 && d.objects.size() == 2);
    assert(deleteSelectedObject(d) && d.objects.size() == 1); assert(d.undo() && d.objects.size() == 2);

    // project round trip (v2)
    assert(saveProject(e, "/tmp/atlas_t2.atlas"));
    Scene q; assert(loadProject(q, "/tmp/atlas_t2.atlas"));
    assert(q.objects.size() == 1 && sameMesh(q.objects[0].mesh, e.objects[0].mesh) && q.nextId == e.nextId);

    // v1 migration + invalid files leave the scene untouched
    FILE* f1 = fopen("/tmp/atlas_v1.atlas", "w"); fputs("ATLAS 1\nnext 2\ncube 1 1 2 3 1 1 1\nend\n", f1); fclose(f1);
    Scene m1; assert(loadProject(m1, "/tmp/atlas_v1.atlas") && m1.objects.size() == 1);
    assert(m1.objects[0].pos[0] == 1 && m1.objects[0].pos[1] == -3 && m1.objects[0].pos[2] == 2);
    FILE* f2 = fopen("/tmp/atlas_bad.atlas", "w"); fputs("ATLAS 2\nnext 3\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 9\nend\n", f2); fclose(f2);
    Scene r; addPrimitive(r, 0); std::string err;
    assert(!loadProject(r, "/tmp/atlas_bad.atlas", &err)); assert(r.objects.size() == 1);
    puts("all tests passed"); return 0;
}
