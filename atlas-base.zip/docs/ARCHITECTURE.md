# Architecture (Phase 1)
- `app/src/main/cpp/core/` : platform-independent scene, commands (undo/redo), project I/O. No GL, no JNI.
- `app/src/main/cpp/renderer.*` : GLES3 renderer reading the scene. Replaceable (Filament planned).
- `app/src/main/cpp/bridge.cpp` : thin JNI layer, flat calls only.
- `app/src/main/kotlin/dev/atlas/` : Android shell, touch input, toolbar.
All edits are Commands executed on the Scene, so undo/redo and later modifiers/evaluation share one path.
Native calls run on the GL thread via `queueEvent`, so no locking is needed yet.
