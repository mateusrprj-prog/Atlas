# Atlas
Independent 3D creation app for Android (no Blender code). Phase 1 skeleton.

## Status
| Feature | Status |
|---|---|
| Native scene + command undo/redo | Implemented and tested (host) |
| Versioned atomic project save/load | Implemented and tested (host) |
| Ray picking (AABB) | Implemented and tested (host) |
| GLES3 viewport, grid, axes, orbit/zoom | Implemented but untested on device |
| Everything else | Not started |

## Build
CI builds the APK (see `.github/workflows/build.yml`). Locally: `gradle :app:assembleDebug`
(run `gradle wrapper` once if you want `./gradlew`). Core tests: `g++ -std=c++17 tests/test_scene.cpp && ./a.out`.

## Notes
The renderer is a minimal GLES3 renderer on purpose, to get a buildable base. Filament is the planned
upgrade for PBR (see docs/ARCHITECTURE.md). Pin NDK 26.1.10909125 (used by CI).
