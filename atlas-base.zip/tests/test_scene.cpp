#include <cassert>
#include <cstdio>
#include "../app/src/main/cpp/core/project_io.hpp"
using namespace atlas;
int main() {
    Scene s;
    uint32_t a = addCube(s, 0, 0, 0);
    assert(s.objects.size() == 1 && s.selected == a);
    assert(moveSelected(s, 1, 2, 3));
    assert(s.find(a)->pos[1] == 2);
    assert(s.undo()); assert(s.find(a)->pos[1] == 0);   // undo restores exact previous state
    assert(s.redo()); assert(s.find(a)->pos[2] == 3);
    assert(s.undo() && s.undo()); assert(s.objects.empty());
    // picking
    Scene p; uint32_t c1 = addCube(p, 0, 0, 0); addCube(p, 0, 0, -5);
    float org[3] = {0, 0, 10}, dir[3] = {0, 0, -1};
    assert(pick(p, org, dir) == c1);                    // nearest object wins
    float miss[3] = {5, 0, 10}; assert(pick(p, miss, dir) == 0);
    // save / load round trip + invalid file
    assert(saveProject(p, "/tmp/atlas_test.atlas"));
    Scene q; assert(loadProject(q, "/tmp/atlas_test.atlas"));
    assert(q.objects.size() == 2 && q.nextId == p.nextId);
    FILE* f = fopen("/tmp/atlas_bad.atlas", "w"); fputs("ATLAS 1\nnext 3\ncube 1 0 0", f); fclose(f);
    Scene r; addCube(r, 0, 0, 0); std::string err;
    assert(!loadProject(r, "/tmp/atlas_bad.atlas", &err)); assert(r.objects.size() == 1);  // untouched
    puts("all tests passed"); return 0;
}
