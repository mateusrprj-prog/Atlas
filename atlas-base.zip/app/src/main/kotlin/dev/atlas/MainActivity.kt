package dev.atlas

import android.app.Activity
import android.opengl.GLSurfaceView
import android.os.Bundle
import android.view.Gravity
import android.view.MotionEvent
import android.view.ScaleGestureDetector
import android.view.ViewGroup
import android.widget.Button
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.Toast
import java.io.File
import javax.microedition.khronos.egl.EGLConfig
import javax.microedition.khronos.opengles.GL10

class MainActivity : Activity() {
    private lateinit var gl: GLSurfaceView
    private val projectFile get() = File(filesDir, "project.atlas").absolutePath

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        gl = ViewportView()
        val root = FrameLayout(this)
        root.addView(gl)
        val bar = LinearLayout(this)
        fun btn(label: String, action: () -> Unit) = bar.addView(Button(this).apply {
            text = label; setOnClickListener { action() }
        })
        btn("+ Cubo") { gl.queueEvent { NativeBridge.addCube() } }
        btn("Mover +X") { gl.queueEvent { NativeBridge.moveSelected(0.5f, 0f, 0f) } }
        btn("Mover +Y") { gl.queueEvent { NativeBridge.moveSelected(0f, 0.5f, 0f) } }
        btn("Desfazer") { gl.queueEvent { NativeBridge.undo() } }
        btn("Refazer") { gl.queueEvent { NativeBridge.redo() } }
        btn("Salvar") { gl.queueEvent { val ok = NativeBridge.save(projectFile); toast(if (ok) "Salvo" else "Falha ao salvar") } }
        btn("Abrir") { gl.queueEvent { val ok = NativeBridge.load(projectFile); toast(if (ok) "Aberto" else "Falha ao abrir") } }
        val scroll = HorizontalScrollView(this).apply { addView(bar) }
        root.addView(scroll, FrameLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT,
            ViewGroup.LayoutParams.WRAP_CONTENT, Gravity.BOTTOM))
        setContentView(root)
    }

    private fun toast(msg: String) = runOnUiThread { Toast.makeText(this, msg, Toast.LENGTH_SHORT).show() }
    override fun onPause() { super.onPause(); gl.onPause() }
    override fun onResume() { super.onResume(); gl.onResume() }

    inner class ViewportView : GLSurfaceView(this@MainActivity) {
        private var lastX = 0f; private var lastY = 0f
        private var downX = 0f; private var downY = 0f
        private var multi = false
        private val scale = ScaleGestureDetector(context, object : ScaleGestureDetector.SimpleOnScaleGestureListener() {
            override fun onScale(d: ScaleGestureDetector): Boolean {
                val f = d.scaleFactor; queueEvent { NativeBridge.zoom(f) }; return true
            }
        })
        init {
            setEGLContextClientVersion(3)
            setRenderer(object : Renderer {
                override fun onSurfaceCreated(g: GL10?, c: EGLConfig?) = NativeBridge.init()
                override fun onSurfaceChanged(g: GL10?, w: Int, h: Int) = NativeBridge.resize(w, h)
                override fun onDrawFrame(g: GL10?) = NativeBridge.draw()
            })
        }
        override fun onTouchEvent(e: MotionEvent): Boolean {
            scale.onTouchEvent(e)
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> { lastX = e.x; lastY = e.y; downX = e.x; downY = e.y; multi = false }
                MotionEvent.ACTION_POINTER_DOWN -> multi = true
                MotionEvent.ACTION_MOVE -> if (e.pointerCount == 1 && !multi) {
                    val dx = e.x - lastX; val dy = e.y - lastY
                    queueEvent { NativeBridge.orbit(dx, dy) }
                    lastX = e.x; lastY = e.y
                }
                MotionEvent.ACTION_UP -> if (!multi && Math.hypot((e.x - downX).toDouble(), (e.y - downY).toDouble()) < 12) {
                    val x = e.x; val y = e.y
                    queueEvent { NativeBridge.pickAt(x, y) }
                }
            }
            return true
        }
    }
}
