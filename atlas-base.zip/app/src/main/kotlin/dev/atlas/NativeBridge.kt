package dev.atlas

object NativeBridge {
    init { System.loadLibrary("atlas") }
    external fun init()
    external fun resize(w: Int, h: Int)
    external fun draw()
    external fun orbit(dx: Float, dy: Float)
    external fun zoom(factor: Float)
    external fun addCube()
    external fun pickAt(x: Float, y: Float): Int
    external fun moveSelected(dx: Float, dy: Float, dz: Float): Boolean
    external fun undo(): Boolean
    external fun redo(): Boolean
    external fun objectCount(): Int
    external fun save(path: String): Boolean
    external fun load(path: String): Boolean
}
