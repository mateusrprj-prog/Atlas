// Versioned text project format with atomic save (write temp, then rename).
#pragma once
#include <cstdio>
#include <fstream>
#include <sstream>
#include <string>
#include "scene.hpp"

namespace atlas {

constexpr int kProjectVersion = 1;

inline bool saveProject(const Scene& s, const std::string& path) {
    const std::string tmp = path + ".tmp";
    {
        std::ofstream f(tmp, std::ios::trunc);
        if (!f) return false;
        f << "ATLAS " << kProjectVersion << "\n";
        f << "next " << s.nextId << "\n";
        for (const auto& o : s.objects)
            f << "cube " << o.id << " " << o.pos[0] << " " << o.pos[1] << " " << o.pos[2] << " "
              << o.scale[0] << " " << o.scale[1] << " " << o.scale[2] << "\n";
        f << "end\n";
        f.flush();
        if (!f) { std::remove(tmp.c_str()); return false; }
    }
    return std::rename(tmp.c_str(), path.c_str()) == 0;
}

// Loads into `out` only if the whole file is valid; otherwise `out` is untouched.
inline bool loadProject(Scene& out, const std::string& path, std::string* err = nullptr) {
    std::ifstream f(path);
    if (!f) { if (err) *err = "cannot open file"; return false; }
    std::string tag; int ver = 0;
    if (!(f >> tag >> ver) || tag != "ATLAS") { if (err) *err = "not an Atlas project"; return false; }
    if (ver > kProjectVersion) { if (err) *err = "project is newer than this app"; return false; }
    Scene tmp; bool ended = false; std::string word;
    while (f >> word) {
        if (word == "next") { if (!(f >> tmp.nextId)) { if (err) *err = "bad header"; return false; } }
        else if (word == "cube") {
            Object o;
            if (!(f >> o.id >> o.pos[0] >> o.pos[1] >> o.pos[2] >> o.scale[0] >> o.scale[1] >> o.scale[2])) {
                if (err) *err = "corrupt object record"; return false;
            }
            o.name = "Cube." + std::to_string(o.id);
            tmp.objects.push_back(o);
        } else if (word == "end") { ended = true; break; }
        else { if (err) *err = "unknown record: " + word; return false; }
    }
    if (!ended) { if (err) *err = "truncated file"; return false; }
    out.objects = tmp.objects; out.nextId = tmp.nextId; out.selected = 0; out.clearHistory();
    return true;
}

}  // namespace atlas
