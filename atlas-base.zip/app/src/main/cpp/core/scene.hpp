// Atlas core: scene model + command-based undo/redo. Platform independent.
#pragma once
#include <cstdint>
#include <memory>
#include <string>
#include <vector>

namespace atlas {

struct Object {
    uint32_t id = 0;
    std::string name;
    float pos[3] = {0, 0, 0};
    float scale[3] = {1, 1, 1};
};

class Scene;
struct Command {
    virtual ~Command() = default;
    virtual void apply(Scene&) = 0;
    virtual void revert(Scene&) = 0;
};

class Scene {
public:
    std::vector<Object> objects;
    uint32_t nextId = 1;
    uint32_t selected = 0;  // 0 = none

    Object* find(uint32_t id) {
        for (auto& o : objects) if (o.id == id) return &o;
        return nullptr;
    }
    void execute(std::unique_ptr<Command> c) {
        c->apply(*this);
        undoStack.push_back(std::move(c));
        redoStack.clear();
    }
    bool undo() {
        if (undoStack.empty()) return false;
        undoStack.back()->revert(*this);
        redoStack.push_back(std::move(undoStack.back()));
        undoStack.pop_back();
        return true;
    }
    bool redo() {
        if (redoStack.empty()) return false;
        redoStack.back()->apply(*this);
        undoStack.push_back(std::move(redoStack.back()));
        redoStack.pop_back();
        return true;
    }
    void clearHistory() { undoStack.clear(); redoStack.clear(); }
    size_t undoDepth() const { return undoStack.size(); }

private:
    std::vector<std::unique_ptr<Command>> undoStack, redoStack;
};

struct AddObjectCmd : Command {
    Object obj;
    explicit AddObjectCmd(Object o) : obj(std::move(o)) {}
    void apply(Scene& s) override { s.objects.push_back(obj); s.selected = obj.id; }
    void revert(Scene& s) override {
        for (size_t i = 0; i < s.objects.size(); ++i)
            if (s.objects[i].id == obj.id) { s.objects.erase(s.objects.begin() + i); break; }
        if (s.selected == obj.id) s.selected = 0;
    }
};

struct MoveCmd : Command {
    uint32_t id; float from[3], to[3];
    MoveCmd(uint32_t i, const float* f, const float* t) : id(i) {
        for (int k = 0; k < 3; ++k) { from[k] = f[k]; to[k] = t[k]; }
    }
    void apply(Scene& s) override { if (auto* o = s.find(id)) for (int k = 0; k < 3; ++k) o->pos[k] = to[k]; }
    void revert(Scene& s) override { if (auto* o = s.find(id)) for (int k = 0; k < 3; ++k) o->pos[k] = from[k]; }
};

inline uint32_t addCube(Scene& s, float x, float y, float z) {
    Object o;
    o.id = s.nextId++;
    o.name = "Cube." + std::to_string(o.id);
    o.pos[0] = x; o.pos[1] = y; o.pos[2] = z;
    uint32_t id = o.id;
    s.execute(std::make_unique<AddObjectCmd>(std::move(o)));
    return id;
}

inline bool moveSelected(Scene& s, float dx, float dy, float dz) {
    Object* o = s.find(s.selected);
    if (!o) return false;
    float to[3] = {o->pos[0] + dx, o->pos[1] + dy, o->pos[2] + dz};
    s.execute(std::make_unique<MoveCmd>(o->id, o->pos, to));
    return true;
}

// Ray vs axis-aligned unit cube (half-extent 0.5 * scale). Returns hit distance or -1.
inline float rayHitObject(const Object& o, const float* org, const float* dir) {
    float tmin = 0, tmax = 1e30f;
    for (int a = 0; a < 3; ++a) {
        float h = 0.5f * o.scale[a], lo = o.pos[a] - h, hi = o.pos[a] + h;
        if (dir[a] > -1e-8f && dir[a] < 1e-8f) {
            if (org[a] < lo || org[a] > hi) return -1;
        } else {
            float t1 = (lo - org[a]) / dir[a], t2 = (hi - org[a]) / dir[a];
            if (t1 > t2) { float t = t1; t1 = t2; t2 = t; }
            if (t1 > tmin) tmin = t1;
            if (t2 < tmax) tmax = t2;
            if (tmin > tmax) return -1;
        }
    }
    return tmin;
}

inline uint32_t pick(const Scene& s, const float* org, const float* dir) {
    uint32_t best = 0; float bd = 1e30f;
    for (const auto& o : s.objects) {
        float d = rayHitObject(o, org, dir);
        if (d >= 0 && d < bd) { bd = d; best = o.id; }
    }
    return best;
}

}  // namespace atlas
