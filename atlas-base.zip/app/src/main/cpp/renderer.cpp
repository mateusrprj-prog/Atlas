#include "renderer.hpp"
#include <GLES3/gl3.h>
#include <cmath>
#include <vector>

namespace atlas {
namespace {
const char* kVS = R"(#version 300 es
layout(location=0) in vec3 aPos;
uniform mat4 uVP; uniform mat4 uModel;
out vec3 vWorld;
void main(){ vec4 w = uModel*vec4(aPos,1.0); vWorld = w.xyz; gl_Position = uVP*w; })";
const char* kFS = R"(#version 300 es
precision mediump float;
in vec3 vWorld; uniform vec4 uColor; uniform float uLit; out vec4 o;
void main(){
  if(uLit < 0.5){ o = uColor; return; }
  vec3 n = normalize(cross(dFdx(vWorld), dFdy(vWorld)));
  float d = 0.35 + 0.65*max(dot(n, normalize(vec3(0.4,0.9,0.6))), 0.0);
  o = vec4(uColor.rgb*d, 1.0); })";

unsigned compile(GLenum t, const char* src) {
    unsigned s = glCreateShader(t); glShaderSource(s, 1, &src, nullptr); glCompileShader(s); return s;
}
void mul(const float* a, const float* b, float* r) {  // column-major r = a*b
    for (int c = 0; c < 4; ++c) for (int rI = 0; rI < 4; ++rI) {
        float v = 0; for (int k = 0; k < 4; ++k) v += a[k * 4 + rI] * b[c * 4 + k]; r[c * 4 + rI] = v;
    }
}
}  // namespace

void Camera::eye(float* e) const {
    e[0] = target[0] + dist * std::cos(pitch) * std::sin(yaw);
    e[1] = target[1] + dist * std::sin(pitch);
    e[2] = target[2] + dist * std::cos(pitch) * std::cos(yaw);
}
void Camera::basis(float* f, float* r, float* u) const {
    float e[3]; eye(e);
    float l = 0; for (int i = 0; i < 3; ++i) { f[i] = target[i] - e[i]; l += f[i] * f[i]; }
    l = std::sqrt(l); for (int i = 0; i < 3; ++i) f[i] /= l;
    r[0] = f[1] * 0 - f[2] * 1; r[1] = f[2] * 0 - f[0] * 0; r[2] = f[0] * 1 - f[1] * 0;  // f x up(0,1,0)
    float rl = std::sqrt(r[0] * r[0] + r[1] * r[1] + r[2] * r[2]);
    for (int i = 0; i < 3; ++i) r[i] /= rl;
    u[0] = r[1] * f[2] - r[2] * f[1]; u[1] = r[2] * f[0] - r[0] * f[2]; u[2] = r[0] * f[1] - r[1] * f[0];
}

void Renderer::screenRay(float px, float py, float* org, float* dir) const {
    float f[3], r[3], u[3]; cam.basis(f, r, u); cam.eye(org);
    float nx = (2.f * px / width - 1.f), ny = (1.f - 2.f * py / height);
    float t = std::tan(cam.fovY * 0.5f), l = 0;
    for (int i = 0; i < 3; ++i) { dir[i] = f[i] + r[i] * nx * t * cam.aspect + u[i] * ny * t; l += dir[i] * dir[i]; }
    l = std::sqrt(l); for (int i = 0; i < 3; ++i) dir[i] /= l;
}

void Renderer::init() {
    unsigned vs = compile(GL_VERTEX_SHADER, kVS), fs = compile(GL_FRAGMENT_SHADER, kFS);
    prog = glCreateProgram(); glAttachShader(prog, vs); glAttachShader(prog, fs); glLinkProgram(prog);
    uVP = glGetUniformLocation(prog, "uVP"); uModel = glGetUniformLocation(prog, "uModel");
    uColor = glGetUniformLocation(prog, "uColor"); uLit = glGetUniformLocation(prog, "uLit");
    // Unit cube, 36 vertices (triangles).
    const float p[8][3] = {{-.5f,-.5f,-.5f},{.5f,-.5f,-.5f},{.5f,.5f,-.5f},{-.5f,.5f,-.5f},
                           {-.5f,-.5f,.5f},{.5f,-.5f,.5f},{.5f,.5f,.5f},{-.5f,.5f,.5f}};
    const int idx[36] = {0,2,1,0,3,2, 4,5,6,4,6,7, 0,1,5,0,5,4, 3,6,2,3,7,6, 0,4,7,0,7,3, 1,2,6,1,6,5};
    std::vector<float> cube; for (int i : idx) cube.insert(cube.end(), p[i], p[i] + 3);
    glGenBuffers(1, &cubeVbo); glBindBuffer(GL_ARRAY_BUFFER, cubeVbo);
    glBufferData(GL_ARRAY_BUFFER, cube.size() * 4, cube.data(), GL_STATIC_DRAW);
    // Grid (lines on XZ plane) + 3 axis lines appended at the end.
    std::vector<float> l;
    for (int i = -10; i <= 10; ++i) {
        l.insert(l.end(), {(float)i, 0, -10, (float)i, 0, 10, -10, 0, (float)i, 10, 0, (float)i});
    }
    lineCount = (int)l.size() / 3;
    l.insert(l.end(), {0,0,0, 3,0,0, 0,0,0, 0,3,0, 0,0,0, 0,0,3});
    glGenBuffers(1, &lineVbo); glBindBuffer(GL_ARRAY_BUFFER, lineVbo);
    glBufferData(GL_ARRAY_BUFFER, l.size() * 4, l.data(), GL_STATIC_DRAW);
    glEnable(GL_DEPTH_TEST); glClearColor(0.16f, 0.17f, 0.19f, 1);
}

void Renderer::resize(int w, int h) { width = w > 0 ? w : 1; height = h > 0 ? h : 1; cam.aspect = (float)width / height; glViewport(0, 0, w, h); }

void Renderer::draw(const Scene& s) {
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);
    glUseProgram(prog);
    float e[3], f[3], r[3], u[3]; cam.eye(e); cam.basis(f, r, u);
    float V[16] = {r[0], u[0], -f[0], 0, r[1], u[1], -f[1], 0, r[2], u[2], -f[2], 0,
                   -(r[0]*e[0]+r[1]*e[1]+r[2]*e[2]), -(u[0]*e[0]+u[1]*e[1]+u[2]*e[2]), (f[0]*e[0]+f[1]*e[1]+f[2]*e[2]), 1};
    float n = 0.1f, fa = 200.f, t = 1.f / std::tan(cam.fovY * 0.5f);
    float P[16] = {t / cam.aspect, 0, 0, 0, 0, t, 0, 0, 0, 0, -(fa + n) / (fa - n), -1, 0, 0, -2 * fa * n / (fa - n), 0};
    float VP[16]; mul(P, V, VP);
    glUniformMatrix4fv(uVP, 1, GL_FALSE, VP);
    float I[16] = {1,0,0,0, 0,1,0,0, 0,0,1,0, 0,0,0,1};
    glUniformMatrix4fv(uModel, 1, GL_FALSE, I);
    glUniform1f(uLit, 0.f);
    glEnableVertexAttribArray(0);
    glBindBuffer(GL_ARRAY_BUFFER, lineVbo); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
    glUniform4f(uColor, 0.35f, 0.36f, 0.4f, 1); glDrawArrays(GL_LINES, 0, lineCount);
    glUniform4f(uColor, 0.9f, 0.25f, 0.25f, 1); glDrawArrays(GL_LINES, lineCount, 2);
    glUniform4f(uColor, 0.3f, 0.85f, 0.3f, 1); glDrawArrays(GL_LINES, lineCount + 2, 2);
    glUniform4f(uColor, 0.3f, 0.5f, 0.95f, 1); glDrawArrays(GL_LINES, lineCount + 4, 2);
    glBindBuffer(GL_ARRAY_BUFFER, cubeVbo); glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 0, nullptr);
    glUniform1f(uLit, 1.f);
    for (const auto& o : s.objects) {
        float M[16] = {o.scale[0],0,0,0, 0,o.scale[1],0,0, 0,0,o.scale[2],0, o.pos[0],o.pos[1],o.pos[2],1};
        glUniformMatrix4fv(uModel, 1, GL_FALSE, M);
        if (o.id == s.selected) glUniform4f(uColor, 1.0f, 0.6f, 0.15f, 1); else glUniform4f(uColor, 0.7f, 0.7f, 0.75f, 1);
        glDrawArrays(GL_TRIANGLES, 0, 36);
    }
}
}  // namespace atlas
