#pragma once
#include "scene.hpp"
namespace atlas {
struct Camera {
    float yaw = 0.7f, pitch = 0.5f, dist = 8.f, target[3] = {0, 0, 0};
    float fovY = 0.9f, aspect = 1.f;
    void eye(float* e) const;
    void basis(float* fwd, float* right, float* up) const;
};
class Renderer {
public:
    void init();
    void resize(int w, int h);
    void draw(const Scene& s);
    Camera cam;
    int width = 1, height = 1;
    // Ray through a screen pixel (origin + normalized direction).
    void screenRay(float px, float py, float* org, float* dir) const;
private:
    unsigned prog = 0, cubeVbo = 0, lineVbo = 0;
    int lineCount = 0;
    int uVP = -1, uModel = -1, uColor = -1, uLit = -1;
};
}
