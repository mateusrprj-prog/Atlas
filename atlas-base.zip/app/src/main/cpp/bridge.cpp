#include <jni.h>
#include <string>
#include "core/project_io.hpp"
#include "renderer.hpp"

static atlas::Scene gScene;
static atlas::Renderer gRenderer;

extern "C" {
#define FN(name) JNIEXPORT auto JNICALL Java_dev_atlas_NativeBridge_##name
FN(init)(JNIEnv*, jobject) -> void { gRenderer.init(); }
FN(resize)(JNIEnv*, jobject, jint w, jint h) -> void { gRenderer.resize(w, h); }
FN(draw)(JNIEnv*, jobject) -> void { gRenderer.draw(gScene); }
FN(orbit)(JNIEnv*, jobject, jfloat dx, jfloat dy) -> void {
    gRenderer.cam.yaw -= dx * 0.01f;
    gRenderer.cam.pitch += dy * 0.01f;
    if (gRenderer.cam.pitch > 1.5f) gRenderer.cam.pitch = 1.5f;
    if (gRenderer.cam.pitch < -1.5f) gRenderer.cam.pitch = -1.5f;
}
FN(zoom)(JNIEnv*, jobject, jfloat factor) -> void {
    gRenderer.cam.dist /= factor;
    if (gRenderer.cam.dist < 1.f) gRenderer.cam.dist = 1.f;
    if (gRenderer.cam.dist > 80.f) gRenderer.cam.dist = 80.f;
}
FN(addCube)(JNIEnv*, jobject) -> void { atlas::addCube(gScene, (float)(gScene.objects.size() % 5) * 1.5f - 3.f, 0.5f, 0.f); }
FN(pickAt)(JNIEnv*, jobject, jfloat x, jfloat y) -> jint {
    float o[3], d[3]; gRenderer.screenRay(x, y, o, d);
    gScene.selected = atlas::pick(gScene, o, d);
    return (jint)gScene.selected;
}
FN(moveSelected)(JNIEnv*, jobject, jfloat dx, jfloat dy, jfloat dz) -> jboolean { return atlas::moveSelected(gScene, dx, dy, dz); }
FN(undo)(JNIEnv*, jobject) -> jboolean { return gScene.undo(); }
FN(redo)(JNIEnv*, jobject) -> jboolean { return gScene.redo(); }
FN(objectCount)(JNIEnv*, jobject) -> jint { return (jint)gScene.objects.size(); }
FN(save)(JNIEnv* env, jobject, jstring path) -> jboolean {
    const char* p = env->GetStringUTFChars(path, nullptr);
    bool ok = atlas::saveProject(gScene, p); env->ReleaseStringUTFChars(path, p); return ok;
}
FN(load)(JNIEnv* env, jobject, jstring path) -> jboolean {
    const char* p = env->GetStringUTFChars(path, nullptr);
    bool ok = atlas::loadProject(gScene, p); env->ReleaseStringUTFChars(path, p); return ok;
}
}
