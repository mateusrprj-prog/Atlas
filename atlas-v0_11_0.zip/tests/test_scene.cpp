#include <cassert>
#include <limits>
#include <map>
#include <set>
#include <cstdio>
#include "../app/src/main/cpp/core/project_io.hpp"
using namespace atlas;

static void checkOutward(const Mesh& m) {
    assert(validMesh(m));
    for (const auto& fc : m.f) {
        Vec3 c; for (int i : fc) c = c + m.v[i]; c = c * (1.f / fc.size());
        assert(dot(faceNormal(m, fc), c) > 0);  // normals point away from the origin
    }
}

// ---- helpers for 0.7.0 tests ----
static double signedVolume(const Mesh& m) {   // divergence theorem over a fan triangulation (positive when normals point outward)
    double vol = 0;
    for (const auto& fc : m.f) for (size_t k = 1; k + 1 < fc.size(); ++k) {
        const Vec3 &a = m.v[fc[0]], &b = m.v[fc[k]], &c = m.v[fc[k + 1]];
        vol += ((double)a.x * ((double)b.y * c.z - (double)b.z * c.y) - (double)a.y * ((double)b.x * c.z - (double)b.z * c.x) + (double)a.z * ((double)b.x * c.y - (double)b.y * c.x)) / 6.0;
    }
    return vol;
}
static bool closedManifold(const Mesh& m, int* edgesOut = nullptr) {   // every directed edge appears once and has its reverse
    std::map<std::pair<int, int>, int> d;
    for (const auto& fc : m.f) for (size_t k = 0; k < fc.size(); ++k) ++d[{fc[k], fc[(k + 1) % fc.size()]}];
    int edges = 0;
    for (auto& kv : d) { if (kv.second != 1 || !d.count({kv.first.second, kv.first.first})) return false; ++edges; }
    if (edgesOut) *edgesOut = edges / 2;
    return true;
}
static bool near(float a, float b, float e = 1e-4f) { return std::fabs(a - b) < e; }

int main() {
    // primitives
    checkOutward(makeCube()); checkOutward(makeCylinder()); checkOutward(makeUVSphere());
    assert(makeCube().v.size() == 8 && makeCube().f.size() == 6);

    // object add / transform / undo / redo
    Scene s; uint32_t a = addPrimitive(s, 0);
    assert(s.objects.size() == 1 && s.selected == a && s.objects[0].name == "Cube");
    uint32_t b = addPrimitive(s, 0); assert(s.find(b)->name == "Cube.001");
    Xf x = getXf(*s.find(a)); x.pos[0] = 3; x.rot[2] = 90; assert(s.selected == b);
    s.selected = a; assert(setObjectTransform(s, x));
    assert(s.find(a)->pos[0] == 3); assert(s.undo()); assert(s.find(a)->pos[0] == 0); assert(s.redo()); assert(s.find(a)->rot[2] == 90);

    // picking respects rotation/scale/translation
    Scene p; uint32_t c1 = addPrimitive(p, 0); uint32_t c2 = addPrimitive(p, 0);
    p.find(c2)->pos[1] = -6;   // behind c1 along the ray from +y? ray goes -y from y=+10
    Vec3 org{0, 10, 0}, dir{0, -1, 0};
    assert(pickObject(p, org, dir) == c1);
    Vec3 miss{5, 10, 0}; assert(pickObject(p, miss, dir) == 0);
    p.find(c1)->scale[0] = 6; assert(pickObject(p, miss, dir) == c1);  // scaled object now hit

    // edit mode: extrude a face, undo restores exact mesh
    Scene e; uint32_t id = addPrimitive(e, 0); assert(setEditMode(e, true)); assert(setSelectMode(e, 2));
    Mesh original = e.find(id)->mesh;
    int topFace = pickActiveFace(e, Vec3{0, 0, 10}, Vec3{0, 0, -1}); assert(topFace == 1);
    e.toggleFace(topFace);
    assert(extrudeSelected(e, 0.5f));
    const Mesh& m = e.find(id)->mesh;
    assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m));
    for (const auto& fc : m.f) { Vec3 n = faceNormal(m, fc); assert(length(n) > 0.99f); }
    float maxz = -9; for (auto& v : m.v) maxz = std::max(maxz, v.z); assert(std::fabs(maxz - 1.5f) < 1e-5f);
    assert(e.undo()); assert(sameMesh(e.find(id)->mesh, original));
    assert(e.redo()); assert(e.find(id)->mesh.f.size() == 10);
    assert(deleteSelection(e)); assert(e.find(id)->mesh.f.size() == 9 && validMesh(e.find(id)->mesh));
    assert(e.undo()); assert(e.find(id)->mesh.f.size() == 10);

    // undoing the creation while in edit mode leaves a consistent state
    Scene g; addPrimitive(g, 3); setEditMode(g, true); g.undo();
    assert(g.objects.empty() && !g.editMode && g.selected == 0);

    // delete / duplicate
    Scene d; addPrimitive(d, 2); assert(duplicateSelected(d) != 0 && d.objects.size() == 2);
    assert(deleteSelectedObject(d) && d.objects.size() == 1); assert(d.undo() && d.objects.size() == 2);

    // project round trip (v2)
    assert(saveProject(e, "/tmp/atlas_t2.atlas"));
    Scene q; assert(loadProject(q, "/tmp/atlas_t2.atlas"));
    assert(q.objects.size() == 1 && sameMesh(q.objects[0].mesh, e.objects[0].mesh) && q.nextId == e.nextId);

    // v1 migration + invalid files leave the scene untouched
    FILE* f1 = fopen("/tmp/atlas_v1.atlas", "w"); fputs("ATLAS 1\nnext 2\ncube 1 1 2 3 1 1 1\nend\n", f1); fclose(f1);
    Scene m1; assert(loadProject(m1, "/tmp/atlas_v1.atlas") && m1.objects.size() == 1);
    assert(m1.objects[0].pos[0] == 1 && m1.objects[0].pos[1] == -3 && m1.objects[0].pos[2] == 2);
    FILE* f2 = fopen("/tmp/atlas_bad.atlas", "w"); fputs("ATLAS 2\nnext 3\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 9\nend\n", f2); fclose(f2);
    Scene r; addPrimitive(r, 0); std::string err;
    assert(!loadProject(r, "/tmp/atlas_bad.atlas", &err)); assert(r.objects.size() == 1);
    // ================= v0.3: element selection and new modeling ops =================
    puts("v0.3 tests...");
    // closed-manifold check: every directed edge appears exactly once and so does its reverse
    auto closed = [](const Mesh& m) {
        std::map<std::pair<int, int>, int> c;
        for (const auto& fc : m.f) for (size_t i = 0; i < fc.size(); ++i) c[{fc[i], fc[(i + 1) % fc.size()]}]++;
        for (auto& kv : c) if (kv.second != 1 || c.count({kv.first.second, kv.first.first}) != 1) return false;
        return true;
    };
    auto totalArea = [](const Mesh& m) { float a = 0; for (auto& fc : m.f) a += faceArea(m, fc); return a; };
    assert(closed(makeCube()) && closed(makeCylinder()) && closed(makeUVSphere()));
    assert(std::fabs(totalArea(makeCube()) - 24.f) < 1e-4f);

    // selection mode conversion: face -> vertex -> edge -> face round trip on the cube's top face
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(setSelectMode(c, 0) && c.sel.mode == 0 && c.sel.v == std::set<int>({4, 5, 6, 7}) && c.sel.f.empty());
        assert(setSelectMode(c, 1) && c.sel.e.size() == 4 && c.sel.v.empty());
        assert(setSelectMode(c, 2) && c.sel.f == std::set<int>({1}));
        // two lone vertices are not enough for a face
        setSelectMode(c, 0); c.sel.v = {4, 5}; assert(setSelectMode(c, 2) && c.sel.f.empty());
        // invert / select all
        setSelectMode(c, 2); c.sel.clearSets(); selectAllActive(c); assert(c.sel.f.size() == 6);
        invertActive(c); assert(c.sel.f.empty()); (void)cid;
    }

    // picking vertices / edges with occlusion
    {
        Scene c; addPrimitive(c, 0); setEditMode(c, true);
        float tol = 0.02f; Vec3 eye{3, 3, 3};
        assert(pickActiveVertex(c, eye, normalized(Vec3{-1, -1, -1}), tol) == 6);       // front corner, not the hidden one behind it
        assert(pickActiveVertex(c, eye, normalized(Vec3{-1, 0.2f, -1}), tol) == -1);      // empty space
        Edge ed; Vec3 e2{0, -5, 5};
        assert(pickActiveEdge(c, e2, normalized(Vec3{0, 4, -4}), tol, &ed) && ed == mkEdge(4, 5));
        assert(!pickActiveEdge(c, Vec3{0, -5, 5}, normalized(Vec3{0, 1, 0.2f}), 0.001f, &ed));
    }

    // extrude edges of a plane (boundary edge) -> strip of quads, new edge selected, exact undo
    {
        Scene c; uint32_t pid = addPrimitive(c, 1); setEditMode(c, true); setSelectMode(c, 1);
        Mesh orig = c.find(pid)->mesh; c.toggleEdge(mkEdge(0, 1));
        assert(extrudeSelected(c, 0.5f));
        const Mesh& m = c.find(pid)->mesh;
        assert(m.v.size() == 6 && m.f.size() == 2 && validMesh(m));
        assert(m.v[4].z == 0.5f && m.v[5].z == 0.5f && c.sel.e.size() == 1 && *c.sel.e.begin() == mkEdge(4, 5));
        assert(c.undo() && sameMesh(c.find(pid)->mesh, orig) && c.sel.e.count(mkEdge(0, 1)) == 1);  // selection restored too
        assert(c.redo() && c.find(pid)->mesh.f.size() == 2);
        assert(!extrudeSelected(c, 0.f));
    }
    // extrude from vertex mode: 4 verts of a face extrude as a face; 2 verts extrude as an edge
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0);
        c.sel.v = {4, 5, 6, 7}; assert(extrudeSelected(c, 1.f));
        const Mesh& m = c.find(cid)->mesh; assert(m.v.size() == 12 && m.f.size() == 10 && closed(m) && c.sel.v.size() == 4);
        float maxz = -9; for (auto& v : m.v) maxz = std::max(maxz, v.z); assert(std::fabs(maxz - 2.f) < 1e-5f);
        setSelectMode(c, 0); c.sel.v = {0, 1}; assert(extrudeSelected(c, 0.3f)); assert(c.find(cid)->mesh.f.size() == 11);
    }
    // delete vertices / edges
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0);
        c.sel.v = {0}; assert(deleteSelection(c)); const Mesh& m = c.find(cid)->mesh;   // 3 faces touch a corner
        assert(m.f.size() == 3 && validMesh(m) && c.sel.v.empty()); assert(c.undo() && c.find(cid)->mesh.f.size() == 6 && c.sel.v.count(0));
        setSelectMode(c, 1); c.sel.clearSets(); c.toggleEdge(mkEdge(0, 1)); assert(deleteSelection(c) && c.find(cid)->mesh.f.size() == 4);
    }
    // inset: ring of quads, inner face keeps its index and orientation, area drops as expected
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(!insetSelected(c, 0.f) && !insetSelected(c, 1.f));
        assert(insetSelected(c, 0.5f)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m) && closed(m) && c.sel.f == std::set<int>({1}));
        assert(std::fabs(faceArea(m, m.f[1]) - 1.f) < 1e-5f);           // 2x2 face scaled by 0.5 -> 1x1
        assert(std::fabs(totalArea(m) - (20.f + 1.f + 3.f)) < 1e-4f);   // 5 untouched faces (20) + inner (1) + ring (4-1=3)
        assert(dot(faceNormal(m, m.f[1]), Vec3{0, 0, 1}) > 0.99f);
    }
    // subdivide: watertight, area preserved, neighbours get the new midpoints
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(subdivideSelected(c)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 13 && m.f.size() == 9 && validMesh(m) && closed(m) && c.sel.f.size() == 4);
        assert(std::fabs(totalArea(m) - 24.f) < 1e-4f);
        for (const auto& fc : m.f) assert(dot(faceNormal(m, fc), Vec3{0, 0, 0}) == 0 && length(faceNormal(m, fc)) > 0.99f);
        assert(subdivideSelected(c) && closed(c.find(cid)->mesh) && std::fabs(totalArea(c.find(cid)->mesh) - 24.f) < 1e-3f);  // repeatable
        assert(c.undo() && c.undo() && sameMesh(c.find(cid)->mesh, makeCube()));
    }
    // merge at center collapses a face into a vertex (cube -> pyramid-like, 5 verts / 5 faces)
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0); c.sel.v = {4, 5, 6, 7};
        assert(mergeSelectedAtCenter(c)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 5 && m.f.size() == 5 && validMesh(m) && closed(m) && c.sel.v.size() == 1);
        int tip = *c.sel.v.begin(); assert(std::fabs(m.v[tip].z - 1.f) < 1e-6f && std::fabs(m.v[tip].x) < 1e-6f);
        assert(!mergeSelectedAtCenter(c));   // one vertex is nothing to merge
    }
    // flip normals
    {
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 2); c.toggleFace(1);
        assert(flipSelectedFaces(c)); assert(dot(faceNormal(c.find(cid)->mesh, c.find(cid)->mesh.f[1]), Vec3{0, 0, 1}) < -0.99f);
        assert(c.undo() && sameMesh(c.find(cid)->mesh, makeCube()));
    }
    // edit-mode transforms about the pivot
    {
        Mesh m = makeCube(); std::vector<char> top(8, 0); for (int i = 4; i < 8; ++i) top[i] = 1;
        assert(moveVertices(m, top, Vec3{0, 0, 2}) && m.v[4].z == 3.f && m.v[0].z == -1.f);
        assert(scaleVertices(m, top, Vec3{0.5f, 0.5f, 1.f}) && std::fabs(m.v[6].x - 0.5f) < 1e-6f && m.v[6].z == 3.f);
        assert(rotateVertices(m, top, 2, 90.f) && std::fabs(m.v[6].x + 0.5f) < 1e-5f && std::fabs(m.v[6].y - 0.5f) < 1e-5f);
        std::vector<char> none(8, 0); assert(!moveVertices(m, none, Vec3{1, 0, 0}) && !rotateVertices(m, none, 0, 10.f));
    }
    // history keeps selection valid after the object is removed
    {
        Scene c; addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 0); c.sel.v = {0, 1};
        c.undo(); assert(c.sel.v.empty() && !c.editMode);
    }

    // ================= v0.4: loop cut + edge loops =================
    puts("v0.4 tests...");
    {   // cube: ring of 4 quads is cut at x=-0.5 for EVERY ring edge (direction stays consistent)
        Scene c; uint32_t cid = addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 1); c.toggleEdge(mkEdge(0, 1));
        assert(!loopCutSelected(c, 0.f) && !loopCutSelected(c, 1.f));
        assert(loopCutSelected(c, 0.25f)); const Mesh& m = c.find(cid)->mesh;
        assert(m.v.size() == 12 && m.f.size() == 10 && validMesh(m) && closed(m) && c.sel.e.size() == 4);
        for (size_t i = 8; i < 12; ++i) assert(std::fabs(m.v[i].x + 0.5f) < 1e-6f);
        assert(std::fabs(totalArea(m) - 24.f) < 1e-4f);
        assert(c.undo() && sameMesh(c.find(cid)->mesh, makeCube()) && c.sel.e.count(mkEdge(0, 1)));
        // vertex mode: two verts forming an edge work too
        setSelectMode(c, 0); c.sel.clearSets(); c.sel.v = {0, 1}; assert(loopCutSelected(c, 0.5f) && c.sel.v.size() == 4);
    }
    {   // plane: open ring of one quad
        Scene c; uint32_t pid = addPrimitive(c, 1); setEditMode(c, true); setSelectMode(c, 1); c.toggleEdge(mkEdge(0, 1));
        assert(loopCutSelected(c, 0.5f) && c.find(pid)->mesh.v.size() == 6 && c.find(pid)->mesh.f.size() == 2);
    }
    {   // sphere: closed ring around the body, and an open ring ending in cap triangles stays watertight
        Scene c; uint32_t sid = addPrimitive(c, 3); setEditMode(c, true); setSelectMode(c, 1);
        c.toggleEdge(mkEdge(1, 17)); assert(loopCutSelected(c, 0.5f)); assert(c.find(sid)->mesh.v.size() == makeUVSphere().v.size() + 16);
        assert(closed(c.find(sid)->mesh) && std::fabs(totalArea(c.find(sid)->mesh) - totalArea(makeUVSphere())) < 1e-3f);
        Scene d; uint32_t did = addPrimitive(d, 3); setEditMode(d, true); setSelectMode(d, 1);
        d.toggleEdge(mkEdge(1, 2)); assert(loopCutSelected(d, 0.5f)); assert(closed(d.find(did)->mesh) && validMesh(d.find(did)->mesh));
    }
    {   // edge loops on a 4x4 grid (plane subdivided twice): centre line has 4 edges; corner-ish edge stays short
        Scene c; uint32_t pid = addPrimitive(c, 1); setEditMode(c, true); setSelectMode(c, 2);
        selectAllActive(c); assert(subdivideSelected(c)); assert(subdivideSelected(c));
        const Mesh& m = c.find(pid)->mesh; assert(m.f.size() == 16);
        setSelectMode(c, 1); c.sel.clearSets();
        Edge pick{-1, -1};
        for (const auto& e : uniqueEdges(m)) if (std::fabs(m.v[e.first].y) < 1e-6f && std::fabs(m.v[e.second].y) < 1e-6f) { pick = e; break; }
        assert(pick.first >= 0); c.toggleEdge(pick);
        assert(selectLoopActive(c) && c.sel.e.size() == 4);
        for (const auto& e : c.sel.e) assert(std::fabs(m.v[e.first].y) < 1e-6f && std::fabs(m.v[e.second].y) < 1e-6f);
        c.sel.clearSets(); assert(!selectLoopActive(c));
    }
    {   // cube corner edges have valence 3, so the loop is the single edge
        Scene c; addPrimitive(c, 0); setEditMode(c, true); setSelectMode(c, 1); c.toggleEdge(mkEdge(0, 1));
        assert(selectLoopActive(c) && c.sel.e.size() == 1);
    }

    // ================= v0.5: modifier stack =================
    puts("v0.5 tests...");
    {   // mirror: open half box (cube shifted to x in [0,2] without its x=0 face) becomes a closed 4x2x2 box
        Scene c; uint32_t id = addPrimitive(c, 0); Object* o = c.find(id);
        for (auto& v : o->mesh.v) v.x += 1.f;
        assert(deleteFaces(o->mesh, {4}));          // face {0,4,7,3} lies on x=0
        o->meshRev = nextRev();
        assert(o->mesh.f.size() == 5 && o->mesh.v.size() == 8);
        assert(addModifier(c, kMirror)); assert(c.find(id)->mods.size() == 1);
        const Mesh& d = displayMesh(*c.find(id));
        assert(d.v.size() == 12 && d.f.size() == 10 && validMesh(d) && closed(d) && std::fabs(totalArea(d) - 40.f) < 1e-4f);
        float mn = 9; for (auto& v : d.v) mn = std::min(mn, v.x); assert(std::fabs(mn + 2.f) < 1e-6f);
        for (const auto& fc : d.f) { Vec3 cen; for (int i : fc) cen = cen + d.v[i]; cen = cen * (1.f / fc.size()); assert(dot(faceNormal(d, fc), cen) > 0); }
        assert(c.find(id)->mesh.v.size() == 8);     // base mesh untouched (non destructive)
        // toggling off shows the base mesh again; on again re-evaluates
        assert(toggleModifier(c, 0)); assert(displayMesh(*c.find(id)).f.size() == 5);
        assert(toggleModifier(c, 0)); assert(displayMesh(*c.find(id)).f.size() == 10);
        // editing the base mesh updates the evaluated mesh
        c.find(id)->mesh.v[1].z += 1.f; c.find(id)->meshRev = nextRev(); assert(displayMesh(*c.find(id)).v.size() == 12);
        // apply bakes the result into the base mesh and undo restores both
        Mesh baseBefore = c.find(id)->mesh;
        assert(applyModifierAt(c, 0)); assert(c.find(id)->mods.empty() && c.find(id)->mesh.f.size() == 10 && closed(c.find(id)->mesh));
        assert(c.undo()); assert(c.find(id)->mods.size() == 1 && sameMesh(c.find(id)->mesh, baseBefore));
        assert(c.redo() && c.find(id)->mesh.f.size() == 10);
    }
    {   // array: 3 copies, offset 3 along X; stack order matters; limits
        Scene c; uint32_t id = addPrimitive(c, 0); assert(addModifier(c, kArray));
        Modifier m = c.find(id)->mods[0]; m.count = 3; m.offset[0] = 3.f; assert(setModifier(c, 0, m));
        const Mesh& d = displayMesh(*c.find(id));
        assert(d.v.size() == 24 && d.f.size() == 18 && validMesh(d) && closed(d) && std::fabs(totalArea(d) - 72.f) < 1e-3f);
        float mx = -9; for (auto& v : d.v) mx = std::max(mx, v.x); assert(std::fabs(mx - 7.f) < 1e-6f);
        // objects are pickable where the arrayed copies are, not only where the base mesh is
        assert(pickObject(c, Vec3{6, 10, 0}, Vec3{0, -1, 0}) == id);
        c.find(id)->mods[0].enabled = false; c.find(id)->modsRev = nextRev(); assert(pickObject(c, Vec3{6, 10, 0}, Vec3{0, -1, 0}) == 0);
        c.find(id)->mods[0].enabled = true; c.find(id)->modsRev = nextRev();
        Modifier bad = m; bad.count = 0; assert(!setModifier(c, 0, bad)); bad.count = 65; assert(!setModifier(c, 0, bad));
        assert(addModifier(c, kMirror) && moveModifier(c, 1, -1) && c.find(id)->mods[0].type == kMirror && !moveModifier(c, 0, -1));
        assert(removeModifier(c, 0) && c.find(id)->mods.size() == 1 && !removeModifier(c, 5));
        assert(c.undo() && c.undo() && c.undo() && c.find(id)->mods.size() == 1);   // back to the first array state (count 2)
        assert(!applyModifierAt(c, 3));
    }
    {   // project v3 round trip, v2 files still load, corrupt modifiers are rejected
        Scene c; uint32_t id = addPrimitive(c, 0); addModifier(c, kArray); Modifier m = c.find(id)->mods[0]; m.count = 4; m.offset[1] = 2.5f; setModifier(c, 0, m);
        addModifier(c, kMirror); toggleModifier(c, 1);
        assert(saveProject(c, "/tmp/atlas_t3.atlas"));
        Scene q; assert(loadProject(q, "/tmp/atlas_t3.atlas") && q.objects[0].mods.size() == 2);
        assert(q.objects[0].mods[0].count == 4 && q.objects[0].mods[0].offset[1] == 2.5f && !q.objects[0].mods[1].enabled && q.objects[0].mods[1].type == kMirror);
        assert(displayMesh(q.objects[0]).f.size() == 24);
        FILE* f = fopen("/tmp/atlas_v2.atlas", "w"); fputs("ATLAS 2\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nend\n", f); fclose(f);
        Scene o2; assert(loadProject(o2, "/tmp/atlas_v2.atlas") && o2.objects[0].mods.empty());
        f = fopen("/tmp/atlas_badmod.atlas", "w"); fputs("ATLAS 3\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nmods 1\nmod 1 1 0 0.001 0 1 0 0\nend\n", f); fclose(f);
        Scene keep; addPrimitive(keep, 0); std::string err;
        assert(!loadProject(keep, "/tmp/atlas_badmod.atlas", &err) && keep.objects.size() == 1);
        f = fopen("/tmp/atlas_nomods.atlas", "w"); fputs("ATLAS 3\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nend\n", f); fclose(f);
        assert(!loadProject(keep, "/tmp/atlas_nomods.atlas", &err) && keep.objects.size() == 1);
    }

    {   // 0.7.0: Catmull-Clark subdivision surface
        Mesh cu = makeCube(); Modifier sm; sm.type = kSubsurf; sm.levels = 1;
        Mesh l1 = applyModifier(cu, sm); int e1 = 0;
        assert(l1.v.size() == 26 && l1.f.size() == 24 && closedManifold(l1, &e1) && (int)l1.v.size() - e1 + (int)l1.f.size() == 2);
        for (const auto& fc : l1.f) assert(fc.size() == 4);
        bool foundCorner = false, foundEdge = false;
        for (const auto& v : l1.v) { if (near(v.x, 5.f / 9) && near(v.y, 5.f / 9) && near(v.z, 5.f / 9)) foundCorner = true; if (near(v.x, .75f) && near(v.y, .75f) && near(v.z, 0)) foundEdge = true; }
        assert(foundCorner && foundEdge);   // corner rule (F+2R+(n-3)P)/n and edge rule (A+B+F1+F2)/4 checked against hand-computed values
        sm.levels = 2; Mesh l2 = applyModifier(cu, sm); e1 = 0;
        assert(l2.f.size() == 96 && l2.v.size() == 98 && closedManifold(l2, &e1) && (int)l2.v.size() - e1 + (int)l2.f.size() == 2);
        assert(signedVolume(l2) > 2.0 && signedVolume(l2) < 8.0 && signedVolume(l1) < 8.0 && signedVolume(l1) > 2.0);   // smooth, shrinks the cube, outward normals
        float mx = 0; for (const auto& v : l2.v) mx = std::max(mx, std::max(std::fabs(v.x), std::max(std::fabs(v.y), std::fabs(v.z)))); assert(mx < 1.f);
        Mesh sp = makeUVSphere(); sm.levels = 1; Mesh sp1 = applyModifier(sp, sm); assert(closedManifold(sp1) && signedVolume(sp1) > 0 && sp1.f.size() > sp.f.size());
        // boundary rule: a single quad keeps a straight border and corners pull in by the B-spline rule
        Mesh pl = makePlane(); Mesh pl1 = applyModifier(pl, sm);
        assert(pl1.f.size() == 4 && pl1.v.size() == 9);
        float w0 = 0; for (const auto& v : pl.v) w0 = std::max(w0, v.x);
        bool corner = false, border = false;
        for (const auto& v : pl1.v) { if (near(v.x, -0.75f * w0) && near(v.y, -0.75f * w0)) corner = true; if (near(v.x, -w0) && near(v.y, 0)) border = true; }
        assert(corner && border);   // corner -> 0.75P + 0.125(A+B); boundary edge point stays on the border line
        for (const auto& v : pl1.v) assert(near(v.z, 0));
        // no mutation of the input, levels bounded, absurd size guarded
        assert(sameMesh(cu, makeCube()));
        Modifier bad = sm; bad.levels = 0; assert(!validModifier(bad)); bad.levels = 5; assert(!validModifier(bad));
        // stack: mirror then subsurf; object picking + display use the evaluated result; apply bakes with one undo step
        Scene c; uint32_t id = addPrimitive(c, 0); assert(addModifier(c, kSubsurf));
        assert(displayMesh(*c.find(id)).f.size() == 24);
        Modifier m = c.find(id)->mods[0]; m.levels = 3; assert(setModifier(c, 0, m) && displayMesh(*c.find(id)).f.size() == 384);
        assert(!setModifier(c, 0, m));   // no-op: no undo step
        assert(applyModifierAt(c, 0) && c.find(id)->mesh.f.size() == 384 && c.find(id)->mods.empty());
        assert(c.undo() && c.find(id)->mesh.f.size() == 6 && c.find(id)->mods.size() == 1 && c.undo() && c.find(id)->mods[0].levels == 1);
    }
    {   // 0.7.0: Solidify
        Modifier so; so.type = kSolidify; so.thickness = 0.1f; so.shift = -1.f;
        Mesh cu = makeCube(); Mesh sc = applyModifier(cu, so);
        assert(sc.v.size() == 16 && sc.f.size() == 12 && closedManifold(sc));
        // outer shell is the original cube (shift -1), inner shell is 0.1 inside on every face: volume 8 - 1.8^3
        assert(near((float)signedVolume(sc), 8.f - 1.8f * 1.8f * 1.8f, 1e-3f));
        for (int i = 0; i < 8; ++i) assert(near(sc.v[i].x, cu.v[i].x) && near(sc.v[i].y, cu.v[i].y) && near(sc.v[i].z, cu.v[i].z));
        so.shift = 1.f; Mesh out = applyModifier(cu, so); assert(near((float)signedVolume(out), 2.2f * 2.2f * 2.2f - 8.f, 1e-3f));   // grows outward, inner shell = original
        so.shift = 0.f; Mesh mid = applyModifier(cu, so); assert(near((float)signedVolume(mid), 2.1f * 2.1f * 2.1f - 1.9f * 1.9f * 1.9f, 1e-3f));
        // open mesh gets a rim: a plane becomes a closed slab of volume area * thickness
        so.shift = -1.f; so.thickness = 0.2f; Mesh pl = makePlane(); Mesh sp = applyModifier(pl, so);
        assert(sp.v.size() == 8 && sp.f.size() == 6 && closedManifold(sp));
        float w = pl.v[0].x, area = 0; for (const auto& v : pl.v) w = std::max(w, v.x); area = (2 * w) * (2 * w);
        assert(near((float)signedVolume(sp), area * 0.2f, 1e-3f));
        assert(!validModifier([&] { Modifier b = so; b.thickness = 0; return b; }()) && !validModifier([&] { Modifier b = so; b.shift = 2; return b; }()));
        // chaining with subsurf keeps the surface closed and with outward normals
        Modifier sm; sm.type = kSubsurf; sm.levels = 1; Mesh both = applyModifier(sc, sm); assert(closedManifold(both) && signedVolume(both) > 0);
        // scene: undo/redo and apply
        Scene c; uint32_t id = addPrimitive(c, 0); assert(addModifier(c, kSolidify) && c.find(id)->mods[0].thickness == 0.1f);
        Modifier m = c.find(id)->mods[0]; m.thickness = 0.3f; assert(setModifier(c, 0, m) && displayMesh(*c.find(id)).v.size() == 16);
        assert(applyModifierAt(c, 0) && c.find(id)->mesh.f.size() == 12); assert(c.undo() && c.find(id)->mesh.f.size() == 6);
    }
    {   // project v4 round trip keeps subsurf/solidify parameters; v3 files still load with defaults
        Scene c; uint32_t id = addPrimitive(c, 0); addModifier(c, kSubsurf); addModifier(c, kSolidify);
        Modifier a = c.find(id)->mods[0]; a.levels = 3; setModifier(c, 0, a);
        Modifier b = c.find(id)->mods[1]; b.thickness = 0.25f; b.shift = 0.5f; setModifier(c, 1, b);
        assert(saveProject(c, "/tmp/atlas_t4.atlas"));
        Scene q; assert(loadProject(q, "/tmp/atlas_t4.atlas") && q.objects[0].mods.size() == 2);
        assert(q.objects[0].mods[0].type == kSubsurf && q.objects[0].mods[0].levels == 3 && q.objects[0].mods[1].type == kSolidify);
        assert(near(q.objects[0].mods[1].thickness, 0.25f) && near(q.objects[0].mods[1].shift, 0.5f));
        FILE* f = fopen("/tmp/atlas_v3b.atlas", "w"); fputs("ATLAS 3\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nmods 1\nmod 0 1 0 0.001 2 1 0 0\nend\n", f); fclose(f);
        Scene o3; assert(loadProject(o3, "/tmp/atlas_v3b.atlas") && o3.objects[0].mods.size() == 1 && o3.objects[0].mods[0].levels == 1);
        f = fopen("/tmp/atlas_badv4.atlas", "w"); fputs("ATLAS 4\nnext 2\nobject 1 A 0 0 0 0 0 0 1 1 1 3 1\nv 0 0 0\nv 1 0 0\nv 0 1 0\nf 3 0 1 2\nmods 1\nmod 2 1 0 0.001 2 1 0 0 9 0.1 -1\nend\n", f); fclose(f);
        Scene keep; addPrimitive(keep, 0); std::string err; assert(!loadProject(keep, "/tmp/atlas_badv4.atlas", &err) && keep.objects.size() == 1);
    }

    {   // 0.8.0: rename, apply transform, origin to geometry, select linked
        Scene c; uint32_t a = addPrimitive(c, 0); uint32_t b = addPrimitive(c, 0); c.selected = a;
        assert(renameSelected(c, "  My Cube  ") && c.find(a)->name == "My_Cube");
        assert(!renameSelected(c, "My Cube") && !renameSelected(c, "   ") && !renameSelected(c, ""));   // same name / empty: no-op, no undo step
        assert(renameSelected(c, "Cube.001") && c.find(a)->name == "Cube" && c.find(b)->name == "Cube.001");   // clash with b -> made unique
        assert(c.undo() && c.find(a)->name == "My_Cube" && c.undo() && c.find(a)->name == "Cube" && c.redo() && c.find(a)->name == "My_Cube");
        // apply all transforms: world positions of every vertex stay, transform becomes identity, undo restores
        Scene t; uint32_t id = addPrimitive(t, 0); Xf x = getXf(*t.find(id)); x.pos[0] = 3; x.pos[1] = -1; x.rot[2] = 90; x.rot[0] = 30; x.scale[0] = 2; x.scale[2] = 0.5f;
        assert(setObjectTransform(t, x));
        std::vector<Vec3> w0; for (const auto& p : t.find(id)->mesh.v) w0.push_back(localToWorldPoint(*t.find(id), p));
        assert(applyTransformSelected(t, 0));
        const Object& o = *t.find(id);
        for (int i = 0; i < 3; ++i) assert(o.pos[i] == 0 && o.rot[i] == 0 && o.scale[i] == 1);
        for (size_t i = 0; i < w0.size(); ++i) assert(near(o.mesh.v[i].x, w0[i].x) && near(o.mesh.v[i].y, w0[i].y) && near(o.mesh.v[i].z, w0[i].z));
        assert(!applyTransformSelected(t, 0));   // already identity: no-op
        assert(t.undo() && t.find(id)->pos[0] == 3 && t.find(id)->scale[0] == 2 && near(t.find(id)->mesh.v[0].x, makeCube().v[0].x));
        assert(t.redo() && t.find(id)->pos[0] == 0);
        // scale-only bake, with a negative scale: winding is flipped so normals stay outward
        Scene n; uint32_t nid = addPrimitive(n, 0); Xf nx = getXf(*n.find(nid)); nx.scale[0] = -2; nx.scale[1] = 3; assert(setObjectTransform(n, nx));
        assert(applyTransformSelected(n, 1) && n.find(nid)->scale[0] == 1 && n.find(nid)->scale[1] == 1);
        checkOutward(n.find(nid)->mesh); assert(near((float)signedVolume(n.find(nid)->mesh), 8.f * 2 * 3, 1e-3f));
        // object mode only
        setEditMode(n, true); assert(!applyTransformSelected(n, 0) && !originToGeometry(n) && !renameSelected(n, "Zzz")); setEditMode(n, false);
        // origin to geometry: mesh recentred, geometry does not move in the world
        Scene g; uint32_t gid = addPrimitive(g, 0); Object* go = g.find(gid);
        for (auto& p : go->mesh.v) { p = p + Vec3{1, 2, 3}; }
        go->meshRev = nextRev();
        Xf gx = getXf(*go); gx.pos[0] = 5; gx.rot[2] = 90; gx.scale[0] = 2; assert(setObjectTransform(g, gx));
        std::vector<Vec3> gw; for (const auto& p : g.find(gid)->mesh.v) gw.push_back(localToWorldPoint(*g.find(gid), p));
        assert(originToGeometry(g));
        Vec3 med; for (const auto& p : g.find(gid)->mesh.v) med = med + p; assert(near(med.x, 0, 1e-4f) && near(med.y, 0, 1e-4f) && near(med.z, 0, 1e-4f));
        for (size_t i = 0; i < gw.size(); ++i) { Vec3 q = localToWorldPoint(*g.find(gid), g.find(gid)->mesh.v[i]); assert(near(q.x, gw[i].x) && near(q.y, gw[i].y) && near(q.z, gw[i].z)); }
        assert(!originToGeometry(g));   // already centred
        assert(g.undo() && near(g.find(gid)->mesh.v[0].x, makeCube().v[0].x + 1));
        // select linked: two disjoint cubes (array, baked)
        Scene l; uint32_t lid = addPrimitive(l, 0); addModifier(l, kArray); Modifier am = l.find(lid)->mods[0]; am.count = 2; am.offset[0] = 5; setModifier(l, 0, am); applyModifierAt(l, 0);
        assert(l.find(lid)->mesh.f.size() == 12 && setEditMode(l, true));
        setSelectMode(l, 2); l.sel.f = {0}; assert(selectLinkedActive(l) && l.sel.f.size() == 6 && l.sel.f.count(0) && !l.sel.f.count(6));
        setSelectMode(l, 0); l.sel.clearSets(); l.sel.v = {9}; assert(selectLinkedActive(l) && l.sel.v.size() == 8 && l.sel.v.count(9) && !l.sel.v.count(0));
        setSelectMode(l, 1); l.sel.clearSets(); l.sel.e = {mkEdge(l.find(lid)->mesh.f[0][0], l.find(lid)->mesh.f[0][1])};
        assert(selectLinkedActive(l) && l.sel.e.size() == 12);
        l.sel.clearSets(); assert(!selectLinkedActive(l));
    }
    {   // 0.9.0: Triangulate (ear clipping), Weld / Merge by Distance
        Modifier tm; tm.type = kTriangulate;
        Mesh cu = makeCube(); Mesh tc = applyModifier(cu, tm);
        assert(tc.f.size() == 12 && closedManifold(tc) && near((float)signedVolume(tc), 8.f, 1e-4f)); for (const auto& fc : tc.f) assert(fc.size() == 3);
        // concave L-shaped hexagon (area 3), both windings
        for (int flip = 0; flip < 2; ++flip) for (int rot = 0; rot < 6; ++rot) {   // every start corner, including the reflex one
            Mesh L; L.v = {{0, 0, 0}, {2, 0, 0}, {2, 1, 0}, {1, 1, 0}, {1, 2, 0}, {0, 2, 0}}; L.f = {{0, 1, 2, 3, 4, 5}};
            std::rotate(L.f[0].begin(), L.f[0].begin() + rot, L.f[0].end());
            if (flip) std::reverse(L.f[0].begin(), L.f[0].end());
            Mesh tl = triangulateMesh(L); assert(tl.f.size() == 4);
            float area = 0; for (const auto& fc : tl.f) {
                assert(fc.size() == 3);
                Vec3 a = tl.v[fc[0]], b = tl.v[fc[1]], d = tl.v[fc[2]];
                float az = ((b.x - a.x) * (d.y - a.y) - (b.y - a.y) * (d.x - a.x)) * 0.5f;
                assert(flip ? az < 0 : az > 0);   // winding of the source face is kept
                area += std::fabs(az);
            }
            assert(near(area, 3.f, 1e-4f));
        }
        // sphere keeps volume and stays closed; triangle count = sum(k-2)
        Mesh sp = makeUVSphere(); size_t expect = 0; for (const auto& fc : sp.f) expect += fc.size() - 2;
        Mesh ts = triangulateMesh(sp); assert(ts.f.size() == expect && closedManifold(ts) && near((float)signedVolume(ts), (float)signedVolume(sp), 1e-3f));
        // weld: two touching cubes share 4 vertex pairs
        Modifier am; am.type = kArray; am.count = 2; am.offset[0] = 2.f; Mesh two = applyModifier(cu, am); assert(two.v.size() == 16);
        Mesh w = two; assert(weldVertices(w, 0.001f) == 4 && w.v.size() == 12 && validMesh(w) && w.f.size() == 12);
        Mesh far = applyModifier(cu, [] { Modifier a; a.type = kArray; a.count = 2; a.offset[0] = 2.5f; return a; }()); Mesh f2 = far; assert(weldVertices(f2, 0.001f) == 0 && sameMesh(f2, far));
        std::vector<char> half(16, 0); for (int i = 0; i < 8; ++i) half[i] = 1; Mesh hm = two; assert(weldVertices(hm, 0.001f, &half) == 0);   // partners are not selected
        std::vector<char> all(16, 1); Mesh am2 = two; assert(weldVertices(am2, 0.001f, &all) == 4);
        // collapsing a tiny face drops it and leaves no stray vertices
        Mesh q; q.v = {{0, 0, 0}, {0.0004f, 0, 0}, {0.0004f, 0.0004f, 0}, {0, 0.0004f, 0}, {5, 5, 0}, {6, 5, 0}, {5, 6, 0}}; q.f = {{0, 1, 2, 3}, {4, 5, 6}};
        assert(weldVertices(q, 0.001f) == 3 && q.f.size() == 1 && q.v.size() == 3 && validMesh(q));
        // modifier in a stack: mirror then weld(0) removes nothing extra; weld as modifier on baked doubles
        Scene c; uint32_t id = addPrimitive(c, 0); addModifier(c, kArray); Modifier m = c.find(id)->mods[0]; m.count = 2; m.offset[0] = 2; setModifier(c, 0, m);
        assert(addModifier(c, kWeld) && c.find(id)->mods[1].type == kWeld && displayMesh(*c.find(id)).v.size() == 12);
        assert(addModifier(c, kTriangulate) && displayMesh(*c.find(id)).f.size() == 24);
        Modifier wm = c.find(id)->mods[1]; wm.merge = 0; assert(setModifier(c, 1, wm) && displayMesh(*c.find(id)).v.size() == 12);   // distance 0 still merges exact duplicates
        wm.merge = -1; assert(!validModifier(wm)); wm.merge = 2000; assert(!validModifier(wm));
        // edit op: Merge by Distance on the selection, one undo step
        Scene e; uint32_t eid = addPrimitive(e, 0); addModifier(e, kArray); Modifier em = e.find(eid)->mods[0]; em.count = 2; em.offset[0] = 2; setModifier(e, 0, em); applyModifierAt(e, 0);
        assert(setEditMode(e, true)); setSelectMode(e, 0); selectAllActive(e);
        assert(weldSelected(e, 0.001f) && e.find(eid)->mesh.v.size() == 12 && selectionCount(e.sel) == 0 && !weldSelected(e, 0.001f));
        assert(!weldSelected(e, -1.f) && e.undo() && e.find(eid)->mesh.v.size() == 16);
        // project round trip keeps the new modifier types and the weld distance
        addModifier(c, kWeld); Modifier w2 = c.find(id)->mods[3]; w2.merge = 0.02f; setModifier(c, 3, w2);
        assert(saveProject(c, "/tmp/atlas_t9.atlas")); Scene q2; assert(loadProject(q2, "/tmp/atlas_t9.atlas") && q2.objects[0].mods.size() == 4);
        assert(q2.objects[0].mods[2].type == kTriangulate && q2.objects[0].mods[3].type == kWeld && near(q2.objects[0].mods[3].merge, 0.02f));
    }

    {   // 0.10.0: Dissolve Edges, Limited Dissolve, Separate Selection
        // helper: nx x ny grid of quads on z = 0 (CCW seen from +Z), 1 unit cells
        auto grid = [](int nx, int ny) {
            Mesh g;
            for (int y = 0; y <= ny; ++y) for (int x = 0; x <= nx; ++x) g.v.push_back({(float)x, (float)y, 0});
            for (int y = 0; y < ny; ++y) for (int x = 0; x < nx; ++x) {
                int a = y * (nx + 1) + x; g.f.push_back({a, a + 1, a + nx + 2, a + nx + 1});
            }
            return g;
        };
        // loop cut a cube, then dissolve the new loop: back to a plain cube (8 verts, 6 faces, volume 8)
        Mesh cu = makeCube(); std::set<Edge> cut;
        assert(loopCut(cu, mkEdge(0, 4), 0.5f, &cut) && cu.v.size() == 12 && cu.f.size() == 10 && cut.size() == 4);
        Mesh d = cu; std::vector<int> made;
        assert(dissolveEdges(d, cut, &made) == 4 && made.size() == 4);
        assert(d.v.size() == 8 && d.f.size() == 6 && closedManifold(d) && near((float)signedVolume(d), 8.f, 1e-4f)); checkOutward(d);
        for (const auto& fc : d.f) assert(fc.size() == 4);
        // boundary edges and edges that are not in the mesh do nothing and leave the mesh untouched
        Mesh pl = makePlane(); Mesh pl0 = pl; assert(dissolveEdges(pl, {mkEdge(0, 1)}) == 0 && sameMesh(pl, pl0));
        assert(dissolveEdges(pl, {mkEdge(0, 2)}) == 0 && sameMesh(pl, pl0));
        // 2x1 strip: dissolving the middle edge gives one 2x1 quad (the two middle vertices were straight, so they go too)
        Mesh st = grid(2, 1); assert(dissolveEdges(st, {mkEdge(1, 4)}) == 1 && st.f.size() == 1 && st.v.size() == 4 && near(faceArea(st, st.f[0]), 2.f));
        // L-shape from a 2x2 grid: dissolving two edges of the L keeps the real corner (not straight) and the area
        Mesh g22 = grid(2, 2);   // cells 0,1 / 2,3 ; vertex 4 is the centre
        Mesh L = g22; assert(dissolveEdges(L, {mkEdge(1, 4), mkEdge(3, 4)}) == 1);   // merges cells 0|1 and 0|2 -> one L polygon of 3 cells... plus keep cell 3
        assert(L.f.size() == 2 && validMesh(L));
        float tot = 0; for (const auto& fc : L.f) tot += faceArea(L, fc); assert(near(tot, 4.f));
        size_t big = 0; for (const auto& fc : L.f) big = std::max(big, fc.size()); assert(big == 6);   // L hexagon: corner kept
        // chain of three cells merges into ONE polygon, not pairs
        Mesh row = grid(3, 1); assert(dissolveEdges(row, {mkEdge(1, 5), mkEdge(2, 6)}) == 1 && row.f.size() == 1 && row.v.size() == 4 && near(faceArea(row, row.f[0]), 3.f));
        // dissolving all four interior edges of a 2x2 grid leaves a single quad (centre vertex disappears)
        Mesh all4 = g22; assert(dissolveEdges(all4, {mkEdge(1, 4), mkEdge(3, 4), mkEdge(4, 5), mkEdge(4, 7)}) == 1 && all4.f.size() == 1 && all4.v.size() == 4 && near(faceArea(all4, all4.f[0]), 4.f));
        // a ring of faces around a hole would leave a polygon with a hole: refused, mesh unchanged
        Mesh g33 = grid(3, 3); Mesh ring = g33;   // dissolve every edge shared by the 8 outer cells -> hole in the middle cell
        std::set<Edge> re = {mkEdge(1, 5), mkEdge(2, 6), mkEdge(4, 5), mkEdge(8, 9), mkEdge(9, 10), mkEdge(6, 10), mkEdge(5, 9), mkEdge(6, 7), mkEdge(10, 11), mkEdge(4, 8), mkEdge(7, 11), mkEdge(8, 12), mkEdge(9, 13), mkEdge(10, 14), mkEdge(11, 15)};
        Mesh before = ring; int nring = dissolveEdges(ring, re);
        assert(nring == 0 ? sameMesh(ring, before) : validMesh(ring));   // either refused or a valid merge, never a broken mesh
        // two faces that walk the shared edge in the SAME direction (inconsistent winding) are not merged
        Mesh wrong; wrong.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}, {2, 0, 0}, {2, 1, 0}}; wrong.f = {{0, 1, 2, 3}, {1, 2, 5, 4}};
        Mesh wrong0 = wrong; assert(dissolveEdges(wrong, {mkEdge(1, 2)}) == 0 && sameMesh(wrong, wrong0));
        // Limited Dissolve: flat 4x4 grid collapses to a single quad
        Mesh g44 = grid(4, 4); assert(limitedDissolve(g44, 5.f) == 1 && g44.f.size() == 1 && g44.v.size() == 4 && near(faceArea(g44, g44.f[0]), 16.f));
        // a cube is not dissolved (90 degree faces), but a coplanar subdivided cube face is
        Mesh c2 = makeCube(); assert(limitedDissolve(c2, 5.f) == 0 && sameMesh(c2, makeCube()));
        Mesh sub = makeCube(); subdivideFaces(sub, {0});   // face 0 -> 4 quads (bottom face), neighbours get extra vertices (n-gons)
        assert(sub.f.size() == 9 && limitedDissolve(sub, 5.f) == 1 && sub.f.size() == 6 && sub.v.size() == 8 && closedManifold(sub) && near((float)signedVolume(sub), 8.f, 1e-4f));
        // angle limit: a slightly bent strip (10 degrees) merges at 15 but not at 5
        float k = 10.f * 0.01745329252f; Mesh bent; bent.v = {{0, 0, 0}, {1, 0, 0}, {1, 1, 0}, {0, 1, 0}, {1 + std::cos(k), 0, std::sin(k)}, {1 + std::cos(k), 1, std::sin(k)}};
        bent.f = {{0, 1, 2, 3}, {1, 4, 5, 2}};
        Mesh b5 = bent; assert(limitedDissolve(b5, 5.f) == 0 && sameMesh(b5, bent));
        Mesh b15 = bent; assert(limitedDissolve(b15, 15.f) == 1 && b15.f.size() == 1);
        // mask: faces outside the mask are never merged
        Mesh gm = grid(2, 1); std::vector<char> only0 = {1, 0}; assert(limitedDissolve(gm, 5.f, &only0) == 0);
        std::vector<char> both = {1, 1}; assert(limitedDissolve(gm, 5.f, &both) == 1);
        assert(limitedDissolve(gm, -1.f) == 0 && limitedDissolve(gm, 181.f) == 0);
        // scene ops: edge mode, face mode (merge faces), vertex mode, undo/redo restores mesh + selection
        {
            Scene s; uint32_t id = addPrimitive(s, 1); assert(setEditMode(s, true));
            for (int i = 0; i < 2; ++i) { setSelectMode(s, 2); selectAllActive(s); assert(subdivideSelected(s)); }   // plane -> 16 quads
            assert(s.find(id)->mesh.f.size() == 16);
            setSelectMode(s, 2); selectAllActive(s);
            const Mesh m0 = s.find(id)->mesh;
            assert(limitedDissolveSelected(s, 5.f) && s.find(id)->mesh.f.size() == 1 && s.find(id)->mesh.v.size() == 4 && s.sel.f.size() == 1 && s.sel.f.count(0));
            assert(!limitedDissolveSelected(s, 5.f));   // nothing left to merge: no undo step
            assert(s.undo() && sameMesh(s.find(id)->mesh, m0) && s.sel.f.size() == 16 && s.redo() && s.find(id)->mesh.f.size() == 1);
            assert(s.undo());
            assert(!limitedDissolveSelected(s, 0.f) && !limitedDissolveSelected(s, 200.f));
            // face mode dissolve edges: two neighbouring faces merge; one face alone does nothing
            s.sel.clearSets(); s.sel.f = {0}; assert(!dissolveSelectedEdges(s));
            int fa = -1, fb = -1; Edge shared = {-1, -1};   // find two faces that share an edge
            { auto efm = detail::edgeFaces(s.find(id)->mesh); for (const auto& kv : efm) if (kv.second.size() == 2) { fa = kv.second[0]; fb = kv.second[1]; shared = kv.first; break; } }
            assert(fa >= 0);
            s.sel.f = {fa, fb}; assert(dissolveSelectedEdges(s) && s.find(id)->mesh.f.size() == 15 && s.sel.f.size() == 1);
            // edge mode: the picked edge between two faces
            assert(s.undo()); setSelectMode(s, 1); s.sel.clearSets();
            s.sel.e = {shared};
            assert(dissolveSelectedEdges(s) && s.find(id)->mesh.f.size() == 15 && s.sel.f.empty() && s.sel.e.size() >= 4);
            assert(s.undo() && s.find(id)->mesh.f.size() == 16);
            // outside edit mode: refused
            setEditMode(s, false); assert(!dissolveSelectedEdges(s) && !limitedDissolveSelected(s, 5.f));
        }
        // Separate: a cube with an extruded top face; separate the extrusion's faces into a new object
        {
            Scene s; uint32_t id = addPrimitive(s, 0); s.find(id)->pos[0] = 3.f; s.find(id)->scale[2] = 2.f; addModifier(s, kTriangulate);
            assert(setEditMode(s, true)); setSelectMode(s, 2);
            s.sel.f = {0, 1, 2, 3, 4, 5}; assert(separateSelected(s) == 0);   // everything selected: refused
            s.sel.clearSets(); assert(separateSelected(s) == 0);              // nothing selected: refused
            s.sel.f = {1}; const Mesh m0 = s.find(id)->mesh; const size_t nobj = s.objects.size();
            uint32_t nid = separateSelected(s);
            assert(nid != 0 && nid != id && s.objects.size() == nobj + 1 && s.selected == nid && !s.editMode);
            const Object* a = s.find(id); const Object* b = s.find(nid);
            assert(a->mesh.f.size() == 5 && a->mesh.v.size() == 8 && b->mesh.f.size() == 1 && b->mesh.v.size() == 4 && validMesh(a->mesh) && validMesh(b->mesh));
            assert(b->name != a->name && near(b->pos[0], 3.f) && near(b->scale[2], 2.f) && b->mods.size() == 1);   // same transform and modifiers
            assert(near(faceArea(b->mesh, b->mesh.f[0]), 4.f));
            assert(s.undo() && s.objects.size() == nobj && s.find(nid) == nullptr && sameMesh(s.find(id)->mesh, m0) && s.editMode && s.selected == id && s.sel.f.count(1));
            assert(s.redo() && s.objects.size() == nobj + 1 && s.selected == nid && s.find(nid)->mesh.f.size() == 1);
            // vertex mode: only fully covered faces move
            assert(s.undo()); setSelectMode(s, 0); s.sel.clearSets(); for (int vi : s.find(id)->mesh.f[1]) s.sel.v.insert(vi);
            assert(separateSelected(s) != 0 && s.objects.size() == nobj + 1);
            // project round trip with the separated object
            assert(saveProject(s, "/tmp/atlas_t10.atlas")); Scene q; assert(loadProject(q, "/tmp/atlas_t10.atlas") && q.objects.size() == nobj + 1);
        }
    }
    {   // 0.11.0: Smooth, Simple Deform, Planar Decimate, project format v5
        // --- Smooth ---
        Modifier sm; sm.type = kSmooth; sm.factor = 0.5f; sm.iterations = 1;
        Mesh cu = makeCube(); Mesh s1 = applyModifier(cu, sm);
        assert(s1.v.size() == 8 && s1.f == cu.f && near(s1.v[6].x, 2.f / 3.f) && near(s1.v[6].y, 2.f / 3.f) && near(s1.v[6].z, 2.f / 3.f));   // corner moves halfway to the mean of its 3 neighbours
        assert(near(s1.v[0].x, -2.f / 3.f));
        assert(sameMesh(cu, makeCube()));   // input untouched
        Modifier s2m = sm; s2m.iterations = 2; Mesh s2 = applyModifier(cu, s2m); Mesh s11 = applyModifier(s1, sm);
        for (size_t i = 0; i < s2.v.size(); ++i) assert(near(s2.v[i].x, s11.v[i].x) && near(s2.v[i].y, s11.v[i].y) && near(s2.v[i].z, s11.v[i].z));   // 2 passes = 2 applications
        Modifier s0 = sm; s0.factor = 0.f; assert(sameMesh(applyModifier(cu, s0), cu));
        Modifier sf = sm; sf.factor = 1.f; Mesh sf1 = applyModifier(cu, sf); assert(near(sf1.v[6].x, 1.f / 3.f) && near(sf1.v[6].z, 1.f / 3.f));
        assert(signedVolume(s1) > 0 && signedVolume(s1) < signedVolume(cu) && closedManifold(s1));
        // a flat grid stays flat; a bump relaxes towards its neighbours
        Mesh flat; for (int y = 0; y < 5; ++y) for (int x = 0; x < 5; ++x) flat.v.push_back({(float)x, (float)y, 0});
        for (int y = 0; y < 4; ++y) for (int x = 0; x < 4; ++x) { int a = y * 5 + x; flat.f.push_back({a, a + 1, a + 6, a + 5}); }
        Mesh bump = flat; bump.v[12].z = 1.f; Mesh sb = applyModifier(bump, sm);
        assert(sb.v[12].z < 1.f && sb.v[12].z > 0.f && sb.v[7].z > 0.f && sb.v[11].z > 0.f);
        Mesh sflat = applyModifier(flat, sm); for (const auto& p : sflat.v) assert(near(p.z, 0.f));
        Mesh iso; iso.v = {{0, 0, 0}, {1, 0, 0}, {0, 1, 0}, {5, 5, 5}}; iso.f = {{0, 1, 2}}; Mesh isoS = applyModifier(iso, sm); assert(isoS.v[3].x == 5.f && isoS.v[3].y == 5.f && isoS.v[3].z == 5.f);   // vertex with no edges does not move
        // --- Simple Deform ---
        Mesh bar; bar.v = {{-0.5f, -0.5f, 0}, {0.5f, -0.5f, 0}, {0.5f, 0.5f, 0}, {-0.5f, 0.5f, 0}, {-0.5f, -0.5f, 4}, {0.5f, -0.5f, 4}, {0.5f, 0.5f, 4}, {-0.5f, 0.5f, 4}};
        bar.f = makeCube().f;
        Modifier tw; tw.type = kSimpleDeform; tw.mode = kTwist; tw.axis = 2; tw.angle = 90.f;
        Mesh bt = applyModifier(bar, tw);
        for (int i = 0; i < 4; ++i) assert(near(bt.v[i].x, bar.v[i].x) && near(bt.v[i].y, bar.v[i].y) && near(bt.v[i].z, bar.v[i].z));   // low end fixed
        assert(near(bt.v[4].x, 0.5f) && near(bt.v[4].y, -0.5f) && near(bt.v[4].z, 4.f));   // (-.5,-.5) rotated 90 deg -> (.5,-.5)
        for (size_t i = 0; i < bt.v.size(); ++i) assert(near(std::sqrt(bt.v[i].x * bt.v[i].x + bt.v[i].y * bt.v[i].y), std::sqrt(bar.v[i].x * bar.v[i].x + bar.v[i].y * bar.v[i].y)) && near(bt.v[i].z, bar.v[i].z));
        Modifier tw0 = tw; tw0.angle = 0.f; assert(sameMesh(applyModifier(bar, tw0), bar));
        // twist about X uses the X extent: a bar along X with its low end fixed
        Mesh barX; for (auto p : bar.v) barX.v.push_back({p.z, p.x, p.y}); barX.f = bar.f;
        Modifier twx = tw; twx.axis = 0; Mesh btx = applyModifier(barX, twx); assert(near(btx.v[0].y, barX.v[0].y) && near(btx.v[4].x, 4.f) && near(std::sqrt(btx.v[4].y * btx.v[4].y + btx.v[4].z * btx.v[4].z), std::sqrt(0.5f)));
        // bend: neutral line (x = 0) of a straight bar bent 90 degrees ends on the arc of radius L / (pi/2)
        Mesh line; line.v = {{0, 0, 0}, {0, 0, 1}, {0, 0, 2}, {0, 0, 4}, {1, 0, 4}}; line.f = {{0, 1, 2}};
        Modifier bd; bd.type = kSimpleDeform; bd.mode = kBend; bd.axis = 2; bd.angle = 90.f; Mesh bb = applyModifier(line, bd);
        const float R = 4.f / (3.14159265f / 2.f);
        assert(near(bb.v[0].x, 0.f) && near(bb.v[0].z, 0.f) && near(bb.v[3].x, R, 1e-3f) && near(bb.v[3].z, R, 1e-3f));   // end of the neutral axis: (R, R)
        for (int i = 0; i < 4; ++i) {   // every neutral-axis point lies on the circle of radius R around (x = R, z = 0)
            const float dx = bb.v[i].x - R; assert(near(std::sqrt(dx * dx + bb.v[i].z * bb.v[i].z), R, 1e-3f));
        }
        // arc length preserved on the neutral axis (segment 0 -> 1 is ~1 long for a 90 degree total bend)
        { Vec3 a = bb.v[0], b2 = bb.v[1]; float chord = length(b2 - a); assert(chord > 0.9f && chord < 1.0f); }
        // a point offset towards the inside of the bend (x = +1 at the end) lands at radius R - 1 from the centre of curvature (R, 0 side)
        { const float rr = R - 1.f, th = 3.14159265f / 2.f; assert(near(bb.v[4].x, R - rr * std::cos(th), 1e-3f) && near(bb.v[4].z, rr * std::sin(th), 1e-3f)); }
        Modifier bd0 = bd; bd0.angle = 0.f; assert(sameMesh(applyModifier(line, bd0), line));
        // taper: low end unchanged, high end scaled by 1 + factor
        Modifier tp; tp.type = kSimpleDeform; tp.mode = kTaper; tp.axis = 2; tp.factor = -0.5f; Mesh tpm = applyModifier(bar, tp);
        assert(near(tpm.v[0].x, -0.5f) && near(tpm.v[4].x, -0.25f) && near(tpm.v[4].y, -0.25f) && near(tpm.v[4].z, 4.f));
        tp.factor = -3.f; Mesh tpz = applyModifier(bar, tp); assert(near(tpz.v[4].x, 0.f) && near(tpz.v[4].y, 0.f));   // never mirrors through the axis
        // stretch: volume preserved for a box, length grows by (1 + factor) about the middle
        Modifier stc; stc.type = kSimpleDeform; stc.mode = kStretch; stc.axis = 2; stc.factor = 1.f; Mesh stm = applyModifier(bar, stc);
        assert(near(stm.v[4].z - stm.v[0].z, 8.f) && near(stm.v[0].z, -2.f) && near(std::fabs(stm.v[0].x), 0.5f / std::sqrt(2.f)));
        assert(near((float)signedVolume(stm), (float)signedVolume(bar), 1e-3f));
        // flat mesh along the axis (zero extent) is left alone
        Mesh pl = makePlane(); assert(sameMesh(applyModifier(pl, tw), pl));
        // --- Planar Decimate ---
        Modifier pd; pd.type = kPlanarDecimate; pd.angle = 5.f;
        Mesh sub = makeCube(); subdivideFaces(sub, {0, 1, 2, 3, 4, 5});   // 24 quads on the cube
        assert(sub.f.size() == 24); Mesh dec = applyModifier(sub, pd);
        assert(dec.f.size() == 6 && dec.v.size() == 8 && closedManifold(dec) && near((float)signedVolume(dec), 8.f, 1e-4f));
        Mesh sph = makeUVSphere(); Mesh sd = applyModifier(sph, pd);   // curved surface: only the two nearly flat polar caps (16 triangles each) merge into a 16-gon
        assert(sd.f.size() == sph.f.size() - 30 && sd.v.size() == sph.v.size() - 2 && closedManifold(sd) && validMesh(sd));
        { size_t gon = 0; for (const auto& fc : sd.f) if (fc.size() == 16) ++gon; assert(gon == 2); }
        Modifier pdBig = pd; pdBig.angle = 180.f; Mesh whole = applyModifier(makeCube(), pdBig); assert(sameMesh(whole, makeCube()));   // a closed group has no outline: refused, mesh untouched
        Modifier pd0 = pd; pd0.angle = 0.f; assert(!validModifier(pd0)); pd0.angle = 181.f; assert(!validModifier(pd0));
        // --- validation of the new fields ---
        Modifier bad = sm; bad.factor = 1.5f; assert(!validModifier(bad)); bad = sm; bad.factor = -0.1f; assert(!validModifier(bad));
        bad = sm; bad.iterations = 0; assert(!validModifier(bad)); bad.iterations = 33; assert(!validModifier(bad));
        bad = tw; bad.mode = 4; assert(!validModifier(bad)); bad = tw; bad.angle = std::numeric_limits<float>::quiet_NaN(); assert(!validModifier(bad));
        bad = tw; bad.angle = 4000.f; assert(!validModifier(bad)); bad = tw; bad.type = 9; assert(!validModifier(bad));
        // --- scene: add, defaults, edit, stack, apply, undo ---
        Scene c; uint32_t id = addPrimitive(c, 0);
        assert(addModifier(c, kSmooth) && addModifier(c, kSimpleDeform) && addModifier(c, kPlanarDecimate) && !addModifier(c, 9));
        const auto& md = c.find(id)->mods;
        assert(md[0].type == kSmooth && near(md[0].factor, 0.5f) && md[0].iterations == 1);
        assert(md[1].type == kSimpleDeform && md[1].mode == kTwist && md[1].axis == 2 && near(md[1].angle, 45.f));
        assert(md[2].type == kPlanarDecimate && near(md[2].angle, 5.f));
        Modifier e = md[0]; e.iterations = 3; assert(setModifier(c, 0, e) && c.find(id)->mods[0].iterations == 3 && !setModifier(c, 0, e));   // second identical set is a no-op
        e.factor = 2.f; assert(!setModifier(c, 0, e));
        Modifier e1 = c.find(id)->mods[1]; e1.mode = kBend; e1.angle = 30.f; assert(setModifier(c, 1, e1) && c.find(id)->mods[1].mode == kBend);
        const Mesh shown = displayMesh(*c.find(id)); assert(shown.v.size() == 8 && !sameMesh(shown, c.find(id)->mesh));
        assert(c.undo() && c.find(id)->mods[1].mode == kTwist);
        assert(c.redo());
        // apply bakes smooth into the mesh
        assert(applyModifierAt(c, 0) && c.find(id)->mods.size() == 2 && near(c.find(id)->mesh.v[6].x, 8.f / 27.f) && near(c.find(id)->mesh.v[0].z, -8.f / 27.f));   // 3 passes: corner * (2/3)^3
        assert(c.undo() && c.find(id)->mods.size() == 3);
        // --- project format v5 round trip and v4 compatibility ---
        { Modifier r = c.find(id)->mods[1]; r.axis = 1; r.angle = -37.5f; r.factor = 0.25f; r.mode = kStretch; assert(setModifier(c, 1, r)); }
        assert(saveProject(c, "/tmp/atlas_t11.atlas")); Scene q; assert(loadProject(q, "/tmp/atlas_t11.atlas") && q.objects[0].mods.size() == 3);
        const auto& qm = q.objects[0].mods;
        assert(qm[0].type == kSmooth && qm[0].iterations == 3 && qm[1].type == kSimpleDeform && qm[1].mode == kStretch && qm[1].axis == 1 && near(qm[1].angle, -37.5f) && near(qm[1].factor, 0.25f) && qm[2].type == kPlanarDecimate && near(qm[2].angle, 5.f));
        {   // a v4 file (no new columns) still loads with defaults
            FILE* f = fopen("/tmp/atlas_v4.atlas", "w");
            fputs("ATLAS 4\nnext 2\nobject 1 Cube 0 0 0 0 0 0 1 1 1 4 1\nv -1 -1 0\nv 1 -1 0\nv 1 1 0\nv -1 1 0\nf 4 0 1 2 3\nmods 1\nmod 3 1 0 0.001 2 1 0 0 1 0.2 -1\nend\n", f); fclose(f);
            Scene o; assert(loadProject(o, "/tmp/atlas_v4.atlas") && o.objects[0].mods.size() == 1 && o.objects[0].mods[0].type == kSolidify && near(o.objects[0].mods[0].thickness, 0.2f) && o.objects[0].mods[0].iterations == 1);
        }
        {   // corrupt / out of range v5 records are rejected without touching the open scene
            Scene keep; addPrimitive(keep, 0); const size_t n = keep.objects.size();
            FILE* f = fopen("/tmp/atlas_bad5.atlas", "w");
            fputs("ATLAS 5\nnext 2\nobject 1 Cube 0 0 0 0 0 0 1 1 1 4 1\nv -1 -1 0\nv 1 -1 0\nv 1 1 0\nv -1 1 0\nf 4 0 1 2 3\nmods 1\nmod 6 1 0 0.001 2 1 0 0 1 0.1 -1 5 1 0 45\nend\n", f); fclose(f);   // smooth with factor 5
            assert(!loadProject(keep, "/tmp/atlas_bad5.atlas") && keep.objects.size() == n);
            f = fopen("/tmp/atlas_bad5b.atlas", "w");
            fputs("ATLAS 5\nnext 2\nobject 1 Cube 0 0 0 0 0 0 1 1 1 4 1\nv -1 -1 0\nv 1 -1 0\nv 1 1 0\nv -1 1 0\nf 4 0 1 2 3\nmods 1\nmod 7 1 2 0.001 2 1 0 0 1 0.1 -1 0.5\nend\n", f); fclose(f);   // truncated record
            assert(!loadProject(keep, "/tmp/atlas_bad5b.atlas") && keep.objects.size() == n);
        }
    }

    puts("all tests passed"); return 0;
}
