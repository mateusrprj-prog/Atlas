// Polygon mesh (indexed faces, any vertex count >= 3) and modeling operations. Z-up, CCW = outward.
#pragma once
#include <algorithm>
#include <cmath>
#include <map>
#include <set>
#include <utility>
#include <vector>
#include "math3.hpp"

namespace atlas {

struct Mesh {
    std::vector<Vec3> v;
    std::vector<std::vector<int>> f;
};

using Edge = std::pair<int, int>;  // always (min, max)
inline Edge mkEdge(int a, int b) { return {std::min(a, b), std::max(a, b)}; }

inline bool sameMesh(const Mesh& a, const Mesh& b) {
    if (a.v.size() != b.v.size() || a.f != b.f) return false;
    for (size_t i = 0; i < a.v.size(); ++i)
        if (a.v[i].x != b.v[i].x || a.v[i].y != b.v[i].y || a.v[i].z != b.v[i].z) return false;
    return true;
}

inline bool validMesh(const Mesh& m) {
    for (const auto& fc : m.f) {
        if (fc.size() < 3) return false;
        for (int i : fc) if (i < 0 || i >= (int)m.v.size()) return false;
    }
    return true;
}

// Newell's method: robust normal for any planar-ish polygon.
inline Vec3 faceNormal(const Mesh& m, const std::vector<int>& face) {
    Vec3 n; size_t k = face.size();
    for (size_t i = 0; i < k; ++i) {
        const Vec3& a = m.v[face[i]]; const Vec3& b = m.v[face[(i + 1) % k]];
        n.x += (a.y - b.y) * (a.z + b.z);
        n.y += (a.z - b.z) * (a.x + b.x);
        n.z += (a.x - b.x) * (a.y + b.y);
    }
    return normalized(n);
}

// ---------- primitives (default size like a 2 m cube) ----------
inline Mesh makeCube() {
    Mesh m;
    for (int z = 0; z < 2; ++z) {
        const float zz = z ? 1.f : -1.f;
        m.v.push_back({-1, -1, zz}); m.v.push_back({1, -1, zz});
        m.v.push_back({1, 1, zz}); m.v.push_back({-1, 1, zz});
    }
    m.f = {{0, 3, 2, 1}, {4, 5, 6, 7}, {0, 1, 5, 4}, {3, 7, 6, 2}, {0, 4, 7, 3}, {1, 2, 6, 5}};
    return m;
}
inline Mesh makePlane() {
    Mesh m; m.v = {{-1, -1, 0}, {1, -1, 0}, {1, 1, 0}, {-1, 1, 0}}; m.f = {{0, 1, 2, 3}}; return m;
}
inline Mesh makeCylinder(int n = 16) {
    Mesh m;
    for (int i = 0; i < n; ++i) { float a = 6.2831853f * i / n; m.v.push_back({std::cos(a), std::sin(a), -1}); }
    for (int i = 0; i < n; ++i) { float a = 6.2831853f * i / n; m.v.push_back({std::cos(a), std::sin(a), 1}); }
    for (int i = 0; i < n; ++i) { int j = (i + 1) % n; m.f.push_back({i, j, n + j, n + i}); }
    std::vector<int> top, bot;
    for (int i = 0; i < n; ++i) top.push_back(n + i);
    for (int i = n - 1; i >= 0; --i) bot.push_back(i);
    m.f.push_back(top); m.f.push_back(bot);
    return m;
}
inline Mesh makeUVSphere(int seg = 16, int rings = 8) {
    Mesh m;
    m.v.push_back({0, 0, 1});
    for (int k = 1; k < rings; ++k) {
        float th = 3.14159265f * k / rings, z = std::cos(th), r = std::sin(th);
        for (int j = 0; j < seg; ++j) { float ph = 6.2831853f * j / seg; m.v.push_back({r * std::cos(ph), r * std::sin(ph), z}); }
    }
    const int bottom = (int)m.v.size(); m.v.push_back({0, 0, -1});
    auto ring = [&](int k, int j) { return 1 + (k - 1) * seg + (j % seg); };
    for (int j = 0; j < seg; ++j) m.f.push_back({0, ring(1, j), ring(1, j + 1)});
    for (int k = 1; k < rings - 1; ++k)
        for (int j = 0; j < seg; ++j) m.f.push_back({ring(k, j), ring(k + 1, j), ring(k + 1, j + 1), ring(k, j + 1)});
    for (int j = 0; j < seg; ++j) m.f.push_back({bottom, ring(rings - 1, j + 1), ring(rings - 1, j)});
    return m;
}
inline Mesh makePrimitive(int kind) {
    switch (kind) { case 1: return makePlane(); case 2: return makeCylinder(); case 3: return makeUVSphere(); default: return makeCube(); }
}
inline const char* primitiveName(int kind) {
    switch (kind) { case 1: return "Plane"; case 2: return "Cylinder"; case 3: return "Sphere"; default: return "Cube"; }
}

// ---------- queries ----------
inline bool rayTriangle(Vec3 o, Vec3 d, Vec3 a, Vec3 b, Vec3 c, float& t) {
    Vec3 e1 = b - a, e2 = c - a, p = cross(d, e2);
    float det = dot(e1, p);
    if (std::fabs(det) < 1e-12f) return false;
    float inv = 1.f / det; Vec3 s = o - a;
    float u = dot(s, p) * inv; if (u < 0 || u > 1) return false;
    Vec3 q = cross(s, e1);
    float v = dot(d, q) * inv; if (v < 0 || u + v > 1) return false;
    t = dot(e2, q) * inv; return t >= 0;
}
// Nearest face hit (fan triangulation). Returns face index or -1.
inline int pickFace(const Mesh& m, Vec3 o, Vec3 d, float* tOut = nullptr) {
    int best = -1; float bt = 1e30f;
    for (size_t fi = 0; fi < m.f.size(); ++fi) {
        const auto& fc = m.f[fi];
        for (size_t i = 1; i + 1 < fc.size(); ++i) {
            float t;
            if (rayTriangle(o, d, m.v[fc[0]], m.v[fc[i]], m.v[fc[i + 1]], t) && t < bt) { bt = t; best = (int)fi; }
        }
    }
    if (tOut) *tOut = bt;
    return best;
}
inline std::vector<std::pair<int, int>> uniqueEdges(const Mesh& m) {
    std::vector<std::pair<int, int>> e;
    for (const auto& fc : m.f)
        for (size_t i = 0; i < fc.size(); ++i) {
            int a = fc[i], b = fc[(i + 1) % fc.size()];
            e.push_back({std::min(a, b), std::max(a, b)});
        }
    std::sort(e.begin(), e.end());
    e.erase(std::unique(e.begin(), e.end()), e.end());
    return e;
}

// ---------- modeling operations ----------
// Extrude the selected faces as one region along their (averaged) normals. Selected faces are moved
// to duplicated vertices; side quads are created on the region boundary. Face indices stay valid.
inline bool extrudeFaces(Mesh& m, const std::vector<int>& sel, float dist) {
    if (sel.empty() || std::fabs(dist) < 1e-6f) return false;
    for (int i : sel) if (i < 0 || i >= (int)m.f.size()) return false;
    std::map<std::pair<int, int>, int> cnt;
    std::map<int, Vec3> vn;
    for (int fi : sel) {
        const auto& fc = m.f[fi]; Vec3 n = faceNormal(m, fc);
        for (size_t i = 0; i < fc.size(); ++i) {
            int a = fc[i], b = fc[(i + 1) % fc.size()];
            cnt[{std::min(a, b), std::max(a, b)}]++;
            vn[a] = vn[a] + n;
        }
    }
    std::map<int, int> dup;
    for (auto& kv : vn) {
        Vec3 n = normalized(kv.second);
        dup[kv.first] = (int)m.v.size();
        m.v.push_back(m.v[kv.first] + n * dist);
    }
    std::vector<std::vector<int>> sides;
    for (int fi : sel) {
        const auto& fc = m.f[fi];
        for (size_t i = 0; i < fc.size(); ++i) {
            int a = fc[i], b = fc[(i + 1) % fc.size()];
            if (cnt[{std::min(a, b), std::max(a, b)}] != 1) continue;
            if (dist > 0) sides.push_back({a, b, dup[b], dup[a]});
            else sides.push_back({a, dup[a], dup[b], b});
        }
    }
    for (int fi : sel) for (int& vi : m.f[fi]) vi = dup[vi];
    for (auto& s : sides) m.f.push_back(s);
    return true;
}

// Remove faces and compact unused vertices.
inline bool deleteFaces(Mesh& m, const std::vector<int>& sel) {
    if (sel.empty()) return false;
    std::vector<char> del(m.f.size(), 0);
    for (int i : sel) { if (i < 0 || i >= (int)m.f.size()) return false; del[i] = 1; }
    std::vector<std::vector<int>> nf;
    for (size_t i = 0; i < m.f.size(); ++i) if (!del[i]) nf.push_back(m.f[i]);
    std::vector<int> remap(m.v.size(), -1); std::vector<Vec3> nv;
    for (auto& fc : nf) for (int& vi : fc) {
        if (remap[vi] < 0) { remap[vi] = (int)nv.size(); nv.push_back(m.v[vi]); }
        vi = remap[vi];
    }
    m.v = nv; m.f = nf; return true;
}

// Surface area of a (planar-ish) polygon.
inline float faceArea(const Mesh& m, const std::vector<int>& face) {
    Vec3 n; size_t k = face.size();
    for (size_t i = 0; i < k; ++i) {
        const Vec3& a = m.v[face[i]]; const Vec3& b = m.v[face[(i + 1) % k]];
        n.x += (a.y - b.y) * (a.z + b.z); n.y += (a.z - b.z) * (a.x + b.x); n.z += (a.x - b.x) * (a.y + b.y);
    }
    return 0.5f * length(n);
}

namespace detail {
inline bool uniqueValidFaces(const Mesh& m, const std::vector<int>& in, std::vector<int>& out) {
    out = in; std::sort(out.begin(), out.end()); out.erase(std::unique(out.begin(), out.end()), out.end());
    for (int i : out) if (i < 0 || i >= (int)m.f.size()) return false;
    return !out.empty();
}
}  // namespace detail

// Extrude selected edges into a strip of quads. New vertices move along the averaged normals of the faces
// that touch each selected edge. `newEdges` receives the edges of the extruded copy. Every selected edge
// must belong to at least one face.
inline bool extrudeEdges(Mesh& m, const std::set<Edge>& sel, float dist, std::set<Edge>* newEdges = nullptr) {
    if (sel.empty() || std::fabs(dist) < 1e-6f) return false;
    for (const auto& e : sel) if (e.first < 0 || e.second >= (int)m.v.size() || e.first >= e.second) return false;
    std::map<int, Vec3> vn; std::map<Edge, std::pair<int, int>> dirOf;
    for (const auto& fc : m.f) {
        Vec3 n = faceNormal(m, fc);
        for (size_t i = 0; i < fc.size(); ++i) {
            int a = fc[i], b = fc[(i + 1) % fc.size()]; Edge e = mkEdge(a, b);
            if (!sel.count(e)) continue;
            vn[a] = vn[a] + n; vn[b] = vn[b] + n;
            if (!dirOf.count(e)) dirOf[e] = {a, b};
        }
    }
    if (dirOf.size() != sel.size()) return false;
    std::map<int, int> dup;
    for (auto& kv : vn) {
        Vec3 d = normalized(kv.second); if (length(d) < 0.5f) d = Vec3{0, 0, 1};
        dup[kv.first] = (int)m.v.size(); m.v.push_back(m.v[kv.first] + d * dist);
    }
    std::set<Edge> made;
    for (const auto& kv : dirOf) {
        int a = kv.second.first, b = kv.second.second;
        m.f.push_back({b, a, dup[a], dup[b]});   // shared edge runs opposite to the original face
        made.insert(mkEdge(dup[a], dup[b]));
    }
    if (newEdges) *newEdges = made;
    return true;
}

inline bool deleteVertices(Mesh& m, const std::set<int>& sel) {
    std::vector<int> faces;
    for (size_t fi = 0; fi < m.f.size(); ++fi) for (int vi : m.f[fi]) if (sel.count(vi)) { faces.push_back((int)fi); break; }
    return deleteFaces(m, faces);
}
inline bool deleteEdges(Mesh& m, const std::set<Edge>& sel) {
    std::vector<int> faces;
    for (size_t fi = 0; fi < m.f.size(); ++fi) {
        const auto& fc = m.f[fi];
        for (size_t i = 0; i < fc.size(); ++i) if (sel.count(mkEdge(fc[i], fc[(i + 1) % fc.size()]))) { faces.push_back((int)fi); break; }
    }
    return deleteFaces(m, faces);
}

// Inset each selected face individually: the face shrinks towards its centroid by `amount` (0..1, exclusive)
// and a ring of quads fills the gap. Face indices stay valid (each face becomes its inner face).
inline bool insetFaces(Mesh& m, const std::vector<int>& selIn, float amount) {
    std::vector<int> sel;
    if (!detail::uniqueValidFaces(m, selIn, sel) || !(amount > 1e-6f) || !(amount < 1.f)) return false;
    for (int fi : sel) {
        const std::vector<int> fc = m.f[fi]; const size_t n = fc.size();
        Vec3 c; for (int vi : fc) c = c + m.v[vi]; c = c * (1.f / n);
        std::vector<int> in(n);
        for (size_t i = 0; i < n; ++i) { in[i] = (int)m.v.size(); m.v.push_back(m.v[fc[i]] + (c - m.v[fc[i]]) * amount); }
        for (size_t i = 0; i < n; ++i) { size_t j = (i + 1) % n; m.f.push_back({fc[i], fc[j], in[j], in[i]}); }
        m.f[fi] = in;
    }
    return true;
}

// Split each selected face into quads (edge midpoints + face centre). Neighbouring unselected faces receive
// the new midpoints so the mesh stays watertight (they become n-gons). `created` = all faces that came from
// the selection.
inline bool subdivideFaces(Mesh& m, const std::vector<int>& selIn, std::vector<int>* created = nullptr) {
    std::vector<int> sel;
    if (!detail::uniqueValidFaces(m, selIn, sel)) return false;
    const int origN = (int)m.f.size();
    std::map<Edge, int> mid;
    auto midOf = [&](int a, int b) {
        Edge e = mkEdge(a, b); auto it = mid.find(e); if (it != mid.end()) return it->second;
        int i = (int)m.v.size(); m.v.push_back((m.v[a] + m.v[b]) * 0.5f); mid[e] = i; return i;
    };
    std::vector<char> isSel(origN, 0);
    for (int fi : sel) { isSel[fi] = 1; const auto& fc = m.f[fi]; for (size_t i = 0; i < fc.size(); ++i) midOf(fc[i], fc[(i + 1) % fc.size()]); }
    for (int fi = 0; fi < origN; ++fi) {
        if (isSel[fi]) continue;
        const auto& fc = m.f[fi]; std::vector<int> out;
        for (size_t i = 0; i < fc.size(); ++i) {
            out.push_back(fc[i]);
            auto it = mid.find(mkEdge(fc[i], fc[(i + 1) % fc.size()])); if (it != mid.end()) out.push_back(it->second);
        }
        if (out.size() != fc.size()) m.f[fi] = out;
    }
    std::vector<int> made;
    for (int fi : sel) {
        const std::vector<int> fc = m.f[fi]; const size_t n = fc.size();
        Vec3 c; for (int vi : fc) c = c + m.v[vi]; c = c * (1.f / n);
        int ci = (int)m.v.size(); m.v.push_back(c);
        std::vector<int> mids(n); for (size_t i = 0; i < n; ++i) mids[i] = midOf(fc[i], fc[(i + 1) % n]);
        for (size_t i = 0; i < n; ++i) {
            std::vector<int> q = {fc[i], mids[i], ci, mids[(i + n - 1) % n]};
            if (i == 0) { m.f[fi] = q; made.push_back(fi); } else { m.f.push_back(q); made.push_back((int)m.f.size() - 1); }
        }
    }
    if (created) *created = made;
    return true;
}

// Collapse the selected vertices into one vertex at their centroid. Degenerate faces are removed.
// `merged` receives the index of the resulting vertex (after compaction).
inline bool mergeVerticesAtCenter(Mesh& m, const std::set<int>& sel, int* merged = nullptr) {
    if (sel.size() < 2) return false;
    for (int i : sel) if (i < 0 || i >= (int)m.v.size()) return false;
    Vec3 c; for (int i : sel) c = c + m.v[i]; c = c * (1.f / sel.size());
    const int keep = *sel.begin(); m.v[keep] = c;
    std::vector<int> remap(m.v.size()); for (size_t i = 0; i < remap.size(); ++i) remap[i] = (int)i;
    for (int i : sel) remap[i] = keep;
    std::vector<std::vector<int>> nf;
    for (const auto& fc : m.f) {
        std::vector<int> out;
        for (int vi : fc) { int r = remap[vi]; if (out.empty() || out.back() != r) out.push_back(r); }
        while (out.size() > 1 && out.front() == out.back()) out.pop_back();
        if (out.size() >= 3) nf.push_back(out);
    }
    std::vector<int> compact(m.v.size(), -1); std::vector<Vec3> nv;
    for (auto& fc : nf) for (int& vi : fc) { if (compact[vi] < 0) { compact[vi] = (int)nv.size(); nv.push_back(m.v[vi]); } vi = compact[vi]; }
    if (merged) *merged = compact[keep];
    m.v = nv; m.f = nf; return true;
}

inline bool flipFaces(Mesh& m, const std::vector<int>& selIn) {
    std::vector<int> sel; if (!detail::uniqueValidFaces(m, selIn, sel)) return false;
    for (int fi : sel) std::reverse(m.f[fi].begin(), m.f[fi].end());
    return true;
}

// ---------- edit-mode transforms on a vertex mask (pivot = median point of the masked vertices) ----------
inline bool maskCentroid(const Mesh& m, const std::vector<char>& mask, Vec3* c) {
    Vec3 sum; int n = 0;
    for (size_t i = 0; i < mask.size() && i < m.v.size(); ++i) if (mask[i]) { sum = sum + m.v[i]; ++n; }
    if (!n) return false;
    *c = sum * (1.f / n); return true;
}
inline bool moveVertices(Mesh& m, const std::vector<char>& mask, Vec3 d) {
    bool any = false;
    for (size_t i = 0; i < mask.size() && i < m.v.size(); ++i) if (mask[i]) { m.v[i] = m.v[i] + d; any = true; }
    return any;
}
// Rotate about the local axis (0=X, 1=Y, 2=Z) through the pivot.
inline bool rotateVertices(Mesh& m, const std::vector<char>& mask, int axis, float deg) {
    Vec3 c; if (!maskCentroid(m, mask, &c)) return false;
    float a = deg * 0.01745329252f, cs = std::cos(a), sn = std::sin(a);
    for (size_t i = 0; i < mask.size() && i < m.v.size(); ++i) if (mask[i]) {
        Vec3 p = m.v[i] - c, q = p;
        if (axis == 0) { q.y = p.y * cs - p.z * sn; q.z = p.y * sn + p.z * cs; }
        else if (axis == 1) { q.x = p.x * cs + p.z * sn; q.z = -p.x * sn + p.z * cs; }
        else { q.x = p.x * cs - p.y * sn; q.y = p.x * sn + p.y * cs; }
        m.v[i] = c + q;
    }
    return true;
}
inline bool scaleVertices(Mesh& m, const std::vector<char>& mask, Vec3 k) {
    Vec3 c; if (!maskCentroid(m, mask, &c)) return false;
    for (size_t i = 0; i < mask.size() && i < m.v.size(); ++i) if (mask[i]) {
        Vec3 p = m.v[i] - c; m.v[i] = c + Vec3{p.x * k.x, p.y * k.y, p.z * k.z};
    }
    return true;
}

// ---------- edge rings / loops ----------
namespace detail {
inline std::map<Edge, std::vector<int>> edgeFaces(const Mesh& m) {
    std::map<Edge, std::vector<int>> r;
    for (size_t fi = 0; fi < m.f.size(); ++fi) { const auto& fc = m.f[fi]; for (size_t i = 0; i < fc.size(); ++i) r[mkEdge(fc[i], fc[(i + 1) % fc.size()])].push_back((int)fi); }
    return r;
}
}  // namespace detail

// Loop cut: walks the ring of quads that contains `start` (edges "parallel" across quads) and splits every quad
// of the ring with a new edge loop. `t` (0..1, exclusive) is measured from start.first towards start.second and
// stays consistent along the whole ring. Triangles/n-gons at the end of an open ring receive the midpoints so the
// mesh stays watertight. `newEdges` receives the cut edges.
inline bool loopCut(Mesh& m, Edge start, float t, std::set<Edge>* newEdges = nullptr) {
    if (!(t > 1e-4f) || !(t < 1.f - 1e-4f)) return false;
    auto ef = detail::edgeFaces(m);
    if (!ef.count(start)) return false;
    std::map<Edge, std::pair<int, int>> dir;           // ring edge -> directed (p,q), parallel to start
    std::vector<std::pair<int, int>> todo = {{start.first, start.second}};
    while (!todo.empty()) {
        auto pq = todo.back(); todo.pop_back();
        Edge e = mkEdge(pq.first, pq.second); if (dir.count(e)) continue;
        dir[e] = pq;
        for (int fi : ef[e]) {
            const auto& fc = m.f[fi]; if (fc.size() != 4) continue;
            for (int i = 0; i < 4; ++i) {
                if (mkEdge(fc[i], fc[(i + 1) % 4]) != e) continue;
                int c = fc[(i + 2) % 4], d = fc[(i + 3) % 4];
                todo.push_back(fc[i] == pq.first ? std::make_pair(d, c) : std::make_pair(c, d));
                break;
            }
        }
    }
    std::map<Edge, int> mid;
    for (const auto& kv : dir) {
        const Vec3 &P = m.v[kv.second.first], &Q = m.v[kv.second.second];
        mid[kv.first] = (int)m.v.size(); m.v.push_back(P + (Q - P) * t);
    }
    std::set<Edge> made; const int n0 = (int)m.f.size();
    for (int fi = 0; fi < n0; ++fi) {
        const std::vector<int> fc = m.f[fi]; const size_t n = fc.size();
        std::vector<int> hit; for (size_t i = 0; i < n; ++i) if (mid.count(mkEdge(fc[i], fc[(i + 1) % n]))) hit.push_back((int)i);
        if (hit.empty()) continue;
        if (n == 4 && hit.size() == 2 && hit[1] - hit[0] == 2) {          // split the quad
            int i = hit[0]; int a = fc[i], b = fc[(i + 1) % 4], c = fc[(i + 2) % 4], d = fc[(i + 3) % 4];
            int m1 = mid[mkEdge(a, b)], m2 = mid[mkEdge(c, d)];
            m.f[fi] = {a, m1, m2, d}; m.f.push_back({m1, b, c, m2}); made.insert(mkEdge(m1, m2));
        } else {                                                           // just insert midpoints
            std::vector<int> out;
            for (size_t i = 0; i < n; ++i) { out.push_back(fc[i]); auto it = mid.find(mkEdge(fc[i], fc[(i + 1) % n])); if (it != mid.end()) out.push_back(it->second); }
            m.f[fi] = out;
        }
    }
    if (newEdges) *newEdges = made;
    return !made.empty();
}

// Edge loop through `start`: continues straight through vertices of valence 4 in both directions.
inline std::set<Edge> edgeLoop(const Mesh& m, Edge start) {
    auto ef = detail::edgeFaces(m); std::set<Edge> loop;
    if (!ef.count(start)) return loop;
    std::map<int, std::vector<Edge>> inc;
    for (const auto& kv : ef) { inc[kv.first.first].push_back(kv.first); inc[kv.first.second].push_back(kv.first); }
    auto shareFace = [&](const Edge& x, const Edge& y) { for (int f : ef[x]) for (int g : ef[y]) if (f == g) return true; return false; };
    loop.insert(start);
    for (int dirn = 0; dirn < 2; ++dirn) {
        Edge cur = start; int v = dirn ? start.first : start.second;
        for (;;) {
            auto& list = inc[v]; if (list.size() != 4) break;
            const Edge* next = nullptr;
            for (const auto& e : list) if (e != cur && !shareFace(cur, e)) { next = &e; break; }
            if (!next || loop.count(*next)) break;
            loop.insert(*next); cur = *next; v = cur.first == v ? cur.second : cur.first;
        }
    }
    return loop;
}


// ---------- 0.10.0: dissolve ----------
// Removes vertices no face uses, keeping the order of the rest. Returns how many were removed.
inline int compactUnusedVertices(Mesh& m) {
    std::vector<char> used(m.v.size(), 0);
    for (const auto& fc : m.f) for (int i : fc) used[i] = 1;
    std::vector<int> remap(m.v.size(), -1); std::vector<Vec3> nv;
    for (size_t i = 0; i < m.v.size(); ++i) if (used[i]) { remap[i] = (int)nv.size(); nv.push_back(m.v[i]); }
    const int removed = (int)m.v.size() - (int)nv.size();
    if (removed == 0) return 0;
    for (auto& fc : m.f) for (int& i : fc) i = remap[i];
    m.v = std::move(nv); return removed;
}

namespace detail {
// Direction (a->b) in which `fc` walks the edge {a,b}: +1 if a then b, -1 if b then a, 0 if the face does not have the edge.
inline int edgeDirInFace(const std::vector<int>& fc, int a, int b) {
    const size_t n = fc.size();
    for (size_t i = 0; i < n; ++i) {
        const int p = fc[i], q = fc[(i + 1) % n];
        if (p == a && q == b) return 1;
        if (p == b && q == a) return -1;
    }
    return 0;
}

// Merges the two faces on each given manifold edge (winding must be consistent). Faces chained through several edges
// become ONE polygon. A group whose outline is not a single simple loop is left untouched. Vertex indices never change
// (leftover vertices stay in the mesh). `made` gets the indices (in the final face list) of the merged faces.
// Returns the number of polygons created.
inline int dissolveEdgesCore(Mesh& m, const std::set<Edge>& edges, std::vector<int>* made) {
    auto ef = edgeFaces(m);
    const int nf = (int)m.f.size();
    std::vector<int> par(nf); for (int i = 0; i < nf; ++i) par[i] = i;
    auto root = [&](int x) { while (par[x] != x) { par[x] = par[par[x]]; x = par[x]; } return x; };
    std::vector<char> inGroup(nf, 0);
    for (const Edge& e : edges) {
        auto it = ef.find(e); if (it == ef.end() || it->second.size() != 2) continue;
        const int f1 = it->second[0], f2 = it->second[1]; if (f1 == f2) continue;
        if (edgeDirInFace(m.f[f1], e.first, e.second) * edgeDirInFace(m.f[f2], e.first, e.second) != -1) continue;
        const int a = root(f1), b = root(f2); if (a != b) par[std::max(a, b)] = std::min(a, b);
        inGroup[f1] = inGroup[f2] = 1;
    }
    std::map<int, std::vector<int>> groups;
    for (int i = 0; i < nf; ++i) if (inGroup[i]) groups[root(i)].push_back(i);
    std::vector<char> removed(nf, 0); std::map<int, std::vector<int>> merged;   // representative face -> new polygon
    for (auto& g : groups) {
        const std::vector<int>& fs = g.second; if (fs.size() < 2) continue;
        std::set<std::pair<int, int>> dir;
        for (int fi : fs) { const auto& fc = m.f[fi]; for (size_t i = 0; i < fc.size(); ++i) dir.insert({fc[i], fc[(i + 1) % fc.size()]}); }
        std::map<int, int> next; bool ok = true; size_t bnd = 0;
        for (const auto& d : dir) {
            if (dir.count({d.second, d.first})) continue;       // shared by two faces of the group: interior
            if (next.count(d.first)) { ok = false; break; }     // vertex touched twice by the outline: pinched
            next[d.first] = d.second; ++bnd;
        }
        if (!ok || bnd < 3) continue;
        std::vector<int> poly; const int start = next.begin()->first; int cur = start;
        for (size_t guard = 0; guard <= bnd; ++guard) {
            poly.push_back(cur); auto it = next.find(cur); if (it == next.end()) { ok = false; break; }
            cur = it->second; if (cur == start) break;
        }
        if (!ok || cur != start || poly.size() != bnd) continue;   // more than one loop (hole) or open outline
        merged[fs[0]] = poly;
        for (size_t k = 1; k < fs.size(); ++k) removed[fs[k]] = 1;
    }
    if (merged.empty()) return 0;
    std::vector<std::vector<int>> nfaces;
    for (int i = 0; i < nf; ++i) {
        if (removed[i]) continue;
        auto it = merged.find(i);
        if (it != merged.end()) { if (made) made->push_back((int)nfaces.size()); nfaces.push_back(it->second); }
        else nfaces.push_back(m.f[i]);
    }
    m.f = std::move(nfaces); return (int)merged.size();
}

// Removes vertices flagged in `mask` that have exactly two neighbours and are straight within `cosLimit`
// (cos of the largest allowed bend; -1 = any bend). Faces must keep >= 3 corners; the shortcut edge must be new.
// Vertex indices are not changed. Returns how many vertices were dissolved.
inline int dissolveStraightVerts(Mesh& m, const std::vector<char>& mask, float cosLimit) {
    const int nv = (int)m.v.size();
    std::vector<std::set<int>> nb(nv); std::vector<std::vector<int>> vf(nv); std::set<Edge> es;
    for (size_t fi = 0; fi < m.f.size(); ++fi) {
        const auto& fc = m.f[fi]; const size_t n = fc.size();
        for (size_t i = 0; i < n; ++i) {
            const int a = fc[i], b = fc[(i + 1) % n];
            nb[a].insert(b); nb[b].insert(a); es.insert(mkEdge(a, b)); vf[a].push_back((int)fi);
        }
    }
    int count = 0;
    for (int v = 0; v < nv && v < (int)mask.size(); ++v) {
        if (!mask[v] || nb[v].size() != 2 || vf[v].empty() || vf[v].size() > 2) continue;
        const int a = *nb[v].begin(), b = *nb[v].rbegin();
        if (a == b || es.count(mkEdge(a, b))) continue;
        bool big = true; for (int fi : vf[v]) if (m.f[fi].size() < 4) big = false;
        if (!big) continue;
        const Vec3 d1 = normalized(m.v[v] - m.v[a]), d2 = normalized(m.v[b] - m.v[v]);
        if (dot(d1, d2) < cosLimit) continue;
        for (int fi : vf[v]) { auto& fc = m.f[fi]; fc.erase(std::find(fc.begin(), fc.end(), v)); }
        es.erase(mkEdge(a, v)); es.erase(mkEdge(v, b)); es.insert(mkEdge(a, b));
        nb[a].erase(v); nb[a].insert(b); nb[b].erase(v); nb[b].insert(a); nb[v].clear();
        ++count;
    }
    return count;
}
}  // namespace detail

// Dissolve Edges: merges the faces on each selected edge into one polygon (chains merge into a single face). Edges on a
// boundary, on non-manifold seams or with inconsistent winding are ignored. Vertices left straight (< 1 degree) by the
// merge are removed too. Returns the polygons created (0 = mesh untouched). `made` = merged faces in the new face list.
inline int dissolveEdges(Mesh& m, const std::set<Edge>& edges, std::vector<int>* made = nullptr) {
    Mesh work = m; std::vector<int> mf;
    const int n = detail::dissolveEdgesCore(work, edges, &mf);
    if (n == 0) return 0;
    std::vector<char> mask(work.v.size(), 0);
    for (const Edge& e : edges) { if (e.first >= 0 && e.first < (int)mask.size()) mask[e.first] = 1; if (e.second >= 0 && e.second < (int)mask.size()) mask[e.second] = 1; }
    detail::dissolveStraightVerts(work, mask, std::cos(1.f * 0.01745329252f));
    compactUnusedVertices(work);
    if (!validMesh(work)) return 0;
    m = std::move(work); if (made) *made = mf; return n;
}

// Limited Dissolve: merges neighbouring faces whose normals differ by at most `angleDeg` (only faces flagged in
// `faceMask`, if given) and removes the vertices that end up straight within the same angle. Returns polygons created.
inline int limitedDissolve(Mesh& m, float angleDeg, const std::vector<char>* faceMask = nullptr, std::vector<int>* made = nullptr) {
    if (!std::isfinite(angleDeg) || angleDeg < 0.f || angleDeg > 180.f) return 0;
    const float cosL = std::cos(angleDeg * 0.01745329252f) - 1e-6f;
    auto ef = detail::edgeFaces(m);
    std::vector<Vec3> nrm(m.f.size()); for (size_t i = 0; i < m.f.size(); ++i) nrm[i] = faceNormal(m, m.f[i]);
    std::set<Edge> flat;
    for (const auto& kv : ef) {
        if (kv.second.size() != 2) continue;
        const int a = kv.second[0], b = kv.second[1];
        if (faceMask && (a >= (int)faceMask->size() || b >= (int)faceMask->size() || !(*faceMask)[a] || !(*faceMask)[b])) continue;
        if (length(nrm[a]) < 0.5f || length(nrm[b]) < 0.5f) continue;
        if (dot(nrm[a], nrm[b]) >= cosL) flat.insert(kv.first);
    }
    Mesh work = m; std::vector<int> mf;
    const int n = detail::dissolveEdgesCore(work, flat, &mf);
    if (n == 0) return 0;
    std::vector<char> mask(work.v.size(), 0);
    for (const Edge& e : flat) { mask[e.first] = 1; mask[e.second] = 1; }
    detail::dissolveStraightVerts(work, mask, cosL);
    compactUnusedVertices(work);
    if (!validMesh(work)) return 0;
    // faces keep their order, so `made` (computed before vertex cleanup) is still valid
    m = std::move(work); if (made) *made = mf; return n;
}

// Splits the mesh into the faces in `sel` and the rest. Both parts get their own compact vertex list.
inline bool separateFaces(const Mesh& m, const std::vector<int>& selIn, Mesh& picked, Mesh& rest) {
    std::vector<int> sel; if (!detail::uniqueValidFaces(m, selIn, sel)) return false;
    if (sel.size() >= m.f.size()) return false;                         // nothing would stay behind
    std::vector<char> take(m.f.size(), 0); for (int i : sel) take[i] = 1;
    picked = Mesh(); rest = Mesh();
    auto copyFace = [&](Mesh& out, std::vector<int>& remap, const std::vector<int>& fc) {
        std::vector<int> g; g.reserve(fc.size());
        for (int vi : fc) { if (remap[vi] < 0) { remap[vi] = (int)out.v.size(); out.v.push_back(m.v[vi]); } g.push_back(remap[vi]); }
        out.f.push_back(std::move(g));
    };
    std::vector<int> ra(m.v.size(), -1), rb(m.v.size(), -1);
    for (size_t i = 0; i < m.f.size(); ++i) { if (take[i]) copyFace(picked, ra, m.f[i]); else copyFace(rest, rb, m.f[i]); }
    return true;
}

}  // namespace atlas
